buildscript {

    repositories {
        google()
        gradlePluginPortal()
        mavenCentral()
    }

    dependencies {
        classpath(BuildPlugins.android)
        //classpath(BuildPlugins.kotlin)
        classpath(BuildPlugins.ksp)
        classpath(BuildPlugins.hilt)
        classpath(BuildPlugins.navigation)
        classpath(BuildPlugins.gradleVersion)
        classpath("org.sonarsource.scanner.gradle:sonarqube-gradle-plugin:3.3")

        if (gradle.startParameter.taskRequests.toString().contains("Intune")) {
            classpath("org.javassist:javassist:3.27.0-GA")
            classpath(files("app/MAMSDK/com.microsoft.intune.mam.build.jar"))
        }
    }
}

allprojects {
    repositories {
        google()
        jcenter()
        maven {
            url = uri("https://maven.google.com")
        }
        mavenCentral()
        maven {
            url = uri("https://pkgs.dev.azure.com/MicrosoftDeviceSDK/DuoSDK-Public/_packaging/Duo-SDK-Feed/maven/v1")
            name = "Duo-SDK-Feed"
        }
        maven {
            url = uri("https://jitpack.io")
        }
        flatDir {
            dirs("libs")
        }
    }
}

tasks.register("clean", Delete::class) {
    delete(rootProject.buildDir)
}

//task scanAssembleRelease(type: GradleBuild) {
//    tasks = ['sonarqube', 'bundleRelease', 'assembleRelease']
//}