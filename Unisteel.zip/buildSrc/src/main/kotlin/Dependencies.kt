/** To define plugins */
object BuildPlugins {
    val android by lazy { "com.android.tools.build:gradle:${Versions.gradlePlugin}" }
    //val kotlin by lazy { "org.jetbrains.kotlin:kotlin-gradle-plugin:${Versions.kotlin}" }
    val ksp by lazy {
        "com.google.devtools.ksp:com.google.devtools.ksp.gradle.plugin:${Versions.ksp}"
    }
    val hilt by lazy { "com.google.dagger:hilt-android-gradle-plugin:${Versions.hilt}" }
    val navigation by lazy {
        "androidx.navigation:navigation-safe-args-gradle-plugin:${Versions.navigation}"
    }
    val gradleVersion by lazy {
        "com.github.ben-manes:gradle-versions-plugin:${Versions.gradleVersion}"
    }
}

/** To define dependencies */
object Deps {
//    val kotlinStdLib by lazy { "org.jetbrains.kotlin:kotlin-stdlib-jdk8:${Versions.kotlin}" }

    object Hilt {
        val android by lazy { "com.google.dagger:hilt-android:${Versions.hilt}" }
        val compiler by lazy { "com.google.dagger:hilt-compiler:${Versions.hilt}" }
    }

    object Coroutines {
        val core by lazy { "org.jetbrains.kotlinx:kotlinx-coroutines-core:${Versions.coroutines}" }
        val android by lazy {
            "org.jetbrains.kotlinx:kotlinx-coroutines-android:${Versions.coroutines}"
        }
    }

    object Lifecycle {
        val viewModel by lazy { "androidx.lifecycle:lifecycle-viewmodel-ktx:${Versions.lifecycle}" }
        val liveData by lazy { "androidx.lifecycle:lifecycle-livedata-ktx:${Versions.lifecycle}" }
        val common by lazy { "androidx.lifecycle:lifecycle-common-java8:${Versions.lifecycle}" }
    }

    val appCompat by lazy { "androidx.appcompat:appcompat:${Versions.appCompat}" }
    val timber by lazy { "com.jakewharton.timber:timber:${Versions.timber}" }
    val constraintLayout by lazy {
        "androidx.constraintlayout:constraintlayout:${Versions.constraintLayout}"
    }

    object Room {
        val runtime by lazy { "androidx.room:room-runtime:${Versions.room}" }
        val ktx by lazy { "androidx.room:room-ktx:${Versions.room}" }
        val compiler by lazy { "androidx.room:room-compiler:${Versions.room}" }
    }

    object Navigation {
        val fragment by lazy {
            "androidx.navigation:navigation-fragment-ktx:${Versions.navigation}"
        }
        val ui by lazy { "androidx.navigation:navigation-ui-ktx:${Versions.navigation}" }
    }

    object AppCenter {
        val analytics by lazy {
            "com.microsoft.appcenter:appcenter-analytics:${Versions.appCenter}"
        }
        val crashes by lazy { "com.microsoft.appcenter:appcenter-crashes:${Versions.appCenter}" }
    }

    object Retrofit2 {
        val retrofit by lazy { "com.squareup.retrofit2:retrofit:${Versions.retrofit2}" }
        val gson by lazy { "com.squareup.retrofit2:converter-gson:${Versions.retrofit2}" }
        val logging by lazy { "com.squareup.okhttp3:logging-interceptor:4.10.0" }
    }

    val msal by lazy { "com.microsoft.identity.client:msal:${Versions.msal}" }

    val passCodeView by lazy { "com.hanks:passcodeview:${Versions.passCodeView}" }

    val zxing by lazy { "com.journeyapps:zxing-android-embedded:${Versions.zxing}" }

    object AndroidX {
        val core by lazy { "androidx.core:core-ktx:${Versions.coreKtx}" }
        val fragment by lazy { "androidx.fragment:fragment-ktx:${Versions.fragmentKtx}" }
    }

    object Aar {
        val dataCollection by lazy { "libs/DataCollection.aar" }
    }

    val securityCrypto by lazy { "androidx.security:security-crypto:${Versions.securityCrypto}" }
}
