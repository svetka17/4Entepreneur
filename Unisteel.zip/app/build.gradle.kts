import com.github.benmanes.gradle.versions.updates.DependencyUpdatesTask

plugins {
    id("com.android.application")
    kotlin("android")
    kotlin("kapt")
    id("dagger.hilt.android.plugin")
    id("kotlin-parcelize")
    id("androidx.navigation.safeargs.kotlin")
    id("com.google.devtools.ksp")
    id("com.github.ben-manes.versions")
    id("org.sonarqube")
}

if (gradle.startParameter.taskRequests.toString().contains("Intune")) {
    apply(plugin = "com.microsoft.intune.mam")
}

android {

    compileSdk = ConfigData.compileSdkVersion
    buildToolsVersion = ConfigData.buildToolsVersion

    defaultConfig {
        applicationId  = "com.sytecs.unisteel"
        minSdk = ConfigData.minSdkVersion
        targetSdk = ConfigData.targetSdkVersion
        versionCode = ConfigData.versionCode
        versionName = ConfigData.versionName
        signingConfig = signingConfigs.getByName("debug")
    }

    buildFeatures {
        dataBinding = true
        viewBinding = true
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("keystore.jks")
            storePassword = "!1symbol"
            keyAlias = "sytecs"
            keyPassword = "!1symbol"
        }
        create("release") {
            storeFile = file("keystore.jks")
            storePassword = "!1symbol"
            keyAlias = "sytecs"
            keyPassword = "!1symbol"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile> {
        kotlinOptions {
            jvmTarget = "11"
        }
    }

    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            isDebuggable = false
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
            isDebuggable = true
            isMinifyEnabled = false
        }
    }

    flavorDimensions.add("version")

    productFlavors {
        create("default") {
            isDefault = true
            dimension = "version"
        }
        create("intune") {
            dimension = "version"
//            versionNameSuffix = "-intune"
        }
    }

    lint {
        abortOnError = false
    }

}

dependencies {

    if (gradle.startParameter.taskRequests.toString().contains("Intune")) {
        implementation(files("MAMSDK/Microsoft.Intune.MAM.SDK.aar"))
    }

//    implementation(Deps.kotlinStdLib)

    implementation(Deps.appCompat)
    implementation(Deps.AndroidX.core)
    implementation(Deps.AndroidX.fragment)
    implementation(Deps.constraintLayout)

    //Msal
    implementation(Deps.msal)

    //Retrofit
    implementation(Deps.Retrofit2.retrofit)
    implementation(Deps.Retrofit2.gson)
    implementation(Deps.Retrofit2.logging)

    //Lifecycle
    implementation(Deps.Lifecycle.common)
    implementation(Deps.Lifecycle.liveData)
    implementation(Deps.Lifecycle.viewModel)

    //Kotlin Coroutines
    implementation(Deps.Coroutines.core)
    implementation(Deps.Coroutines.android)

    //Hilt
    implementation(Deps.Hilt.android)
    kapt(Deps.Hilt.compiler)

    //Room
    implementation(Deps.Room.runtime)
    implementation(Deps.Room.ktx)
    ksp(Deps.Room.compiler)

    //Navigation
    implementation(Deps.Navigation.fragment)
    implementation(Deps.Navigation.ui)

    //Timber
    implementation(Deps.timber)

    //AppCenter MS
    implementation(Deps.AppCenter.analytics)
    implementation(Deps.AppCenter.crashes)

    //Honeywell scanner
    implementation(files(Deps.Aar.dataCollection))

    implementation(Deps.zxing)
    implementation(Deps.passCodeView)
    implementation(Deps.securityCrypto)
}

fun isNonStable(version: String): Boolean {
    val stableKeyword = listOf("RELEASE", "FINAL", "GA").any { version.toUpperCase().contains(it) }
    val regex = "^[0-9,.v-]+(-r)?$".toRegex()
    val isStable = stableKeyword || regex.matches(version)
    return isStable.not()
}

tasks.named<DependencyUpdatesTask>("dependencyUpdates").configure {
    checkForGradleUpdate = true
    resolutionStrategy {
        componentSelection {
            all {
                if (isNonStable(candidate.version) && !isNonStable(currentVersion)) {
                    reject("Release candidate")
                }
            }
        }
    }
}

sonarqube {
    androidVariant = "intuneRelease"
    properties {
        property("sonar.projectName", "Unisteel")
        property("sonar.projectKey", "Sytecs-LLC_unisteel")
        property("sonar.organization", "sytecs-llc")
        property("sonar.host.url", "https://sonarcloud.io")
        property("sonar.login", "49c45bd4da3948d29beb4606f63a95d2e0a61604")
        property("sonar.coverage.exclusions", "**/*.*")
    }
}