package com.sytecs.unisteel.presentation.`in`.inbound

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.Storage
import com.sytecs.unisteel.data.entities.db.StorageGroup
import com.sytecs.unisteel.databinding.InInboundFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class InInboundFragment : AppFragment() {

    companion object {
        var lastGroup: String? = null
        var lastStorage: String? = null
    }

    private val args by navArgs<InInboundFragmentArgs>()

    private var binding: InInboundFragmentBinding by autoCleared()
    private val viewModel: InInboundViewModel by viewModels()

    private var currentGroup: StorageGroup? = null
    private var currentStorage: Storage? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = InInboundFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        binding.textSerial.text = args.item.serial

        setupObservers()

        binding.buttonBack.setOnClickListener { goBack() }

        binding.buttonSave.setOnClickListener {
            currentStorage?.let {
                lastGroup = currentGroup?.code
                lastStorage = currentStorage?.code
                viewModel.save(args.item, it, args.isManual)
            }
        }

        binding.buttonGroup.setOnClickListener {
            viewModel.storageGroups.value?.let { showList(it, currentGroup) }
        }

        binding.buttonStorage.setOnClickListener {
            if (currentGroup == null) {
                showAlert(Options(getString(R.string.in_storages_empty)))
            } else {
                viewModel.showStorages(currentGroup!!)
            }
        }

        setGroup(null)
    }

    private fun setupObservers() {

        if (lastGroup != null && lastStorage != null) {
            observe(viewModel.storages) { storages ->
                viewModel.storageGroups.value?.let { groups ->
                    val group = groups.firstOrNull { it.code == lastGroup }
                    val storage = storages.firstOrNull { it.code == lastStorage }
                    if (group != null && storage != null) {
                        setGroup(group, storage)
                    }
                }
            }
        } else {
            observe(viewModel.storageGroups) {
                if (it.size == 1) {
                    setGroup(it.first())
                }
            }
        }

        observeEvent(viewModel.eventSaved) {
            if (it.isSuccess) {
                showToast(getString(R.string.text_saved))
                goBack()
            } else {
                showAlert(Options(it.message))
            }
        }

        observeEvent(viewModel.eventStorages) { showList(it) }

        observeEvent(onListItemSelected) {
            when (it) {
                is StorageGroup -> setGroup(it)
                is Storage -> setStorage(it)
            }
        }

        observeEvent(viewModel.eventAlert) { event ->
            showAlert(Options(event.first, event.second))
        }
    }

    private fun setGroup(group: StorageGroup?, storage: Storage? = null) {
        this.currentGroup = group
        binding.buttonGroup.text = group?.name ?: getString(R.string.spinner_placeholder)
        binding.buttonStorage.isEnabled = group != null
        setStorage(storage)
    }

    private fun setStorage(storage: Storage?) {
        this.currentStorage = storage
        binding.buttonStorage.text = storage?.name ?: getString(R.string.spinner_placeholder)
        updateValidation()
    }

    private fun updateValidation() {
        val valid = currentGroup != null && currentStorage != null
        binding.buttonSave.visibility = if (valid) View.VISIBLE else View.GONE
    }

    override fun onBarcodeText(text: String) {
        // binding.textBarcode.setText(text)
    }
}
