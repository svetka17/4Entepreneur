package com.sytecs.unisteel.data.entities.embedded

import android.os.Parcelable
import com.sytecs.unisteel.data.entities.db.InvItem
import com.sytecs.unisteel.data.entities.db.InvTask
import com.sytecs.unisteel.data.entities.db.Storage
import kotlinx.parcelize.Parcelize

@Parcelize
data class InvItemWithTaskStorage(val item: InvItem, val task: InvTask, val storage: Storage) :
    Parcelable
