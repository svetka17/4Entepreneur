package com.sytecs.unisteel.presentation.trans.items

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.setFragmentResultListener
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import com.google.android.material.snackbar.Snackbar
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.BarcodeItem
import com.sytecs.unisteel.data.entities.db.Place
import com.sytecs.unisteel.databinding.TransItemsFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint
import java.net.URLDecoder
import timber.log.Timber

@AndroidEntryPoint
class TransItemsFragment : AppFragment() {

    private val args by navArgs<TransItemsFragmentArgs>()

    private var binding: TransItemsFragmentBinding by autoCleared()
    private val viewModel: TransItemsViewModel by viewModels()
    private val adapter: TransItemAdapter by lazy { TransItemAdapter() }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = TransItemsFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        binding.textTitle.text = getString(R.string.trans_items_title, args.storage.name)

        setupRecyclerView()
        setupObservers()

        binding.buttonBack.setOnClickListener { goBack() }
        binding.buttonClear.setOnClickListener {
            showConfirm(Options(getString(R.string.trans_task_clear_confirm))) {
                viewModel.removeTask()
            }
        }
        binding.buttonRefresh.setOnClickListener {
            showConfirm(Options(getString(R.string.trans_upload_confirm))) { viewModel.syncData() }
        }

        setFragmentResultListener("nav_trans_place") { _, bundle ->
            val barcodeItem = bundle.get("barcodeItem") as BarcodeItem
            val place = bundle.get("place") as Place
            Timber.d("Selected place is $place")
            viewModel.onBarcodeItem(barcodeItem, place)
        }
    }

    private fun setupRecyclerView() {
        binding.itemsRv.adapter = adapter
    }

    private fun setupObservers() {
        observe(viewModel.data) {
            adapter.setItems(it)

            val itemCount = it.size
            val itemErrorCount = it.count { item -> item.errorMessage != null }

            binding.itemCount.text = itemCount.toString()
            binding.itemErrorCount.text = itemErrorCount.toString()
            binding.itemErrorCount.visibility = if (itemErrorCount > 0) View.VISIBLE else View.GONE
            binding.itemErrorCountDelimiter.visibility =
                if (itemErrorCount > 0) View.VISIBLE else View.GONE

            binding.buttonClear.visibility = View.VISIBLE

            binding.buttonRefresh.visibility = if (itemCount > 0) View.VISIBLE else View.GONE
        }

        observeEvent(viewModel.eventBeep) { playScanError() }

        observeEvent(viewModel.eventScrollUp) { binding.itemsRv.smoothScrollToPosition(0) }

        observeEvent(viewModel.eventToast) { showToast(it) }

        observeEvent(viewModel.eventAlert) { event ->
            showAlert(Options(event.first, event.second))
        }

        observeEvent(adapter.eventClickItemError) { item ->
            item.errorMessage?.let { showAlert(Options(it)) }
        }

        observeEvent(adapter.eventClickItemRemove) { item ->
            showConfirm(Options(getString(R.string.trans_item_clear_confirm))) {
                viewModel.removeItem(item)
            }
        }

        observeEvent(viewModel.eventSync) {
            if (it.isSuccess) {
                showAlert(Options(getString(R.string.text_upload_success))) { goBack() }
            } else if (it.isError) {
                showAlert(Options(it.message))
            }
        }

        observeEvent(viewModel.eventBack) { goBack() }

        observeEvent(adapter.eventClickItemInfo) {
            showAlert(Options(getString(R.string.trans_item_info_alert, it.size)))
        }

        observeEvent(viewModel.eventSelectPlace) {
            navigate(
                TransItemsFragmentDirections.actionTransItemsFragmentToTransPlaceFragment(
                    it.first, it.second))
        }

        observeEvent(viewModel.eventSelectPlaceAgain) {
            navigate(
                TransItemsFragmentDirections.actionTransItemsFragmentToTransPlaceFragment(
                    it.first, it.second, true))
        }

        observeEvent(viewModel.eventAddedToPlace) {
            showToast("Локація: ${it.name}")
        }
    }

    override fun onBarcodeText(text: String) {
        val decodedBarcode = URLDecoder.decode(text, "UTF-8")
        Timber.d("onBarcodeText: $decodedBarcode")
        viewModel.onBarcodeText(decodedBarcode)
    }
}
