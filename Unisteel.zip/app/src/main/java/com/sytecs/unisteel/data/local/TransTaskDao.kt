package com.sytecs.unisteel.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sytecs.unisteel.data.entities.db.TransTask
import com.sytecs.unisteel.data.entities.embedded.TransTaskWithStorage

@Dao
interface TransTaskDao {

    @Query("SELECT count(1) FROM trans_tasks WHERE process = :process")
    fun getCount(process: Int): Long

    @Query("SELECT * FROM trans_tasks WHERE process = :process")
    fun getAll(process: Int): List<TransTask>

    @Query("SELECT * FROM trans_tasks WHERE id = :id") fun get(id: Long): TransTask?

    @Query("SELECT * FROM trans_tasks WHERE process = :process AND storageCode = :storageCode")
    fun getByStorage(process: Int, storageCode: String): TransTask?

    @Transaction
    @Query("SELECT * FROM trans_tasks WHERE process = :process ORDER BY id DESC")
    fun getWithStorageLiveData(process: Int): LiveData<List<TransTaskWithStorage>>

    @Transaction
    @Query("SELECT * FROM trans_tasks WHERE process = :process ORDER BY id DESC")
    fun getWithStorage(process: Int): List<TransTaskWithStorage>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<TransTask>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: TransTask): Long

    @Update fun update(row: TransTask)

    @Delete fun delete(row: TransTask)

    @Query("DELETE FROM trans_tasks WHERE :process IS NULL OR process = :process")
    fun truncate(process: Int? = null)

    @Query(
        "UPDATE trans_tasks SET " +
            "itemCount = (SELECT COUNT(1) FROM trans_items WHERE trans_items.taskId = trans_tasks.id), " +
            "itemCountError = (SELECT COUNT(1) FROM trans_items WHERE trans_items.taskId = trans_tasks.id AND trans_items.errorMessage IS NOT NULL) " +
            "WHERE process = :process")
    fun updateStat(process: Int)

    @Query("DELETE FROM trans_tasks WHERE process = :process AND itemCount = 0")
    fun cleanEmpty(process: Int)

    @Query("DELETE FROM trans_tasks WHERE itemCount = 0 AND id = :taskId")
    fun cleanEmptyByTask(taskId: Long)
}
