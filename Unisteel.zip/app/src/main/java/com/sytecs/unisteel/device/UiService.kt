package com.sytecs.unisteel.device

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.MutableLiveData
import java.util.*

class UiService : LifecycleEventObserver {

    val stateEvent = MutableLiveData<Boolean>()

    private var timer: Timer? = null

    override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
        if (event == Lifecycle.Event.ON_START) {
            timer =
                Timer().apply {
                    scheduleAtFixedRate(
                        object : TimerTask() {
                            override fun run() {
                                stateEvent.postValue(true)
                            }
                        },
                        0,
                        1000)
                }
        } else if (event == Lifecycle.Event.ON_STOP) {
            timer?.cancel()
            timer = null
        }
    }
}
