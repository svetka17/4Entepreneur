package com.sytecs.unisteel.presentation.unpack.list

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.UnpackTask
import com.sytecs.unisteel.databinding.UnpackListFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class UnpackListFragment : AppFragment() {

    private var binding: UnpackListFragmentBinding by autoCleared()
    private val viewModel: UnpackListViewModel by viewModels()
    private lateinit var adapter: UnpackTaskAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = UnpackListFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        binding.buttonBack.setOnClickListener { goBack() }
        binding.buttonAdd.setOnClickListener {
            navigate(UnpackListFragmentDirections.actionUnpackListFragmentToUnpackAddFragment())
        }
        binding.buttonRefresh.setOnClickListener {
            showConfirm(Options("Передати на сервер?")) {
                // TODO viewModel.syncData()
            }
        }

        binding.buttonClear.setOnClickListener {
            showConfirm(Options(getString(R.string.unpack_clear_all_confirm))) {
                viewModel.removeItems()
            }
        }

        setupRecyclerView()
        setupObservers()

        initFilter(binding.searchLayout, binding.buttonFilter)
    }

    private fun setupRecyclerView() {
        adapter = UnpackTaskAdapter()
        binding.listRv.adapter = adapter
    }

    private fun setupObservers() {
        observe(viewModel.data) {
            adapter.setItems(it)
            adapter.filter.filter(filterQuery)

            val itemCount = it.sumOf { item -> item.task.itemCount }
            val itemScanCount = it.sumOf { item -> item.task.itemCountScanned }
            val itemErrorCount = it.sumOf { item -> item.task.itemCountError }

            binding.itemCount.text = itemCount.toString()
            binding.itemScanCount.text = itemScanCount.toString()

            binding.itemErrorCount.text = itemErrorCount.toString()
            binding.itemErrorCount.visibility = if (itemErrorCount > 0) View.VISIBLE else View.GONE
            binding.itemErrorCountDelimiter.visibility =
                if (itemErrorCount > 0) View.VISIBLE else View.GONE

            binding.itemScanCount.visibility = if (itemScanCount > 0) View.VISIBLE else View.GONE
            binding.itemScanCountDelimiter.visibility =
                if (itemScanCount > 0) View.VISIBLE else View.GONE

            binding.buttonClear.visibility = if (it.isNotEmpty()) View.VISIBLE else View.GONE
        }

        observeEvent(adapter.eventClick) { openTask(it.task) }

        observeEvent(adapter.eventClickSync) {
            showConfirm(Options("Передати на сервер?")) { viewModel.syncData(it.task) }
        }

        observeEvent(viewModel.eventSync) {
            if (it.isSuccess) {
                showAlert(Options("Виконано без помилок"))
            } else if (it.isError) {
                showAlert(Options(it.message))
            }
        }

        observeEvent(eventFilterQuery) { adapter.filter.filter(it) }
    }

    private fun openTask(task: UnpackTask) {
        navigate(UnpackListFragmentDirections.actionUnpackListFragmentToUnpackItemsFragment(task))
    }

    override fun onBarcodeText(text: String) {
        playScanError()
    }
}
