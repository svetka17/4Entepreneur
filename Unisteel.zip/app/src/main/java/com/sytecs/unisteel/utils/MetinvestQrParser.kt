package com.sytecs.unisteel.utils

import com.sytecs.unisteel.data.entities.BarcodeItem
import timber.log.Timber
import java.util.regex.Pattern

class MetinvestQrParser(private val barcode: String) {

    fun parse(): BarcodeItem? {

        if (barcode.contains("metinvest.io", true)) {
            try {
                val blocks = barcode.split("&/&")
                val mainBlock = blocks[0].split('&')
                val dataBlock = blocks[1].split('&')

                //
                val factoryCode = mainBlock[1]
                val accountSystem = mainBlock[2]
                val shopNumber = mainBlock[3]
                val verificationCode = mainBlock[4]

                val checkCode = dataBlock[0]

                // Плавка
                val meltingNumber = dataBlock[1]
                // Партия
                val batchNumber = dataBlock[2].replace('_', ' ')
                // Номер единици продукции
                val itemNumber = dataBlock[3].replace('-', '/')
                // Нетто
                val net = dataBlock[4]
                // Брутто
                val gross = dataBlock[5]
                // Вид продукции
                val productTypeOriginal = dataBlock[6].replace('_', ' ').replace('-', '/')

                val productType =
                    if (productTypeOriginal.contains('/') &&
                        !Pattern.matches(
                            ".*\\p{InCyrillic}.*",
                            productTypeOriginal.subSequence(
                                productTypeOriginal.indexOf('/') + 1, productTypeOriginal.length)))
                        productTypeOriginal
                            .subSequence(0, productTypeOriginal.indexOf('/'))
                            .toString()
                    else productTypeOriginal

                // Размер
                val size = dataBlock[7].replace('_', ' ').replace('-', '/')
                // Марка стали
                val steelBrand = dataBlock[8]
                //
                val orderNumber = dataBlock[9]
                //
                val additionalBlock = dataBlock[10].split('|')
                val year = additionalBlock[0]
                val pak = if (additionalBlock.size > 1) additionalBlock[1] else null

                val idCode =
                    if (factoryCode.isEmpty() &&
                        accountSystem.isEmpty() &&
                        shopNumber.isEmpty() &&
                        verificationCode.isEmpty())
                        ""
                    else "$factoryCode&$accountSystem&$shopNumber&$verificationCode"

                return BarcodeItem(
                    true,
                    barcode,
                    factoryCode,
                    accountSystem,
                    shopNumber,
                    idCode,
                    verificationCode,
                    checkCode,
                    meltingNumber,
                    batchNumber,
                    itemNumber,
                    net,
                    gross,
                    productType,
                    size,
                    steelBrand,
                    orderNumber,
                    year,
                    pak)
            } catch (e: Exception) {
                Timber.e(e)
            }
        }

        return null
    }
}
