package com.sytecs.unisteel.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sytecs.unisteel.data.entities.db.Storage

@Dao
interface StorageDao {

    @Query("SELECT count(1) FROM storages") fun getCount(): Long

    @Query("SELECT * FROM storages") fun getAll(): List<Storage>

    @Query("SELECT * FROM storages") fun getAllLiveData(): LiveData<List<Storage>>

    @Query("SELECT * FROM storages WHERE code = :code") fun get(code: String): Storage?

    @Query("SELECT * FROM storages WHERE groupCode = :groupCode")
    fun getByGroup(groupCode: String): List<Storage>

    @Query("SELECT * FROM storages WHERE groupCode = :groupCode")
    fun getByGroupLiveData(groupCode: String): LiveData<List<Storage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<Storage>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: Storage)

    @Update fun update(row: Storage)

    @Delete fun delete(row: Storage)

    @Query("DELETE FROM storages") fun truncate()
}
