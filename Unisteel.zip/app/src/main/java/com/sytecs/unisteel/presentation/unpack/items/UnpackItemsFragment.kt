package com.sytecs.unisteel.presentation.unpack.items

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import com.sytecs.unisteel.R
import com.sytecs.unisteel.databinding.UnpackItemsFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber
import java.net.URLDecoder

@AndroidEntryPoint
class UnpackItemsFragment : AppFragment() {

    private val args by navArgs<UnpackItemsFragmentArgs>()

    private var binding: UnpackItemsFragmentBinding by autoCleared()
    private val viewModel: UnpackItemsViewModel by viewModels()
    private val adapter: UnpackItemAdapter by lazy { UnpackItemAdapter() }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = UnpackItemsFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        binding.textTitle.text = getString(R.string.unpack_items_title, args.task.code)

        setupRecyclerView()
        setupObservers()

        binding.buttonBack.setOnClickListener { goBack() }
        binding.buttonClear.setOnClickListener {
            showConfirm(Options(getString(R.string.unpack_item_clear_confirm_all))) {
                viewModel.removeItems()
            }
        }
        binding.buttonRefresh.setOnClickListener {
            showConfirm(Options(getString(R.string.unpack_upload_confirm))) {
                viewModel.syncData(args.task)
            }
        }
    }

    private fun setupRecyclerView() {
        binding.itemsRv.adapter = adapter
    }

    private fun setupObservers() {
        observe(viewModel.data) {
            adapter.setItems(it)

            val itemCount = it.size
            val itemScanCount = it.count { item -> item.unpackCreated != null }
            val itemErrorCount = it.count { item -> item.errorMessage != null }

            binding.itemCount.text = itemCount.toString()
            binding.itemScanCount.text = itemScanCount.toString()
            binding.itemErrorCount.text = itemErrorCount.toString()

            binding.itemScanCount.visibility = if (itemScanCount > 0) View.VISIBLE else View.GONE
            binding.itemScanCountDelimiter.visibility =
                if (itemScanCount > 0) View.VISIBLE else View.GONE

            binding.itemErrorCount.visibility = if (itemErrorCount > 0) View.VISIBLE else View.GONE
            binding.itemErrorCountDelimiter.visibility =
                if (itemErrorCount > 0) View.VISIBLE else View.GONE

            binding.buttonClear.visibility = if (itemScanCount > 0) View.VISIBLE else View.GONE

            binding.buttonRefresh.visibility = if (itemScanCount > 0) View.VISIBLE else View.GONE
        }

        observeEvent(viewModel.eventBeep) { playScanError() }

        observeEvent(viewModel.eventScrollUp) { binding.itemsRv.smoothScrollToPosition(0) }

        observeEvent(viewModel.eventToast) { showToast(it) }

        observeEvent(viewModel.eventAlert) { event ->
            showAlert(Options(event.first, event.second))
        }

        observeEvent(adapter.eventClickItemError) { item ->
            item.errorMessage?.let { showAlert(Options(it)) }
        }

        observeEvent(adapter.eventClickItemRemove) { item ->
            showConfirm(Options(getString(R.string.unpack_item_clear_confirm))) {
                viewModel.removeItem(item)
            }
        }

        observeEvent(adapter.eventClickItemAdd) { item ->
            showConfirm(Options(getString(R.string.unpack_item_add_confirm))) {
                viewModel.addItem(item)
            }
        }

        observeEvent(viewModel.eventSync) {
            if (it.isSuccess) {
                showAlert(Options(getString(R.string.text_upload_success))) { goBack() }
            } else if (it.isError) {
                showAlert(Options(it.message))
            }
        }

        observeEvent(viewModel.eventBack) { goBack() }

        observeEvent(adapter.eventClickItemInfo) {
            showAlert(
                Options(getString(R.string.unpack_item_info_alert, it.barcode, it.steelGrade)))
        }
    }

    override fun onBarcodeText(text: String) {
        val decodedBarcode = URLDecoder.decode(text, "UTF-8")
        Timber.d("onBarcodeText: $decodedBarcode")
        viewModel.onBarcodeText(decodedBarcode)
    }
}
