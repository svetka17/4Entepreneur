package com.sytecs.unisteel.presentation.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.core.os.bundleOf
import androidx.fragment.app.FragmentManager
import com.sytecs.unisteel.R
import com.sytecs.unisteel.presentation.base.AppDialog
import com.sytecs.unisteel.utils.SingleLiveEvent

class DialogAlert : AppDialog() {

    companion object {
        fun show(manager: FragmentManager, options: Options): DialogAlert? {
            if (IsDialogShow) return null
            return newInstance(options).apply { show(manager, null) }
        }

        fun newInstance(options: Options) =
            DialogAlert().apply { arguments = bundleOf("options" to options) }
    }

    val onClickPositive = SingleLiveEvent<Boolean>()

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.run {
            val options =
                arguments?.getParcelable<Options>("options")
                    ?: throw IllegalStateException("Options cannot be null")

            val dialog = Dialog(this)
            dialog.setContentView(if (options.isRed) R.layout.dialog_ok_red else R.layout.dialog_ok)
            dialog.setCanceledOnTouchOutside(false)
            dialog.setCancelable(false)
            dialog.setOnKeyListener { _, keyCode, _ -> keyCode == KeyEvent.KEYCODE_BACK }

            val text1 = dialog.findViewById<TextView>(R.id.text1)
            val text2 = dialog.findViewById<TextView>(R.id.text2)
            val buttonOk = dialog.findViewById<Button>(R.id.buttonOk)

            text1.text = options.title
            text2.text = options.message
            text2.gravity =
                if (options.isCentered) Gravity.CENTER_HORIZONTAL else Gravity.NO_GRAVITY
            text1.visibility = if (options.isTitle) View.VISIBLE else View.GONE

            buttonOk.setOnClickListener {
                dialog.dismiss()
                onClickPositive.postValue(true)
            }

            return dialog.also { if (savedInstanceState != null) dismiss() }
        }
            ?: throw IllegalStateException("Activity cannot be null")
    }
}
