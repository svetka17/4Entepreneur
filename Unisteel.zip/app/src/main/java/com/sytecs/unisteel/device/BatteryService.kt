package com.sytecs.unisteel.device

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import com.sytecs.unisteel.R
import javax.inject.Inject

class BatteryService @Inject constructor(private val appContext: Context) : LifecycleEventObserver {

    var batteryLevel: Float = 100.0f
        private set
    var batteryCharging: Boolean = false
        private set

    private val batteryLevelReceiver: BroadcastReceiver =
        object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent) {
                val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                batteryLevel = level / scale.toFloat() * 100.0f
                batteryCharging = status == BatteryManager.BATTERY_STATUS_CHARGING

                invalidateRes()
            }
        }

    override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
        if (event == Lifecycle.Event.ON_START) {
            val batteryLevelFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            appContext.registerReceiver(batteryLevelReceiver, batteryLevelFilter)
        } else if (event == Lifecycle.Event.ON_STOP) {
            appContext.unregisterReceiver(batteryLevelReceiver)
        }
    }

    var batteryImageResId: Int = R.drawable.ic_battery_100
        private set

    private fun invalidateRes() {
        batteryImageResId =
            if (batteryCharging) R.drawable.ic_charging_100 else R.drawable.ic_battery_100

        if (batteryCharging) {
            // batteryImageResId = R.drawable.battery_charge
            when {
                batteryLevel < 20 -> batteryImageResId = R.drawable.ic_charging_20
                batteryLevel < 30 -> batteryImageResId = R.drawable.ic_charging_30
                batteryLevel < 50 -> batteryImageResId = R.drawable.ic_charging_50
                batteryLevel < 60 -> batteryImageResId = R.drawable.ic_charging_60
                batteryLevel < 80 -> batteryImageResId = R.drawable.ic_charging_80
                batteryLevel < 90 -> batteryImageResId = R.drawable.ic_charging_90
            }
        } else {
            when {
                batteryLevel < 20 -> batteryImageResId = R.drawable.ic_battery_20
                batteryLevel < 30 -> batteryImageResId = R.drawable.ic_battery_30
                batteryLevel < 50 -> batteryImageResId = R.drawable.ic_battery_50
                batteryLevel < 60 -> batteryImageResId = R.drawable.ic_battery_60
                batteryLevel < 80 -> batteryImageResId = R.drawable.ic_battery_80
                batteryLevel < 90 -> batteryImageResId = R.drawable.ic_battery_90
            }
        }
    }
}
