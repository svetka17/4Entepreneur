package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JPlaceResult(@SerializedName("EvMesto") val placeList: List<JPlace>) {
    data class JPlace(
        @SerializedName("SkladCode") val storageCode: String,
        @SerializedName("SkladName") val storageName: String,
        @SerializedName("Ryad") val rowNum: Int,
        @SerializedName("Mesto") val placeNum: Int,
        @SerializedName("Name") val name: String,
        @SerializedName("ShtrixCode") val barcode: String
    )
}
