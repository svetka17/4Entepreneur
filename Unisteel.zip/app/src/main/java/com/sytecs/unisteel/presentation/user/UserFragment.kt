package com.sytecs.unisteel.presentation.user

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.msal.MsalResult
import com.sytecs.unisteel.databinding.UserFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class UserFragment : AppFragment() {

    private var binding: UserFragmentBinding by autoCleared()
    private val viewModel: UserViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = UserFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        setupObservers()

        binding.buttonConfig.setOnClickListener { mainActivity?.requestPin() }

        binding.buttonWork.setOnClickListener { viewModel.beginWork() }

        binding.buttonLogin.setOnClickListener { viewModel.onLoginClick(requireActivity()) }

        binding.buttonLogout.setOnClickListener { viewModel.onLogoutClick() }
    }

    private fun processMsalResult(msalResult: MsalResult) {
        val hasAccount = msalResult.user != null
        binding.imageAccount.setImageResource(
            if (hasAccount) R.drawable.ic_shield_green_128 else R.drawable.ic_shield_blue_128)
        binding.textStatus.setText(
            if (hasAccount) R.string.text_login_status_1 else R.string.text_login_status_0)
        binding.textAccount.text =
            if (hasAccount) msalResult.user?.userFio ?: msalResult.user?.userName else null
        binding.buttonLogin.visibility = if (hasAccount) View.GONE else View.VISIBLE
        binding.buttonLogout.visibility = if (hasAccount) View.VISIBLE else View.GONE
        binding.buttonWork.visibility = if (hasAccount) View.VISIBLE else View.GONE
        binding.buttonConfig.visibility = if (hasAccount) View.GONE else View.VISIBLE

        /*if (BuildConfig.DEBUG) {
            binding.buttonWork.visibility = View.VISIBLE
        }*/
    }

    private fun setupObservers() {

        observeEvent(viewModel.msalError) { showAlert(Options(it)) }

        observe(viewModel.msalStatus) { processMsalResult(it) }

        observeEvent(viewModel.eventDataCheck) {
            if (it.isSuccess) {
                viewModel.isProd.value?.let { isProd ->
                    if (isProd) {
                        navigate(UserFragmentDirections.actionUserFragmentToHomeFragment())
                    } else {
                        showAlert(Options(getString(R.string.text_qas_alert), isRed = true)) {
                            navigate(UserFragmentDirections.actionUserFragmentToHomeFragment())
                        }
                    }
                }
            }
        }
    }

    override fun onPinChecked(success: Boolean) {
        if (success) {
            navigate(UserFragmentDirections.actionUserFragmentToSettingsFragment())
        }
    }
}
