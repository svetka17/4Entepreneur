package com.sytecs.unisteel.data.remote

import com.sytecs.unisteel.data.config.AppSettings
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response
import javax.inject.Inject

class HostSelectionInterceptor @Inject constructor(private val settings: AppSettings) :
    Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        var request: Request = chain.request()

        val host =
            if (settings.currentSettings.isProd) settings.currentSettings.apiUrlProd
            else settings.currentSettings.apiUrlQas

        request =
            request
                .newBuilder()
                .url(request.url.toString().replace("https://nobase.url", host))
                .build()

        return chain.proceed(request)
    }
}
