package com.sytecs.unisteel.data.entities.embedded

import android.os.Parcelable
import androidx.room.Embedded
import androidx.room.Relation
import com.sytecs.unisteel.data.entities.db.ShipItem
import com.sytecs.unisteel.data.entities.db.ShipTask
import kotlinx.parcelize.Parcelize

@Parcelize
data class ShipItemWithTask(
    @Embedded val item: ShipItem,
    @Relation(parentColumn = "taskId", entityColumn = "id") val task: ShipTask
) : Parcelable
