package com.sytecs.unisteel.presentation.`in`.items

import android.annotation.SuppressLint
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.embedded.InItemWithCertificate
import com.sytecs.unisteel.databinding.RowInItemBinding
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.format
import java.text.SimpleDateFormat
import java.util.*

class InItemAdapter : ListAdapter<InItemWithCertificate, InItemAdapter.VH>(InItemDiffCallback()) {

    private var list = listOf<InItemWithCertificate>()
    private val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault())
    var eventClickItem = SingleLiveEvent<InItemWithCertificate>()
    var eventClickItemInfo = SingleLiveEvent<InItemWithCertificate>()
    var eventClickItemError = SingleLiveEvent<InItemWithCertificate>()
    var eventClickItemRemove = SingleLiveEvent<InItemWithCertificate>()
    var eventClickItemAdd = SingleLiveEvent<InItemWithCertificate>()

    fun setItems(list: List<InItemWithCertificate>) {
        this.list = list
        submitList(list)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding: RowInItemBinding =
            RowInItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding, dateFormat)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    private class InItemDiffCallback : DiffUtil.ItemCallback<InItemWithCertificate>() {
        override fun areItemsTheSame(
            oldItem: InItemWithCertificate,
            newItem: InItemWithCertificate
        ): Boolean {
            return oldItem.item.id == newItem.item.id
        }

        override fun areContentsTheSame(
            oldItem: InItemWithCertificate,
            newItem: InItemWithCertificate
        ): Boolean {
            return oldItem == newItem
        }
    }

    inner class VH(
        private val itemBinding: RowInItemBinding,
        private val dateFormat: SimpleDateFormat
    ) : RecyclerView.ViewHolder(itemBinding.root), View.OnClickListener {

        private lateinit var item: InItemWithCertificate

        init {
            itemBinding.root.setOnClickListener(this)
        }

        @SuppressLint("SetTextI18n")
        fun bind(item: InItemWithCertificate) {
            this.item = item

            itemBinding.viewRoot.setBackgroundResource(
                if (item.item.inCreated != null)
                    if (item.item.inManual == true) R.drawable.background_item_manual
                    else R.drawable.background_item_success
                else R.drawable.background_item)

            itemBinding.buttonAdd.visibility = View.GONE
            // if (item.item.inCreated == null) View.VISIBLE else View.GONE
            itemBinding.buttonRemove.visibility =
                if (item.item.inCreated != null) View.VISIBLE else View.GONE

            itemBinding.buttonInfo.setOnClickListener { eventClickItemInfo.postValue(this.item) }

            itemBinding.imageQr.visibility =
                if (item.item.qr.isNotEmpty()) View.VISIBLE else View.GONE

            itemBinding.buttonError.visibility =
                if (item.item.errorMessage != null) View.VISIBLE else View.GONE

            itemBinding.buttonError.setOnClickListener { eventClickItemError.postValue(this.item) }

            itemBinding.buttonAdd.setOnClickListener { eventClickItemAdd.postValue(this.item) }

            itemBinding.buttonRemove.setOnClickListener {
                eventClickItemRemove.postValue(this.item)
            }

            itemBinding.table.removeAllViews()

            addRow(itemBinding.table, "Плавка: ", item.item.melting.trim())
            addRow(itemBinding.table, "Партія: ", item.item.batch)
            addRow(itemBinding.table, "Розмір: ", "${item.item.width}x${item.item.thickness}")
            addRow(itemBinding.table, "НЕТТО, т: ", item.item.weight.format(3))
            addRow(itemBinding.table, "Серія: ", item.item.serial)
            addRow(itemBinding.table, "Серт.: ", item.certificate.code)
            // addRow(itemBinding.table, "QR: ", if (item.item.qr.isEmpty()) "відсутній" else
            // "присутній")
            // addRow(itemBinding.table, "Код Unisteel: ", if (item.item.barcode.isEmpty()) "-" else
            // item.item.barcode)

            item.item.inStorageCode?.let { addRow(itemBinding.table, "Склад: ", it) }

            item.item.inCreated?.let {
                addRow(itemBinding.table, "Сканування: ", dateFormat.format(it))
            }
        }

        private fun addRow(table: TableLayout, col1: String, col2: String) {
            val row = TableRow(table.context)

            val text1 = TextView(this.itemView.context)
            val text2 = TextView(this.itemView.context)

            text1.maxLines = 1
            text1.ellipsize = TextUtils.TruncateAt.END

            text1.text = col1
            text2.text = col2
            text2.textAlignment = View.TEXT_ALIGNMENT_VIEW_END
            row.addView(text1)
            row.addView(text2)

            table.addView(row)

            TableRow.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .let {
                    it.weight = 1.0f
                    // text1.layoutParams = it
                    text2.layoutParams = it
                }
        }

        override fun onClick(v: View?) {
            eventClickItem.postValue(item)
        }
    }
}
