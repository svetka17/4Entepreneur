package com.sytecs.unisteel.data.entities.embedded

import android.os.Parcelable
import androidx.room.Embedded
import androidx.room.Relation
import com.sytecs.unisteel.data.entities.db.Active
import com.sytecs.unisteel.data.entities.db.InCertificate
import com.sytecs.unisteel.data.entities.db.InTransport
import kotlinx.parcelize.Parcelize

@Parcelize
data class InTransportWithCertificates(
    @Embedded val transport: InTransport,
    @Relation(parentColumn = "activeCode", entityColumn = "code") val active: Active?,
    @Relation(parentColumn = "id", entityColumn = "transportId")
    val certificates: List<InCertificate>
) : Parcelable
