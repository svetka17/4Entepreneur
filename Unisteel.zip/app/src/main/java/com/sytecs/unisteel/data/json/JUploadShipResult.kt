package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JUploadShipResult(
    @SerializedName("Seriya") val serial: String,
    @SerializedName("ShtrixCode") val barcode: String,
    @SerializedName("QR") val qr: String,
    @SerializedName("Error") var error: String?
)
