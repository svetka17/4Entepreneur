package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JUploadUnpack(
    @SerializedName("CodeOper") val operationCode: Int,
    @SerializedName("CodeSmen") val shiftCode: Int,
    @SerializedName("nomer") val number: Int,
    @SerializedName("date") val operationDate: String,
    @SerializedName("user") val userLogin: String,
    @SerializedName("POSITIONS") val positions: List<Position>
) {
    data class Position(
        @SerializedName("seriya") val serial: String,
        @SerializedName("ShtrixCode") val barcode: String,
        @SerializedName("QR") val qr: String,
        @SerializedName("ves") val weight: Double,
        @SerializedName("comment") val comment: String?
    )
}
