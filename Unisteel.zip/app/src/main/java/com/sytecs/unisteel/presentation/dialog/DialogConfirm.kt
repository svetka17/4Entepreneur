package com.sytecs.unisteel.presentation.dialog

import android.os.Bundle
import android.view.*
import androidx.core.os.bundleOf
import androidx.fragment.app.FragmentManager
import com.sytecs.unisteel.databinding.DialogConfirmBinding
import com.sytecs.unisteel.presentation.base.AppDialog
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.autoCleared
import com.sytecs.unisteel.utils.setHtml

class DialogConfirm : AppDialog() {

    companion object {
        fun show(manager: FragmentManager, options: Options): DialogConfirm? {
            if (IsDialogShow) return null
            return newInstance(options).apply { show(manager, null) }
        }

        fun newInstance(options: Options) =
            DialogConfirm().apply { arguments = bundleOf("options" to options) }
    }

    private var binding: DialogConfirmBinding by autoCleared()
    val onClickPositive = SingleLiveEvent<Boolean>()
    val onClickNegative = SingleLiveEvent<Boolean>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        savedInstanceState?.let { dismiss() }

        binding = DialogConfirmBinding.inflate(inflater, container, false)

        val options =
            arguments?.getParcelable<Options>("options")
                ?: throw IllegalStateException("Options cannot be null")

        dialog?.run {
            setCanceledOnTouchOutside(false)
            setCancelable(false)
            setOnKeyListener { _, keyCode, _ -> keyCode == KeyEvent.KEYCODE_BACK }
        }

        binding.text1.text = options.title
        if (options.messageHtml.isNotEmpty()) {
            binding.text2.setHtml(options.messageHtml)
        } else {
            binding.text2.text = options.message
        }
        binding.text2.gravity =
            if (options.isCentered) Gravity.CENTER_HORIZONTAL else Gravity.NO_GRAVITY
        binding.text1.visibility = if (options.isTitle) View.VISIBLE else View.GONE

        binding.buttonNo.setOnClickListener {
            dismiss()
            onClickNegative.postValue(true)
        }

        binding.buttonYes.setOnClickListener {
            dismiss()
            onClickPositive.postValue(true)
        }

        return binding.root
    }
}
