package com.sytecs.unisteel.utils

import android.content.Context
import android.content.res.AssetFileDescriptor
import android.media.MediaPlayer
import android.text.Html
import android.widget.TextView
import androidx.lifecycle.LifecycleCoroutineScope
import com.sytecs.unisteel.data.entities.BarcodeItem
import java.io.IOException
import java.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import timber.log.Timber

fun JSONObject.getStringIgnoreCase(key: String): String? {
    try {
        this.keys().forEach { if (it.equals(key, true)) return this.getString(it) }
    } catch (e: Exception) {
        return null
    }
    return null
}

fun JSONObject.getStringArrayIgnoreCase(key: String): List<String>? {
    try {
        this.keys().forEach {
            if (it.equals(key, true)) {
                val arr = this.getJSONArray(key)
                val res = mutableListOf<String>()
                for (i in 0 until arr.length()) {
                    res.add(arr.getString(i))
                }
                return res
            }
        }
    } catch (e: Exception) {
        return null
    }
    return null
}

fun TextView.setHtml(html: String) {
    this.text = Html.fromHtml(html, Html.FROM_HTML_MODE_COMPACT)
}

fun Date.removeTime(): Date {
    val calendar = Calendar.getInstance().also { it.time = this }
    calendar.set(Calendar.HOUR_OF_DAY, 0)
    calendar.set(Calendar.MINUTE, 0)
    calendar.set(Calendar.SECOND, 0)
    calendar.set(Calendar.MILLISECOND, 0)
    return calendar.time
}

fun parseQrIdOrNull(qrCode: String): String? {
    val qrItem = MetinvestQrParser(qrCode).parse()
    qrItem?.let {
        return it.idCode
    }
    return null
}

fun parseItemQr(barcodeText: String): BarcodeItem? {

    val metinvestBarcode = MetinvestQrParser(barcodeText).parse()
    if (metinvestBarcode != null) return metinvestBarcode

    val idCodeBarcode = IdCodeQrParser(barcodeText).parse()
    if (idCodeBarcode != null) return idCodeBarcode

    Timber.e("Unknown barcode! ($barcodeText)")
    return null
}

fun startSound(
    scope: LifecycleCoroutineScope,
    context: Context,
    filename: String,
    delayMs: Long = 0
) {
    scope.launch(Dispatchers.IO) {
        delay(delayMs)
        startSound(context, filename)
    }
}

fun startSound(context: Context, filename: String) {
    var afd: AssetFileDescriptor? = null
    try {
        afd = context.resources.assets.openFd(filename)
    } catch (e: IOException) {
        e.printStackTrace()
    }
    val player = MediaPlayer()
    try {
        assert(afd != null)
        player.setDataSource(afd!!.fileDescriptor, afd.startOffset, afd.length)
    } catch (e: IOException) {
        e.printStackTrace()
    }
    try {
        player.prepare()
    } catch (e: IOException) {
        e.printStackTrace()
    }
    player.start()
}

fun now(): Date = Calendar.getInstance().time

fun Double.format(digits: Int) = "%.${digits}f".format(this).replace(',', '.')
