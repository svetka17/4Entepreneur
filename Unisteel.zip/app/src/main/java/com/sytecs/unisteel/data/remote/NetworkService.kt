package com.sytecs.unisteel.data.remote

import com.sytecs.unisteel.data.json.*
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface NetworkService {
    @GET("/zhcm_get_аctiv") suspend fun getActives(): Response<JActiveResult>

    @GET("/zhcm_get_roly")
    suspend fun getAccess(@Query("user") user: String): Response<JAccessResult>

    @GET("/zhcm_get_sklad") suspend fun getStorages(): Response<JStoragesResult>

    @GET("/zhcm_get_mesto") suspend fun getPlaces(): Response<JPlaceResult>

    @GET("/zhcm_get_smeny") suspend fun getShifts(): Response<JShiftResult>

    @GET("/zhcm_get_sert")
    suspend fun getCertificate(
        @Query("sert") certificateCode: String?,
        @Query("ts") transport: String?,
        @Query("ttn") ttn: String?
    ): Response<JCertificateResult>

    @POST("/zhcm_post_prixod")
    suspend fun postIn(@Body body: JUploadIn): Response<List<JUploadInResult>>

    @POST("/zhcm_post_prixod")
    suspend fun postInRaw(@Body body: RequestBody): Response<List<JUploadInResult>>

    @POST("/zhcm_post_perem")
    suspend fun postTrans(@Body body: JUploadTrans): Response<List<JUploadTransResult>>

    @POST("/zhcm_post_perem")
    suspend fun postTransRaw(@Body body: RequestBody): Response<List<JUploadTransResult>>

    @GET("/zhcm_post_shtrixcode")
    suspend fun getBarcode(@Query("shtrixcode") barcode: String): Response<JBarcodeResult>

    @POST("/zhcm_post_zayavka")
    suspend fun getShipTask(@Body body: RequestBody): Response<JShipTaskResult>

    @POST("/zhcm_post_otgruzka")
    suspend fun postShipTask(@Body body: JUploadShip): Response<List<JUploadShipResult>>

    @GET("/zhcm_param_proizv")
    suspend fun getUnpackTask(@Query("nomer") number: String): Response<JUnpackResult>

    @POST("/zhcm_post_raspakovka")
    suspend fun postUnpackRaw(@Body body: RequestBody): Response<List<JUploadUnpackResult>>

    @POST("/zhcm_post_inventarizaciya")
    suspend fun postInv(@Body body: JUploadInv): Response<List<JUploadInvResult>>

    @POST("/zhcm_post_inventarizaciya")
    suspend fun postInvRaw(@Body body: RequestBody): Response<List<JUploadInvResult>>
}
