package com.sytecs.unisteel.data.entities.embedded

import android.os.Parcelable
import androidx.room.Embedded
import androidx.room.Relation
import com.sytecs.unisteel.data.entities.db.InvItem
import com.sytecs.unisteel.data.entities.db.InvTask
import kotlinx.parcelize.Parcelize

@Parcelize
data class InvItemWithTask(
    @Embedded val item: InvItem,
    @Relation(parentColumn = "taskId", entityColumn = "id") val task: InvTask
) : Parcelable
