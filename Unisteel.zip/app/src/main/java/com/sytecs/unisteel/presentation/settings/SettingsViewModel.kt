package com.sytecs.unisteel.presentation.settings

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.data.entities.Settings
import com.sytecs.unisteel.data.repository.Repo
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel
@Inject
constructor(
    private val repo: Repo,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {

    val data = repo.getSettings()

    private val _userData = MutableLiveData<Boolean>()
    val userData: LiveData<Boolean> = _userData

    val eventSaved = SingleLiveEvent<Boolean>()
    val eventReset = SingleLiveEvent<Boolean>()

    private fun checkUserData() {
        viewModelScope.launch(Dispatchers.IO) { _userData.postValue(repo.haveUserData()) }
    }

    init {
        checkUserData()
    }

    fun onClearClick() {
        viewModelScope.launch(Dispatchers.IO) {
            repo.clearSettings()
            repo.truncateDatabase()
            _userData.postValue(repo.haveUserData())
            eventSaved.postValue(true)
        }
    }

    fun onSaveClick(
        isProd: Boolean, apiUrlProd: String, apiUrlQas: String, isCameraScan: Boolean,
        aadClientId: String, adTenantId: String,
        aadClientIdQas: String, adTenantIdQas: String
    ) {
        if (data.value == null) return

        val currentConfig = data.value!!

        viewModelScope.launch(Dispatchers.IO) {
            repo.putSettings(
                Settings(
                    isProd, apiUrlProd, apiUrlQas, isCameraScan,
                    aadClientId, adTenantId, aadClientIdQas, adTenantIdQas
                )
            )

            if (currentConfig.isProd != isProd) {
                repo.truncateDatabase()
                _userData.postValue(repo.haveUserData())
            }

            eventSaved.postValue(true)
        }
    }

    fun onTruncateClick() {
        viewModelScope.launch(Dispatchers.IO) {
            repo.truncateDatabase()
            checkUserData()
        }
    }
}
