package com.sytecs.unisteel.data.local

import androidx.room.*
import com.sytecs.unisteel.data.entities.db.Shift

@Dao
interface ShiftDao {

    @Query("SELECT count(1) FROM shifts") fun getCount(): Long

    @Query("SELECT * FROM shifts") fun getAll(): List<Shift>

    @Query("SELECT * FROM shifts WHERE code = :code") fun get(code: String): Shift?

    @Query("SELECT * FROM shifts WHERE groupCode = :groupCode")
    fun getByGroup(groupCode: String): List<Shift>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<Shift>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: Shift)

    @Update fun update(row: Shift)

    @Delete fun delete(row: Shift)

    @Query("DELETE FROM shifts") fun truncate()
}
