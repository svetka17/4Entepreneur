package com.sytecs.unisteel.data.repository

import com.google.gson.JsonArray
import com.sytecs.unisteel.data.entities.BarcodeItem
import com.sytecs.unisteel.data.entities.db.ShipItem
import com.sytecs.unisteel.data.entities.db.ShipTask
import com.sytecs.unisteel.data.entities.embedded.ShipItemWithTask
import com.sytecs.unisteel.data.json.JUploadShip
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.now
import com.sytecs.unisteel.utils.parseQrIdOrNull
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import okhttp3.RequestBody.Companion.toRequestBody
import timber.log.Timber

class RepoShip @Inject constructor(private val repo: Repo) {

    fun taskList() = repo.local.shipTaskDao().getAllLiveData()
    fun itemList(task: ShipTask) = repo.local.shipItemDao().getByTaskLiveData(task.id)

    suspend fun loadTask(number: String): Resource<Boolean> {

        repo.local.shipTaskDao().get(number)?.let {
            return Resource.error("Заявка вже присутня!")
        }

        val arr = JsonArray(1)
        arr.add(number)

        val res = repo.remote.getShipTask(arr.toString().toRequestBody())

        if (res.status == Resource.Status.ERROR || res.data == null) {
            return Resource.error(res.message.ifEmpty { "Помилка отримання даних" })
        }

        with(res.data) {
            if (taskNumber == null) {
                return Resource.error("Заявка не знайдена!")
            }

            val taskId =
                repo.local
                    .shipTaskDao()
                    .insert(
                        ShipTask(
                            0,
                            this.taskNumber,
                            now(),
                            transportName ?: "",
                            driverName ?: "",
                            consigneeName ?: "",
                            transportType ?: "",
                            transportType == "Автотранспортом",
                            isFinished ?: false,
                            now(),
                            0.0,
                            "",
                            false,
                            0,
                            0,
                            0
                        )
                    )

            val rows =
                positions.map { item ->
                    ShipItem(
                        0,
                        taskId,
                        item.steelGrade,
                        item.thickness,
                        item.width,
                        item.weight,
                        item.nomenclature,
                        item.serial,
                        item.barcode,
                        item.qrCode,
                        parseQrIdOrNull(item.qrCode),
                        item.storageCode,
                        item.placeName,
                        item.gross,
                        item.gross2,
                        item.spec,
                        item.number,
                        item.isShipped,
                        now(),
                        null,
                        null,
                        null
                    )
                }
            repo.local.shipItemDao().insertAll(rows)
        }

        // var itemList = data.positions

        updateStat()

        return Resource.success(true)
    }

    private fun updateStat() {
        repo.local.shipTaskDao().updateStat()
    }

    fun deleteTasks() {
        repo.local.shipItemDao().truncate()
        repo.local.shipTaskDao().truncate()
    }

    fun removeTask(task: ShipTask) {
        repo.local.shipItemDao().deleteByTask(task.id)
        repo.local.shipTaskDao().delete(task)
    }

    suspend fun findItem(item: BarcodeItem): ShipItemWithTask? {
        return if (item.isQr) {
            repo.local.shipItemDao().findItemByQr(item.text, item.idCode)
        } else {
            repo.local.shipItemDao().findItemByBarcode(item.text)
        }
    }

    fun shipItemAdd(shipItem: ShipItem, barcodeItem: BarcodeItem) {
        repo.local.shipItemDao().addFact(shipItem.id, now(), barcodeItem.text)
        updateStat()
    }

    fun shipItemRemove(shipItem: ShipItem) {
        repo.local.shipItemDao().removeFact(shipItem.id)
        updateStat()
    }

    fun shipItemsRemove(task: ShipTask) {
        repo.local.shipItemDao().removeFactByTask(task.id)
        updateStat()
    }

    suspend fun uploadItems(
        task: ShipTask,
        comment: String,
        useAwning: Boolean
    ): Resource<Boolean> {

        // task.comment = if (useAwning) comment else "Авто без тента $comment"
        task.carWithoutAwning = !useAwning
        task.comment = comment
        repo.local.shipTaskDao().update(task)

        val items = repo.local.shipItemDao().getByTaskFact(task.id)
        return uploadItems(items, task)
    }

    private suspend fun uploadItems(items: List<ShipItem>, task: ShipTask): Resource<Boolean> {

        Timber.w("Upload ${items.size} items!")

        val dateTimeFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault())

        val positions = mutableListOf<JUploadShip.Position>()

        items.forEach { item ->
            positions.add(
                JUploadShip.Position(
                    operationDate = dateTimeFormat.format(now()),
                    userLogin = repo.userNameApi,
                    serial = item.serial,
                    barcode = item.barcode,
                    qrCode = item.qr,
                    isShipped = true
                )
            )
        }

        val uploadStruct =
            JUploadShip(
                number = task.code,
                comment = task.comment,
                carWithoutAwning = task.carWithoutAwning,
                isShipped = true,
                positions = positions
            )

        val res = repo.remote.postShipTask(uploadStruct)

        if (res.isError) {
            return Resource.error(res.message)
        }

        if (res.data == null) {
            return Resource.error("Data error")
        }

        val data = res.data

        var allOk = true

        items.forEach { item ->
            val remoteItem =
                data.firstOrNull { item2 -> Objects.equals(item.serial, item2.serial) }
                    ?: data.firstOrNull { item2 -> Objects.equals(item.qr, item2.qr) }
                        ?: data.firstOrNull { item2 -> Objects.equals(item.barcode, item2.barcode) }

            //            remoteItem?.let {
            //                remoteItem.error = "test error!"
            //            }

            if (remoteItem?.error?.isNotEmpty() == true) {
                item.errorMessage = remoteItem.error
                repo.local.shipItemDao().update(item)
                allOk = false
            } else {
                repo.local.shipItemDao().delete(item)
            }
        }

        updateStat()
        clearEmptyData(task)

        return if (allOk) Resource.success(true)
        else Resource.error("Виконано з помилками, перегляньте відмічені позиції")
    }

    private fun clearEmptyData(task: ShipTask) {
        repo.local.shipTaskDao().cleanEmptyByTask(task.id)
    }

    suspend fun editTask(task: ShipTask, transportName: String, driverFio: String) {
        task.transportName = transportName
        task.driverName = driverFio
        repo.local.shipTaskDao().update(task)
    }
}
