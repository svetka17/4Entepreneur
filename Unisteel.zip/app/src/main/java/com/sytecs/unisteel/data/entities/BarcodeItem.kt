package com.sytecs.unisteel.data.entities

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class BarcodeItem(
    val isQr: Boolean,
    val text: String,

    // QR
    val factoryCode: String? = null,
    val accountSystem: String? = null,
    val shopNumber: String? = null,
    val idCode: String? = null,
    val verificationCode: String? = null,
    val checkCode: String? = null,
    val meltingNumber: String? = null,
    val batchNumber: String? = null,
    val itemNumber: String? = null,
    val net: String? = null,
    val gross: String? = null,
    val productType: String? = null,
    val size: String? = null,
    val steelBrand: String? = null,
    val orderNumber: String? = null,
    val year: String? = null,
    val pak: String? = null
) : Parcelable
