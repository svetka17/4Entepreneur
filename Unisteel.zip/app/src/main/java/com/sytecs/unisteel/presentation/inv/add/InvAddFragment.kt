package com.sytecs.unisteel.presentation.inv.add

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.Storage
import com.sytecs.unisteel.data.entities.db.StorageGroup
import com.sytecs.unisteel.databinding.InvAddFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.utils.autoCleared
import com.sytecs.unisteel.utils.now
import dagger.hilt.android.AndroidEntryPoint
import java.util.*

@AndroidEntryPoint
class InvAddFragment : AppFragment() {

    companion object {
        var lastDate: Date? = null
        var lastGroup: String? = null
        var lastStorage: String? = null
    }

    private var binding: InvAddFragmentBinding by autoCleared()
    private val viewModel: InvAddViewModel by viewModels()
    private var currentDate: Date = now()
    private var currentGroup: StorageGroup? = null
    private var currentStorage: Storage? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = InvAddFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        setupObservers()

        binding.buttonBack.setOnClickListener { goBack() }

        binding.buttonSave.setOnClickListener {
            currentStorage?.let { storage ->
                lastDate = currentDate
                lastGroup = currentGroup?.code
                lastStorage = storage.code
                viewModel.save(currentDate, storage)
            }
        }

        binding.buttonDate.setOnClickListener { showDatePicker(currentDate) { setCurrentDate(it) } }

        binding.buttonGroup.setOnClickListener {
            viewModel.storageGroups.value?.let { showList(it, currentGroup) }
        }

        binding.buttonStorage.setOnClickListener {
            if (currentGroup == null) {
                showAlert(Options(getString(R.string.in_storages_empty)))
            } else {
                viewModel.showStorages(currentGroup!!)
            }
        }

        setCurrentDate(lastDate ?: now())
        setGroup(null)
    }

    private fun setCurrentDate(date: Date) {
        currentDate = date
        binding.buttonDate.text = dateFormat.format(date)
    }

    private fun setupObservers() {

        if (lastGroup != null && lastStorage != null) {
            observe(viewModel.storages) { storages ->
                viewModel.storageGroups.value?.let { groups ->
                    val group = groups.firstOrNull { it.code == lastGroup }
                    val storage = storages.firstOrNull { it.code == lastStorage }
                    if (group != null && storage != null) {
                        setGroup(group, storage)
                    }
                }
            }
        } else {
            observe(viewModel.storageGroups) {
                if (it.size == 1) {
                    setGroup(it.first())
                }
            }
        }

        observeEvent(viewModel.eventSaved) {
            showToast(getString(R.string.text_saved))
            goBack()
        }

        observeEvent(viewModel.eventStorages) { showList(it, currentStorage) }

        observeEvent(onListItemSelected) {
            when (it) {
                is StorageGroup -> setGroup(it)
                is Storage -> setStorage(it)
            }
        }

        observeEvent(viewModel.eventAlert) { event ->
            showAlert(Options(event.first, event.second))
        }

        observeEvent(viewModel.eventBeep) { playScanError() }
    }

    private fun setGroup(group: StorageGroup?, storage: Storage? = null) {
        this.currentGroup = group
        binding.buttonGroup.text = group?.name ?: getString(R.string.spinner_placeholder)
        binding.buttonStorage.isEnabled = group != null
        setStorage(storage)
    }

    private fun setStorage(storage: Storage?) {
        this.currentStorage = storage
        binding.buttonStorage.text = storage?.name ?: getString(R.string.spinner_placeholder)
        updateValidation()
    }

    private fun updateValidation() {
        val valid =
            currentGroup != null && currentStorage != null && viewModel.isLoading.value != true
        binding.buttonSave.visibility = if (valid) View.VISIBLE else View.GONE
    }
}
