package com.sytecs.unisteel.presentation.base

import android.app.Application
import android.content.Context
import android.content.res.Resources
import androidx.lifecycle.AndroidViewModel
import com.sytecs.unisteel.MainApplication
import java.text.SimpleDateFormat
import java.util.*

open class AppViewModel(applicationContext: Context) :
    AndroidViewModel(applicationContext as Application) {
    protected val res: Resources
        get() = getApplication<MainApplication>().resources

    protected val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
}
