package com.sytecs.unisteel.data.entities.db

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.util.*

@Parcelize
@Entity(tableName = "actives")
data class Active(
    @PrimaryKey val code: String,
    val name: String,
    val description: String,
    val created: Date
) : Parcelable
