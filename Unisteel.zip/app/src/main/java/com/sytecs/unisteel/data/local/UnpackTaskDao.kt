package com.sytecs.unisteel.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sytecs.unisteel.data.entities.db.UnpackTask
import com.sytecs.unisteel.data.entities.embedded.UnpackTaskWithShift

@Dao
interface UnpackTaskDao {

    @Query("SELECT count(1) FROM unpack_tasks") fun getCount(): Long

    @Query("SELECT * FROM unpack_tasks") fun getAll(): List<UnpackTask>

    @Query("SELECT * FROM unpack_tasks") fun getAllLiveData(): LiveData<List<UnpackTask>>

    @Transaction
    @Query("SELECT * FROM unpack_tasks")
    fun getAllWithShiftLiveData(): LiveData<List<UnpackTaskWithShift>>

    @Query("SELECT * FROM unpack_tasks WHERE id = :id") fun get(id: Long): UnpackTask?

    @Query("SELECT * FROM unpack_tasks WHERE code = :code") fun get(code: String): UnpackTask?

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<UnpackTask>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: UnpackTask): Long

    @Update fun update(row: UnpackTask)

    @Delete fun delete(row: UnpackTask)

    @Query("DELETE FROM unpack_tasks") fun truncate()

    @Query(
        "UPDATE unpack_tasks SET " +
            "weight = (SELECT TOTAL(weight) FROM unpack_items WHERE unpack_items.taskId = unpack_tasks.id), " +
            "itemCount = (SELECT COUNT(1) FROM unpack_items WHERE unpack_items.taskId = unpack_tasks.id), " +
            "itemCountScanned = (SELECT COUNT(1) FROM unpack_items WHERE unpack_items.taskId = unpack_tasks.id AND unpack_items.unpackCreated IS NOT NULL), " +
            "itemCountError = (SELECT COUNT(1) FROM unpack_items WHERE unpack_items.taskId = unpack_tasks.id AND unpack_items.errorMessage IS NOT NULL) ")
    fun updateStat()

    @Query("DELETE FROM unpack_tasks WHERE id = :id AND itemCount = 0")
    fun cleanEmptyByTask(id: Long)
}
