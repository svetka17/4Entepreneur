package com.sytecs.unisteel.presentation.trans.list

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.embedded.TransTaskWithStorage
import com.sytecs.unisteel.databinding.RowTransTaskBinding
import com.sytecs.unisteel.utils.SingleLiveEvent
import java.text.SimpleDateFormat
import java.util.*

class TransTaskAdapter :
    ListAdapter<TransTaskWithStorage, TransTaskAdapter.VH>(TransTaskDiffCallback()), Filterable {

    private val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
    private var list = listOf<TransTaskWithStorage>()
    var eventClick = SingleLiveEvent<TransTaskWithStorage>()
    var eventClickSync = SingleLiveEvent<TransTaskWithStorage>()

    fun setItems(list: List<TransTaskWithStorage>) {
        this.list = list
        submitList(list)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding: RowTransTaskBinding =
            RowTransTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val filteredList = mutableListOf<TransTaskWithStorage>()
                if (constraint == null || constraint.isEmpty()) {
                    filteredList.addAll(list)
                } else {
                    list
                        .filter {
                            /*it.task.comment.contains(constraint, true) ||*/
                            it.storage.name.contains(constraint, true)
                        }
                        .forEach { filteredList.add(it) }
                }
                return FilterResults().also { it.values = filteredList }
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                submitList(results?.values as MutableList<TransTaskWithStorage>)
            }
        }
    }

    private class TransTaskDiffCallback : DiffUtil.ItemCallback<TransTaskWithStorage>() {
        override fun areItemsTheSame(
            oldItem: TransTaskWithStorage,
            newItem: TransTaskWithStorage
        ): Boolean {
            return oldItem.task.id == newItem.task.id
        }

        override fun areContentsTheSame(
            oldItem: TransTaskWithStorage,
            newItem: TransTaskWithStorage
        ): Boolean {
            return oldItem == newItem
        }
    }

    inner class VH(private val itemBinding: RowTransTaskBinding) :
        RecyclerView.ViewHolder(itemBinding.root), View.OnClickListener {

        private lateinit var item: TransTaskWithStorage

        init {
            itemBinding.root.setOnClickListener(this)
        }

        fun bind(item: TransTaskWithStorage) {
            this.item = item

            val resId: Int =
                when {
                    item.task.itemCountError > 0 -> R.color.status_container_error
                    item.task.itemCount > 0 -> R.color.status_container_success
                    else -> R.color.status_container_empty
                }

            val withError = item.task.itemCountError > 0

            itemBinding.viewRoot.setBackgroundResource(R.drawable.background_empty)
            itemBinding.viewMark.setBackgroundResource(resId)

            val sb = StringBuilder()
            sb.append(dateFormat.format(item.task.created))

            itemBinding.text1.text = item.storage.name
            itemBinding.text2.text = sb.toString()

            itemBinding.itemCount.text = item.task.itemCount.toString()
            itemBinding.itemErrorCount.text = item.task.itemCountError.toString()
            itemBinding.itemSuccessCount.visibility = View.GONE
            itemBinding.itemSuccessDelimiter.visibility = View.GONE
            itemBinding.itemErrorDelimiter.visibility = if (withError) View.VISIBLE else View.GONE
            itemBinding.itemErrorCount.visibility = if (withError) View.VISIBLE else View.GONE

            itemBinding.itemCount.visibility =
                if (item.task.itemCount > 0) View.VISIBLE else View.INVISIBLE
            itemBinding.buttonSync.visibility =
                if (item.task.itemCount > 0) View.VISIBLE else View.INVISIBLE
            itemBinding.buttonSync.setOnClickListener { eventClickSync.postValue(item) }
        }

        override fun onClick(v: View?) {
            eventClick.postValue(item)
        }
    }
}
