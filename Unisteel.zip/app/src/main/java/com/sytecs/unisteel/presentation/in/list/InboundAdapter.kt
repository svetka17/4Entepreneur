package com.sytecs.unisteel.presentation.`in`.list

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.embedded.InTransportWithCertificates
import com.sytecs.unisteel.databinding.RowInTransportBinding
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.format

class InboundAdapter :
    ListAdapter<InTransportWithCertificates, InboundAdapter.VH>(InboundDiffCallback()), Filterable {

    private var list = listOf<InTransportWithCertificates>()

    var eventClick = SingleLiveEvent<InTransportWithCertificates>()
    var eventClickSync = SingleLiveEvent<InTransportWithCertificates>()

    fun setItems(list: List<InTransportWithCertificates>) {
        this.list = list
        submitList(list)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding: RowInTransportBinding =
            RowInTransportBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val filteredList = mutableListOf<InTransportWithCertificates>()

                if (constraint == null || constraint.isEmpty()) {
                    filteredList.addAll(list)
                } else {
                    list
                        .filter { it.transport.name.contains(constraint, true) }
                        .forEach { filteredList.add(it) }
                }
                return FilterResults().also { it.values = filteredList }
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                submitList(results?.values as MutableList<InTransportWithCertificates>)
            }
        }
    }

    private class InboundDiffCallback : DiffUtil.ItemCallback<InTransportWithCertificates>() {
        override fun areItemsTheSame(
            oldItem: InTransportWithCertificates,
            newItem: InTransportWithCertificates
        ): Boolean {
            return oldItem.transport.id == newItem.transport.id
        }

        override fun areContentsTheSame(
            oldItem: InTransportWithCertificates,
            newItem: InTransportWithCertificates
        ): Boolean {
            return oldItem == newItem
        }
    }

    inner class VH(private val itemBinding: RowInTransportBinding) :
        RecyclerView.ViewHolder(itemBinding.root), View.OnClickListener {

        private lateinit var item: InTransportWithCertificates

        init {
            itemBinding.root.setOnClickListener(this)
        }

        fun bind(item: InTransportWithCertificates) {
            this.item = item

            val resId: Int =
                when {
                    item.transport.itemCountError > 0 -> {
                        R.color.status_container_error
                    }
                    item.transport.itemCountScanned == item.transport.itemCount -> {
                        R.color.status_container_success
                    }
                    else -> {
                        R.color.status_container_empty
                    }
                }

            val isCar = item.transport.name.any { it.isLetter() }
            val withError = item.transport.itemCountError > 0

            itemBinding.image2.visibility = if (isCar) View.VISIBLE else View.GONE
            itemBinding.image1.visibility = if (isCar) View.GONE else View.VISIBLE

            itemBinding.viewRoot.setBackgroundResource(
                when {
                    item.transport.itemCountScanned == item.transport.itemCount ->
                        R.drawable.background_green
                    item.transport.itemCountScanned > 0 -> R.drawable.background_yellow
                    else -> R.drawable.background_empty
                })

            itemBinding.viewMark.setBackgroundResource(resId)

            val sb = StringBuilder()

            sb.append("${item.active?.name ?: "-"}\n")
            sb.append("ТТН: ${(item.transport.ttn.ifEmpty { "-" })}\n")
            sb.append("НЕТТО, т: ${item.transport.weight.format(3)}\n")

            sb.append("Серт.: ")

            if (item.certificates.isNotEmpty()) {
                item.certificates.forEachIndexed { index, certificate ->
                    sb.append(certificate.code)
                    if (index + 1 < item.certificates.size) sb.append(", ")
                }
            } else {
                sb.append("-")
            }

            itemBinding.text1.text = item.transport.name
            itemBinding.text2.text = sb.toString()
            itemBinding.itemCount.text = item.transport.itemCount.toString()
            itemBinding.itemSuccessCount.text = item.transport.itemCountScanned.toString()
            itemBinding.itemErrorCount.text = item.transport.itemCountError.toString()
            itemBinding.buttonSync.visibility =
                if (item.transport.itemCountScanned > 0) View.VISIBLE else View.GONE

            itemBinding.itemErrorDelimiter.visibility = if (withError) View.VISIBLE else View.GONE
            itemBinding.itemErrorCount.visibility = if (withError) View.VISIBLE else View.GONE

            itemBinding.buttonSync.setOnClickListener { eventClickSync.postValue(item) }
        }

        override fun onClick(v: View?) {
            eventClick.postValue(item)
        }
    }
}
