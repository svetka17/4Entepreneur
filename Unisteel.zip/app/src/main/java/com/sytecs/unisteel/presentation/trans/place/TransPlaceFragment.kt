package com.sytecs.unisteel.presentation.trans.place

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.setFragmentResult
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.Place
import com.sytecs.unisteel.databinding.TransPlaceFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber

@AndroidEntryPoint
class TransPlaceFragment : AppFragment() {

    private val args by navArgs<TransPlaceFragmentArgs>()

    private var binding: TransPlaceFragmentBinding by autoCleared()
    private val viewModel: TransPlaceViewModel by viewModels()

    private var currentPlace: Place? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = TransPlaceFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        binding.textStorage.text = args.storage.name

        setupObservers()

        binding.buttonBack.setOnClickListener { goBack() }

        binding.buttonSave.setOnClickListener {
            currentPlace?.let {
                setFragmentResult(
                    "nav_trans_place", bundleOf("barcodeItem" to args.barcodeItem, "place" to it))
            }
            goBack()
        }

        binding.buttonPlace.setOnClickListener {
            viewModel.data.value?.let { showList(it, currentPlace) }
        }

        setPlace(null)
    }

    private fun setupObservers() {
        observe(viewModel.data) { Timber.d("Loaded ${it.size} places!") }

        observeEvent(onListItemSelected) {
            when (it) {
                is Place -> setPlace(it)
            }
        }

        observeEvent(viewModel.eventBeep) { playScanError() }

        observeEvent(viewModel.eventAlert) { event ->
            showAlert(Options(event.first, event.second))
        }

        observeEvent(viewModel.eventPlace) { setPlace(it) }

        observeEvent(viewModel.eventPlaceReady) {
            if (isValid()) {
                binding.buttonSave.performClick()
            }
        }
    }

    private fun setPlace(place: Place?) {
        this.currentPlace = place
        binding.buttonPlace.text = place?.name ?: getString(R.string.spinner_placeholder)
        updateValidation()
    }

    private fun isValid() = currentPlace != null

    private fun updateValidation() {
        binding.buttonSave.visibility = if (isValid()) View.VISIBLE else View.GONE
    }

    override fun onBarcodeText(text: String) {
        // binding.textBarcode.setText(text)
        viewModel.onBarcodeText(text)
    }
}
