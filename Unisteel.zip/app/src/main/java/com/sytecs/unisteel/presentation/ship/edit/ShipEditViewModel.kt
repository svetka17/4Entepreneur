package com.sytecs.unisteel.presentation.ship.edit

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.data.entities.db.ShipTask
import com.sytecs.unisteel.data.repository.RepoShip
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ShipEditViewModel
@Inject
constructor(
    private val repoShip: RepoShip,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {

    private val task: ShipTask
        get() = savedStateHandle.get<ShipTask>("task")!!

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    val eventSaved = SingleLiveEvent<Unit>()

    fun save(transportName: String, driverFio: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            repoShip.editTask(task, transportName, driverFio)
            eventSaved.postValue(Unit)
            _isLoading.postValue(false)
        }
    }
}
