package com.sytecs.unisteel.device.scanner

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import timber.log.Timber

class ZebraScanner : BaseScanner() {

    private val ACTIVITY_INTENT_FILTER_ACTION = "com.sytecs.barcode.ACTION"
    private val DATAWEDGE_INTENT_KEY_SOURCE = "com.symbol.datawedge.source"
    private val DATAWEDGE_INTENT_KEY_LABEL_TYPE = "com.symbol.datawedge.label_type"
    private val DATAWEDGE_INTENT_KEY_DATA = "com.symbol.datawedge.data_string"
    private val DATAWEDGE_INTENT_KEY_SOURCE_LEGACY = "com.motorolasolutions.emdk.datawedge.source"
    private val DATAWEDGE_INTENT_KEY_LABEL_TYPE_LEGACY =
        "com.motorolasolutions.emdk.datawedge.label_type"
    private val DATAWEDGE_INTENT_KEY_DATA_LEGACY =
        "com.motorolasolutions.emdk.datawedge.data_string"
    private val ACTION_RESULT = "com.symbol.datawedge.api.RESULT_ACTION"
    private val ACTION_DATA_WEDGE = "com.symbol.datawedge.api.ACTION"
    private val EXTRA_PROFILE_NAME: String
        get() = packageName
    private val EXTRA_SET_CONFIG = "com.symbol.datawedge.api.SET_CONFIG"
    private val EXTRA_CREATE_PROFILE = "com.symbol.datawedge.api.CREATE_PROFILE"
    private val EXTRA_GET_PROFILE_LIST = "com.symbol.datawedge.api.GET_PROFILES_LIST"
    private val RESULT_GET_PROFILE_LIST = "com.symbol.datawedge.api.RESULT_GET_PROFILES_LIST"

    private var scanFilter: IntentFilter? = null
    private var scanReceiver: BroadcastReceiver? = null

    override fun create(appContext: Context) {
        super.create(appContext)
        checkProfiles()

        scanFilter =
            IntentFilter().apply {
                addCategory(Intent.CATEGORY_DEFAULT)
                addAction(ACTIVITY_INTENT_FILTER_ACTION)
            }

        scanReceiver =
            object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    if (intent == null) return
                    if (intent.action.equals(ACTIVITY_INTENT_FILTER_ACTION, true)) {
                        var decodedSource = intent.getStringExtra(DATAWEDGE_INTENT_KEY_SOURCE)
                        var decodedData = intent.getStringExtra(DATAWEDGE_INTENT_KEY_DATA)
                        var decodedLabelType =
                            intent.getStringExtra(DATAWEDGE_INTENT_KEY_LABEL_TYPE)
                        if (decodedSource == null) {
                            decodedSource =
                                intent.getStringExtra(DATAWEDGE_INTENT_KEY_SOURCE_LEGACY)
                            decodedData = intent.getStringExtra(DATAWEDGE_INTENT_KEY_DATA_LEGACY)
                            decodedLabelType =
                                intent.getStringExtra(DATAWEDGE_INTENT_KEY_LABEL_TYPE_LEGACY)
                        }
                        decodedData?.let { onBarcode(it) }
                    }
                }
            }
    }

    private fun checkProfiles() {
        var receiver: BroadcastReceiver? = null

        receiver =
            object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    if (intent == null) return
                    if (intent.action == ACTION_RESULT &&
                        intent.hasExtra(RESULT_GET_PROFILE_LIST)) {
                        val profileList = intent.getStringArrayExtra(RESULT_GET_PROFILE_LIST)
                        val profileExist =
                            profileList?.any { profileName ->
                                profileName.equals(EXTRA_PROFILE_NAME, true)
                            }
                                ?: false
                        if (profileExist) {
                            Timber.d("Profile \"$EXTRA_PROFILE_NAME\" exist!")
                        } else {
                            Timber.d("Profile \"$EXTRA_PROFILE_NAME\" not exist!")
                            createProfile()
                        }
                        appContext?.unregisterReceiver(receiver)
                    }
                }
            }
        appContext?.registerReceiver(
            receiver,
            IntentFilter().apply {
                addCategory(Intent.CATEGORY_DEFAULT)
                addAction(ACTION_RESULT)
            })

        appContext?.sendBroadcast(
            Intent().apply {
                action = ACTION_DATA_WEDGE
                putExtra(EXTRA_GET_PROFILE_LIST, "")
            })
    }

    private fun createProfile() {
        appContext?.sendBroadcast(
            Intent().apply {
                action = ACTION_DATA_WEDGE
                putExtra(EXTRA_CREATE_PROFILE, EXTRA_PROFILE_NAME)
                putExtra("SEND_RESULT", "true")
            })

        // Configure created profile to apply to this app
        val profileConfig = Bundle()
        profileConfig.putString("PROFILE_NAME", EXTRA_PROFILE_NAME)
        profileConfig.putString("PROFILE_ENABLED", "true")
        profileConfig.putString("CONFIG_MODE", "OVERWRITE")

        // Configure barcode input plugin
        val barcodeConfig = Bundle()
        barcodeConfig.putString("PLUGIN_NAME", "BARCODE")
        barcodeConfig.putString("RESET_CONFIG", "true") //  This is the default
        val barcodeProps = Bundle()
        barcodeConfig.putBundle("PARAM_LIST", barcodeProps)
        profileConfig.putBundle("PLUGIN_CONFIG", barcodeConfig)

        // Associate profile with this app
        val appConfig = Bundle()
        appConfig.putString("PACKAGE_NAME", packageName)
        appConfig.putStringArray("ACTIVITY_LIST", arrayOf("*"))
        profileConfig.putParcelableArray("APP_LIST", arrayOf(appConfig))
        profileConfig.remove("PLUGIN_CONFIG")
        val bundleKSOutConfig = Bundle()
        bundleKSOutConfig.putString("PLUGIN_NAME", "KEYSTROKE")
        bundleKSOutConfig.putString("RESET_CONFIG", "false")
        val bundleKSParams = Bundle()
        bundleKSParams.putString("keystroke_output_enabled", "false")
        bundleKSOutConfig.putBundle("PARAM_LIST", bundleKSParams)

        // Configure intent output for captured data to be sent to this app
        val intentConfig = Bundle()
        intentConfig.putString("PLUGIN_NAME", "INTENT")
        intentConfig.putString("RESET_CONFIG", "true")
        val intentProps = Bundle()
        intentProps.putString("intent_output_enabled", "true")
        intentProps.putString("intent_action", ACTIVITY_INTENT_FILTER_ACTION)
        intentProps.putString("intent_delivery", "2")

        // Add each bundle to the profile configuration
        val bundlePluginConfig: ArrayList<Bundle> = ArrayList()
        bundlePluginConfig.add(barcodeConfig)
        bundlePluginConfig.add(intentConfig)
        bundlePluginConfig.add(bundleKSOutConfig)
        intentConfig.putBundle("PARAM_LIST", intentProps)
        profileConfig.putParcelableArrayList("PLUGIN_CONFIG", bundlePluginConfig)

        appContext?.sendBroadcast(
            Intent().apply {
                action = ACTION_DATA_WEDGE
                putExtra(EXTRA_SET_CONFIG, profileConfig)
                putExtra("SEND_RESULT", "true")
            })
    }

    override fun start() {
        super.start()
        try {
            appContext?.registerReceiver(scanReceiver, scanFilter)
        } catch (ignored: Exception) {}
    }

    override fun stop() {
        super.stop()
        try {
            appContext?.unregisterReceiver(scanReceiver)
        } catch (ignored: Exception) {}
    }
}
