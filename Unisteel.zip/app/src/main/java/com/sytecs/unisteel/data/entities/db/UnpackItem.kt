package com.sytecs.unisteel.data.entities.db

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.util.*

@Parcelize
@Entity(tableName = "unpack_items")
data class UnpackItem(
    @PrimaryKey(autoGenerate = true) val id: Long,
    @ColumnInfo(index = true) val taskId: Long,
    val steelGrade: String,
    val thickness: String,
    val width: String,
    val weight: Double,
    val nomenclature: String,
    val serial: String,
    val barcode: String,
    val qr: String,
    val qrId: String?,
    val created: Date,
    var unpackCreated: Date?,
    var unpackBarcode: String?,
    var errorMessage: String?
) : Parcelable
