package com.sytecs.unisteel.presentation.inv.items

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.BarcodeItem
import com.sytecs.unisteel.data.entities.db.InvItem
import com.sytecs.unisteel.data.entities.db.InvTask
import com.sytecs.unisteel.data.entities.db.Storage
import com.sytecs.unisteel.data.repository.RepoInv
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.parseItemQr
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class InvItemsViewModel
@Inject
constructor(
    private val repoInv: RepoInv,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {

    private val task: InvTask
        get() = savedStateHandle.get<InvTask>("task")!!
    private val storage: Storage
        get() = savedStateHandle.get<Storage>("storage")!!

    val data: LiveData<List<InvItem>> = repoInv.itemList(task)

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    val eventBack = SingleLiveEvent<Unit>()
    val eventBeep = SingleLiveEvent<Unit>()
    val eventScrollUp = SingleLiveEvent<Unit>()
    val eventToast = SingleLiveEvent<String>()
    val eventAlert = SingleLiveEvent<Pair<String, String?>>()
    val eventSync = SingleLiveEvent<Resource<Boolean>>()

    fun onManualItem(nomenclatureSerial: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repoInv.findItem(nomenclatureSerial)?.let {
                if (it.task != task) {
                    eventAlert.postValue(
                        Pair(
                            res.getString(
                                R.string.inv_item_already_scanned_in_storage,
                                dateFormat.format(it.task.date),
                                it.storage.name),
                            null))
                    eventBeep.postValue(Unit)
                    return@launch
                }
            }

            val itemInv = repoInv.findItem(nomenclatureSerial, task)

            if (itemInv != null) {
                eventAlert.postValue(Pair(res.getString(R.string.inv_item_already_scanned), null))
                eventBeep.postValue(Unit)
                return@launch
            }

            saveItem(nomenclatureSerial)
        }
    }

    fun onBarcodeText(text: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val item = parseItemQr(text)

            if (item == null) {
                eventAlert.postValue(Pair(text, res.getString(R.string.inv_item_invalid)))
                eventBeep.postValue(Unit)
                return@launch
            }

            repoInv.findItem(item)?.let {
                if (it.task != task) {
                    eventAlert.postValue(
                        Pair(
                            res.getString(
                                R.string.inv_item_already_scanned_in_storage,
                                dateFormat.format(it.task.date),
                                it.storage.name),
                            null))
                    eventBeep.postValue(Unit)
                    return@launch
                }
            }

            val itemInv = repoInv.findItem(item, task)

            if (itemInv != null) {
                eventAlert.postValue(Pair(res.getString(R.string.inv_item_already_scanned), null))
                eventBeep.postValue(Unit)
                return@launch
            }

            saveItem(item)
        }
    }

    private suspend fun saveItem(nomenclatureSerial: String) {
        repoInv.addItem(task, nomenclatureSerial)
        eventScrollUp.postValue(Unit)
    }

    private suspend fun saveItem(barcodeItem: BarcodeItem) {
        repoInv.addItem(task, barcodeItem)
        eventScrollUp.postValue(Unit)

        if (!barcodeItem.isQr) {
            viewModelScope.launch(Dispatchers.IO) { repoInv.loadBarcode(barcodeItem, task) }
        }
    }

    fun removeItems() {
        viewModelScope.launch(Dispatchers.IO) { repoInv.removeTaskItems(task) }
    }

    fun removeItem(item: InvItem) {
        viewModelScope.launch(Dispatchers.IO) { repoInv.removeItem(item) }
    }

    fun removeTask() {
        viewModelScope.launch(Dispatchers.IO) {
            repoInv.removeTask(task)
            eventBack.postValue(Unit)
        }
    }

    fun syncData(task: InvTask) {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            val res = repoInv.uploadItems(task)
            _isLoading.postValue(false)
            eventSync.postValue(res)
        }
    }
}
