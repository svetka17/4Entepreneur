package com.sytecs.unisteel.presentation.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.sytecs.unisteel.R
import com.sytecs.unisteel.databinding.HomeFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class HomeFragment : AppFragment() {

    private var binding: HomeFragmentBinding by autoCleared()
    private val viewModel: HomeViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = HomeFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        setupObservers()

        binding.buttonBack.setOnClickListener { goBack() }

        binding.buttonInfo.setOnClickListener { viewModel.onPermissionsClick() }

        binding.buttonInv.setOnClickListener {
            navigate(HomeFragmentDirections.actionHomeFragmentToInvListFragment())
        }

        binding.buttonUnpack.setOnClickListener {
            navigate(HomeFragmentDirections.actionHomeFragmentToUnpackListFragment())
        }

        binding.buttonIn.setOnClickListener {
            navigate(HomeFragmentDirections.actionHomeFragmentToInListFragment())
        }

        binding.buttonTrans.setOnClickListener {
            navigate(HomeFragmentDirections.actionHomeFragmentToTransListFragment(4))
        }

        binding.buttonTransPlace.setOnClickListener {
            navigate(HomeFragmentDirections.actionHomeFragmentToTransListFragment(5))
        }

        binding.buttonShip.setOnClickListener {
            navigate(HomeFragmentDirections.actionHomeFragmentToShipListFragment())
        }
    }

    private fun setupObservers() {

        observe(viewModel.accessList) {
            binding.buttonInv.isEnabled = it.any { access -> access.code == 1 }
            binding.buttonIn.isEnabled = it.any { access -> access.code == 2 }
            binding.buttonUnpack.isEnabled = it.any { access -> access.code == 3 }
            binding.buttonTrans.isEnabled = it.any { access -> access.code == 4 }
            binding.buttonTransPlace.isEnabled = it.any { access -> access.code == 5 }
            binding.buttonShip.isEnabled = it.any { access -> access.code == 6 }
        }

        observeEvent(viewModel.eventPermissions) {
            showAlert(
                Options(
                    message = it,
                    isCentered = false,
                    title = getString(R.string.home_permissions_title)))
        }
    }

    override fun onBarcodeText(text: String) {
        playScanError()
    }
}
