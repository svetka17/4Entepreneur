package com.sytecs.unisteel.data.entities.db

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.util.*

@Parcelize
@Entity(tableName = "trans_tasks")
data class TransTask(
    @PrimaryKey(autoGenerate = true) var id: Long,
    @ColumnInfo(index = true) val process: Int,
    @ColumnInfo(index = true) val storageCode: String,
    val created: Date,
    val itemCount: Int,
    val itemCountError: Int
) : Parcelable
