package com.sytecs.unisteel.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sytecs.unisteel.data.entities.db.InvTask
import com.sytecs.unisteel.data.entities.embedded.InvTaskWithStorage
import java.util.*

@Dao
interface InvTaskDao {

    @Query("SELECT count(1) FROM inv_tasks") fun getCount(): Long

    @Query("SELECT * FROM inv_tasks") fun getAll(): List<InvTask>

    @Query("SELECT * FROM inv_tasks WHERE id = :id") fun get(id: Long): InvTask?

    @Query("SELECT * FROM inv_tasks WHERE date = :date AND storageCode = :storageCode")
    fun getByDateStorage(date: Date, storageCode: String): InvTask?

    @Transaction
    @Query("SELECT * FROM inv_tasks ORDER BY id DESC")
    fun getWithStorageLiveData(): LiveData<List<InvTaskWithStorage>>

    @Transaction
    @Query("SELECT * FROM inv_tasks ORDER BY id DESC")
    fun getWithStorage(): List<InvTaskWithStorage>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<InvTask>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: InvTask): Long

    @Update fun update(row: InvTask)

    @Delete fun delete(row: InvTask)

    @Query("DELETE FROM inv_tasks") fun truncate()

    @Query(
        "UPDATE inv_tasks SET " +
            "itemCount = (SELECT COUNT(1) FROM inv_items WHERE inv_items.taskId = inv_tasks.id), " +
            "itemCountError = (SELECT COUNT(1) FROM inv_items WHERE inv_items.taskId = inv_tasks.id AND inv_items.errorMessage IS NOT NULL)")
    fun updateStat()

    @Query("DELETE FROM inv_tasks WHERE itemCount = 0") fun cleanEmpty()

    @Query("DELETE FROM inv_tasks WHERE itemCount = 0 AND id = :taskId")
    fun cleanEmptyByTask(taskId: Long)
}
