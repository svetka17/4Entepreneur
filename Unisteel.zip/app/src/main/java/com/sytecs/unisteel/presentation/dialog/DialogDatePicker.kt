package com.sytecs.unisteel.presentation.dialog

import android.app.DatePickerDialog
import android.content.Context
import java.util.*

class DialogDatePicker(private val listener: DatePickerListener) {

    fun interface DatePickerListener {
        fun onDateSelected(selectedDate: Date)
    }

    companion object {
        fun show(context: Context, selectedDate: Date? = null, listener: DatePickerListener) {
            DialogDatePicker(listener).show(context, selectedDate)
        }
    }

    fun show(context: Context, selectedDate: Date? = null) {
        val cal = Calendar.getInstance()
        selectedDate?.let { cal.time = it }

        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH)
        val day = cal.get(Calendar.DAY_OF_MONTH)
        DatePickerDialog(
                context,
                { _, _year, _month, _dayOfMonth ->
                    listener.onDateSelected(
                        Calendar.getInstance().apply { set(_year, _month, _dayOfMonth) }.time)
                },
                year,
                month,
                day)
            .show()
    }
}
