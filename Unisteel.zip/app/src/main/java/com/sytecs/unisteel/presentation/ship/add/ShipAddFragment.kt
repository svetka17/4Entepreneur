package com.sytecs.unisteel.presentation.ship.add

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.sytecs.unisteel.R
import com.sytecs.unisteel.databinding.ShipAddFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ShipAddFragment : AppFragment() {

    private var binding: ShipAddFragmentBinding by autoCleared()
    private val viewModel: ShipAddViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = ShipAddFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        setupObservers()

        binding.buttonBack.setOnClickListener { goBack() }

        binding.buttonSave.setOnClickListener { viewModel.save(binding.textName.text.toString()) }
    }

    private fun setupObservers() {

        observeEvent(viewModel.eventSaved) {
            if (it.isSuccess) {
                showToast(getString(R.string.text_saved))
                goBack()
            } else {
                showAlert(Options(it.message))
            }
        }

        observeEvent(viewModel.eventAlert) { event ->
            showAlert(Options(event.first, event.second))
        }
    }
}
