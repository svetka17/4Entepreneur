package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JUnpackResult(
    @SerializedName("DocDate") val docDate: String,
    @SerializedName("EvProizv") val positions: List<JPosition>
) {
    data class JPosition(
        @SerializedName("Marka") val steelGrade: String,
        @SerializedName("Nomenklatura") val nomenclature: String,
        @SerializedName("QR") val qrCode: String,
        @SerializedName("Seriya") val serial: String,
        @SerializedName("Shirina") val width: String,
        @SerializedName("ShtrixCode") val barcode: String,
        @SerializedName("Tolshina") val thickness: String,
        @SerializedName("Ves") val weight: Double
    )
}
