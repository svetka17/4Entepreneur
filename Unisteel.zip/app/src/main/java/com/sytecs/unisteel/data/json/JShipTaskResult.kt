package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JShipTaskResult(
    @SerializedName("EvNomerZayavky") val taskNumber: String?,
    @SerializedName("EvDateZayavky") val taskDate: String?,
    @SerializedName("EvNomerTS") val transportName: String?,
    @SerializedName("EvVoditely") val driverName: String?,
    @SerializedName("EvPoluchately") val consigneeName: String?,
    @SerializedName("EvTSType") val transportType: String?,
    @SerializedName("EvOtgrugenaVsyaZayavka") val isFinished: Boolean?,
    @SerializedName("POSITIONS") val positions: List<JPosition>
) {
    data class JPosition(
        @SerializedName("Marka") val steelGrade: String,
        @SerializedName("Tolshina") val thickness: String,
        @SerializedName("Shirina") val width: String,
        @SerializedName("Ves") val weight: Double,
        @SerializedName("Nomenklatura") val nomenclature: String,
        @SerializedName("Seriya") val serial: String,
        @SerializedName("ShtrixCode") val barcode: String,
        @SerializedName("QR") val qrCode: String,
        @SerializedName("CodeSklad") val storageCode: String,
        @SerializedName("mesto") val placeName: String,
        @SerializedName("VesBrutto") val gross: Double,
        @SerializedName("VesBrutto2") val gross2: Double,
        @SerializedName("Spec") val spec: String,
        @SerializedName("NomerPP") val number: Int,
        @SerializedName("Otgrugeno") val isShipped: Boolean
    )
}
