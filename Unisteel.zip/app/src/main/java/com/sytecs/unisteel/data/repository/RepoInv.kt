package com.sytecs.unisteel.data.repository

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.sytecs.unisteel.data.entities.BarcodeItem
import com.sytecs.unisteel.data.entities.db.InvItem
import com.sytecs.unisteel.data.entities.db.InvTask
import com.sytecs.unisteel.data.entities.db.Storage
import com.sytecs.unisteel.data.entities.embedded.InvItemWithTaskStorage
import com.sytecs.unisteel.data.json.JUploadInv
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.now
import com.sytecs.unisteel.utils.removeTime
import okhttp3.RequestBody.Companion.toRequestBody
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

class RepoInv @Inject constructor(private val repo: Repo) {

    fun taskList() = repo.local.invTaskDao().getWithStorageLiveData()
    fun itemList(task: InvTask) = repo.local.invItemDao().getByTaskLiveData(task.id)

    suspend fun addTask(date: Date, storage: Storage): Boolean {
        repo.local.invTaskDao().insert(InvTask(0, date.removeTime(), storage.code, now(), 0, 0))
        return true
    }

    fun removeTask(task: InvTask): Boolean {
        repo.local.invItemDao().deleteByTask(task.id)
        repo.local.invTaskDao().delete(task)
        updateStat()
        return true
    }

    fun removeItem(item: InvItem): Boolean {
        repo.local.invItemDao().delete(item)
        updateStat()
        return true
    }

    fun removeTaskItems(task: InvTask): Boolean {
        repo.local.invItemDao().deleteByTask(task.id)
        updateStat()
        return true
    }

    suspend fun addItem(task: InvTask, nomenclatureSerial: String): Boolean {
        repo.local
            .invItemDao()
            .insert(
                InvItem(
                    id = 0,
                    taskId = task.id,
                    isQr = false,
                    idCode = null,
                    factoryCode = null,
                    accountSystem = null,
                    shopNumber = null,
                    verificationCode = null,
                    checkCode = null,
                    meltingNumber = null,
                    batchNumber = null,
                    itemNumber = null,
                    net = null,
                    gross = null,
                    productType = null,
                    size = null,
                    steelBrand = null,
                    orderNumber = null,
                    year = null,
                    pak = null,
                    barcodeText = nomenclatureSerial,
                    created = now(),
                    errorMessage = null,
                    barcodeSerial = nomenclatureSerial,
                    isManual = true))
        updateStat()
        return true
    }

    suspend fun addItem(task: InvTask, item: BarcodeItem): Boolean {
        repo.local
            .invItemDao()
            .insert(
                InvItem(
                    id = 0,
                    taskId = task.id,
                    isQr = item.isQr,
                    idCode = item.idCode,
                    factoryCode = item.factoryCode,
                    accountSystem = item.accountSystem,
                    shopNumber = item.shopNumber,
                    verificationCode = item.verificationCode,
                    checkCode = item.checkCode,
                    meltingNumber = item.meltingNumber,
                    batchNumber = item.batchNumber,
                    itemNumber = item.itemNumber,
                    net = item.net,
                    gross = item.gross,
                    productType = item.productType,
                    size = item.size,
                    steelBrand = item.steelBrand,
                    orderNumber = item.orderNumber,
                    year = item.year,
                    pak = item.pak,
                    barcodeText = item.text,
                    created = now(),
                    errorMessage = null,
                    barcodeSerial = null,
                    isManual = false))
        updateStat()
        return true
    }

    private fun updateStat() {
        repo.local.invTaskDao().updateStat()
    }

    fun findItem(nomenclatureSerial: String, task: InvTask? = null): InvItemWithTaskStorage? {

        val res =
            if (task == null) repo.local.invItemDao().findItemByBarcode(nomenclatureSerial)
            else repo.local.invItemDao().findItemByBarcodeTask(nomenclatureSerial, task.id)

        if (res == null) return null

        val storage = repo.local.storageDao().get(res.task.storageCode) ?: return null

        return InvItemWithTaskStorage(item = res.item, task = res.task, storage = storage)
    }

    fun findItem(item: BarcodeItem, task: InvTask? = null): InvItemWithTaskStorage? {

        val res =
            if (task == null) repo.local.invItemDao().findItemByBarcode(item.text)
            else repo.local.invItemDao().findItemByBarcodeTask(item.text, task.id)

        if (res == null) return null

        val storage = repo.local.storageDao().get(res.task.storageCode) ?: return null

        return InvItemWithTaskStorage(item = res.item, task = res.task, storage = storage)
    }

    fun findTask(date: Date, storage: Storage): InvTask? {
        return repo.local.invTaskDao().getByDateStorage(date.removeTime(), storage.code)
    }

    fun deleteTasks() {
        repo.local.invItemDao().truncate()
        repo.local.invTaskDao().truncate()
    }

    suspend fun uploadItems(task: InvTask): Resource<Boolean> {
        val items = repo.local.invItemDao().getByTask(task.id)
        return uploadItems(items, task)
    }

    private suspend fun uploadItems(items: List<InvItem>, task: InvTask): Resource<Boolean> {

        // Timber.w("Upload ${items.size} items!")
        // return Resource.error("Виконано з помилками, перегляньте відмічені позиції")

        val dateTimeFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault())

        val positions = mutableListOf<JUploadInv.Position>()

        for (item in items) {

            positions.add(
                JUploadInv.Position(
                    qrCode = (if (item.isQr) item.barcodeText else null) ?: "",
                    barcode = (if (!item.isQr && !item.isManual) item.barcodeText else null) ?: "",
                    serial = (if (!item.isQr && item.isManual) item.barcodeText else null) ?: "",
                    userLogin = repo.userNameApi,
                    scanDate = dateTimeFormat.format(item.created),
                    comment = ""))
        }

        val uploadStruct =
            JUploadInv(
                storageCode = task.storageCode,
                date = dateTimeFormat.format(task.date),
                positions = positions,
                comment = "")

        val json = JsonObject()
        json.addProperty("SkladCode", uploadStruct.storageCode)
        json.addProperty("Datedoc", uploadStruct.date)
        json.addProperty("Comment", uploadStruct.comment)

        val arr = JsonArray(positions.size)
        positions.forEach { pos ->
            arr.add(
                JsonObject().also {
                    it.addProperty("date", pos.scanDate)
                    it.addProperty("user", pos.userLogin)
                    it.addProperty("seriya", pos.serial)
                    it.addProperty("ShtrixCode", pos.barcode)
                    it.addProperty("QR", pos.qrCode)
                    it.addProperty("CommentSeriya", pos.comment)
                })
        }
        json.add("POSITIONS", arr)

        val raw = json.toString()

        val res = repo.remote.postInvRaw(raw.toRequestBody())
        // val res = repo.remote.postInv(uploadStruct)

        if (res.isError) {
            return Resource.error(res.message)
        }

        if (res.data == null) {
            return Resource.error("Data error")
        }

        val data = res.data

        var allOk = true

        items.forEach { item ->
            val itemIsQr = item.isQr
            val itemIsBarcode = !item.isQr && !item.isManual
            val itemIsManual = !item.isQr && item.isManual

            val remoteItem =
                when {
                    itemIsQr ->
                        data.firstOrNull { item2 -> Objects.equals(item.barcodeText, item2.qrCode) }
                    itemIsBarcode ->
                        data.firstOrNull { item2 ->
                            Objects.equals(item.barcodeText, item2.barcode)
                        }
                    itemIsManual ->
                        data.firstOrNull { item2 -> Objects.equals(item.barcodeText, item2.serial) }
                    else -> null
                }

            //            remoteItem?.let {
            //                remoteItem.error = "test error!"
            //            }

            if (remoteItem?.error?.isNotEmpty() == true) {
                item.errorMessage = remoteItem.error
                repo.local.invItemDao().update(item)
                allOk = false
            } else {
                repo.local.invItemDao().delete(item)
            }
        }

        updateStat()
        clearEmptyData(task)

        return if (allOk) Resource.success(true)
        else Resource.error("Виконано з помилками, перегляньте відмічені позиції")
    }

    private fun clearEmptyData(task: InvTask? = null) {
        if (task != null) {
            repo.local.invTaskDao().cleanEmptyByTask(task.id)
        } else {
            repo.local.invTaskDao().cleanEmpty()
        }
    }

    suspend fun loadBarcode(item: BarcodeItem, task: InvTask) {
        val res = repo.remote.getBarcode(item.text)

        if (res.status == Resource.Status.ERROR ||
            res.data == null ||
            res.data.positions.isEmpty()) {
            Timber.d("Error loading barcode info: ${res.message}")
            return
        }

        val position = res.data.positions.first()

        findItem(item, task)?.let {
            it.item.apply {
                size = "${position.thickness}x${position.width}"
                net = position.netto
                gross = position.gross
                barcodeSerial = position.serial
            }
            repo.local.invItemDao().update(it.item)
        }

        Timber.d("Barcode info: $position")
    }
}
