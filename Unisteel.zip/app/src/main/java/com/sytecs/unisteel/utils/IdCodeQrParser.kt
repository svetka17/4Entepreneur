package com.sytecs.unisteel.utils

import com.sytecs.unisteel.data.entities.BarcodeItem

class IdCodeQrParser(private val barcode: String) {
    fun parse(): BarcodeItem? {
        if (barcode.length == 13) {
            return BarcodeItem(false, barcode)
        }
        return null
    }
}
