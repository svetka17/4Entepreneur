package com.sytecs.unisteel.presentation.ship.list

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.ShipTask
import com.sytecs.unisteel.databinding.ShipListFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.presentation.ship.base.DialogSync
import com.sytecs.unisteel.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ShipListFragment : AppFragment() {

    // private val args by navArgs<ShipListFragmentArgs>()
    private var binding: ShipListFragmentBinding by autoCleared()
    private val viewModel: ShipListViewModel by viewModels()
    private lateinit var adapter: ShipTaskAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = ShipListFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        binding.buttonBack.setOnClickListener { goBack() }
        binding.buttonAdd.setOnClickListener {
            navigate(ShipListFragmentDirections.actionShipListFragmentToShipAddFragment())
        }
        binding.buttonRefresh.visibility = View.GONE

        binding.buttonClear.setOnClickListener {
            showConfirm(Options(getString(R.string.ship_clear_all_confirm))) {
                viewModel.removeItems()
            }
        }

        setupRecyclerView()
        setupObservers()

        initFilter(binding.searchLayout, binding.buttonFilter)
    }

    private fun setupRecyclerView() {
        adapter = ShipTaskAdapter()
        binding.listRv.adapter = adapter
    }

    private fun setupObservers() {
        observe(viewModel.data) {
            adapter.setItems(it)
            adapter.filter.filter(filterQuery)

            val itemCount = it.sumOf { item -> item.itemCount }
            val itemScanCount = it.sumOf { item -> item.itemCountScanned }
            val itemErrorCount = it.sumOf { item -> item.itemCountError }

            binding.itemCount.text = itemCount.toString()
            binding.itemScanCount.text = itemScanCount.toString()

            binding.itemErrorCount.text = itemErrorCount.toString()
            binding.itemErrorCount.visibility = if (itemErrorCount > 0) View.VISIBLE else View.GONE
            binding.itemErrorCountDelimiter.visibility =
                if (itemErrorCount > 0) View.VISIBLE else View.GONE

            binding.itemScanCount.visibility = if (itemScanCount > 0) View.VISIBLE else View.GONE
            binding.itemScanCountDelimiter.visibility =
                if (itemScanCount > 0) View.VISIBLE else View.GONE

            binding.buttonClear.visibility = if (it.isNotEmpty()) View.VISIBLE else View.GONE
        }

        observeEvent(adapter.eventClick) { openTask(it) }

        observeEvent(adapter.eventClickSync) { item ->
            DialogSync.show(parentFragmentManager, item)?.run {
                observeEvent(onClickPositive) { viewModel.syncData(item, it.comment, it.useAwning) }
            }
        }

        observeEvent(viewModel.eventSync) {
            if (it.isSuccess) {
                showAlert(Options(getString(R.string.text_upload_success)))
            } else if (it.isError) {
                showAlert(Options(it.message))
            }
        }

        observeEvent(eventFilterQuery) { adapter.filter.filter(it) }
    }

    private fun openTask(task: ShipTask) {
        navigate(ShipListFragmentDirections.actionShipListFragmentToShipItemsFragment(task))
    }

    override fun onBarcodeText(text: String) {
        playScanError()
    }
}
