package com.sytecs.unisteel.device

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.content.FileProvider
import com.google.gson.GsonBuilder
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Streaming
import retrofit2.http.Url
import timber.log.Timber
import java.io.*
import javax.inject.Inject
/*
class UpdateService
@Inject
constructor(
    private val context: Context,
    private val baseUrl: String,
    private val listener: IUpdateListener
) : CoroutineScope by CoroutineScope(Dispatchers.IO) {

    data class VersionInfo(
        @SerializedName("version_code") var code: Int,
        @SerializedName("version_name") var name: String,
        @SerializedName("version_date") var date: String,
        @SerializedName("changelog") var changelog: String,
        @SerializedName("fileName") var fileName: String
    )

    private interface NetInterface {
        @GET fun getVersion(@Url url: String): Call<VersionInfo>

        @Streaming @GET fun download(@Url url: String): Call<ResponseBody>
    }

    interface IUpdateListener {
        fun onVersionSuccess(versionInfo: VersionInfo)
        fun onVersionError(e: Throwable)
        fun onUpdateSuccess(versionInfo: VersionInfo)
        fun onUpdateError(e: Throwable)
        fun onUpdateProgress(progressValue: Int)
    }

    private val net =
        Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create(GsonBuilder().create()))
            .client(OkHttpClient.Builder().build())
            .baseUrl(baseUrl)
            .build()
            .create(NetInterface::class.java)

    fun checkVersion() {

        val req = net.getVersion("version.json")

        req.enqueue(
            object : Callback<VersionInfo> {
                override fun onResponse(call: Call<VersionInfo>, response: Response<VersionInfo>) {
                    if (response.isSuccessful && response.body() != null) {
                        listener.onVersionSuccess(response.body()!!)
                    } else {
                        listener.onVersionError(Exception(response.errorBody()?.toString()))
                    }
                }

                override fun onFailure(call: Call<VersionInfo>, t: Throwable) {
                    Timber.e(t, "Failed to check version")
                    listener.onVersionError(t)
                }
            })
    }

    fun run(versionInfo: VersionInfo) {
        val apk = File("${context.getExternalFilesDir("download")?.path}/${versionInfo.fileName}")
        val uri =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                FileProvider.getUriForFile(context, "${context.packageName}.provider", apk)
            else Uri.fromFile(apk)

        val intent = Intent(Intent.ACTION_VIEW)
        intent.setDataAndType(uri, "application/vnd.android.package-archive")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            context.startActivity(intent)
            Timber.d("Run success")
        } catch (e: ActivityNotFoundException) {
            Timber.e(e, "StartActivity failed")
        }
    }

    fun update(versionInfo: VersionInfo) {
        val req = net.download(versionInfo.fileName)

        req.enqueue(
            object : Callback<ResponseBody> {
                override fun onResponse(
                    call: Call<ResponseBody>,
                    response: Response<ResponseBody>
                ) {
                    if (response.isSuccessful) {

                        Timber.d("Response successful")

                        launch {
                            if (response.body()?.let {
                                writeFile(
                                    it,
                                    context.getExternalFilesDir("download")?.path +
                                        "/" +
                                        versionInfo.fileName)
                            } == true) {
                                listener.onUpdateSuccess(versionInfo)
                            } else {
                                listener.onUpdateError(Exception("Could not save file"))
                            }
                        }
                    } else {
                        Timber.d("Failed to download file")
                        listener.onUpdateError(Exception("Failed to download file"))
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    if (call.isCanceled) {
                        Timber.d("Download canceled")
                    } else {
                        Timber.d("Failed to download file")
                        listener.onUpdateError(Exception("Failed to download file"))
                    }
                }
            })
    }

    fun writeFile(body: ResponseBody, filePath: String): Boolean {
        return try {
            val file = File(filePath)
            if (file.exists()) return true
            val totalBytes = body.contentLength()
            var inputStream: InputStream? = null
            var outputStream: OutputStream? = null
            try {
                val fileReader = ByteArray(4096)
                var downloadedBytes: Long = 0
                inputStream = body.byteStream()
                outputStream = FileOutputStream(file)
                var read: Int
                while (inputStream.read(fileReader).also { read = it } != -1) {
                    outputStream.write(fileReader, 0, read)
                    downloadedBytes += read.toLong()
                    val progressValue = (downloadedBytes * 100 / totalBytes).toInt()
                    Timber.d("Download progress $progressValue%%")
                    listener.onUpdateProgress(progressValue)
                }
                outputStream.flush()
                true
            } catch (e: IOException) {
                false
            } finally {
                inputStream?.close()
                outputStream?.close()
            }
        } catch (e: IOException) {
            false
        }
    }
}

 */