package com.sytecs.unisteel.data.entities.db

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.util.*

@Parcelize
@Entity(tableName = "storage_groups")
data class StorageGroup(@PrimaryKey val code: String, val name: String, val created: Date) :
    Parcelable
