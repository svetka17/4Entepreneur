package com.sytecs.unisteel.presentation.ship.base

import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.FragmentManager
import com.sytecs.unisteel.data.entities.db.ShipTask
import com.sytecs.unisteel.databinding.DialogShipUploadBinding
import com.sytecs.unisteel.presentation.base.AppDialog
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.autoCleared

class DialogSync : AppDialog() {

    companion object {
        fun show(manager: FragmentManager, task: ShipTask): DialogSync? {
            if (IsDialogShow) return null
            return newInstance(task).apply { show(manager, null) }
        }

        fun newInstance(task: ShipTask) =
            DialogSync().apply { arguments = bundleOf("task" to task) }
    }

    private var binding: DialogShipUploadBinding by autoCleared()
    val onClickPositive = SingleLiveEvent<DialogSyncResult>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        savedInstanceState?.let { dismiss() }

        binding = DialogShipUploadBinding.inflate(inflater, container, false)

        val task =
            arguments?.getParcelable<ShipTask>("task")
                ?: throw IllegalStateException("Task cannot be null")

        binding.check1.visibility = if (task.isCar) View.VISIBLE else View.GONE

        dialog?.run {
            setCanceledOnTouchOutside(false)
            setCancelable(false)
            setOnKeyListener { _, keyCode, _ -> keyCode == KeyEvent.KEYCODE_BACK }
        }

        binding.buttonYes.setOnClickListener {
            dismiss()
            onClickPositive.postValue(
                DialogSyncResult(binding.edit1.text.toString(), binding.check1.isChecked))
        }

        binding.buttonNo.setOnClickListener { dismiss() }

        return binding.root
    }
}
