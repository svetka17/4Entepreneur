package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JAccessResult(
    @SerializedName("EvDostup") val accessList: List<JAccess>,
    @SerializedName("error") val error: String
) {
    data class JAccess(
        @SerializedName("Code") val code: Int,
        @SerializedName("Dostup") val active: Boolean
    )
}
