package com.sytecs.unisteel.presentation.user

import android.app.Activity
import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.data.msal.MsalResult
import com.sytecs.unisteel.data.repository.Repo
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class UserViewModel
@Inject
constructor(
    private val repo: Repo,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {

    private val _msalStatus = MutableLiveData<MsalResult>()
    val msalStatus: LiveData<MsalResult> = _msalStatus
    val msalError = SingleLiveEvent<String>()

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    val eventDataCheck = SingleLiveEvent<Resource<Boolean>>()

    private val _isProd = MutableLiveData<Boolean>()
    val isProd: LiveData<Boolean> = _isProd

    init {
        beginCheck()
    }

    private fun beginCheck() {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            _msalStatus.postValue(repo.msalCheck())
            _isLoading.postValue(false)
        }
    }

    fun onLoginClick(activity: Activity) {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            val res = repo.msalSignIn(activity)
            if (!res.success && res.exception != null && res.exception !is CancellationException) {
                msalError.postValue(res.exception.message)
            }
            _msalStatus.postValue(res)
            _isLoading.postValue(false)
        }
    }

    fun onLogoutClick() {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            val res = repo.msalSignOut()
            _msalStatus.postValue(res)
            _isLoading.postValue(false)
        }
    }

    fun beginWork() {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            _isProd.postValue(repo.isProd)
            val res = repo.dataCheck()
            if (res.isError) {
                msalError.postValue(res.message)
                beginCheck()
            } else {
                eventDataCheck.postValue(res)
            }
            _isLoading.postValue(false)
        }
    }
}
