package com.sytecs.unisteel.data.entities.db

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.util.*

@Parcelize
@Entity(tableName = "ship_items")
data class ShipItem(
    @PrimaryKey(autoGenerate = true) val id: Long,
    @ColumnInfo(index = true) val taskId: Long,
    val steelGrade: String,
    val thickness: String,
    val width: String,
    val weight: Double,
    val nomenclature: String,
    val serial: String,
    val barcode: String,
    val qr: String,
    val qrId: String?,
    val storageCode: String,
    val placeName: String,
    val gross: Double,
    val gross2: Double,
    val spec: String,
    val number: Int,
    val isShipped: Boolean,
    val created: Date,
    var shipCreated: Date?,
    var shipBarcode: String?,
    var errorMessage: String?
) : Parcelable
