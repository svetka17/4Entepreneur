package com.sytecs.unisteel.presentation.`in`.list

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.setFragmentResultListener
import androidx.fragment.app.viewModels
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.InTransport
import com.sytecs.unisteel.databinding.InListFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber

@AndroidEntryPoint
class InListFragment : AppFragment() {

    private var binding: InListFragmentBinding by autoCleared()
    private val viewModel: InListViewModel by viewModels()
    private lateinit var adapter: InboundAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = InListFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        binding.buttonBack.setOnClickListener { goBack() }
        binding.buttonAdd.setOnClickListener {
            navigate(InListFragmentDirections.actionInListFragmentToInAddFragment())
        }
        binding.buttonRefresh.setOnClickListener {
            showConfirm(Options(getString(R.string.in_upload_confirm))) { viewModel.syncData() }
        }
        binding.buttonClear.setOnClickListener {
            showConfirm(Options(getString(R.string.in_clear_all_confirm))) {
                viewModel.removeItems()
            }
        }

        setupRecyclerView()
        setupObservers()

        setFragmentResultListener("nav_transport") { _, bundle ->
            val qr = bundle.getString("qr")
            val transport = bundle.get("transport") as InTransport
            Timber.d("Transport is $transport")
            openTransport(transport, qr)
        }

        initFilter(binding.searchLayout, binding.buttonFilter)
    }

    private fun setupRecyclerView() {
        adapter = InboundAdapter()
        binding.listRv.adapter = adapter
    }

    private fun setupObservers() {
        observe(viewModel.data) {
            adapter.setItems(it)
            adapter.filter.filter(filterQuery)

            val itemCount = it.sumOf { item -> item.transport.itemCount }
            val itemScanCount = it.sumOf { item -> item.transport.itemCountScanned }
            val itemErrorCount = it.sumOf { item -> item.transport.itemCountError }

            binding.itemCount.text = itemCount.toString()
            binding.itemScanCount.text = itemScanCount.toString()

            binding.itemErrorCount.text = itemErrorCount.toString()
            binding.itemErrorCount.visibility = if (itemErrorCount > 0) View.VISIBLE else View.GONE
            binding.itemErrorCountDelimiter.visibility =
                if (itemErrorCount > 0) View.VISIBLE else View.GONE

            binding.itemScanCount.visibility = if (itemScanCount > 0) View.VISIBLE else View.GONE
            binding.itemScanCountDelimiter.visibility =
                if (itemScanCount > 0) View.VISIBLE else View.GONE

            binding.buttonRefresh.visibility = if (itemScanCount > 0) View.VISIBLE else View.GONE
            binding.buttonClear.visibility = if (it.isNotEmpty()) View.VISIBLE else View.GONE
        }

        observeEvent(adapter.eventClick) { openTransport(it.transport) }

        observeEvent(adapter.eventClickSync) { item ->
            showConfirm(Options(getString(R.string.in_upload_confirm))) {
                viewModel.syncData(item.transport)
            }
        }

        observeEvent(viewModel.eventSync) {
            if (it.isSuccess) {
                showAlert(Options(getString(R.string.text_upload_success)))
            } else if (it.isError) {
                showAlert(Options(it.message))
            }
        }

        observeEvent(eventFilterQuery) { adapter.filter.filter(it) }
    }

    private fun openTransport(transport: InTransport, qr: String? = null) {
        navigate(InListFragmentDirections.actionInListFragmentToInItemsFragment(transport, qr))
    }

    override fun onBarcodeText(text: String) {
        playScanError()
    }
}
