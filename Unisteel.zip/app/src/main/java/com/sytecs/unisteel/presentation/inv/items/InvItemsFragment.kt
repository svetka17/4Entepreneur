package com.sytecs.unisteel.presentation.inv.items

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import com.sytecs.unisteel.R
import com.sytecs.unisteel.databinding.InvItemsFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber
import java.net.URLDecoder

@AndroidEntryPoint
class InvItemsFragment : AppFragment() {

    private val args by navArgs<InvItemsFragmentArgs>()

    private var binding: InvItemsFragmentBinding by autoCleared()
    private val viewModel: InvItemsViewModel by viewModels()
    private val adapter: InvItemAdapter by lazy { InvItemAdapter() }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = InvItemsFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        binding.textTitle.text = getString(R.string.inv_items_title, args.storage.name)

        setupRecyclerView()
        setupObservers()

        binding.buttonBack.setOnClickListener { goBack() }
        binding.buttonAdd.setOnClickListener {
            showInput(
                Options(
                    title = "Додавання позиції",
                    message = "Серія номенклатури",
                    isCentered = false)) {
                if (it.isNotEmpty()) {
                    viewModel.onManualItem(it)
                }
            }
        }
        binding.buttonClear.setOnClickListener {
            showConfirm(Options(getString(R.string.inv_task_clear_confirm))) {
                viewModel.removeTask()
            }
        }
        binding.buttonRefresh.setOnClickListener {
            showConfirm(Options(getString(R.string.inv_upload_confirm))) {
                viewModel.syncData(args.task)
            }
        }
    }

    private fun setupRecyclerView() {
        binding.itemsRv.adapter = adapter
    }

    private fun setupObservers() {
        observe(viewModel.data) {
            adapter.setItems(it)

            val itemCount = it.size
            val itemErrorCount = it.count { item -> item.errorMessage != null }

            binding.itemCount.text = itemCount.toString()
            binding.itemErrorCount.text = itemErrorCount.toString()
            binding.itemErrorCount.visibility = if (itemErrorCount > 0) View.VISIBLE else View.GONE
            binding.itemErrorCountDelimiter.visibility =
                if (itemErrorCount > 0) View.VISIBLE else View.GONE

            binding.buttonClear.visibility = View.VISIBLE

            binding.buttonRefresh.visibility = if (itemCount > 0) View.VISIBLE else View.GONE
        }

        observeEvent(viewModel.eventBeep) { playScanError() }

        observeEvent(viewModel.eventScrollUp) { binding.itemsRv.smoothScrollToPosition(0) }

        observeEvent(viewModel.eventToast) { showToast(it) }

        observeEvent(viewModel.eventAlert) { event ->
            showAlert(Options(event.first, event.second))
        }

        observeEvent(adapter.eventClickItemError) { item ->
            item.errorMessage?.let { showAlert(Options(it)) }
        }

        observeEvent(adapter.eventClickItemRemove) { item ->
            showConfirm(Options(getString(R.string.inv_item_clear_confirm))) {
                viewModel.removeItem(item)
            }
        }

        observeEvent(viewModel.eventSync) {
            if (it.isSuccess) {
                showAlert(Options(getString(R.string.text_upload_success))) { goBack() }
            } else if (it.isError) {
                showAlert(Options(it.message))
            }
        }

        observeEvent(viewModel.eventBack) { goBack() }

        observeEvent(adapter.eventClickItemInfo) {
            showAlert(Options(getString(R.string.inv_item_info_alert, it.size)))
        }
    }

    override fun onBarcodeText(text: String) {
        val decodedBarcode = URLDecoder.decode(text, "UTF-8")
        Timber.d("onBarcodeText: $decodedBarcode")
        viewModel.onBarcodeText(decodedBarcode)
    }
}
