package com.sytecs.unisteel.data.entities.db

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.util.*

@Parcelize
@Entity(tableName = "trans_items")
data class TransItem(
    @PrimaryKey(autoGenerate = true) val id: Long,
    @ColumnInfo(index = true) val taskId: Long,
    @ColumnInfo(index = true) val process: Int,
    val rowNum: Int?,
    val placeNum: Int?,
    val isQr: Boolean,
    val idCode: String?,
    val factoryCode: String?,
    val accountSystem: String?,
    val shopNumber: String?,
    val verificationCode: String?,
    val checkCode: String?,
    val meltingNumber: String?,
    val batchNumber: String?,
    val itemNumber: String?,
    var net: String?,
    var gross: String?,
    val productType: String?,
    var size: String?,
    val steelBrand: String?,
    val orderNumber: String?,
    val year: String?,
    val pak: String?,
    var barcodeSerial: String?,
    @ColumnInfo(index = true) val barcodeText: String,
    val created: Date,
    var errorMessage: String?
) : Parcelable {
    val serial: String
        get() = if (isQr) idCode ?: "" else barcodeText
}
