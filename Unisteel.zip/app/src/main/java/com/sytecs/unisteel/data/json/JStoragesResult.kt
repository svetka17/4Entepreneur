package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JStoragesResult(@SerializedName("EvSklad") val storageList: List<JStorage>) {
    data class JStorage(
        @SerializedName("CodeGruppa") val groupCode: String,
        @SerializedName("NameGruppa") val groupName: String,
        @SerializedName("Code") val code: String,
        @SerializedName("Name") val name: String
    )
}
