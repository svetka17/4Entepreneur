package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JUploadInResult(
    @SerializedName("Seriya") val serial: String,
    @SerializedName("Error") var error: String
)
