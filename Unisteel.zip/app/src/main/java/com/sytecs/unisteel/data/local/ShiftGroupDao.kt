package com.sytecs.unisteel.data.local

import androidx.room.*
import com.sytecs.unisteel.data.entities.db.ShiftGroup

@Dao
interface ShiftGroupDao {

    @Query("SELECT count(1) FROM shift_groups") fun getCount(): Long

    @Query("SELECT * FROM shift_groups") fun getAll(): List<ShiftGroup>

    @Query("SELECT * FROM shift_groups WHERE code = :code") fun get(code: String): ShiftGroup?

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<ShiftGroup>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: ShiftGroup)

    @Update fun update(row: ShiftGroup)

    @Delete fun delete(row: ShiftGroup)

    @Query("DELETE FROM shift_groups") fun truncate()
}
