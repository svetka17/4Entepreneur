package com.sytecs.unisteel.presentation.inv.list

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.data.entities.db.InvTask
import com.sytecs.unisteel.data.entities.embedded.InvTaskWithStorage
import com.sytecs.unisteel.data.repository.RepoInv
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class InvListViewModel
@Inject
constructor(
    private val repoInv: RepoInv,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {

    val data: LiveData<List<InvTaskWithStorage>> = repoInv.taskList()

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    val eventSync = SingleLiveEvent<Resource<Boolean>>()

    fun syncData(task: InvTask) {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            val res = repoInv.uploadItems(task)
            _isLoading.postValue(false)
            eventSync.postValue(res)
        }
    }

    fun removeItems() {
        viewModelScope.launch(Dispatchers.IO) { repoInv.deleteTasks() }
    }
}
