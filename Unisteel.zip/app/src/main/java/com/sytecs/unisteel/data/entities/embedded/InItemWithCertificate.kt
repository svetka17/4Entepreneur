package com.sytecs.unisteel.data.entities.embedded

import android.os.Parcelable
import androidx.room.Embedded
import androidx.room.Relation
import com.sytecs.unisteel.data.entities.db.InCertificate
import com.sytecs.unisteel.data.entities.db.InItem
import kotlinx.parcelize.Parcelize

@Parcelize
data class InItemWithCertificate(
    @Embedded val item: InItem,
    @Relation(parentColumn = "certificateId", entityColumn = "id") val certificate: InCertificate
) : Parcelable
