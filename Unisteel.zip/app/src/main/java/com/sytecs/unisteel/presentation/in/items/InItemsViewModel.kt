package com.sytecs.unisteel.presentation.`in`.items

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.InItem
import com.sytecs.unisteel.data.entities.db.InTransport
import com.sytecs.unisteel.data.entities.embedded.InItemWithCertTransport
import com.sytecs.unisteel.data.repository.RepoIn
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.parseItemQr
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class InItemsViewModel
@Inject
constructor(
    private val repoIn: RepoIn,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {

    private var transport: InTransport = savedStateHandle.get<InTransport>("transport")!!

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    val data = repoIn.itemList(transport)

    val eventBack = SingleLiveEvent<Boolean>()
    val eventBeep = SingleLiveEvent<Boolean>()
    val eventScrollUp = SingleLiveEvent<Boolean>()
    val eventToast = SingleLiveEvent<String>()
    val eventAlert = SingleLiveEvent<Pair<String, String?>>()
    val eventItemExist = SingleLiveEvent<Pair<String, InTransport>>()
    val eventSync = SingleLiveEvent<Resource<Boolean>>()
    val eventInbound = SingleLiveEvent<InItemWithCertTransport>()

    fun onBarcodeText(text: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val item = parseItemQr(text)
            if (item != null) {
                val itemIn = repoIn.findItem(item)

                if (itemIn == null) {
                    eventAlert.postValue(Pair(text, res.getString(R.string.in_item_not_found)))
                    eventBeep.postValue(true)
                } else {

                    val sameTransport = itemIn.transport.id == transport.id
                    val isInbounded = itemIn.item.inCreated != null

                    if (isInbounded) {
                        if (sameTransport) {
                            eventAlert.postValue(
                                Pair(res.getString(R.string.in_item_already_scanned), null))
                        } else {
                            eventAlert.postValue(
                                Pair(
                                    res.getString(
                                        R.string.in_item_already_scanned_transport,
                                        itemIn.transport.name),
                                    null))
                        }
                        eventBeep.postValue(true)
                    } else {
                        if (sameTransport) {
                            itemIn.let { eventInbound.postValue(it) }
                        } else {
                            eventItemExist.postValue(Pair(text, itemIn.transport))
                            eventBeep.postValue(true)
                        }
                    }
                }
            } else {
                eventAlert.postValue(Pair(text, res.getString(R.string.in_item_invalid)))
                eventBeep.postValue(true)
            }
        }
    }

    fun removeItems() {
        viewModelScope.launch(Dispatchers.IO) { repoIn.itemInboundRemove(transport) }
    }

    fun removeItem(item: InItem) {
        viewModelScope.launch(Dispatchers.IO) { repoIn.itemInboundRemove(item) }
    }

    fun removeTransport() {
        viewModelScope.launch(Dispatchers.IO) {
            repoIn.removeTransport(transport)
            eventBack.postValue(true)
        }
    }

    fun syncData(transport: InTransport? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            val res = repoIn.uploadItems(transport)
            _isLoading.postValue(false)
            eventSync.postValue(res)
        }
    }
}
