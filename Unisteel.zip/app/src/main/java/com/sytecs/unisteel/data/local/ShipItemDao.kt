package com.sytecs.unisteel.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sytecs.unisteel.data.entities.db.ShipItem
import com.sytecs.unisteel.data.entities.embedded.ShipItemWithTask
import java.util.*

@Dao
interface ShipItemDao {

    @Query("SELECT count(1) FROM ship_items") fun getCount(): Long

    @Query("SELECT * FROM ship_items") fun getAll(): List<ShipItem>

    @Query("SELECT * FROM ship_items WHERE taskId = :taskId order by number")
    fun getByTask(taskId: Long): List<ShipItem>

    @Query("SELECT * FROM ship_items WHERE taskId = :taskId order by number")
    fun getByTaskLiveData(taskId: Long): LiveData<List<ShipItem>>

    @Query(
        "SELECT * FROM ship_items WHERE taskId = :taskId AND shipCreated IS NOT NULL ORDER BY number")
    fun getByTaskFact(taskId: Long): List<ShipItem>

    @Transaction
    @Query("SELECT * FROM ship_items WHERE taskId = :taskId order by number")
    fun getWithTask(taskId: Long): List<ShipItemWithTask>

    @Transaction
    @Query("SELECT * FROM ship_items WHERE taskId = :taskId order by number")
    fun getWithTaskLiveData(taskId: Long): LiveData<List<ShipItemWithTask>>

    @Transaction
    @Query("SELECT * FROM ship_items WHERE qr = :qr OR qrId = :qrId")
    fun findItemByQr(qr: String, qrId: String?): ShipItemWithTask?

    @Transaction
    @Query("SELECT * FROM ship_items WHERE barcode = :barcode")
    fun findItemByBarcode(barcode: String): ShipItemWithTask?

    @Query("SELECT * FROM ship_items WHERE (qr = :qr OR qrId = :qrId) AND taskId = :taskId")
    fun findItemByQrTask(qr: String, qrId: String?, taskId: Long): ShipItem?

    @Query(
        "UPDATE ship_items SET shipCreated = NULL, shipBarcode = NULL, errorMessage = NULL WHERE id = :id")
    fun removeFact(id: Long)

    @Query("UPDATE ship_items SET shipCreated = :date, shipBarcode = :barcode WHERE id = :id")
    fun addFact(id: Long, date: Date, barcode: String)

    @Query(
        "UPDATE ship_items SET shipCreated = NULL, shipBarcode = NULL, errorMessage = NULL WHERE taskId = :taskId")
    fun removeFactByTask(taskId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<ShipItem>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: ShipItem): Long

    @Update fun update(row: ShipItem)

    @Query("DELETE FROM ship_items WHERE taskId = :taskId") fun deleteByTask(taskId: Long)

    @Delete fun delete(row: ShipItem)

    @Query("DELETE FROM ship_items") fun truncate()
}
