package com.sytecs.unisteel.data.local

import androidx.room.*
import com.sytecs.unisteel.data.entities.db.Active

@Dao
interface ActiveDao {

    @Query("SELECT count(1) FROM actives") fun getCount(): Long

    @Query("SELECT * FROM actives") fun getAll(): List<Active>

    @Query("SELECT * FROM actives WHERE code = :code") fun get(code: String): Active?

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<Active>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: Active)

    @Update fun update(row: Active)

    @Delete fun delete(row: Active)

    @Query("DELETE FROM actives") fun truncate()
}
