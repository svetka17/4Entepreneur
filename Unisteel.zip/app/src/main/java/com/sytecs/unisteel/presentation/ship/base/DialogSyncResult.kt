package com.sytecs.unisteel.presentation.ship.base

data class DialogSyncResult(val comment: String, val useAwning: Boolean)
