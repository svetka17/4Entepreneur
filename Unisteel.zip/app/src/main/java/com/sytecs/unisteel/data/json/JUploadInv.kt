package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JUploadInv(
    @SerializedName("SkladCode") val storageCode: String,
    @SerializedName("Comment") val comment: String,
    @SerializedName("Datedoc") val date: String,
    @SerializedName("POSITIONS") val positions: List<Position>
) {
    data class Position(
        @SerializedName("date") val scanDate: String,
        @SerializedName("user") val userLogin: String,
        @SerializedName("seriya") val serial: String?,
        @SerializedName("ShtrixCode") val barcode: String?,
        @SerializedName("QR") val qrCode: String?,
        @SerializedName("CommentSeriya") val comment: String
    )
}
