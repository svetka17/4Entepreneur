package com.sytecs.unisteel.data.repository

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.sytecs.unisteel.data.entities.BarcodeItem
import com.sytecs.unisteel.data.entities.db.Shift
import com.sytecs.unisteel.data.entities.db.UnpackItem
import com.sytecs.unisteel.data.entities.db.UnpackTask
import com.sytecs.unisteel.data.entities.embedded.UnpackItemWithTask
import com.sytecs.unisteel.data.json.JUploadUnpack
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.now
import com.sytecs.unisteel.utils.parseQrIdOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

class RepoUnpack @Inject constructor(private val repo: Repo) {

    fun taskList() = repo.local.unpackTaskDao().getAllLiveData()
    fun taskListWithShift() = repo.local.unpackTaskDao().getAllWithShiftLiveData()
    fun itemList(task: UnpackTask) = repo.local.unpackItemDao().getByTaskLiveData(task.id)

    suspend fun loadTask(number: String, shift: Shift): Resource<Boolean> {

        repo.local.unpackTaskDao().get(number)?.let {
            return Resource.error("Заявка вже присутня!")
        }

        val res = repo.remote.getUnpackTask(number)

        if (res.status == Resource.Status.ERROR || res.data == null) {
            return Resource.error(res.message.ifEmpty { "Помилка отримання даних" })
        }

        if (res.data.docDate.isEmpty()) {
            return Resource.error("Заявка не знайдена!")
        }

        with(res.data) {
            val taskId =
                repo.local
                    .unpackTaskDao()
                    .insert(
                        UnpackTask(
                            0, number, shift.groupCode, shift.code, now(), now(), 0.0, 0, 0, 0))

            val rows =
                positions.map { item ->
                    UnpackItem(
                        0,
                        taskId,
                        item.steelGrade,
                        item.thickness,
                        item.width,
                        item.weight,
                        item.nomenclature,
                        item.serial,
                        item.barcode,
                        item.qrCode,
                        parseQrIdOrNull(item.qrCode),
                        now(),
                        null,
                        null,
                        null)
                }
            repo.local.unpackItemDao().insertAll(rows)
        }

        updateStat()

        return Resource.success(true)
    }

    private fun updateStat() {
        repo.local.unpackTaskDao().updateStat()
    }

    fun deleteTasks() {
        repo.local.unpackItemDao().truncate()
        repo.local.unpackTaskDao().truncate()
    }

    fun removeTask(task: UnpackTask) {
        repo.local.unpackItemDao().deleteByTask(task.id)
        repo.local.unpackTaskDao().delete(task)
    }

    fun findItem(item: BarcodeItem): UnpackItemWithTask? {
        return if (item.isQr) {
            repo.local.unpackItemDao().findItemByQr(item.text, item.idCode)
        } else {
            repo.local.unpackItemDao().findItemByBarcode(item.text)
        }
    }

    fun unpackItemAdd(item: UnpackItem, barcodeItem: BarcodeItem? = null) {
        repo.local.unpackItemDao().addFact(item.id, now(), barcodeItem?.text)
        updateStat()
    }

    fun unpackItemRemove(item: UnpackItem) {
        repo.local.unpackItemDao().removeFact(item.id)
        updateStat()
    }

    fun unpackItemsRemove(task: UnpackTask) {
        repo.local.unpackItemDao().removeFactByTask(task.id)
        updateStat()
    }

    suspend fun uploadItems(task: UnpackTask): Resource<Boolean> {
        val items = repo.local.unpackItemDao().getByTaskFact(task.id)
        return uploadItems(items, task)
    }

    private suspend fun uploadItems(items: List<UnpackItem>, task: UnpackTask): Resource<Boolean> {

        Timber.w("Upload ${items.size} items!")

        val dateTimeFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault())

        val positions = mutableListOf<JUploadUnpack.Position>()

        items.forEach { item ->
            positions.add(
                JUploadUnpack.Position(
                    serial = item.serial,
                    barcode = item.barcode,
                    qr = item.qr,
                    weight = item.weight,
                    comment = ""))
        }

        val uploadStruct =
            JUploadUnpack(
                operationCode = 3,
                shiftCode = task.shiftCode.toInt(),
                number = task.code.toInt(),
                operationDate = dateTimeFormat.format(now()),
                userLogin = repo.userNameApi,
                positions = positions)

        val json = JsonObject()
        json.addProperty("CodeOper", uploadStruct.operationCode)
        json.addProperty("CodeSmen", uploadStruct.shiftCode)
        json.addProperty("date", uploadStruct.operationDate)
        json.addProperty("user", uploadStruct.userLogin)
        json.addProperty("nomer", uploadStruct.number)

        val arr = JsonArray(positions.size)
        positions.forEach { pos ->
            arr.add(
                JsonObject().also {
                    it.addProperty("seriya", pos.serial)
                    it.addProperty("ShtrixCode", pos.barcode)
                    it.addProperty("QR", pos.qr)
                    it.addProperty("ves", pos.weight)
                    it.addProperty("Comment", pos.comment)
                })
        }
        json.add("POSITIONS", arr)

        val raw = json.toString()

        val res = repo.remote.postUnpackRaw(raw.toRequestBody())

        if (res.isError) {
            return Resource.error(res.message)
        }

        if (res.data == null) {
            return Resource.error("Data error")
        }

        val data = res.data

        var allOk = true

        items.forEach { item ->
            val remoteItem = data.firstOrNull { item2 -> Objects.equals(item.serial, item2.serial) }

            //            remoteItem?.let {
            //                remoteItem.error = "test error!"
            //            }

            if (remoteItem?.error?.isNotEmpty() == true) {
                item.errorMessage = remoteItem.error
                repo.local.unpackItemDao().update(item)
                allOk = false
            } else {
                repo.local.unpackItemDao().delete(item)
            }
        }

        updateStat()
        clearEmptyData(task)

        return if (allOk) Resource.success(true)
        else Resource.error("Виконано з помилками, перегляньте відмічені позиції")
    }

    private fun clearEmptyData(task: UnpackTask) {
        repo.local.unpackTaskDao().cleanEmptyByTask(task.id)
    }
}
