package com.sytecs.unisteel.data.entities.embedded

import android.os.Parcelable
import androidx.room.Embedded
import androidx.room.Relation
import com.sytecs.unisteel.data.entities.db.UnpackItem
import com.sytecs.unisteel.data.entities.db.UnpackTask
import kotlinx.parcelize.Parcelize

@Parcelize
data class UnpackItemWithTask(
    @Embedded val item: UnpackItem,
    @Relation(parentColumn = "taskId", entityColumn = "id") val task: UnpackTask
) : Parcelable
