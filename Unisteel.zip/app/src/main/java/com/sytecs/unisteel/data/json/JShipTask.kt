package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JShipTask(@SerializedName("POSITIONS") val positions: List<String>)
