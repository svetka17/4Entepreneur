package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JUploadShip(
    @SerializedName("Number") val number: String,
    @SerializedName("Comment") val comment: String,
    @SerializedName("AvtoBezTenta") val carWithoutAwning: Boolean,
    @SerializedName("Otgrugeno") val isShipped: Boolean,
    @SerializedName("POSITIONS") val positions: List<Position>
) {
    data class Position(
        @SerializedName("date") val operationDate: String,
        @SerializedName("user") val userLogin: String,
        @SerializedName("seriya") val serial: String,
        @SerializedName("ShtrixCode") val barcode: String,
        @SerializedName("QR") val qrCode: String,
        @SerializedName("Otgrugeno") val isShipped: Boolean
    )
}
