package com.sytecs.unisteel.presentation.unpack.add

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.Shift
import com.sytecs.unisteel.data.entities.db.ShiftGroup
import com.sytecs.unisteel.data.repository.Repo
import com.sytecs.unisteel.data.repository.RepoUnpack
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class UnpackAddViewModel
@Inject
constructor(
    private val repo: Repo,
    private val repoUnpack: RepoUnpack,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _shiftGroups = MutableLiveData<List<ShiftGroup>>()
    val shiftGroups: LiveData<List<ShiftGroup>> = _shiftGroups

    private val _shift = MutableLiveData<List<Shift>>()
    val shifts: LiveData<List<Shift>> = _shift

    val eventSaved = SingleLiveEvent<Resource<Boolean>>()
    val eventAlert = SingleLiveEvent<Pair<String, String?>>()
    val eventShifts = SingleLiveEvent<List<Shift>>()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            _shiftGroups.postValue(repo.getShiftGroups())
            _shift.postValue(repo.getShifts())
            _isLoading.postValue(false)
        }
    }

    fun showShifts(group: ShiftGroup) {
        viewModelScope.launch(Dispatchers.IO) {
            val res =
                if (shifts.value == null) listOf()
                else shifts.value!!.filter { it.groupCode == group.code }

            eventShifts.postValue(res)
        }
    }

    fun save(name: String, shift: Shift) {
        if (name.isEmpty()) {
            eventAlert.postValue(Pair(res.getString(R.string.unpack_add_number_empty), null))
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            val res = repoUnpack.loadTask(name, shift)
            eventSaved.postValue(res)
            _isLoading.postValue(false)
        }
    }
}
