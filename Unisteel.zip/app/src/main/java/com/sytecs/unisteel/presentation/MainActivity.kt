package com.sytecs.unisteel.presentation

// import com.journeyapps.barcodescanner.ScanContract
// import com.journeyapps.barcodescanner.ScanOptions
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import com.sytecs.unisteel.BuildConfig
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.config.AppSettings
import com.sytecs.unisteel.data.msal.MsalClient
import com.sytecs.unisteel.databinding.ActivityMainBinding
import com.sytecs.unisteel.device.BatteryService
import com.sytecs.unisteel.device.NetService
import com.sytecs.unisteel.device.UiService
//import com.sytecs.unisteel.device.UpdateService
import com.sytecs.unisteel.device.scanner.BaseScanner
import com.sytecs.unisteel.device.scanner.HoneywellScanner
import com.sytecs.unisteel.device.scanner.ZebraScanner
import com.sytecs.unisteel.presentation.base.AppDialog
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.utils.now
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import timber.log.Timber

@AndroidEntryPoint
class MainActivity : AppCompatActivity()/*, UpdateService.IUpdateListener*/ {

    private var appFragment: AppFragment? = null
    private lateinit var binding: ActivityMainBinding

    private val batteryService: BatteryService = BatteryService(this)
    private val netService: NetService = NetService(this)
    private val uiService: UiService = UiService()
    //private val updateService =
      //  UpdateService(this, "https://od.sytecs.com.ua/files/unisteel/", this)
    // private val storage = SimpleStorage(this)

    @Inject lateinit var msalClient: MsalClient
    @Inject lateinit var settings: AppSettings

    private val scannerList: ArrayList<BaseScanner> =
        arrayListOf(HoneywellScanner(), ZebraScanner())

    private val dateFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        lifecycle.addObserver(batteryService)
        lifecycle.addObserver(netService)
        lifecycle.addObserver(uiService)

        scannerList.forEach { it.create(this) }

        setupObservers()

        binding.buttonScan.setOnClickListener { scanBarcode() }
        updateCameraScan()

        if (BuildConfig.FLAVOR != "intune") {
            //updateService.checkVersion()
        }
    }

    public fun updateCameraScan(isView: Boolean? = null) {
        binding.buttonScan.visibility =
            if ((settings.currentSettings.isCameraScan && isView == null ) || isView == true) View.VISIBLE else View.GONE
    }

    private fun setupObservers() {
        uiService.stateEvent.observe(this) {
            binding.textAppTitle.text = getString(R.string.app_title, BuildConfig.VERSION_NAME)
            binding.imageAppNetwork.setImageResource(netService.wifiImageResId)
            binding.imageAppBattery.setImageResource(batteryService.batteryImageResId)
            binding.textAppTime.text = dateFormat.format(now())
        }

        scannerList.forEach {
            it.eventBarcode.observeEvent(this) { barcode ->
                if (!AppDialog.IsDialogShow) {
                    appFragment?.onBarcodeText(barcode)
                }
            }
        }
    }

    fun setCurrentFragment(appFragment: AppFragment?) {
        this.appFragment = appFragment
        scannerList.forEach { if (appFragment == null) it.stop() else it.start() }
    }

    override fun onDestroy() {
        super.onDestroy()
        scannerList.forEach { it.destroy() }
    }

    override fun dispatchKeyEvent(event: KeyEvent?): Boolean {
        if (BuildConfig.DEBUG && !AppDialog.IsDialogShow && event?.action == KeyEvent.ACTION_UP) {
            /*if (event?.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_1) {
                appFragment?.onBarcodeText("https://metinvest.io/qr/&2100&0&106&634524&/&109313940&0312135-4&770&63&9910&9995&&1.98x1250&DX51D&2021_974000-0021_0&2021%7C103%7C&/")
                return false
            } else if (event?.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_2) {
                appFragment?.onBarcodeText("http://metinvest.io/qr/&2100&0&106&634537&/&44507705&0111991-4&769&62&11980&12065&&1.98x1250&S350GD&2021_974000-0021_0&2021%7C103%7C&/")
                return false
            } else if (event?.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_3) {
                appFragment?.onBarcodeText("2000001162132")
                return false
            } else if (event?.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_4) {
                appFragment?.onBarcodeText("2000001161104")
                return false
            }*/
            val text =
                when (event.keyCode) {
                    KeyEvent.KEYCODE_1 ->
                        "http://metinvest.io/qr/&9966&0&1&35126970&/&8900712&&18259&&3570&3610&ОЦИНКОВАННЫЙ_ПРОКАТ_В_РУЛОНАХ&1.10х1000&DX51D&106-948ПД&100|C|М|A&/"
                    KeyEvent.KEYCODE_2 ->
                        "http://metinvest.io/qr/&2100&0&106&639012&/&599081222&0312179-4&803&31&12800&12885&&1.86x1235&DX51D&2021_974000-0026_0&2021|103|&/"
                    KeyEvent.KEYCODE_3 -> "http://metinvest.io/qr/&9966&0&1&35753384&/&5222755&&18598&&5230&5290&ОЦИНКОВАНИЙ_ПРОКАТ_В_РУЛОНАХ&0.60х1000&DX51D&105-926ПД&140|C|М|A&/"
                    KeyEvent.KEYCODE_4 -> "2000001722336"
                    KeyEvent.KEYCODE_5 -> "2000000554556"
                    KeyEvent.KEYCODE_6 -> "2000000554754"
                    KeyEvent.KEYCODE_7 -> "2000000554792"
                    KeyEvent.KEYCODE_8 -> "2000001079546"
                    KeyEvent.KEYCODE_9 -> "2000001079621"
                    else -> null
                }

            if (text != null) {
                appFragment?.onBarcodeText(text)
            }
            return false
        }
        return super.dispatchKeyEvent(event)
    }
/*
    fun startUpdate(versionInfo: UpdateService.VersionInfo) {
        updateService.update(versionInfo)
    }

    override fun onVersionSuccess(versionInfo: UpdateService.VersionInfo) {
        if (versionInfo.code > BuildConfig.VERSION_CODE) {
            appFragment?.onNewVersion(versionInfo)
        }
    }



    override fun onVersionError(e: Throwable) {
        // appFragment?.showAlert(Options("Помилка при перевірці версіі програми"))
    }

    override fun onUpdateSuccess(versionInfo: UpdateService.VersionInfo) {
        updateService.run(versionInfo)
    }

    override fun onUpdateError(e: Throwable) {
        appFragment?.showAlert(Options("Помилка при оновленні програми!"))
    }



    override fun onUpdateProgress(progressValue: Int) {
        Timber.d("Update progress: $progressValue")
    }

 */

    fun openFragment(fragment: Fragment) {
        val transaction: FragmentTransaction = supportFragmentManager.beginTransaction()
        transaction.add(R.id.nav_host_fragment, fragment)
        transaction.addToBackStack(null)
        transaction.commit()
    }

    private val pinLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            appFragment?.onPinChecked(result.resultCode == Activity.RESULT_OK)
        }

    fun requestPin(pinCode: String? = null) {
        pinLauncher.launch(
            Intent(this, PinActivity::class.java).also { it.putExtra("pin_code", pinCode) })
    }

    private var cameraBarcode: String? = null

    fun checkCameraBarcode() {
        cameraBarcode?.let {
            if (!AppDialog.IsDialogShow) {
                appFragment?.onBarcodeText(it)
            }
            cameraBarcode = null
        }
    }

    private val scanLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            result?.let {
                ScanContract().parseResult(result.resultCode, result.data)?.let { intentResult ->
                    Timber.d("CAMERA BARCODE: ${intentResult.contents} ${intentResult.formatName}")
                    cameraBarcode = intentResult.contents
                }
            }
        }

    private fun scanBarcode() {

        val intent =
            ScanContract()
                .createIntent(
                    this,
                    ScanOptions().apply {
                        setPrompt("Відскануйте штрихкод або QR-код")
                        setBeepEnabled(true)
                        setOrientationLocked(false)
                    })

        scanLauncher.launch(intent)
    }
}
