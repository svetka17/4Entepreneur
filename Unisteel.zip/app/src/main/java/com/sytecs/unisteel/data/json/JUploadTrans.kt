package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JUploadTrans(
    @SerializedName("CodeOper") val operationCode: Int,
    @SerializedName("date") val operationDate: String,
    @SerializedName("user") val userLogin: String,
    @SerializedName("POSITIONS") val positions: List<Position>
) {
    data class Position(
        @SerializedName("seriya") val serial: String,
        @SerializedName("skladpoluch") val storage: String,
        @SerializedName("mesto") val place: String,
        @SerializedName("comment") val comment: String?
    )
}
