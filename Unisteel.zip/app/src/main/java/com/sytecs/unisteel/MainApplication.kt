package com.sytecs.unisteel

import android.app.Application
import android.os.Build
import com.microsoft.appcenter.AppCenter
import com.microsoft.appcenter.analytics.Analytics
import com.microsoft.appcenter.crashes.AbstractCrashesListener
import com.microsoft.appcenter.crashes.Crashes
import com.microsoft.appcenter.crashes.ingestion.models.ErrorAttachmentLog
import com.microsoft.appcenter.crashes.model.ErrorReport
import com.sytecs.unisteel.data.local.AppDatabase
import dagger.hilt.android.HiltAndroidApp
import java.io.File
import timber.log.Timber

@HiltAndroidApp
class MainApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        if (BuildConfig.DEBUG) {
            Timber.plant(
                object : Timber.DebugTree() {
                    override fun createStackElementTag(element: StackTraceElement): String {
                        return "${element.fileName}[L:${element.lineNumber}] ${
                        super.createStackElementTag(
                            element
                        )
                    }"
                    }

                    override fun log(priority: Int, tag: String?, message: String, t: Throwable?) {
                        super.log(priority, BuildConfig.APPLICATION_ID, "$tag $message", t)
                    }
                })
        }

        Timber.d(
            "Start application version: ${BuildConfig.VERSION_NAME} (code: ${BuildConfig.VERSION_CODE}) ${if (BuildConfig.DEBUG) "DEBUG" else "RELEASE"}\"")
        Timber.d(
            "Device: ${Build.MANUFACTURER} ${Build.MODEL} - Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")

        prepareAppCenter()
    }

    private fun prepareAppCenter() {

        AppCenter.start(
            this,
            "b37eac81-0f94-4e16-a81d-3beb26742d0a",
            Analytics::class.java,
            Crashes::class.java)

        Crashes.setListener(
            object : AbstractCrashesListener() {
                override fun getErrorAttachments(
                    report: ErrorReport?
                ): MutableIterable<ErrorAttachmentLog> {

                    val attachments = mutableListOf<ErrorAttachmentLog>()

                    val dbFilePath =
                        if (BuildConfig.DEBUG)
                            File(
                                getExternalFilesDir(null)?.absolutePath,
                                AppDatabase.DatabaseFileName)
                        else getDatabasePath(AppDatabase.DatabaseFileName)

                    val dbJournalFilePath =
                        if (BuildConfig.DEBUG)
                            File(
                                getExternalFilesDir(null)?.absolutePath,
                                AppDatabase.DatabaseJournalFileName)
                        else getDatabasePath(AppDatabase.DatabaseJournalFileName)

                    val dbAttachment =
                        prepareAttachment(
                            dbFilePath.absolutePath,
                            AppDatabase.DatabaseFileName,
                            "application/x-sqlite3")
                    dbAttachment?.let { attachments.add(it) }

                    val dbJournalAttachment =
                        prepareAttachment(
                            dbJournalFilePath.absolutePath, AppDatabase.DatabaseJournalFileName)
                    dbJournalAttachment?.let { attachments.add(it) }

                    return attachments
                }
            })
    }

    private fun prepareAttachment(
        filePath: String,
        title: String,
        contentType: String? = "application/octet-stream"
    ): ErrorAttachmentLog? {

        val file = File(filePath)
        if (file.exists()) {
            try {
                return ErrorAttachmentLog.attachmentWithBinary(file.readBytes(), title, contentType)
            } catch (e: Exception) {}
        }

        return null
    }
}
