package com.sytecs.unisteel.device.scanner

import android.content.Context
import com.honeywell.aidc.*
import com.honeywell.aidc.BarcodeReader.BarcodeListener
import com.honeywell.aidc.BarcodeReader.TriggerListener
import com.sytecs.unisteel.BuildConfig
import timber.log.Timber
import java.nio.charset.StandardCharsets

class HoneywellScanner : BaseScanner(), BarcodeListener, TriggerListener {

    private var barcodeReader: BarcodeReader? = null
    private var manager: AidcManager? = null

    override fun create(appContext: Context) {
        super.create(appContext)
        AidcManager.create(appContext) {
            manager = it
            try {
                barcodeReader = it.createBarcodeReader()
                Timber.d("Barcode reader created!")
                initScanner()
            } catch (e: InvalidScannerNameException) {
                Timber.e(e, "createBarcodeReader()")
            } catch (e: Exception) {
                Timber.e(e, "createBarcodeReader()")
            }
        }
    }

    override fun destroy() {
        super.destroy()
        if (barcodeReader != null) {
            barcodeReader!!.removeBarcodeListener(this)
            barcodeReader!!.removeTriggerListener(this)
        }
    }

    override fun start() {
        super.start()
        try {
            if (barcodeReader != null) barcodeReader!!.claim()
        } catch (e: ScannerUnavailableException) {
            Timber.e(e, "Scanner unavailable")
        } catch (e: Exception) {}
    }

    override fun stop() {
        super.stop()
        try {
            if (barcodeReader != null) barcodeReader!!.release()
        } catch (e: Exception) {
            Timber.e(e, "Scanner unavailable")
        }
    }

    private fun initScanner() {

        barcodeReader?.let {
            it.addBarcodeListener(this)
            it.addTriggerListener(this)

            if (it.loadProfile(BuildConfig.APPLICATION_ID) /* || it.loadProfile("DEFAULT")*/) return

            try {
                it.setProperty(
                    BarcodeReader.PROPERTY_TRIGGER_CONTROL_MODE,
                    BarcodeReader.TRIGGER_CONTROL_MODE_AUTO_CONTROL)
            } catch (e: UnsupportedPropertyException) {
                Timber.e(e, "Failed to apply properties")
            }

            val properties: MutableMap<String, Any> = HashMap()
            //
            properties[BarcodeReader.PROPERTY_DATA_PROCESSOR_LAUNCH_BROWSER] = false
            properties.put(BarcodeReader.PROPERTY_NOTIFICATION_VIBRATE_ENABLED, true)
            // Set Symbologies On/Off
            properties[BarcodeReader.PROPERTY_CODE_128_ENABLED] = true
            properties[BarcodeReader.PROPERTY_GS1_128_ENABLED] = true
            properties[BarcodeReader.PROPERTY_QR_CODE_ENABLED] = true
            properties[BarcodeReader.PROPERTY_CODE_39_ENABLED] = true
            properties[BarcodeReader.PROPERTY_DATAMATRIX_ENABLED] = true
            properties[BarcodeReader.PROPERTY_UPC_A_ENABLE] = true
            properties[BarcodeReader.PROPERTY_EAN_13_ENABLED] = true
            properties[BarcodeReader.PROPERTY_EAN_13_CHECK_DIGIT_TRANSMIT_ENABLED] = true
            properties[BarcodeReader.PROPERTY_EAN_8_CHECK_DIGIT_TRANSMIT_ENABLED] = true
            properties[BarcodeReader.PROPERTY_AZTEC_ENABLED] = true
            properties[BarcodeReader.PROPERTY_CODABAR_ENABLED] = true
            properties[BarcodeReader.PROPERTY_INTERLEAVED_25_ENABLED] = true
            properties[BarcodeReader.PROPERTY_PDF_417_ENABLED] = true
            // Set Max Code 39 barcode length
            properties[BarcodeReader.PROPERTY_CODE_39_MAXIMUM_LENGTH] = 10
            // Turn on center decoding
            properties[BarcodeReader.PROPERTY_CENTER_DECODE] = true
            // Enable bad read response
            properties[BarcodeReader.PROPERTY_NOTIFICATION_BAD_READ_ENABLED] = true
            // Apply the settings
            it.setProperties(properties)
        }
    }

    override fun onBarcodeEvent(event: BarcodeReadEvent) {
        val barcodeText = decodeString(event)
        onBarcode(barcodeText)
    }

    private fun decodeString(event: BarcodeReadEvent): String {
        if (event.charset == StandardCharsets.UTF_8) return event.barcodeData

        return try {
            val bytes: ByteArray = event.barcodeData.toByteArray(event.charset)
            String(bytes)
        } catch (ex: java.lang.Exception) {
            ex.printStackTrace()
            event.barcodeData
        }
    }

    override fun onFailureEvent(barcodeFailureEvent: BarcodeFailureEvent) {}
    override fun onTriggerEvent(triggerStateChangeEvent: TriggerStateChangeEvent) {}
}
