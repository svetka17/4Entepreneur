package com.sytecs.unisteel.presentation.dialog

import android.os.Bundle
import android.view.*
import androidx.core.os.bundleOf
import androidx.fragment.app.FragmentManager
import com.sytecs.unisteel.databinding.DialogInputBinding
import com.sytecs.unisteel.presentation.base.AppDialog
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.autoCleared

class DialogInput : AppDialog() {

    companion object {
        fun show(manager: FragmentManager, options: Options): DialogInput? {
            if (IsDialogShow) return null
            return newInstance(options).apply { show(manager, null) }
        }

        fun newInstance(options: Options) =
            DialogInput().apply { arguments = bundleOf("options" to options) }
    }

    private var binding: DialogInputBinding by autoCleared()
    val onClickPositive = SingleLiveEvent<String>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        savedInstanceState?.let { dismiss() }

        binding = DialogInputBinding.inflate(inflater, container, false)

        val options =
            arguments?.getParcelable<Options>("options")
                ?: throw IllegalStateException("Options cannot be null")

        dialog?.run {
            setCanceledOnTouchOutside(false)
            setCancelable(false)
            setOnKeyListener { _, keyCode, _ -> keyCode == KeyEvent.KEYCODE_BACK }
        }

        binding.text1.text = options.title
        binding.text2.text = options.message
        binding.text2.gravity =
            if (options.isCentered) Gravity.CENTER_HORIZONTAL else Gravity.NO_GRAVITY
        binding.text1.visibility = if (options.isTitle) View.VISIBLE else View.GONE

        binding.buttonYes.setOnClickListener {
            dismiss()
            onClickPositive.postValue(binding.edit1.text.toString())
        }

        binding.buttonNo.setOnClickListener { dismiss() }

        return binding.root
    }
}
