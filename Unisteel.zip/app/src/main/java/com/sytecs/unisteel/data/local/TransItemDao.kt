package com.sytecs.unisteel.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sytecs.unisteel.data.entities.db.TransItem
import com.sytecs.unisteel.data.entities.embedded.TransItemWithTask

@Dao
interface TransItemDao {

    @Query("SELECT count(1) FROM trans_items WHERE process = :process")
    fun getCount(process: Int): Long

    @Query("SELECT * FROM trans_items WHERE process = :process")
    fun getAll(process: Int): List<TransItem>

    @Query("SELECT * FROM trans_items WHERE taskId = :taskId ORDER BY id DESC")
    fun getByTask(taskId: Long): List<TransItem>

    @Query("SELECT * FROM trans_items WHERE taskId = :taskId ORDER BY id DESC")
    fun getByTaskLiveData(taskId: Long): LiveData<List<TransItem>>

    @Transaction
    @Query("SELECT * FROM trans_items WHERE taskId = :taskId")
    fun getWithTask(taskId: Long): List<TransItemWithTask>

    @Transaction
    @Query("SELECT * FROM trans_items WHERE process = :process AND barcodeText = :barcodeText")
    fun findItemByBarcode(process: Int, barcodeText: String): TransItemWithTask?

    @Transaction
    @Query(
        "SELECT * FROM trans_items WHERE process = :process AND barcodeText = :barcodeText AND taskId = :taskId")
    fun findItemByBarcodeTask(process: Int, barcodeText: String, taskId: Long): TransItemWithTask?

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<TransItem>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: TransItem): Long

    @Update fun update(row: TransItem)

    @Query("DELETE FROM trans_items WHERE taskId = :taskId") fun deleteByTask(taskId: Long)

    @Delete fun delete(row: TransItem)

    @Query("DELETE FROM trans_items WHERE :process IS NULL OR process = :process")
    fun truncate(process: Int? = null)
}
