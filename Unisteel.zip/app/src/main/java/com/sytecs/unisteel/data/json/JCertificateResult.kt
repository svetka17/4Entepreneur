package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JCertificateResult(@SerializedName("EvSert") val certificateList: List<JCertificate>) {
    data class JCertificate(
        @SerializedName("ActivCode") val activeCode: String,
        @SerializedName("Sertifikat") val certificateCode: String,
        @SerializedName("TTN") val ttn: String,
        @SerializedName("TS") val transport: String,
        @SerializedName("Partiya") val batch: String,
        @SerializedName("Plavka") val melting: String,
        @SerializedName("Marka") val steelGrade: String,
        @SerializedName("Tolshina") val thickness: String,
        @SerializedName("Shirina") val width: String,
        @SerializedName("Ves") val weight: Double,
        @SerializedName("Seriya") val serial: String,
        @SerializedName("ShtrixCode") val barcode: String,
        @SerializedName("QR") val qr: String,
        @SerializedName("SeriyaPostav") val serialSupplier: String
    )
}
