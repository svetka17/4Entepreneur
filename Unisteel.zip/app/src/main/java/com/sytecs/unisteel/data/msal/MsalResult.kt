package com.sytecs.unisteel.data.msal

import java.util.*

class MsalResult
private constructor(val success: Boolean, val user: MsalUser?, val exception: Exception?) {
    companion object {
        fun newSuccess(user: MsalUser) = MsalResult(true, user, null)

        fun newError(exception: Exception) = MsalResult(false, null, exception)

        fun newEmpty() = MsalResult(true, null, null)
    }

    class MsalUser(
        val userName: String,
        val accessToken: String,
        val expiresOn: Date,
        val userFio: String,
        val userId: String
    )
}
