package com.sytecs.unisteel.presentation.ship.add

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.repository.RepoShip
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ShipAddViewModel
@Inject
constructor(
    private val repoShip: RepoShip,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    val eventSaved = SingleLiveEvent<Resource<Boolean>>()
    val eventAlert = SingleLiveEvent<Pair<String, String?>>()

    fun save(name: String) {
        if (name.isEmpty()) {
            eventAlert.postValue(Pair(res.getString(R.string.ship_add_number_empty), null))
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            val res = repoShip.loadTask(name)
            eventSaved.postValue(res)
            _isLoading.postValue(false)
        }
    }
}
