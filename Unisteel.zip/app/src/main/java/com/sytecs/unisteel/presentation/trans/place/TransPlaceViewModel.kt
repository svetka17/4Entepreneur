package com.sytecs.unisteel.presentation.trans.place

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.BarcodeItem
import com.sytecs.unisteel.data.entities.db.Place
import com.sytecs.unisteel.data.entities.db.Storage
import com.sytecs.unisteel.data.repository.Repo
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TransPlaceViewModel
@Inject
constructor(
    private val repo: Repo,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {
    private val storage: Storage
        get() = savedStateHandle.get<Storage>("storage")!!
    private val barcodeItem: BarcodeItem
        get() = savedStateHandle.get<BarcodeItem>("barcodeItem")!!

    val data: LiveData<List<Place>> = repo.local.placeDao().getByStorageLiveData(storage.code)

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    val eventAlert = SingleLiveEvent<Pair<String, String?>>()
    val eventBeep = SingleLiveEvent<Unit>()
    val eventPlace = SingleLiveEvent<Place?>()
    val eventPlaceReady = SingleLiveEvent<Unit>()

    fun onBarcodeText(text: String) {
        viewModelScope.launch(Dispatchers.IO) {
            if (text.length != 8) {
                eventPlace.postValue(null)
                eventAlert.postValue(Pair(text, res.getString(R.string.trans_place_invalid)))
                eventBeep.postValue(Unit)
                return@launch
            }

            val place = data.value?.find { it.barcode == text }

            if (place == null) {
                eventPlace.postValue(null)
                eventAlert.postValue(Pair(text, res.getString(R.string.trans_place_not_found)))
                eventBeep.postValue(Unit)
                return@launch
            }

            eventPlace.postValue(place)
            eventPlaceReady.postValue(Unit)
        }
    }
}
