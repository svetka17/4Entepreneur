package com.sytecs.unisteel.device

import android.content.Context
import android.net.wifi.WifiManager
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import com.sytecs.unisteel.R
import java.util.*
import javax.inject.Inject

class NetService @Inject constructor(private val appContext: Context) : LifecycleEventObserver {

    private var timer: Timer? = null

    /*var wifiLevel: Int = 2
        private set
    var wifiConnected: Boolean = false
        private set*/
    var wifiImageResId: Int = R.drawable.ic_wifi_none
        private set

    override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
        if (event == Lifecycle.Event.ON_START) {

            timer =
                Timer().apply {
                    scheduleAtFixedRate(
                        object : TimerTask() {
                            override fun run() {
                                invalidateRes()
                            }
                        },
                        0,
                        1000)
                }
        } else if (event == Lifecycle.Event.ON_STOP) {
            timer?.cancel()
            timer = null
        }
    }

    private fun invalidateRes() {
        val wifiService = appContext.applicationContext.getSystemService(Context.WIFI_SERVICE)
        if (wifiService is WifiManager) {
            var resId = R.drawable.ic_wifi_off
            if (wifiService.isWifiEnabled) {
                wifiService.connectionInfo?.let {
                    resId =
                        if (it.ssid.isEmpty()) {
                            R.drawable.ic_wifi_none
                        } else {
                            when (WifiManager.calculateSignalLevel(it.rssi, 4)) {
                                1 -> R.drawable.ic_wifi_1
                                2 -> R.drawable.ic_wifi_2
                                3 -> R.drawable.ic_wifi_3
                                4 -> R.drawable.ic_wifi_4
                                else -> R.drawable.ic_wifi_0
                            }
                        }
                }
            }
            wifiImageResId = resId
        }
    }
}
