package com.sytecs.unisteel.presentation.dialog

fun interface IDialogListener {
    fun onClickPositive()
}
