package com.sytecs.unisteel.di

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.sytecs.unisteel.data.config.AppSettings
import com.sytecs.unisteel.data.local.AppDatabase
import com.sytecs.unisteel.data.msal.MsalClient
import com.sytecs.unisteel.data.msal.MsalSession
import com.sytecs.unisteel.data.remote.BearerLoginInterceptor
import com.sytecs.unisteel.data.remote.HostSelectionInterceptor
import com.sytecs.unisteel.data.remote.NetworkService
import com.sytecs.unisteel.data.remote.RemoteDataSource
import com.sytecs.unisteel.data.repository.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Named
import javax.inject.Singleton
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Singleton @Provides fun provideMsalSession() = MsalSession.getInstance()

    @Singleton
    @Provides
    fun provideSettings(@ApplicationContext appContext: Context) =
        AppSettings.getInstance(appContext)

    @Singleton
    @Provides
    fun provideMsal(@ApplicationContext appContext: Context) = MsalClient.getInstance(appContext)

    @Singleton
    @Provides
    @Named("Api")
    fun provideRetrofit(
        @ApplicationContext appContext: Context,
        gson: Gson,
    ): Retrofit {

        val appSettings = provideSettings(appContext)

        val interceptor = HttpLoggingInterceptor()
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY)

        val client =
            OkHttpClient.Builder()
                .addInterceptor(interceptor)
                //            .addInterceptor(TimberLoggingInterceptor())
                .addInterceptor(HostSelectionInterceptor(appSettings))
                .addInterceptor(
                    BearerLoginInterceptor(provideMsalSession(), provideMsal(appContext), appSettings)
                )
                .build()

        return Retrofit.Builder()
            .baseUrl("https://nobase.url")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
    }

    @Provides
    fun provideGson(): Gson =
        GsonBuilder()
            // .setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE)
            .create()

    @Singleton
    @Provides
    fun provideDatabase(@ApplicationContext appContext: Context) =
        AppDatabase.getDatabase(appContext)

    @Singleton
    @Provides
    fun provideRepo(
        remoteDataSource: RemoteDataSource,
        localDataSource: AppDatabase,
        msalSession: MsalSession,
        msalClient: MsalClient,
        appSettings: AppSettings,
    ) = Repo(remoteDataSource, localDataSource, msalSession, msalClient, appSettings)

    @Singleton @Provides fun provideRepoIn(repo: Repo) = RepoIn(repo)

    @Singleton @Provides fun provideRepoUnpack(repo: Repo) = RepoUnpack(repo)

    @Singleton @Provides fun provideRepoTrans(repo: Repo) = RepoTrans(repo)

    @Singleton @Provides fun provideRepoShip(repo: Repo) = RepoShip(repo)

    @Singleton @Provides fun provideRepoInv(repo: Repo) = RepoInv(repo)

    @Provides
    fun provideNetworkService(@Named("Api") retrofit: Retrofit): NetworkService =
        retrofit.create(NetworkService::class.java)
}
