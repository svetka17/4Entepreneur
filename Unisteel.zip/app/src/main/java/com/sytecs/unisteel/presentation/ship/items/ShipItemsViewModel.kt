package com.sytecs.unisteel.presentation.ship.items

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.ShipItem
import com.sytecs.unisteel.data.entities.db.ShipTask
import com.sytecs.unisteel.data.repository.RepoShip
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.parseItemQr
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ShipItemsViewModel
@Inject
constructor(
    private val repoShip: RepoShip,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {

    private val task: ShipTask
        get() = savedStateHandle.get<ShipTask>("task")!!

    val data: LiveData<List<ShipItem>> = repoShip.itemList(task)

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    val eventBack = SingleLiveEvent<Boolean>()
    val eventBeep = SingleLiveEvent<Boolean>()
    val eventScrollUp = SingleLiveEvent<Boolean>()
    val eventToast = SingleLiveEvent<String>()
    val eventAlert = SingleLiveEvent<Pair<String, String?>>()
    val eventSync = SingleLiveEvent<Resource<Boolean>>()

    fun onBarcodeText(text: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val item = parseItemQr(text)

            if (item == null) {
                eventAlert.postValue(Pair(text, res.getString(R.string.ship_item_invalid)))
                eventBeep.postValue(true)
                return@launch
            }

            val itemShip = repoShip.findItem(item)

            if (itemShip == null) {
                eventAlert.postValue(Pair(text, res.getString(R.string.ship_item_not_found)))
                eventBeep.postValue(true)
                return@launch
            }

            if (itemShip.task.id != task.id) {
                eventAlert.postValue(
                    Pair(
                        res.getString(
                            R.string.ship_item_already_scanned_in_task, itemShip.task.code),
                        null))
                eventBeep.postValue(true)
                return@launch
            }

            val isShipped = itemShip.item.shipCreated != null

            if (isShipped) {
                eventAlert.postValue(Pair(res.getString(R.string.ship_item_already_scanned), null))
                eventBeep.postValue(true)
                return@launch
            }

            repoShip.shipItemAdd(itemShip.item, item)
        }
    }

    fun removeItems() {
        viewModelScope.launch(Dispatchers.IO) { repoShip.shipItemsRemove(task) }
    }

    fun removeItem(item: ShipItem) {
        viewModelScope.launch(Dispatchers.IO) { repoShip.shipItemRemove(item) }
    }

    fun removeTask() {
        viewModelScope.launch(Dispatchers.IO) {
            repoShip.removeTask(task)
            eventBack.postValue(true)
        }
    }

    fun syncData(task: ShipTask, comment: String, useAwning: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            val res = repoShip.uploadItems(task, comment, useAwning)
            _isLoading.postValue(false)
            eventSync.postValue(res)
        }
    }
}
