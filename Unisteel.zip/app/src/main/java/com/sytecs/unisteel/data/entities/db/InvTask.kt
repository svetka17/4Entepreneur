package com.sytecs.unisteel.data.entities.db

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.util.*

@Parcelize
@Entity(tableName = "inv_tasks")
data class InvTask(
    @PrimaryKey(autoGenerate = true) var id: Long,
    val date: Date,
    @ColumnInfo(index = true) val storageCode: String,
    val created: Date,
    val itemCount: Int,
    val itemCountError: Int
) : Parcelable
