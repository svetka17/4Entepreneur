package com.sytecs.unisteel.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sytecs.unisteel.data.entities.db.InvItem
import com.sytecs.unisteel.data.entities.embedded.InvItemWithTask

@Dao
interface InvItemDao {

    @Query("SELECT count(1) FROM inv_items") fun getCount(): Long

    @Query("SELECT * FROM inv_items") fun getAll(): List<InvItem>

    @Query("SELECT * FROM inv_items WHERE taskId = :taskId ORDER BY id DESC")
    fun getByTask(taskId: Long): List<InvItem>

    @Query("SELECT * FROM inv_items WHERE taskId = :taskId ORDER BY id DESC")
    fun getByTaskLiveData(taskId: Long): LiveData<List<InvItem>>

    @Transaction
    @Query("SELECT * FROM inv_items WHERE taskId = :taskId")
    fun getWithTask(taskId: Long): List<InvItemWithTask>

    @Transaction
    @Query("SELECT * FROM inv_items WHERE barcodeText = :barcodeText")
    fun findItemByBarcode(barcodeText: String): InvItemWithTask?

    @Transaction
    @Query("SELECT * FROM inv_items WHERE barcodeText = :barcodeText AND taskId = :taskId")
    fun findItemByBarcodeTask(barcodeText: String, taskId: Long): InvItemWithTask?

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<InvItem>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: InvItem): Long

    @Update fun update(row: InvItem)

    @Query("DELETE FROM inv_items WHERE taskId = :taskId") fun deleteByTask(taskId: Long)

    @Delete fun delete(row: InvItem)

    @Query("DELETE FROM inv_items") fun truncate()
}
