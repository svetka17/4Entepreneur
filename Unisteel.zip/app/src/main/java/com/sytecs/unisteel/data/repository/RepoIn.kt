package com.sytecs.unisteel.data.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.sytecs.unisteel.data.entities.BarcodeItem
import com.sytecs.unisteel.data.entities.db.InCertificate
import com.sytecs.unisteel.data.entities.db.InItem
import com.sytecs.unisteel.data.entities.db.InTransport
import com.sytecs.unisteel.data.entities.db.Storage
import com.sytecs.unisteel.data.entities.embedded.InItemWithCertTransport
import com.sytecs.unisteel.data.entities.embedded.InItemWithCertificate
import com.sytecs.unisteel.data.entities.embedded.InTransportWithCertificates
import com.sytecs.unisteel.data.json.JUploadIn
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.now
import com.sytecs.unisteel.utils.parseQrIdOrNull
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.RequestBody.Companion.toRequestBody
import timber.log.Timber

class RepoIn @Inject constructor(private val repo: Repo) {

    fun transportList() = repo.local.inTransportDao().getWithCertificatesLiveData()
    fun itemList(transport: InTransport) =
        repo.local.inItemDao().getWithCertificateLiveData(transport.id)

    fun getTransportList(): LiveData<List<InTransportWithCertificates>> =
        liveData(Dispatchers.IO) { emit(repo.local.inTransportDao().getWithCertificates()) }

    fun getItemList(transport: InTransport): LiveData<List<InItemWithCertificate>> =
        liveData(Dispatchers.IO) { emit(repo.local.inItemDao().getWithCertificate(transport.id)) }

    suspend fun loadCertificate(
        certificateCode: String?,
        transportName: String?,
        ttn: String?
    ): Resource<Boolean> =
        withContext(Dispatchers.IO) {
            val res = repo.remote.getCertificate(certificateCode, transportName, ttn)

            if (res.status == Resource.Status.ERROR || res.data == null) {
                return@withContext Resource.error(res.message.ifEmpty { "Помилка отримання даних" })
            }

            var certificateList = res.data.certificateList

            if (transportName?.isNotEmpty() == true) {
                certificateList =
                    certificateList.filter { it.transport.equals(transportName, true) }
            }

            if (ttn?.isNotEmpty() == true) {
                certificateList = certificateList.filter { it.ttn.equals(ttn, true) }
            }

            if (certificateList.isEmpty()) {
                return@withContext Resource.error("За введеними параметрами нічого не знайдено!")
            }

            val localCerts = repo.local.inCertificateDao().getAll()

            val itemRows = mutableListOf<InItem>()

            certificateList.forEach {
                val ce =
                    localCerts.firstOrNull { localCert -> localCert.code == it.certificateCode }
                if (ce == null) {

                    var transport =
                        repo.local.inTransportDao().get(it.activeCode, it.transport, it.ttn)

                    if (transport == null) {
                        transport =
                            InTransport(0, it.activeCode, it.ttn, it.transport, 0.0, now(), 0, 0, 0)
                        transport.id = repo.local.inTransportDao().insert(transport)
                    }

                    var certificate =
                        repo.local
                            .inCertificateDao()
                            .getByTransport(transport.id, it.certificateCode)

                    if (certificate == null) {
                        certificate =
                            InCertificate(0, transport.id, it.certificateCode, 0.0, now(), 0, 0, 0)
                        certificate.id = repo.local.inCertificateDao().insert(certificate)
                    }

                    itemRows.add(
                        InItem(
                            id = 0,
                            certificateId = certificate.id,
                            transportId = transport.id,
                            batch = it.batch,
                            melting = it.melting,
                            steelGrade = it.steelGrade,
                            thickness = it.thickness,
                            width = it.width,
                            weight = it.weight,
                            serial = it.serial,
                            barcode = it.barcode,
                            qr = it.qr,
                            qrId = parseQrIdOrNull(it.qr),
                            serialSupplier = it.serialSupplier,
                            now(),
                            null,
                            null,
                            null,
                            null,
                            null
                        )
                    )
                }
            }

            repo.local.inItemDao().insertAll(itemRows)

            updateStat()

            return@withContext Resource.success(true)
        }

    private fun updateStat() {
        repo.local.inCertificateDao().updateStat()
        repo.local.inTransportDao().updateStat()
    }

    fun itemInboundAdd(
        item: InItem,
        storage: Storage,
        barcode: String?,
        isManual: Boolean
    ): Resource<Boolean> {
        item.inStorageCode = storage.code
        item.inCreated = now()
        item.inBarcode = barcode
        item.inManual = isManual
        repo.local.inItemDao().update(item)
        updateStat()
        return Resource.success(true)
    }

    fun itemInboundRemove(item: InItem): Resource<Boolean> {
        item.inStorageCode = null
        item.inCreated = null
        item.inBarcode = null
        item.inManual = null
        repo.local.inItemDao().update(item)
        updateStat()
        return Resource.success(true)
    }

    fun itemInboundRemove(transport: InTransport): Resource<Boolean> {

        val items = repo.local.inItemDao().getByTransport(transport.id)
        items.forEach { item ->
            item.inStorageCode = null
            item.inCreated = null
            item.inBarcode = null
            item.inManual = null
            repo.local.inItemDao().update(item)
        }

        updateStat()
        return Resource.success(true)
    }

    suspend fun uploadItems(transport: InTransport? = null): Resource<Boolean> {

        val items =
            when {
                transport != null -> repo.local.inItemDao().getByTransport(transport.id)
                else -> repo.local.inItemDao().getAll()
            }.filter { it.inCreated != null }

        return uploadItems(items, transport)
    }

    private suspend fun uploadItems(
        items: List<InItem>,
        transport: InTransport?
    ): Resource<Boolean> {

        Timber.w("Upload ${items.size} items!")

        val dateTimeFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault())

        val positions = mutableListOf<JUploadIn.Position>()

        items.forEach { item ->
            positions.add(
                JUploadIn.Position(
                    serial = item.serial,
                    storage = item.inStorageCode!!,
                    barcode = item.inBarcode,
                    qrCode = item.qr
                )
            )
        }

        val uploadStruct =
            JUploadIn(
                operationCode = 2,
                userLogin = repo.userNameApi,
                operationDate = dateTimeFormat.format(now()),
                positions = positions
            )

        val json = JsonObject()
        json.addProperty("CodeOper", uploadStruct.operationCode)
        json.addProperty("date", uploadStruct.operationDate)
        json.addProperty("user", uploadStruct.userLogin)

        val arr = JsonArray(positions.size)
        positions.forEach { pos ->
            arr.add(
                JsonObject().also {
                    it.addProperty("seriya", pos.serial)
                    it.addProperty("sklad", pos.storage)
                    it.addProperty("ShtrixCode", pos.barcode)
                    it.addProperty("QR", pos.qrCode)
                }
            )
        }
        json.add("POSITIONS", arr)

        val raw = json.toString()

        val res = repo.remote.postInRaw(raw.toRequestBody())

        if (res.isError) {
            return Resource.error(res.message)
        }

        if (res.data == null) {
            return Resource.error("Data error")
        }

        val data = res.data

        var allOk = true

        items.forEach { item ->
            val remoteItem = data.firstOrNull { item2 -> Objects.equals(item.serial, item2.serial) }

            /*remoteItem?.let {
                remoteItem.error = "test error!"
            }*/

            if (remoteItem?.error?.isNotEmpty() == true) {
                item.errorMessage = remoteItem.error
                repo.local.inItemDao().update(item)
                allOk = false
            } else {
                repo.local.inItemDao().delete(item)
            }
        }

        updateStat()
        clearEmptyData(transport)

        return if (allOk) Resource.success(true)
        else Resource.error("Виконано з помилками, перегляньте відмічені позиції")
    }

    private fun clearEmptyData(transport: InTransport?) {
        if (transport != null) {
            repo.local.inCertificateDao().cleanEmptyByTransport(transport.id)
            repo.local.inTransportDao().cleanEmptyByTransport(transport.id)
        } else {
            repo.local.inCertificateDao().cleanEmpty()
            repo.local.inTransportDao().cleanEmpty()
        }
    }

    fun findItem(item: BarcodeItem): InItemWithCertTransport? {
        return if (item.isQr) {
            repo.local.inItemDao().findItemByQr(item.text, item.idCode)
        } else {
            repo.local.inItemDao().findItemByBarcode(item.text)
        }
    }

    fun removeTransport(transport: InTransport) {
        repo.local.inItemDao().deleteByTransport(transport.id)
        updateStat()
        clearEmptyData(transport)
    }

    fun deleteInbounds() {
        repo.local.inItemDao().truncate()
        repo.local.inCertificateDao().truncate()
        repo.local.inTransportDao().truncate()
    }
}
