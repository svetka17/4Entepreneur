package com.sytecs.unisteel.presentation.inv.list

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.InvTask
import com.sytecs.unisteel.data.entities.db.Storage
import com.sytecs.unisteel.databinding.InvListFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class InvListFragment : AppFragment() {

    private var binding: InvListFragmentBinding by autoCleared()
    private val viewModel: InvListViewModel by viewModels()
    private lateinit var adapter: InvTaskAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = InvListFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        binding.textHead.text = getString(R.string.inv_head)

        binding.buttonBack.setOnClickListener { goBack() }
        binding.buttonAdd.setOnClickListener {
            navigate(InvListFragmentDirections.actionInvListFragmentToInvAddFragment())
        }
        binding.buttonClear.setOnClickListener {
            showConfirm(Options(getString(R.string.inv_clear_all_confirm))) {
                viewModel.removeItems()
            }
        }

        setupRecyclerView()
        setupObservers()

        initFilter(binding.searchLayout, binding.buttonFilter)
    }

    private fun setupRecyclerView() {
        adapter = InvTaskAdapter()
        binding.listRv.adapter = adapter
    }

    private fun setupObservers() {
        observe(viewModel.data) {
            adapter.setItems(it)
            adapter.filter.filter(filterQuery)

            val itemCount = it.sumOf { item -> item.task.itemCount }
            val itemErrorCount = it.sumOf { item -> item.task.itemCountError }

            binding.itemCount.text = itemCount.toString()

            binding.itemErrorCount.text = itemErrorCount.toString()
            binding.itemErrorCount.visibility = if (itemErrorCount > 0) View.VISIBLE else View.GONE
            binding.itemErrorCountDelimiter.visibility =
                if (itemErrorCount > 0) View.VISIBLE else View.GONE
            binding.buttonClear.visibility = if (it.isNotEmpty()) View.VISIBLE else View.GONE
        }

        observeEvent(adapter.eventClick) { openTask(it.task, it.storage) }

        observeEvent(adapter.eventClickSync) { item ->
            showConfirm(Options(getString(R.string.inv_upload_confirm))) {
                viewModel.syncData(item.task)
            }
        }

        observeEvent(viewModel.eventSync) {
            if (it.isSuccess) {
                showAlert(Options(getString(R.string.text_upload_success)))
            } else if (it.isError) {
                showAlert(Options(it.message))
            }
        }

        observeEvent(eventFilterQuery) { adapter.filter.filter(it) }
    }

    private fun openTask(task: InvTask, storage: Storage) {
        navigate(InvListFragmentDirections.actionInvListFragmentToInvItemsFragment(task, storage))
    }

    override fun onBarcodeText(text: String) {
        playScanError()
    }
}
