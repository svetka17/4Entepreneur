package com.sytecs.unisteel.data.msal

import android.app.Activity
import android.content.Context
import com.microsoft.identity.client.*
import com.microsoft.identity.client.exception.MsalException
import com.sytecs.unisteel.utils.now
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class MsalClient(private val appContext: Context) {

    companion object {
        @Volatile private var instance: MsalClient? = null

        fun getInstance(context: Context): MsalClient =
            instance
                ?: synchronized(this) { instance ?: MsalClient(context).also { instance = it } }

        private const val qasScope = "https://uns-1c-dev.metinvestholding.com/unisteel_dev2/hs/obmen//user_impersonation"
        private const val prodScope = "https://uns-1c-prd.metinvestholding.com/unisteel/hs/obmen//user_impersonation"
        private const val LOG_ENABLE = false
        private const val AUTHORITY = "https://login.microsoftonline.com/b0bbbc89-2041-434f-8618-bc081a1a01d4"
        private var SCOPES = arrayOf(prodScope)
    }

    private var msalConfig: String = ""

    private var mSingleAccountApp: ISingleAccountPublicClientApplication? = null

    private val isLoaded
        get() = mSingleAccountApp != null

    private suspend fun initMsalClient(): Exception? {
        if (LOG_ENABLE) {
            try {
                val logger = Logger.getInstance()
                logger.setLogLevel(Logger.LogLevel.VERBOSE)
                logger.setEnablePII(true)
                logger.setEnableLogcatLog(true)
                logger.setExternalLogger { _, _, message, _ -> run { Timber.d(message) } }
            } catch (e: Exception) {
                Timber.e(e)
            }
        }

        val completable =
            CompletableDeferred<Pair<ISingleAccountPublicClientApplication?, Exception?>>()

        val file = createFileConfig()

        withContext(Dispatchers.IO) {
            PublicClientApplication.createSingleAccountPublicClientApplication(
                appContext,
                file,
                object : IPublicClientApplication.ISingleAccountApplicationCreatedListener {
                    override fun onCreated(application: ISingleAccountPublicClientApplication) {
                        completable.complete(Pair(application, null))
                    }

                    override fun onError(exception: MsalException) {
                        Timber.d(exception, "createSingleAccountPublicClientApplication()")
                        completable.complete(Pair(null, exception))
                    }
                })
        }

        val res = completable.await()
        mSingleAccountApp = res.first

        return if (res.second == null) null else res.second
    }

    private suspend fun testMsal(): Exception? = if (isLoaded) null else initMsalClient()

    suspend fun signCheck(isProd: Boolean): MsalResult {
        updateScope(isProd)
        val testResult = testMsal()

        if (!isLoaded) return MsalResult.newError(testResult!!)

        if (mSingleAccountApp!!.currentAccount?.currentAccount == null) return MsalResult.newEmpty()

        val completable = CompletableDeferred<Pair<IAuthenticationResult?, Exception?>>()
        withContext(Dispatchers.IO) {
            val p =
                AcquireTokenSilentParameters.Builder()
                    .fromAuthority(AUTHORITY)
                    .withScopes(SCOPES.toMutableList())
                    .forAccount(mSingleAccountApp!!.currentAccount.currentAccount)
                    .withCallback(
                        object : SilentAuthenticationCallback {
                            override fun onSuccess(authenticationResult: IAuthenticationResult) {
                                completable.complete(Pair(authenticationResult, null))
                            }

                            override fun onError(exception: MsalException) {
                                Timber.d(exception, "onError")
                                completable.complete(Pair(null, exception))
                            }
                        })
                    .build()

            mSingleAccountApp!!.acquireTokenSilentAsync(p)
        }
        val result = completable.await()

        if (result.second != null) {

            /*if (result.second is MsalException && (result.second as MsalException).errorCode == "no_tokens_found") {
                val c = CompletableDeferred<MsalResult>()
                withContext(Dispatchers.IO) {
                    return@withContext signOut()
                }
                val cRes = c.await()
                Timber.d(cRes.toString())
            }*/

            return MsalResult.newError(result.second!!)
        }

        val user = result.first!!

        Timber.d("AccessToken: ${user.accessToken}")
        val userFio = user.account.claims?.getValue("name")

        return MsalResult.newSuccess(
            MsalResult.MsalUser(
                user.account.username,
                user.accessToken,
                user.expiresOn,
                if (userFio is String) userFio else user.account.username,
                user.account.id))
    }

    suspend fun signIn(activity: Activity, isProd: Boolean): MsalResult {
        updateScope(isProd)
        val testResult = testMsal()

        if (!isLoaded) return MsalResult.newError(testResult!!)

        if (mSingleAccountApp!!.currentAccount?.currentAccount != null) {
            signOut()
        }

        val completable = CompletableDeferred<Pair<IAuthenticationResult?, Exception?>>()

        val params =
            AcquireTokenParameters.Builder()
                .startAuthorizationFromActivity(activity)
                .withScopes(SCOPES.toMutableList())
                .withPrompt(Prompt.LOGIN)
                .withCallback(
                    object : AuthenticationCallback {
                        override fun onSuccess(authenticationResult: IAuthenticationResult) {
                            completable.complete(Pair(authenticationResult, null))
                        }

                        override fun onError(exception: MsalException) {
                            if (exception.errorCode == "access_denied") {
                                onCancel()
                            } else {
                                Timber.d(exception, "onError")
                                completable.complete(Pair(null, exception))
                            }
                        }

                        override fun onCancel() {
                            Timber.d("onCancel")
                            completable.complete(
                                Pair(null, CancellationException("Sign in canceled")))
                        }
                    })
                .build()

        withContext(Dispatchers.IO) { mSingleAccountApp!!.acquireToken(params) }
        val result = completable.await()

        if (result.second != null) {
            return MsalResult.newError(result.second!!)
        }

        val user = result.first!!

        Timber.d("AccessToken: ${user.accessToken}")
        val userFio = user.account.claims?.getValue("name")

        return MsalResult.newSuccess(
            MsalResult.MsalUser(
                user.account.username,
                user.accessToken,
                user.expiresOn,
                if (userFio is String) userFio else user.account.username,
                user.account.id))
    }

    private fun updateScope(isProd: Boolean) {
        SCOPES = if(isProd)
            arrayOf(prodScope)
        else
            arrayOf(qasScope)
    }

    suspend fun signOut(): MsalResult {

        val testResult = testMsal()

        if (!isLoaded) {
            Timber.e(testResult!!)
            return MsalResult.newEmpty()
        }

        val completable = CompletableDeferred<Exception?>()
        withContext(Dispatchers.IO) {
            mSingleAccountApp!!.signOut(
                object : ISingleAccountPublicClientApplication.SignOutCallback {
                    override fun onSignOut() {
                        completable.complete(null)
                    }

                    override fun onError(exception: MsalException) {
                        Timber.d(exception, "onError")
                        completable.complete(exception)
                    }
                })
        }
        val result = completable.await()

        if (result != null) {
            Timber.e(result)
        }

        return MsalResult.newEmpty()
    }

    fun signCheckDebug() =
        MsalResult.newSuccess(MsalResult.MsalUser("ivanov", "", now(), "Ivanov I.I.", ""))

    private suspend fun createFileConfig() : File {

        val path = appContext.filesDir
        val file = File(path,"msal.json")
        val fileExist = file.exists()
        if(fileExist){
            msalConfig = withContext(Dispatchers.IO) {
                FileInputStream(file).bufferedReader()
            }.use { it.readText() }
        } else {
            msalConfig = "{\n" +
                    "  \"client_id\": \"a22d6b9d-a2a5-4f5d-9ad2-f493074bd14f\",\n" +
                    "  \"authorization_user_agent\": \"DEFAULT\",\n" +
                    "  \"redirect_uri\": \"msauth://com.sytecs.unisteel.apk/s84ifSM5W1VtRhjqxkv7J79%2B%2Fxs%3D\",\n" +
                    "  \"account_mode\": \"SINGLE\",\n" +
                    "  \"authorities\": [\n" +
                    "    {\n" +
                    "      \"type\": \"AAD\",\n" +
                    "      \"audience\": {\n" +
                    "        \"type\": \"AzureADMyOrg\",\n" +
                    "        \"tenant_id\": \"b0bbbc89-2041-434f-8618-bc081a1a01d4\"\n" +
                    "      }\n" +
                    "    }\n" +
                    "  ]\n" +
                    "}"
            withContext(Dispatchers.IO) {
                FileOutputStream(file).use {
                    it.write(msalConfig.toByteArray())
                }
            }
        }

        return file
    }

    suspend fun updateConfig(aadClientId: String, adTenantId: String, isProd: Boolean) {
        val aadClient = aadClientId.ifEmpty { "<aadClientId>" }
        val adTenant = adTenantId.ifEmpty { "<adTenantId>" }

        updateScope(isProd)

        msalConfig = "{\n" +
                "  \"client_id\": \"${aadClient}\",\n" +
                "  \"authorization_user_agent\": \"DEFAULT\",\n" +
                "  \"redirect_uri\": \"msauth://com.sytecs.unisteel.apk/s84ifSM5W1VtRhjqxkv7J79%2B%2Fxs%3D\",\n" +
                "  \"account_mode\": \"SINGLE\",\n" +
                "  \"authorities\": [\n" +
                "    {\n" +
                "      \"type\": \"AAD\",\n" +
                "      \"audience\": {\n" +
                "        \"type\": \"AzureADMyOrg\",\n" +
                "        \"tenant_id\": \"${adTenant}\"\n" +
                "      }\n" +
                "    }\n" +
                "  ]\n" +
                "}"
        val path = appContext.filesDir
        val file = File(path,"msal.json")
        val fileExist = file.exists()
        if(fileExist) {
            file.delete()
        }

        withContext(Dispatchers.IO) {
            FileOutputStream(file).use {
                it.write(msalConfig.toByteArray())
            }
        }
        signOut()
        initMsalClient()
    }
}
