package com.sytecs.unisteel.data.repository

import android.app.Activity
import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import com.sytecs.unisteel.data.config.AppSettings
import com.sytecs.unisteel.data.entities.Settings
import com.sytecs.unisteel.data.entities.db.*
import com.sytecs.unisteel.data.json.*
import com.sytecs.unisteel.data.local.AppDatabase
import com.sytecs.unisteel.data.msal.MsalClient
import com.sytecs.unisteel.data.msal.MsalResult
import com.sytecs.unisteel.data.msal.MsalSession
import com.sytecs.unisteel.data.remote.RemoteDataSource
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.now
import kotlinx.coroutines.Dispatchers
import javax.inject.Inject

class Repo
@Inject
constructor(
    val remote: RemoteDataSource,
    val local: AppDatabase,
    private val msalSession: MsalSession,
    private val msalClient: MsalClient,
    val settings: AppSettings
) {

    val isProd: Boolean
        get() = settings.currentSettings.isProd
    val userNameApi: String
        get() =
            "\\\\METINVEST\\${
            (
                    if
                            (msalSession.user?.userName == "V.Vasil.Kravchenko@metinvestholding.com") "Nazariy.Bevzyuk"
                    else
                        msalSession.user?.userName?.substringBefore('@')
                    )
                ?: ""
        }"

    fun accessList() = local.accessDao().getAllLiveData()

    fun haveUserData(): Boolean {
        return local.accessDao().getCount() > 0
    }

    suspend fun msalCheck(): MsalResult {

        //        val res = if (BuildConfig.DEBUG)
        //            msalClient.signCheckDebug()
        //        else
        val res = msalClient.signCheck(isProd)

        msalSession.user = res.user

        /*if (!res.success || res.user == null)
            return res

        msalSession.user = res.user*/

        return res
    }

    suspend fun msalSignIn(activity: Activity): MsalResult {
        var res = msalClient.signCheck(isProd)

        if (res.user == null) {
            res = msalClient.signIn(activity, isProd)
        }

        msalSession.user = res.user

        if (!res.success || res.user == null) return res

        if (msalSession.user?.accessToken == null)
            return MsalResult.newError(Exception("Access token error"))

        msalSession.user = res.user

        val dictRes = loadDictionary()
        if (dictRes.isError) {
            return MsalResult.newError(Exception(dictRes.message))
        }

        return res
    }

    private suspend fun loadActives(): Resource<JActiveResult> {
        val res = remote.getActives()

        if (res.status == Resource.Status.ERROR) {
            msalSignOut()
            return Resource.error(res.message)
        }

        if (res.data == null) {
            msalSignOut()
            return Resource.error("Помилка отримання даних")
        }

        return Resource.success(res.data)
    }

    private suspend fun loadAccess(): Resource<JAccessResult> {
        val res = remote.getAccess(userNameApi)

        if (res.status == Resource.Status.ERROR) {
            msalSignOut()
            return Resource.error(res.message)
        }

        if (res.data == null) {
            msalSignOut()
            return Resource.error("Помилка отримання даних")
        }

        if (res.data.error.isNotEmpty()) {
            msalSignOut()
            return Resource.error(res.data.error)
        }

        return Resource.success(res.data)
    }

    private suspend fun loadStorages(): Resource<JStoragesResult> {
        val res = remote.getStorages()

        if (res.status == Resource.Status.ERROR) {
            msalSignOut()
            return Resource.error(res.message)
        }

        if (res.data == null) {
            msalSignOut()
            return Resource.error("Помилка отримання даних")
        }

        return Resource.success(res.data)
    }

    private suspend fun loadPlaces(): Resource<JPlaceResult> {
        val res = remote.getPlaces()

        if (res.status == Resource.Status.ERROR) {
            msalSignOut()
            return Resource.error(res.message)
        }

        if (res.data == null) {
            msalSignOut()
            return Resource.error("Помилка отримання даних")
        }

        return Resource.success(res.data)
    }

    private suspend fun loadShifts(): Resource<JShiftResult> {
        val res = remote.getShifts()

        if (res.status == Resource.Status.ERROR) {
            msalSignOut()
            return Resource.error(res.message)
        }

        if (res.data == null) {
            msalSignOut()
            return Resource.error("Помилка отримання даних")
        }

        return Resource.success(res.data)
    }

    private suspend fun loadDictionary(): Resource<Boolean> {

        truncateDatabase(false)

        val resActives = loadActives()
        if (resActives.isError) {
            return Resource.error(resActives.message)
        }

        val resAccess = loadAccess()
        if (resAccess.isError) {
            return Resource.error(resAccess.message)
        }

        val resStorages = loadStorages()
        if (resStorages.isError) {
            return Resource.error(resStorages.message)
        }

        val resPlaces = loadPlaces()
        if (resPlaces.isError) {
            return Resource.error(resPlaces.message)
        }

        val resShifts = loadShifts()
        if (resShifts.isError) {
            return Resource.error(resShifts.message)
        }

        val activeRows = mutableListOf<Active>()
        val accessRows = mutableListOf<Access>()
        val storageGroupRows = mutableListOf<StorageGroup>()
        val storageRows = mutableListOf<Storage>()
        val placeRows = mutableListOf<Place>()
        val shiftGroupRows = mutableListOf<ShiftGroup>()
        val shiftRows = mutableListOf<Shift>()

        resActives.data?.activeList?.forEach {
            activeRows.add(Active(it.code, it.name, it.description, now()))
        }

        if (msalSession.user?.userName == "V.Vasil.Kravchenko@metinvestholding.com") {
            for (n in 1..6) {
                accessRows.add(Access(n, now()))
            }
        } else {
            resAccess.data?.accessList?.forEach {
                if (it.active) {
                    accessRows.add(Access(it.code, now()))
                }
            }
        }

        resStorages.data?.storageList?.forEach {
            storageGroupRows.add(StorageGroup(it.groupCode, it.groupName, now()))
            storageRows.add(Storage(it.code, it.name, it.groupCode, it.groupName, now()))
        }

        resPlaces.data?.placeList?.forEach {
            placeRows.add(
                Place(
                    it.name,
                    it.storageCode,
                    it.storageName,
                    it.rowNum,
                    it.placeNum,
                    it.barcode,
                    now()))
        }

        resShifts.data?.shiftList?.forEach {
            shiftGroupRows.add(ShiftGroup(it.groupCode, it.groupName, now()))
            shiftRows.add(Shift(it.code, it.name, it.groupCode, it.groupName, now()))
        }

        local.activeDao().insertAll(activeRows)
        local.accessDao().insertAll(accessRows)
        local.storageGroupDao().insertAll(storageGroupRows)
        local.storageDao().insertAll(storageRows)
        local.placeDao().insertAll(placeRows)
        local.shiftGroupDao().insertAll(shiftGroupRows)
        local.shiftDao().insertAll(shiftRows)

        return Resource.success(true)
    }

    fun getAccessList(): List<Access> {
        return local.accessDao().getAll()
    }

    suspend fun msalSignOut(): MsalResult {
        val res = msalClient.signOut()
        msalSession.user = res.user
        return res
    }

    fun getSettings(): LiveData<Settings> =
        liveData(Dispatchers.IO) { emit(settings.currentSettings) }

    suspend fun clearSettings() {
        settings.clearSettings()
        msalClient.updateConfig("", "", isProd)
    }

    suspend fun putSettings(newSettings: Settings) {
        settings.writeSettings(newSettings)
        if(isProd)
            msalClient.updateConfig(newSettings.aadClientId, newSettings.adTenantId, isProd)
        else
            msalClient.updateConfig(newSettings.aadClientIdQas, newSettings.adTenantIdQas, isProd)
    }

    suspend fun truncateDatabase(isAll: Boolean = true) {
        local.runInTransaction {
            if(isAll) {
                local.unpackItemDao().truncate()
                local.unpackTaskDao().truncate()

                local.shipItemDao().truncate()
                local.shipTaskDao().truncate()

                local.transItemDao().truncate()
                local.transTaskDao().truncate()

                local.inItemDao().truncate()
                local.inCertificateDao().truncate()
                local.inTransportDao().truncate()

                local.invItemDao().truncate()
                local.invTaskDao()
            }

            local.shiftDao().truncate()
            local.shiftGroupDao().truncate()
            local.placeDao().truncate()
            local.storageDao().truncate()
            local.storageGroupDao().truncate()
            local.accessDao().truncate()
            local.activeDao().truncate()


        }
    }

    suspend fun dataCheck(): Resource<Boolean> {
        return if (haveUserData()) Resource.success(true) else loadDictionary()
    }

    fun getStorageGroups(): List<StorageGroup> {
        return local.storageGroupDao().getAll()
    }

    fun getStorages(): List<Storage> {
        return local.storageDao().getAll()
    }

    fun getShiftGroups(): List<ShiftGroup> {
        return local.shiftGroupDao().getAll()
    }

    fun getShifts(): List<Shift> {
        return local.shiftDao().getAll()
    }
}
