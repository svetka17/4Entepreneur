package com.sytecs.unisteel.presentation.ship.items

import android.annotation.SuppressLint
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.ShipItem
import com.sytecs.unisteel.databinding.RowShipItemBinding
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.format
import java.text.SimpleDateFormat
import java.util.*

class ShipItemAdapter : ListAdapter<ShipItem, ShipItemAdapter.VH>(ShipItemDiffCallback()) {

    private var list = listOf<ShipItem>()
    private val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault())
    var eventClickItem = SingleLiveEvent<ShipItem>()
    var eventClickItemInfo = SingleLiveEvent<ShipItem>()
    var eventClickItemError = SingleLiveEvent<ShipItem>()
    var eventClickItemRemove = SingleLiveEvent<ShipItem>()

    fun setItems(list: List<ShipItem>) {
        this.list = list
        submitList(list)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding: RowShipItemBinding =
            RowShipItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding, dateFormat)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    private class ShipItemDiffCallback : DiffUtil.ItemCallback<ShipItem>() {
        override fun areItemsTheSame(oldItem: ShipItem, newItem: ShipItem): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: ShipItem, newItem: ShipItem): Boolean {
            return oldItem == newItem
        }
    }

    inner class VH(
        private val itemBinding: RowShipItemBinding,
        private val dateFormat: SimpleDateFormat
    ) : RecyclerView.ViewHolder(itemBinding.root), View.OnClickListener {

        private lateinit var item: ShipItem

        init {
            itemBinding.root.setOnClickListener(this)
        }

        @SuppressLint("SetTextI18n")
        fun bind(item: ShipItem) {
            this.item = item

            itemBinding.viewRoot.setBackgroundResource(
                if (item.shipCreated != null) R.drawable.background_item_success
                else R.drawable.background_item)

            itemBinding.buttonAdd.visibility = View.GONE
            itemBinding.buttonRemove.visibility =
                if (item.shipCreated != null) View.VISIBLE else View.GONE

            itemBinding.buttonInfo.setOnClickListener { eventClickItemInfo.postValue(this.item) }

            itemBinding.imageQr.visibility = if (item.qr.isNotEmpty()) View.VISIBLE else View.GONE

            itemBinding.buttonError.visibility =
                if (item.errorMessage != null) View.VISIBLE else View.GONE

            itemBinding.buttonError.setOnClickListener { eventClickItemError.postValue(this.item) }

            itemBinding.buttonRemove.setOnClickListener {
                eventClickItemRemove.postValue(this.item)
            }

            itemBinding.imageQr.visibility = View.GONE
            itemBinding.imageBarcode.visibility = View.GONE
            itemBinding.buttonInfo.visibility = View.VISIBLE

            itemBinding.text1.text = item.nomenclature

            itemBinding.table.removeAllViews()

            addRow(itemBinding.table, "Марка сталі: ", item.steelGrade)
            addRow(itemBinding.table, "Розмір, мм: ", "${item.width}x${item.thickness}")
            addRow(itemBinding.table, "НЕТТО, т: ", item.weight.format(3))
            addRow(itemBinding.table, "Серія: ", item.serial)
            addRow(itemBinding.table, "Місце складування: ", item.placeName.ifEmpty { "-" })

            item.shipCreated?.let {
                addRow(itemBinding.table, "Сканування: ", dateFormat.format(it))
            }
        }

        private fun addRow(table: TableLayout, col1: String, col2: String) {
            val row = TableRow(table.context)

            val text1 = TextView(this.itemView.context)
            val text2 = TextView(this.itemView.context)

            text1.maxLines = 1
            text1.ellipsize = TextUtils.TruncateAt.END

            text1.text = col1
            text2.text = col2
            text2.textAlignment = View.TEXT_ALIGNMENT_VIEW_END
            row.addView(text1)
            row.addView(text2)

            table.addView(row)

            TableRow.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .let {
                    it.weight = 1.0f
                    // text1.layoutParams = it
                    text2.layoutParams = it
                }
        }

        override fun onClick(v: View?) {
            eventClickItem.postValue(item)
        }
    }
}
