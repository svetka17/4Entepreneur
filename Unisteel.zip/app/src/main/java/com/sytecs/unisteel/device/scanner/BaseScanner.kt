package com.sytecs.unisteel.device.scanner

import android.content.Context
import com.sytecs.unisteel.utils.SingleLiveEvent
import timber.log.Timber

open class BaseScanner {

    val eventBarcode = SingleLiveEvent<String>()

    protected var appContext: Context? = null
    protected var packageName = ""

    open fun create(appContext: Context) {
        this.packageName = appContext.packageName
        this.appContext = appContext
    }

    open fun destroy() {}

    open fun start() {}

    open fun stop() {}

    protected open fun onBarcode(text: String) {
        Timber.d("onBarcode(\"$text\")")
        eventBarcode.postValue(text)
    }
}
