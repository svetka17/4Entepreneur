package com.sytecs.unisteel.presentation.home

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.msal.MsalSession
import com.sytecs.unisteel.data.repository.Repo
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel
@Inject
constructor(
    private val repo: Repo,
    private val msalSession: MsalSession,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {

    val accessList = repo.accessList()

    private val _isProd = MutableLiveData(repo.isProd)
    val isProd: LiveData<Boolean> = _isProd

    private val _userFio =
        MutableLiveData(msalSession.user?.userFio ?: msalSession.user?.userName ?: "-")
    val userFio: LiveData<String> = _userFio

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    val eventPermissions = SingleLiveEvent<String>()

    fun onPermissionsClick() {
        viewModelScope.launch(Dispatchers.IO) {
            // _isLoading.postValue(true)

            val sb = StringBuilder()
            val accessList = repo.getAccessList()

            val codeName =
                mapOf(
                    1 to res.getString(R.string.process1_title),
                    2 to res.getString(R.string.process2_title),
                    3 to res.getString(R.string.process3_title),
                    4 to res.getString(R.string.process4_title),
                    5 to res.getString(R.string.process5_title),
                    6 to res.getString(R.string.process6_title))
            (1..6).withIndex().forEach { (index, id) ->
                val access = accessList.find { it.code == id } != null
                sb.append(
                    "${index + 1}. ${codeName[id]}\n(${if (access) "доступно" else "заборонено"})\n\n")
            }

            sb.append(
                "Для управління доступом до операцій використовуйте корпоративний портал самообслуговування")

            // _isLoading.postValue(false)
            eventPermissions.postValue(sb.toString())
        }
    }
}
