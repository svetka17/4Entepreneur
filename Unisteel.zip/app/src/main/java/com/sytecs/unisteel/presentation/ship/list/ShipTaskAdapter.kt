package com.sytecs.unisteel.presentation.ship.list

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.ShipTask
import com.sytecs.unisteel.databinding.RowShipTaskBinding
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.format
import java.text.SimpleDateFormat
import java.util.*

class ShipTaskAdapter :
    ListAdapter<ShipTask, ShipTaskAdapter.VH>(ShipTaskDiffCallback()), Filterable {

    private val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
    private var list = listOf<ShipTask>()
    var eventClick = SingleLiveEvent<ShipTask>()
    var eventClickSync = SingleLiveEvent<ShipTask>()

    fun setItems(list: List<ShipTask>) {
        this.list = list
        submitList(list)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding: RowShipTaskBinding =
            RowShipTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val filteredList = mutableListOf<ShipTask>()
                if (constraint == null || constraint.isEmpty()) {
                    filteredList.addAll(list)
                } else {
                    list
                        .filter {
                            /*it.task.comment.contains(constraint, true) ||*/
                            it.code.contains(constraint, true)
                        }
                        .forEach { filteredList.add(it) }
                }
                return FilterResults().also { it.values = filteredList }
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                submitList(results?.values as MutableList<ShipTask>)
            }
        }
    }

    private class ShipTaskDiffCallback : DiffUtil.ItemCallback<ShipTask>() {
        override fun areItemsTheSame(oldItem: ShipTask, newItem: ShipTask): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: ShipTask, newItem: ShipTask): Boolean {
            return oldItem == newItem
        }
    }

    inner class VH(private val itemBinding: RowShipTaskBinding) :
        RecyclerView.ViewHolder(itemBinding.root), View.OnClickListener {

        private lateinit var item: ShipTask

        init {
            itemBinding.root.setOnClickListener(this)
        }

        fun bind(item: ShipTask) {
            this.item = item
            val withError = item.itemCountError > 0

            val resId: Int =
                when {
                    withError -> {
                        R.color.status_container_error
                    }
                    item.itemCountScanned > 0 -> {
                        R.color.status_container_success
                    }
                    else -> {
                        R.color.status_container_empty
                    }
                }

            itemBinding.viewMark.setBackgroundResource(resId)

            itemBinding.image2.visibility = if (item.isCar) View.VISIBLE else View.GONE
            itemBinding.image1.visibility = if (item.isCar) View.GONE else View.VISIBLE

            itemBinding.viewRoot.setBackgroundResource(
                when {
                    item.itemCountScanned == item.itemCount -> R.drawable.background_green
                    item.itemCountScanned > 0 -> R.drawable.background_yellow
                    else -> R.drawable.background_empty
                })

            val sb = StringBuilder()

            sb.append("Заявка: ${item.code}\n")
            sb.append("${dateFormat.format(item.date)}\n")
            sb.append("НЕТТО, т: ${item.weight.format(3)}\n")
            sb.append("Водій: ${item.driverName.ifEmpty { "-" }}\n")

            itemBinding.text1.text = item.transportName
            itemBinding.text2.text = sb.toString()
            itemBinding.itemCount.text = item.itemCount.toString()
            itemBinding.itemSuccessCount.text = item.itemCountScanned.toString()
            itemBinding.itemErrorCount.text = item.itemCountError.toString()
            itemBinding.buttonSync.visibility =
                if (item.itemCountScanned > 0) View.VISIBLE else View.GONE

            itemBinding.itemErrorDelimiter.visibility = if (withError) View.VISIBLE else View.GONE
            itemBinding.itemErrorCount.visibility = if (withError) View.VISIBLE else View.GONE

            itemBinding.buttonSync.setOnClickListener { eventClickSync.postValue(item) }
        }

        override fun onClick(v: View?) {
            eventClick.postValue(item)
        }
    }
}
