package com.sytecs.unisteel.presentation.inv.items

import android.annotation.SuppressLint
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.InvItem
import com.sytecs.unisteel.databinding.RowInvItemBinding
import com.sytecs.unisteel.utils.SingleLiveEvent
import java.text.SimpleDateFormat
import java.util.*

class InvItemAdapter : ListAdapter<InvItem, InvItemAdapter.VH>(InvItemDiffCallback()) {

    private var list = listOf<InvItem>()
    private val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault())
    var eventClickItem = SingleLiveEvent<InvItem>()
    var eventClickItemInfo = SingleLiveEvent<InvItem>()
    var eventClickItemError = SingleLiveEvent<InvItem>()
    var eventClickItemRemove = SingleLiveEvent<InvItem>()

    fun setItems(list: List<InvItem>) {
        this.list = list
        submitList(list)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding: RowInvItemBinding =
            RowInvItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding, dateFormat)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    private class InvItemDiffCallback : DiffUtil.ItemCallback<InvItem>() {
        override fun areItemsTheSame(oldItem: InvItem, newItem: InvItem): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: InvItem, newItem: InvItem): Boolean {
            return oldItem == newItem
        }
    }

    inner class VH(
        private val itemBinding: RowInvItemBinding,
        private val dateFormat: SimpleDateFormat
    ) : RecyclerView.ViewHolder(itemBinding.root), View.OnClickListener {

        private lateinit var item: InvItem

        init {
            itemBinding.root.setOnClickListener(this)
        }

        @SuppressLint("SetTextI18n")
        fun bind(item: InvItem) {
            this.item = item

            itemBinding.viewRoot.setBackgroundResource(R.drawable.background_item_manual)

            itemBinding.buttonAdd.visibility = View.GONE
            itemBinding.buttonRemove.visibility = View.VISIBLE

            itemBinding.buttonInfo.setOnClickListener { eventClickItemInfo.postValue(this.item) }

            itemBinding.imageQr.visibility = View.VISIBLE

            itemBinding.buttonError.visibility =
                if (item.errorMessage != null) View.VISIBLE else View.GONE

            itemBinding.buttonError.setOnClickListener { eventClickItemError.postValue(this.item) }

            itemBinding.buttonRemove.setOnClickListener {
                eventClickItemRemove.postValue(this.item)
            }

            itemBinding.imageQr.visibility = if (item.isQr) View.VISIBLE else View.GONE
            itemBinding.imageBarcode.visibility =
                if (!item.isQr && !item.isManual) View.VISIBLE else View.GONE
            itemBinding.imageManual.visibility =
                if (!item.isQr && item.isManual) View.VISIBLE else View.GONE
            itemBinding.buttonInfo.visibility =
                View.GONE // if (item.isQr) View.VISIBLE else View.GONE

            itemBinding.table.removeAllViews()

            if (item.isQr) {
                addRow(itemBinding.table, "Номер од.п.: ", item.itemNumber ?: "-")
                addRow(itemBinding.table, "Партія: ", item.batchNumber ?: "-")
                addRow(itemBinding.table, "Плавка: ", item.meltingNumber ?: "-")
                addRow(itemBinding.table, "Марка сталі: ", item.steelBrand ?: "-")
                addRow(itemBinding.table, "Розмір: ", item.size?.replace(" ", "") ?: "-")
                addRow(itemBinding.table, "НЕТТО, кг: ", item.net ?: "-")
                addRow(itemBinding.table, "БРУТТО, кг: ", item.gross ?: "-")
            } else {
                if (item.isManual) {
                    addRow(itemBinding.table, "Серія: ", item.barcodeSerial ?: "-")
                } else {
                    addRow(itemBinding.table, "Штрихкод: ", item.barcodeText)
                    addRow(itemBinding.table, "Серія: ", item.barcodeSerial ?: "-")
                    addRow(itemBinding.table, "Розмір: ", item.size?.replace(" ", "") ?: "-")
                    addRow(itemBinding.table, "НЕТТО, кг: ", item.net ?: "-")
                    addRow(itemBinding.table, "БРУТТО, кг: ", item.gross ?: "-")
                }
            }

            addRow(itemBinding.table, "Сканування: ", dateFormat.format(item.created))
        }

        private fun addRow(table: TableLayout, col1: String, col2: String) {
            val row = TableRow(table.context)

            val text1 = TextView(this.itemView.context)
            val text2 = TextView(this.itemView.context)

            text1.maxLines = 1
            text1.ellipsize = TextUtils.TruncateAt.END

            text1.text = col1
            text2.text = col2
            text2.textAlignment = View.TEXT_ALIGNMENT_VIEW_END
            row.addView(text1)
            row.addView(text2)

            table.addView(row)

            TableRow.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .let {
                    it.weight = 1.0f
                    // text1.layoutParams = it
                    text2.layoutParams = it
                }
        }

        override fun onClick(v: View?) {
            eventClickItem.postValue(item)
        }
    }
}
