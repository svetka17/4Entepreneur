package com.sytecs.unisteel.presentation.unpack.items

import android.annotation.SuppressLint
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.UnpackItem
import com.sytecs.unisteel.databinding.RowUnpackItemBinding
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.format
import java.text.SimpleDateFormat
import java.util.*

class UnpackItemAdapter : ListAdapter<UnpackItem, UnpackItemAdapter.VH>(UnpackItemDiffCallback()) {

    private var list = listOf<UnpackItem>()
    private val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault())
    var eventClickItem = SingleLiveEvent<UnpackItem>()
    var eventClickItemInfo = SingleLiveEvent<UnpackItem>()
    var eventClickItemError = SingleLiveEvent<UnpackItem>()
    var eventClickItemRemove = SingleLiveEvent<UnpackItem>()
    var eventClickItemAdd = SingleLiveEvent<UnpackItem>()

    fun setItems(list: List<UnpackItem>) {
        this.list = list
        submitList(list)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding: RowUnpackItemBinding =
            RowUnpackItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding, dateFormat)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    private class UnpackItemDiffCallback : DiffUtil.ItemCallback<UnpackItem>() {
        override fun areItemsTheSame(oldItem: UnpackItem, newItem: UnpackItem): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: UnpackItem, newItem: UnpackItem): Boolean {
            return oldItem == newItem
        }
    }

    inner class VH(
        private val itemBinding: RowUnpackItemBinding,
        private val dateFormat: SimpleDateFormat
    ) : RecyclerView.ViewHolder(itemBinding.root), View.OnClickListener {

        private lateinit var item: UnpackItem

        init {
            itemBinding.root.setOnClickListener(this)
        }

        @SuppressLint("SetTextI18n")
        fun bind(item: UnpackItem) {
            this.item = item

            itemBinding.viewRoot.setBackgroundResource(
                if (item.unpackCreated != null) R.drawable.background_item_success
                else R.drawable.background_item)

            itemBinding.buttonAdd.visibility =
                if (item.unpackCreated != null) View.GONE else View.VISIBLE
            itemBinding.buttonRemove.visibility =
                if (item.unpackCreated != null) View.VISIBLE else View.GONE

            itemBinding.buttonAdd.setOnClickListener { eventClickItemAdd.postValue(this.item) }

            itemBinding.buttonInfo.setOnClickListener { eventClickItemInfo.postValue(this.item) }

            itemBinding.imageQr.visibility = if (item.qr.isNotEmpty()) View.VISIBLE else View.GONE

            itemBinding.buttonError.visibility =
                if (item.errorMessage != null) View.VISIBLE else View.GONE

            itemBinding.buttonError.setOnClickListener { eventClickItemError.postValue(this.item) }

            itemBinding.buttonRemove.setOnClickListener {
                eventClickItemRemove.postValue(this.item)
            }

            itemBinding.imageQr.visibility = View.GONE
            itemBinding.imageBarcode.visibility = View.GONE
            itemBinding.buttonInfo.visibility = View.GONE

            itemBinding.text1.text = item.nomenclature

            itemBinding.table.removeAllViews()

            addRow(itemBinding.table, "Марка сталі: ", item.steelGrade)
            addRow(itemBinding.table, "Розмір, мм: ", "${item.width}x${item.thickness}")
            addRow(itemBinding.table, "БРУТТО, т: ", item.weight.format(3))
            addRow(itemBinding.table, "Серія: ", item.serial)
            addRow(itemBinding.table, "Штрихкод: ", item.barcode.ifEmpty { "-" })

            item.unpackCreated?.let {
                addRow(itemBinding.table, "Сканування: ", dateFormat.format(it))
            }
        }

        private fun addRow(table: TableLayout, col1: String, col2: String) {
            val row = TableRow(table.context)

            val text1 = TextView(this.itemView.context)
            val text2 = TextView(this.itemView.context)

            text1.maxLines = 1
            text1.ellipsize = TextUtils.TruncateAt.END

            text1.text = col1
            text2.text = col2
            text2.textAlignment = View.TEXT_ALIGNMENT_VIEW_END
            row.addView(text1)
            row.addView(text2)

            table.addView(row)

            TableRow.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .let {
                    it.weight = 1.0f
                    // text1.layoutParams = it
                    text2.layoutParams = it
                }
        }

        override fun onClick(v: View?) {
            eventClickItem.postValue(item)
        }
    }
}
