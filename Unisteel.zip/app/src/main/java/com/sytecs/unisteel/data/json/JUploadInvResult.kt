package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JUploadInvResult(
    @SerializedName("Seriya") val serial: String?,
    @SerializedName("QR") val qrCode: String?,
    @SerializedName("Штрихкод") val barcode: String?,
    @SerializedName("Error") var error: String?
)
