package com.sytecs.unisteel.data.repository

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.sytecs.unisteel.data.entities.BarcodeItem
import com.sytecs.unisteel.data.entities.db.Place
import com.sytecs.unisteel.data.entities.db.Storage
import com.sytecs.unisteel.data.entities.db.TransItem
import com.sytecs.unisteel.data.entities.db.TransTask
import com.sytecs.unisteel.data.entities.embedded.TransItemWithTaskStorage
import com.sytecs.unisteel.data.json.JUploadTrans
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.now
import okhttp3.RequestBody.Companion.toRequestBody
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

class RepoTrans @Inject constructor(private val repo: Repo) {

    fun taskList(process: Int) = repo.local.transTaskDao().getWithStorageLiveData(process)
    fun itemList(task: TransTask) = repo.local.transItemDao().getByTaskLiveData(task.id)

    suspend fun addTask(process: Int, storage: Storage): Resource<Boolean> {

        repo.local.transTaskDao().insert(TransTask(0, process, storage.code, now(), 0, 0))
        return Resource.success(true)
    }

    fun removeTask(task: TransTask): Resource<Boolean> {
        val process = task.process
        repo.local.transItemDao().deleteByTask(task.id)
        repo.local.transTaskDao().delete(task)
        updateStat(process)
        return Resource.success(true)
    }

    fun removeItem(item: TransItem): Resource<Boolean> {
        val process = item.process
        repo.local.transItemDao().delete(item)
        updateStat(process)
        return Resource.success(true)
    }

    fun removeTaskItems(task: TransTask): Resource<Boolean> {
        val process = task.process
        repo.local.transItemDao().deleteByTask(task.id)
        updateStat(process)
        return Resource.success(true)
    }

    suspend fun addItem(
        task: TransTask,
        item: BarcodeItem,
        place: Place? = null
    ): Resource<Boolean> {
        repo.local
            .transItemDao()
            .insert(
                TransItem(
                    id = 0,
                    taskId = task.id,
                    process = task.process,
                    rowNum = place?.rowNum,
                    placeNum = place?.placeNum,
                    isQr = item.isQr,
                    idCode = item.idCode,
                    factoryCode = item.factoryCode,
                    accountSystem = item.accountSystem,
                    shopNumber = item.shopNumber,
                    verificationCode = item.verificationCode,
                    checkCode = item.checkCode,
                    meltingNumber = item.meltingNumber,
                    batchNumber = item.batchNumber,
                    itemNumber = item.itemNumber,
                    net = item.net,
                    gross = item.gross,
                    productType = item.productType,
                    size = item.size,
                    steelBrand = item.steelBrand,
                    orderNumber = item.orderNumber,
                    year = item.year,
                    pak = item.pak,
                    barcodeText = item.text,
                    created = now(),
                    errorMessage = null,
                    barcodeSerial = null))
        updateStat(task.process)
        return Resource.success(true)
    }

    private fun updateStat(process: Int) {
        repo.local.transTaskDao().updateStat(process)
    }

    fun findItem(
        process: Int,
        item: BarcodeItem,
        task: TransTask? = null
    ): TransItemWithTaskStorage? {

        val res =
            if (task == null) repo.local.transItemDao().findItemByBarcode(process, item.text)
            else repo.local.transItemDao().findItemByBarcodeTask(process, item.text, task.id)

        if (res == null) return null

        val storage = repo.local.storageDao().get(res.task.storageCode) ?: return null

        return TransItemWithTaskStorage(item = res.item, task = res.task, storage = storage)
    }

    fun findTask(process: Int, storage: Storage): TransTask? {
        return repo.local.transTaskDao().getByStorage(process, storage.code)
    }

    fun deleteTasks(process: Int) {
        repo.local.transItemDao().truncate(process)
        repo.local.transTaskDao().truncate(process)
    }

    suspend fun uploadItems(process: Int, task: TransTask? = null): Resource<Boolean> {

        val items =
            when {
                task != null -> repo.local.transItemDao().getByTask(task.id)
                else -> repo.local.transItemDao().getAll(process)
            }

        return uploadItems(process, items, task)
    }

    private suspend fun uploadItems(
        process: Int,
        items: List<TransItem>,
        task: TransTask?
    ): Resource<Boolean> {

        Timber.w("Upload ${items.size} items!")

        val dateTimeFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault())

        val positions = mutableListOf<JUploadTrans.Position>()

        val taskList = if (task == null) repo.local.transTaskDao().getAll(process) else listOf()
        val placeList = if (process == 5) repo.local.placeDao().getAll() else listOf()

        for (item in items) {

            val storageCode =
                task?.storageCode
                    ?: taskList.firstOrNull { it.id == item.taskId }?.storageCode ?: ""

            positions.add(
                JUploadTrans.Position(
                    serial = item.serial,
                    storage = storageCode,
                    place =
                        if (process == 5)
                            placeList
                                .firstOrNull {
                                    it.rowNum == item.rowNum &&
                                        it.placeNum == item.placeNum &&
                                        it.storageCode == storageCode
                                }
                                ?.name
                                ?: ""
                        else "",
                    comment = ""))
        }

        val uploadStruct =
            JUploadTrans(
                operationCode = process,
                userLogin = repo.userNameApi,
                operationDate = dateTimeFormat.format(now()),
                positions = positions)

        val json = JsonObject()
        json.addProperty("CodeOper", uploadStruct.operationCode)
        json.addProperty("date", uploadStruct.operationDate)
        json.addProperty("user", uploadStruct.userLogin)

        val arr = JsonArray(positions.size)
        positions.forEach { pos ->
            arr.add(
                JsonObject().also {
                    it.addProperty("seriya", pos.serial)
                    it.addProperty("skladpoluch", pos.storage)
                    it.addProperty("mesto", pos.place)
                })
        }
        json.add("POSITIONS", arr)

        val raw = json.toString()

        val res = repo.remote.postTransRaw(raw.toRequestBody())

        if (res.isError) {
            return Resource.error(res.message)
        }

        if (res.data == null) {
            return Resource.error("Data error")
        }

        val data = res.data

        var allOk = true

        items.forEach { item ->
            val remoteItem = data.firstOrNull { item2 -> Objects.equals(item.serial, item2.serial) }

            /*remoteItem?.let {
                remoteItem.error = "test error!"
            }*/

            if (remoteItem?.error?.isNotEmpty() == true) {
                item.errorMessage = remoteItem.error
                repo.local.transItemDao().update(item)
                allOk = false
            } else {
                repo.local.transItemDao().delete(item)
            }
        }

        updateStat(process)
        clearEmptyData(process, task)

        return if (allOk) Resource.success(true)
        else Resource.error("Виконано з помилками, перегляньте відмічені позиції")
    }

    private fun clearEmptyData(process: Int, task: TransTask? = null) {
        if (task != null) {
            repo.local.transTaskDao().cleanEmptyByTask(task.id)
        } else {
            repo.local.transTaskDao().cleanEmpty(process)
        }
    }

    suspend fun loadBarcode(process: Int, item: BarcodeItem, task: TransTask) {
        val res = repo.remote.getBarcode(item.text)

        if (res.status == Resource.Status.ERROR ||
            res.data == null ||
            res.data.positions.isEmpty()) {
            Timber.d("Error loading barcode info: ${res.message}")
            return
        }

        val position = res.data.positions.first()

        findItem(process, item, task)?.let {
            it.item.apply {
                size = "${position.thickness}x${position.width}"
                net = position.netto
                gross = position.gross
                barcodeSerial = position.serial
            }
            repo.local.transItemDao().update(it.item)
        }

        Timber.d("Barcode info: $position")
    }
}
