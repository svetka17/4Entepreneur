package com.sytecs.unisteel.data.entities.embedded

import android.os.Parcelable
import androidx.room.Embedded
import androidx.room.Relation
import com.sytecs.unisteel.data.entities.db.InvTask
import com.sytecs.unisteel.data.entities.db.Storage
import kotlinx.parcelize.Parcelize

@Parcelize
data class InvTaskWithStorage(
    @Embedded val task: InvTask,
    @Relation(parentColumn = "storageCode", entityColumn = "code") val storage: Storage
) : Parcelable
