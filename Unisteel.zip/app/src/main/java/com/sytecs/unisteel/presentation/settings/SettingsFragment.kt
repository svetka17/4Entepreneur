package com.sytecs.unisteel.presentation.settings

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.sytecs.unisteel.R
import com.sytecs.unisteel.databinding.SettingsFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber


@AndroidEntryPoint
class SettingsFragment : AppFragment() {

    private var binding: SettingsFragmentBinding by autoCleared()
    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = SettingsFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        setupObservers()

        binding.buttonBack.setOnClickListener {
            mainActivity?.updateCameraScan()
            goBack()
        }
        binding.buttonClear.setOnClickListener {
            showConfirm(Options(getString(R.string.settings_reset_warning))) {
                viewModel.onClearClick()
            }
        }
        binding.buttonSave.setOnClickListener {
            val isProdNew = binding.radioProd.isChecked
            val message =
                if (isProdNew != viewModel.data.value!!.isProd)
                    getString(R.string.settings_data_lost_warning)
                else getString(R.string.settings_save_confirm)

            showConfirm(Options(message)) {
                viewModel.onSaveClick(
                    isProdNew,
                    binding.editApiUrlProd.text.toString(),
                    binding.editApiUrlQas.text.toString(),
                    binding.checkCameraScan.isChecked,
                    binding.editAadClientId.text.toString(),
                    binding.editAdTenantId.text.toString(),
                    binding.editAadClientIdQas.text.toString(),
                    binding.editAdTenantIdQas.text.toString()
                )
            }
        }

        binding.buttonTruncate.setOnClickListener { onTruncateClick() }
        binding.radioProd.setOnCheckedChangeListener { _, isChecked ->
            binding.viewProd.visibility = if (isChecked) View.VISIBLE else View.GONE
            binding.viewQas.visibility = if (!isChecked) View.VISIBLE else View.GONE

            binding.viewAadClientId.visibility = if (isChecked) View.VISIBLE else View.GONE
            binding.viewAadClientIdQas.visibility = if (!isChecked) View.VISIBLE else View.GONE

            binding.viewAdTenantId.visibility = if (isChecked) View.VISIBLE else View.GONE
            binding.viewAdTenantIdQas.visibility = if (!isChecked) View.VISIBLE else View.GONE
        }
        binding.checkCameraScan.setOnClickListener {  onCameraScan() }
    }

    private fun onCameraScan() {
        if(binding.checkCameraScan.isChecked) mainActivity?.updateCameraScan( true)
    }

    private fun onTruncateClick() {
        showConfirm(Options(getString(R.string.settings_clear_confirm))) {
            viewModel.onTruncateClick()
            showToast(getString(R.string.settings_post_clear))
        }
    }

    private fun setupObservers() {
        observe(viewModel.data) {
            binding.radioProd.isChecked = it.isProd
            binding.radioQas.isChecked = !it.isProd
            binding.editApiUrlProd.setText(it.apiUrlProd)
            binding.editApiUrlQas.setText(it.apiUrlQas)
            binding.checkCameraScan.isChecked = it.isCameraScan
            binding.editAadClientId.setText(it.aadClientId)
            binding.editAdTenantId.setText(it.adTenantId)
            binding.editAadClientIdQas.setText(it.aadClientIdQas)
            binding.editAdTenantIdQas.setText(it.adTenantIdQas)
        }

        observe(viewModel.userData) {
            binding.buttonTruncate.visibility = if (it) View.VISIBLE else View.GONE
        }

        observeEvent(viewModel.eventSaved) {
            mainActivity?.updateCameraScan()
            goBack()
        }

        observeEvent(viewModel.eventReset) { goBack() }
    }

    override fun onBarcodeText(text: String) {
        if(binding.radioProd.isChecked){
            if(binding.editAadClientId.isFocused) binding.editAadClientId.setText(text)
            else if(binding.editAdTenantId.isFocused) binding.editAdTenantId.setText(text)
        }else{
            if(binding.editAadClientIdQas.isFocused) binding.editAadClientIdQas.setText(text)
            else if(binding.editAdTenantIdQas.isFocused) binding.editAdTenantIdQas.setText(text)
        }
        Timber.d("onBarcodeText: $text")
    }
}
