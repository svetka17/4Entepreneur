package com.sytecs.unisteel.presentation

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.hanks.passcodeview.PasscodeView
import com.sytecs.unisteel.databinding.ActivityPinBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class PinActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPinBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPinBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonBack.setOnClickListener { finish() }

        val pinCode = intent.getStringExtra("pin_code") ?: "7525"

        binding.passcodeView.apply {
            passcodeLength = pinCode.length
            localPasscode = pinCode

            listener =
                object : PasscodeView.PasscodeViewListener {
                    override fun onFail() {
                        finish()
                    }

                    override fun onSuccess(number: String?) {
                        setResult(RESULT_OK)
                        finish()
                    }
                }
        }
    }
}
