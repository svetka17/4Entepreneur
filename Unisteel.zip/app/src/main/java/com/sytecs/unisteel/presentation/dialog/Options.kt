package com.sytecs.unisteel.presentation.dialog

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Options(
    var message: String = "",
    var title: String? = null,
    var isCentered: Boolean = true,
    var messageHtml: String = "",
    var isRed: Boolean = false
) : Parcelable {
    val isTitle: Boolean
        get() = title != null
}
