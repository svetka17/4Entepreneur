package com.sytecs.unisteel.data.local

import androidx.room.*
import com.sytecs.unisteel.data.entities.db.InCertificate

@Dao
interface InCertificateDao {

    @Query("SELECT count(1) FROM in_certificates") fun getCount(): Long

    @Query("SELECT * FROM in_certificates") fun getAll(): List<InCertificate>

    @Query("SELECT * FROM in_certificates WHERE transportId = :transportId")
    fun getByTransport(transportId: Long): List<InCertificate>

    @Query("SELECT * FROM in_certificates WHERE transportId = :transportId AND code = :code")
    fun getByTransport(transportId: Long, code: String): InCertificate?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(rows: List<InCertificate>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: InCertificate): Long

    @Update fun update(row: InCertificate)

    @Delete fun delete(row: InCertificate)

    @Query("DELETE FROM in_certificates") fun truncate()

    @Query(
        "UPDATE in_certificates SET " +
            "weight = (SELECT TOTAL(weight) FROM in_items WHERE in_items.certificateId = in_certificates.id), " +
            "itemCount = (SELECT COUNT(1) FROM in_items WHERE in_items.certificateId = in_certificates.id), " +
            "itemCountScanned = (SELECT COUNT(1) FROM in_items WHERE in_items.certificateId = in_certificates.id AND in_items.inCreated IS NOT NULL), " +
            "itemCountError = (SELECT COUNT(1) FROM in_items WHERE in_items.certificateId = in_certificates.id AND in_items.errorMessage IS NOT NULL)")
    fun updateStat()

    @Query("DELETE FROM in_certificates WHERE itemCount = 0") fun cleanEmpty()

    @Query("DELETE FROM in_certificates WHERE itemCount = 0 AND transportId = :transportId")
    fun cleanEmptyByTransport(transportId: Long)
}
