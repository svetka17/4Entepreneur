package com.sytecs.unisteel.data.remote

import com.sytecs.unisteel.data.config.AppSettings
import com.sytecs.unisteel.data.msal.MsalClient
import com.sytecs.unisteel.data.msal.MsalSession
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response
import timber.log.Timber
import java.util.*
import javax.inject.Inject

class BearerLoginInterceptor
@Inject
constructor(private val session: MsalSession, private val msal: MsalClient,
            val settings: AppSettings
) : Interceptor {

    private suspend fun checkToken() {

        var refreshCondition = true
        if (session.user != null && Calendar.getInstance().time.before(session.user?.expiresOn)) {
            refreshCondition = false
        }

        if (refreshCondition) {
            val t1 = System.currentTimeMillis()
            session.user = msal.signCheck(settings.currentSettings.isProd).user
            val t2 = System.currentTimeMillis() - t1
            Timber.d("Refresh token in $t2 ms")
        }
    }

    override fun intercept(chain: Interceptor.Chain): Response {

        runBlocking { checkToken() }

        val request: Request = chain.request()
        val authenticatedRequest =
            request
                .newBuilder()
                .header("Authorization", "Bearer ${session.user?.accessToken}")
                .build()
        return chain.proceed(authenticatedRequest)
    }
}
