package com.sytecs.unisteel.data.entities.db

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.util.*

@Parcelize
@Entity(tableName = "ship_tasks")
data class ShipTask(
    @PrimaryKey(autoGenerate = true) var id: Long,
    val code: String,
    val date: Date,
    var transportName: String,
    var driverName: String,
    val consigneeName: String,
    val transportType: String,
    val isCar: Boolean,
    val isFinished: Boolean,
    val created: Date,
    val weight: Double,
    var comment: String,
    var carWithoutAwning: Boolean,
    val itemCount: Int,
    val itemCountScanned: Int,
    val itemCountError: Int
) : Parcelable

// "EvNomerZayavky": "9 042",
// "EvDateZayavky": "03.06.2021 17:38:52",
// "EvNomerTS": "Рено ВС7598МІВС2212ХF",
// "EvVoditely": "Бадира Юрій Богданович 0966599813",
// "EvPoluchately": "",
// "EvTSType": "Автотранспортом",
// "EvOtgrugenaVsyaZayavka": false,
