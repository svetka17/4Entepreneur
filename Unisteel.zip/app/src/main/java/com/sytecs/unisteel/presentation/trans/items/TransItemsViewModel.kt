package com.sytecs.unisteel.presentation.trans.items

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.BarcodeItem
import com.sytecs.unisteel.data.entities.db.Place
import com.sytecs.unisteel.data.entities.db.Storage
import com.sytecs.unisteel.data.entities.db.TransItem
import com.sytecs.unisteel.data.entities.db.TransTask
import com.sytecs.unisteel.data.repository.RepoTrans
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.parseItemQr
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@HiltViewModel
class TransItemsViewModel
@Inject
constructor(
    private val repoTrans: RepoTrans,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {

    private val process: Int
        get() = savedStateHandle.get<Int>("process")!!
    private val task: TransTask
        get() = savedStateHandle.get<TransTask>("task")!!
    private val storage: Storage
        get() = savedStateHandle.get<Storage>("storage")!!

    val data: LiveData<List<TransItem>> = repoTrans.itemList(task)

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    val eventBack = SingleLiveEvent<Boolean>()
    val eventBeep = SingleLiveEvent<Boolean>()
    val eventScrollUp = SingleLiveEvent<Boolean>()
    val eventAddedToPlace = SingleLiveEvent<Place>()
    val eventToast = SingleLiveEvent<String>()
    val eventAlert = SingleLiveEvent<Pair<String, String?>>()
    val eventSync = SingleLiveEvent<Resource<Boolean>>()
    val eventSelectPlace = SingleLiveEvent<Pair<Storage, BarcodeItem>>()
    val eventSelectPlaceAgain = SingleLiveEvent<Pair<Storage, BarcodeItem>>()

    fun onBarcodeText(text: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val item = parseItemQr(text)

            if (item == null) {
                eventAlert.postValue(Pair(text, res.getString(R.string.trans_item_invalid)))
                eventBeep.postValue(true)
                return@launch
            }

            repoTrans.findItem(process, item)?.let {
                if (it.task != task) {
                    eventAlert.postValue(
                        Pair(
                            res.getString(
                                R.string.trans_item_already_scanned_in_storage, it.storage.name),
                            null))
                    eventBeep.postValue(true)
                    return@launch
                }
            }

            val itemTrans = repoTrans.findItem(process, item, task)

            if (itemTrans != null) {
                if (process == 4) {
                    eventAlert.postValue(
                        Pair(res.getString(R.string.trans_item_already_scanned), null))
                    eventBeep.postValue(true)
                } else {
                    repoTrans.removeItem(itemTrans.item)
                    eventSelectPlaceAgain.postValue(Pair(storage, item))
                }
                return@launch
            }

            if (process == 4) {
                saveItem(item, null)
                return@launch
            }

            eventSelectPlace.postValue(Pair(storage, item))
        }
    }

    fun onBarcodeItem(barcodeItem: BarcodeItem, place: Place) {
        viewModelScope.launch(Dispatchers.IO) { saveItem(barcodeItem, place) }
    }

    private suspend fun saveItem(barcodeItem: BarcodeItem, place: Place?) {
        repoTrans.addItem(task, barcodeItem, place)
        eventScrollUp.postValue(true)
        place?.let { eventAddedToPlace.postValue(it) }

        if (!barcodeItem.isQr) {
            viewModelScope.launch(Dispatchers.IO) {
                repoTrans.loadBarcode(process, barcodeItem, task)
            }
        }
    }

    fun removeItems() {
        viewModelScope.launch(Dispatchers.IO) { repoTrans.removeTaskItems(task) }
    }

    fun removeItem(item: TransItem) {
        viewModelScope.launch(Dispatchers.IO) { repoTrans.removeItem(item) }
    }

    fun removeTask() {
        viewModelScope.launch(Dispatchers.IO) {
            repoTrans.removeTask(task)
            eventBack.postValue(true)
        }
    }

    fun syncData(task: TransTask? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            val res = repoTrans.uploadItems(process, task)
            _isLoading.postValue(false)
            eventSync.postValue(res)
        }
    }
}
