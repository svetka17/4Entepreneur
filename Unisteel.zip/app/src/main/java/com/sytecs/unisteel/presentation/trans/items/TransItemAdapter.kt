package com.sytecs.unisteel.presentation.trans.items

import android.annotation.SuppressLint
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.TransItem
import com.sytecs.unisteel.databinding.RowTransItemBinding
import com.sytecs.unisteel.utils.SingleLiveEvent
import java.text.SimpleDateFormat
import java.util.*

class TransItemAdapter : ListAdapter<TransItem, TransItemAdapter.VH>(InItemDiffCallback()) {

    private var list = listOf<TransItem>()
    private val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault())
    var eventClickItem = SingleLiveEvent<TransItem>()
    var eventClickItemInfo = SingleLiveEvent<TransItem>()
    var eventClickItemError = SingleLiveEvent<TransItem>()
    var eventClickItemRemove = SingleLiveEvent<TransItem>()

    fun setItems(list: List<TransItem>) {
        this.list = list
        submitList(list)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding: RowTransItemBinding =
            RowTransItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding, dateFormat)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    private class InItemDiffCallback : DiffUtil.ItemCallback<TransItem>() {
        override fun areItemsTheSame(oldItem: TransItem, newItem: TransItem): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: TransItem, newItem: TransItem): Boolean {
            return oldItem == newItem
        }
    }

    inner class VH(
        private val itemBinding: RowTransItemBinding,
        private val dateFormat: SimpleDateFormat
    ) : RecyclerView.ViewHolder(itemBinding.root), View.OnClickListener {

        private lateinit var item: TransItem

        init {
            itemBinding.root.setOnClickListener(this)
        }

        @SuppressLint("SetTextI18n")
        fun bind(item: TransItem) {
            this.item = item

            itemBinding.viewRoot.setBackgroundResource(R.drawable.background_item_manual)

            itemBinding.buttonAdd.visibility = View.GONE
            itemBinding.buttonRemove.visibility = View.VISIBLE

            itemBinding.buttonInfo.setOnClickListener { eventClickItemInfo.postValue(this.item) }

            itemBinding.imageQr.visibility = View.VISIBLE

            itemBinding.buttonError.visibility =
                if (item.errorMessage != null) View.VISIBLE else View.GONE

            itemBinding.buttonError.setOnClickListener { eventClickItemError.postValue(this.item) }

            itemBinding.buttonRemove.setOnClickListener {
                eventClickItemRemove.postValue(this.item)
            }

            itemBinding.imageQr.visibility = if (item.isQr) View.VISIBLE else View.GONE
            itemBinding.imageBarcode.visibility = if (!item.isQr) View.VISIBLE else View.GONE
            itemBinding.buttonInfo.visibility =
                View.GONE // if (item.isQr) View.VISIBLE else View.GONE

            itemBinding.table.removeAllViews()

            if (item.isQr) {
                addRow(itemBinding.table, "Номер од.п.: ", item.itemNumber ?: "-")
                addRow(itemBinding.table, "Партія: ", item.batchNumber ?: "-")
                addRow(itemBinding.table, "Плавка: ", item.meltingNumber ?: "-")
                addRow(itemBinding.table, "Марка сталі: ", item.steelBrand ?: "-")
                addRow(itemBinding.table, "Розмір: ", item.size?.replace(" ", "") ?: "-")
                addRow(itemBinding.table, "НЕТТО, кг: ", item.net ?: "-")
                addRow(itemBinding.table, "БРУТТО, кг: ", item.gross ?: "-")
            } else {
                addRow(itemBinding.table, "Штрихкод: ", item.barcodeText)
                addRow(itemBinding.table, "Серія: ", item.barcodeSerial ?: "-")
                addRow(itemBinding.table, "Розмір: ", item.size?.replace(" ", "") ?: "-")
                addRow(itemBinding.table, "НЕТТО, кг: ", item.net ?: "-")
                addRow(itemBinding.table, "БРУТТО, кг: ", item.gross ?: "-")
            }

            if (item.rowNum != null && item.placeNum != null) {
                addRow(itemBinding.table, "Локація: ", "${item.rowNum}-${item.placeNum}")
            }

            addRow(itemBinding.table, "Сканування: ", dateFormat.format(item.created))
        }

        private fun addRow(table: TableLayout, col1: String, col2: String) {
            val row = TableRow(table.context)

            val text1 = TextView(this.itemView.context)
            val text2 = TextView(this.itemView.context)

            text1.maxLines = 1
            text1.ellipsize = TextUtils.TruncateAt.END

            text1.text = col1
            text2.text = col2
            text2.textAlignment = View.TEXT_ALIGNMENT_VIEW_END
            row.addView(text1)
            row.addView(text2)

            table.addView(row)

            TableRow.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .let {
                    it.weight = 1.0f
                    // text1.layoutParams = it
                    text2.layoutParams = it
                }
        }

        override fun onClick(v: View?) {
            eventClickItem.postValue(item)
        }
    }
}
