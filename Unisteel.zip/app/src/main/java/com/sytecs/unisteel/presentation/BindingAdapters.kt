package com.sytecs.unisteel.presentation

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import androidx.databinding.BindingAdapter
import com.sytecs.unisteel.R

@BindingAdapter("userTitle")
fun bindUserTitle(textView: TextView, userFio: String) {
    textView.text = String.format(textView.context.getString(R.string.home_user_title), userFio)
}

private fun tryHideKeyboard(view: View) {
    view.context?.let { context ->
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE)
        if (imm is InputMethodManager &&
            context is ContextWrapper &&
            context.baseContext is Activity) {
            imm.hideSoftInputFromWindow(
                (context.baseContext as Activity).currentFocus?.windowToken, 0)
        }
    }
}

@BindingAdapter("isVisible")
fun bindIsVisible(view: View, isVisible: Boolean) {
    view.visibility = if (isVisible) View.VISIBLE else View.GONE
    if (!isVisible) {
        tryHideKeyboard(view)
    }
}

@BindingAdapter("isInvisible")
fun bindIsInvisible(view: View, isInvisible: Boolean) {
    view.visibility = if (isInvisible) View.INVISIBLE else View.VISIBLE
    if (isInvisible) {
        tryHideKeyboard(view)
    }
}

@BindingAdapter("isGone")
fun bindIsGone(view: View, isGone: Boolean) {
    view.visibility = if (isGone) View.GONE else View.VISIBLE
    if (isGone) {
        tryHideKeyboard(view)
    }
}
