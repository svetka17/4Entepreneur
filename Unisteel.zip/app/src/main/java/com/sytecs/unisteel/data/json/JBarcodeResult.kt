package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JBarcodeResult(@SerializedName("EvShtrixcode") val positions: List<Position>) {
    data class Position(
        @SerializedName("shtrixcode") val barcode: String,
        @SerializedName("seriya") val serial: String,
        @SerializedName("ves") val netto: String,
        @SerializedName("vesbrutto") val gross: String,
        @SerializedName("tolshina") val thickness: String,
        @SerializedName("shirina") val width: String
    )
}
