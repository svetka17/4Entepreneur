package com.sytecs.unisteel.data.config

import android.content.Context
import android.os.Build
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import com.sytecs.unisteel.data.entities.Settings
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AppSettings @Inject constructor(private val appContext: Context) {

    companion object {
        @Volatile private var instance: AppSettings? = null

        fun getInstance(context: Context): AppSettings =
            instance
                ?: synchronized(this) { instance ?: AppSettings(context).also { instance = it } }
    }

    private val defIsProd = true
    private val defApiUrlProd = "https://uns-1c-prd.metinvestholding.com/unisteel/hs/obmen"
    private val defApiUrlQas = "https://uns-1c-dev.metinvestholding.com/unisteel_dev2/hs/obmen"
    private val defIsCameraScan = false
    private val defAadClientId: String = "a22d6b9d-a2a5-4f5d-9ad2-f493074bd14f"
    private val defAdTenantId: String = "b0bbbc89-2041-434f-8618-bc081a1a01d4"
    private val defAadClientIdQas: String = "7daba381-fa4b-42f9-a2fe-c1809b5ef883"
    private val defAdTenantIdQas: String = "b0bbbc89-2041-434f-8618-bc081a1a01d4"

    private val settingsName: String = "unisteel"

    private var settings: Settings = Settings.newEmpty()

    private val masterKeyAlias by lazy { MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC) }

    private val preferences by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            EncryptedSharedPreferences.create(
                settingsName,
                masterKeyAlias,
                appContext,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } else {
            appContext.getSharedPreferences(settingsName, Context.MODE_PRIVATE)
        }
    }

    val currentSettings: Settings
        get() {
            return settings
        }

    init {
        readSettings()
    }

    private fun readSettings() {
        settings =
            Settings(
                isProd = preferences.getBoolean("isApiProd", defIsProd),
                apiUrlProd = preferences.getString("apiUrlProd", defApiUrlProd) ?: defApiUrlProd,
                apiUrlQas = preferences.getString("apiUrlQas", defApiUrlQas) ?: defApiUrlQas,
                isCameraScan = preferences.getBoolean("isCameraScan", defIsCameraScan),
                aadClientId = preferences.getString("aadClientId", defAadClientId) ?: defAadClientId,
                adTenantId = preferences.getString("adTenantId", defAdTenantId) ?: defAdTenantId,
                aadClientIdQas = preferences.getString("aadClientIdQas", defAadClientIdQas) ?: defAadClientIdQas,
                adTenantIdQas = preferences.getString("adTenantIdQas", defAdTenantIdQas) ?: defAdTenantIdQas
            )
    }

    fun clearSettings() {
        settings =
            Settings(
                isProd = defIsProd,
                apiUrlProd = defApiUrlProd,
                apiUrlQas = defApiUrlQas,
                isCameraScan = defIsCameraScan,
                aadClientId = defAadClientId,
                adTenantId = defAdTenantId,
                aadClientIdQas = defAadClientIdQas,
                adTenantIdQas = defAdTenantIdQas
            )
        writeSettings()
    }

    fun writeSettings(newSettings: Settings) {
        this.settings = newSettings
        writeSettings()
    }

    private fun writeSettings() {
        val editor = preferences.edit()
        editor?.let {
            it.putBoolean("isApiProd", settings.isProd)
            it.putString("apiUrlProd", settings.apiUrlProd)
            it.putString("apiUrlQas", settings.apiUrlQas)
            it.putBoolean("isCameraScan", settings.isCameraScan)
            it.putString("aadClientId", settings.aadClientId)
            it.putString("adTenantId", settings.adTenantId)
            it.putString("aadClientIdQas", settings.aadClientIdQas)
            it.putString("adTenantIdQas", settings.adTenantIdQas)
            it.apply()
        }
    }
}
