package com.sytecs.unisteel.data.entities.db

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.util.*

@Parcelize
@Entity(tableName = "unpack_tasks")
data class UnpackTask(
    @PrimaryKey(autoGenerate = true) var id: Long,
    val code: String,
    val shiftGroupCode: String,
    val shiftCode: String,
    val date: Date,
    val created: Date,
    val weight: Double,
    val itemCount: Int,
    val itemCountScanned: Int,
    val itemCountError: Int
) : Parcelable
