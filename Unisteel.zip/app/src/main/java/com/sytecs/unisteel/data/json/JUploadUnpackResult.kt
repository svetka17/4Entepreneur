package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JUploadUnpackResult(
    @SerializedName("Seriya") val serial: String,
    @SerializedName("Error") var error: String
)
