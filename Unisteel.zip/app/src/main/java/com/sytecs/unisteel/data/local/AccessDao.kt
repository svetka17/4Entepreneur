package com.sytecs.unisteel.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sytecs.unisteel.data.entities.db.Access

@Dao
interface AccessDao {

    @Query("SELECT count(1) FROM access") fun getCount(): Long

    @Query("SELECT * FROM access") fun getAll(): List<Access>

    @Query("SELECT * FROM access") fun getAllLiveData(): LiveData<List<Access>>

    @Query("SELECT * FROM access WHERE code = :code") fun get(code: String): Access?

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<Access>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: Access)

    @Update fun update(row: Access)

    @Delete fun delete(row: Access)

    @Query("DELETE FROM access") fun truncate()
}
