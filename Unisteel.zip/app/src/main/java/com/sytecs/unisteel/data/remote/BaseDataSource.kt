package com.sytecs.unisteel.data.remote

import com.sytecs.unisteel.utils.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.ResponseBody
import retrofit2.Response

abstract class BaseDataSource {

    inline fun <reified T : Any> retrieveSomething(): String {
        return T::class.java.toString()
    }

    @Suppress("BlockingMethodInNonBlockingContext")
    private suspend fun ResponseBody.stringSuspending() = withContext(Dispatchers.IO) { string() }

    protected suspend fun <T> getResult(call: suspend () -> Response<T>): Resource<T> {
        try {
            var response = call()
            if(response.code() == 401) {
                response = call()
            }
            try {
                if (response.isSuccessful) {
                    val body = response.body()
                    if (body != null) return Resource.success(body)
                }
/*
                var errorMessage = "${response.code()} ${response.message()}"

                response.errorBody()?.stringSuspending()?.let {
                    errorMessage = it

                    try {
                        val json = JSONObject(it)
                        json.getStringIgnoreCase("msg")?.let { msg -> errorMessage = msg }
                        json.getStringArrayIgnoreCase("messages")?.let { messages ->
                            if (messages.isNotEmpty()) errorMessage = messages[0]
                        }
                    } catch (e: Exception) {
                    }
                }

 */

                return error(response)
            } catch (e: Exception) {
                return error(response)
            }
        }catch (e: Exception){
            return error("Відсутній зв'язок з сервером")//e.message ?: e.toString())
        }
    }

    private fun <T> error(message: String): Resource<T> {
        return Resource.error(/*"Network call has failed for a following reason: $*/ message /*"*/)
    }

    private fun <T> error(response: Response<T>): Resource<T> {
        val detali: String
        val dia: String
        if (response.code() == 200){
            detali = "відповідь сервера не відповідає протоколу"
            dia = "Зверніться в підтримку"
        }else {
            detali = "помилка інфраструктури чи 1С"
            dia = "Зверніться в підтримку"
        }
        return Resource.error("Метод: ${response.raw().request.method}/${response.raw().request.url.encodedPath}\n" +
                "HTTP-код відповіді: ${response.code()}\n" +
                "Деталі: $detali\n" +
                "Дія: $dia")
    }
}
