package com.sytecs.unisteel.data.entities.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.*

@Entity(tableName = "access") data class Access(@PrimaryKey val code: Int, val created: Date)
