package com.sytecs.unisteel.presentation.unpack.list

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.data.entities.db.UnpackTask
import com.sytecs.unisteel.data.repository.RepoUnpack
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class UnpackListViewModel
@Inject
constructor(
    private val repoUnpack: RepoUnpack,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {

    val data = repoUnpack.taskListWithShift()

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    val eventSync = SingleLiveEvent<Resource<Boolean>>()

    fun syncData(task: UnpackTask) {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            val res = repoUnpack.uploadItems(task)
            _isLoading.postValue(false)
            eventSync.postValue(res)
        }
    }

    fun removeItems() {
        viewModelScope.launch(Dispatchers.IO) { repoUnpack.deleteTasks() }
    }
}
