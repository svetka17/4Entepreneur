package com.sytecs.unisteel.data.entities.embedded

import android.os.Parcelable
import androidx.room.Embedded
import androidx.room.Relation
import com.sytecs.unisteel.data.entities.db.Shift
import com.sytecs.unisteel.data.entities.db.ShiftGroup
import com.sytecs.unisteel.data.entities.db.UnpackTask
import kotlinx.parcelize.Parcelize

@Parcelize
data class UnpackTaskWithShift(
    @Embedded val task: UnpackTask,
    @Relation(parentColumn = "shiftGroupCode", entityColumn = "code") val shiftGroup: ShiftGroup,
    @Relation(parentColumn = "shiftCode", entityColumn = "code") val shift: Shift
) : Parcelable
