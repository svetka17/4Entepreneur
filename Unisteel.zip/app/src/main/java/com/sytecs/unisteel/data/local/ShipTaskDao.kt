package com.sytecs.unisteel.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sytecs.unisteel.data.entities.db.ShipTask

@Dao
interface ShipTaskDao {

    @Query("SELECT count(1) FROM ship_tasks") fun getCount(): Long

    @Query("SELECT * FROM ship_tasks") fun getAll(): List<ShipTask>

    @Query("SELECT * FROM ship_tasks") fun getAllLiveData(): LiveData<List<ShipTask>>

    @Query("SELECT * FROM ship_tasks WHERE id = :id") fun get(id: Long): ShipTask?

    @Query("SELECT * FROM ship_tasks WHERE code = :code") fun get(code: String): ShipTask?

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<ShipTask>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: ShipTask): Long

    @Update fun update(row: ShipTask)

    @Delete fun delete(row: ShipTask)

    @Query("DELETE FROM ship_tasks") fun truncate()

    @Query(
        "UPDATE ship_tasks SET " +
            "weight = (SELECT TOTAL(weight) FROM ship_items WHERE ship_items.taskId = ship_tasks.id), " +
            "itemCount = (SELECT COUNT(1) FROM ship_items WHERE ship_items.taskId = ship_tasks.id), " +
            "itemCountScanned = (SELECT COUNT(1) FROM ship_items WHERE ship_items.taskId = ship_tasks.id AND ship_items.shipCreated IS NOT NULL), " +
            "itemCountError = (SELECT COUNT(1) FROM ship_items WHERE ship_items.taskId = ship_tasks.id AND ship_items.errorMessage IS NOT NULL) ")
    fun updateStat()

    @Query("DELETE FROM ship_tasks WHERE id = :id AND itemCount = 0") fun cleanEmptyByTask(id: Long)
}
