package com.sytecs.unisteel.data.remote

import com.sytecs.unisteel.data.json.JUploadIn
import com.sytecs.unisteel.data.json.JUploadInv
import com.sytecs.unisteel.data.json.JUploadShip
import com.sytecs.unisteel.data.json.JUploadTrans
import javax.inject.Inject
import okhttp3.RequestBody

class RemoteDataSource @Inject constructor(private val networkService: NetworkService) :
    BaseDataSource() {

    suspend fun getActives() = getResult { networkService.getActives() }
    suspend fun getAccess(user: String) = getResult { networkService.getAccess(user) }
    suspend fun getStorages() = getResult { networkService.getStorages() }
    suspend fun getPlaces() = getResult { networkService.getPlaces() }
    suspend fun getShifts() = getResult { networkService.getShifts() }
    suspend fun getCertificate(certificateCode: String?, transport: String?, ttn: String?) =
        getResult {
            networkService.getCertificate(certificateCode, transport, ttn)
        }
    suspend fun postIn(data: JUploadIn) = getResult { networkService.postIn(data) }
    suspend fun postInRaw(data: RequestBody) = getResult { networkService.postInRaw(data) }
    suspend fun postTrans(data: JUploadTrans) = getResult { networkService.postTrans(data) }
    suspend fun postTransRaw(data: RequestBody) = getResult { networkService.postTransRaw(data) }
    suspend fun getBarcode(barcode: String) = getResult { networkService.getBarcode(barcode) }
    suspend fun getShipTask(data: RequestBody) = getResult { networkService.getShipTask(data) }
    suspend fun postShipTask(data: JUploadShip) = getResult { networkService.postShipTask(data) }
    suspend fun getUnpackTask(number: String) = getResult { networkService.getUnpackTask(number) }
    suspend fun postUnpackRaw(data: RequestBody) = getResult { networkService.postUnpackRaw(data) }
    suspend fun postInv(data: JUploadInv) = getResult { networkService.postInv(data) }
    suspend fun postInvRaw(data: RequestBody) = getResult { networkService.postInvRaw(data) }
}
