package com.sytecs.unisteel.data.entities.db

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.util.*

@Parcelize
@Entity(tableName = "in_items")
data class InItem(
    @PrimaryKey(autoGenerate = true) val id: Long,
    @ColumnInfo(index = true) val certificateId: Long,
    @ColumnInfo(index = true) val transportId: Long,
    val batch: String,
    val melting: String,
    val steelGrade: String,
    val thickness: String,
    val width: String,
    val weight: Double,
    val serial: String,
    val barcode: String,
    val qr: String,
    val qrId: String?,
    val serialSupplier: String,
    val created: Date,
    var inCreated: Date?,
    var inManual: Boolean?,
    var inStorageCode: String?,
    var inBarcode: String?,
    var errorMessage: String?
) : Parcelable
