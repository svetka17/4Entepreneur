package com.sytecs.unisteel.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.sytecs.unisteel.BuildConfig
import com.sytecs.unisteel.data.entities.db.*
import timber.log.Timber

@Database(
    entities =
        [
            Active::class,
            Access::class,
            StorageGroup::class,
            Storage::class,
            Place::class,
            ShiftGroup::class,
            Shift::class,
            InTransport::class,
            InCertificate::class,
            InItem::class,
            TransTask::class,
            TransItem::class,
            ShipTask::class,
            ShipItem::class,
            UnpackTask::class,
            UnpackItem::class,
            InvTask::class,
            InvItem::class],
    version = 21,
    exportSchema = false)
@TypeConverters(DateConverter::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun activeDao(): ActiveDao
    abstract fun accessDao(): AccessDao
    abstract fun storageGroupDao(): StorageGroupDao
    abstract fun storageDao(): StorageDao
    abstract fun placeDao(): PlaceDao
    abstract fun shiftGroupDao(): ShiftGroupDao
    abstract fun shiftDao(): ShiftDao

    abstract fun inTransportDao(): InTransportDao
    abstract fun inCertificateDao(): InCertificateDao
    abstract fun inItemDao(): InItemDao

    abstract fun transTaskDao(): TransTaskDao
    abstract fun transItemDao(): TransItemDao

    abstract fun shipTaskDao(): ShipTaskDao
    abstract fun shipItemDao(): ShipItemDao

    abstract fun unpackTaskDao(): UnpackTaskDao
    abstract fun unpackItemDao(): UnpackItemDao

    abstract fun invTaskDao(): InvTaskDao
    abstract fun invItemDao(): InvItemDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase =
            instance
                ?: synchronized(this) { instance ?: buildDatabase(context).also { instance = it } }

        private fun buildDatabase(appContext: Context): AppDatabase {

            val dbName =
                if (BuildConfig.DEBUG) {
                    String.format(
                        "%s/%s",
                        appContext.getExternalFilesDir(null)?.absolutePath,
                        DatabaseFileName)
                } else {
                    DatabaseFileName
                }

            Timber.d("buildDatabase \"${dbName}\"")

            return Room.databaseBuilder(appContext, AppDatabase::class.java, dbName)
                .fallbackToDestructiveMigration()
                .setJournalMode(
                    if (BuildConfig.DEBUG) JournalMode.TRUNCATE else JournalMode.AUTOMATIC)
                .build()
        }

        const val DatabaseFileName = "unisteel.db"
        const val DatabaseJournalFileName = "unisteel.db-journal"
    }
}
