package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JShiftResult(@SerializedName("EvSmeny") val shiftList: List<JShift>) {
    data class JShift(
        @SerializedName("CodeGruppa") val groupCode: String,
        @SerializedName("NameGruppa") val groupName: String,
        @SerializedName("Code") val code: String,
        @SerializedName("Name") val name: String,
    )
}
