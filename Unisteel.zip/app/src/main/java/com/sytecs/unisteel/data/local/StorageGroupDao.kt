package com.sytecs.unisteel.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sytecs.unisteel.data.entities.db.StorageGroup

@Dao
interface StorageGroupDao {

    @Query("SELECT count(1) FROM storage_groups") fun getCount(): Long

    @Query("SELECT * FROM storage_groups") fun getAll(): List<StorageGroup>

    @Query("SELECT * FROM storage_groups") fun getAllLiveData(): LiveData<List<StorageGroup>>

    @Query("SELECT * FROM storage_groups WHERE code = :code") fun get(code: String): StorageGroup?

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<StorageGroup>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: StorageGroup)

    @Update fun update(row: StorageGroup)

    @Delete fun delete(row: StorageGroup)

    @Query("DELETE FROM storage_groups") fun truncate()
}
