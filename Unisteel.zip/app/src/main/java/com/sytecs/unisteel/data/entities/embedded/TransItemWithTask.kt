package com.sytecs.unisteel.data.entities.embedded

import android.os.Parcelable
import androidx.room.Embedded
import androidx.room.Relation
import com.sytecs.unisteel.data.entities.db.TransItem
import com.sytecs.unisteel.data.entities.db.TransTask
import kotlinx.parcelize.Parcelize

@Parcelize
data class TransItemWithTask(
    @Embedded val item: TransItem,
    @Relation(parentColumn = "taskId", entityColumn = "id") val task: TransTask
) : Parcelable
