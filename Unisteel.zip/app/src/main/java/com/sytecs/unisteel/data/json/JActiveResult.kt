package com.sytecs.unisteel.data.json

import com.google.gson.annotations.SerializedName

data class JActiveResult(@SerializedName("EvActiv") val activeList: List<JActive>) {
    data class JActive(
        @SerializedName("Code") val code: String,
        @SerializedName("Name") val name: String,
        @SerializedName("Name2") val description: String
    )
}
