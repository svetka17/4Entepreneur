package com.sytecs.unisteel.presentation.unpack.list

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.embedded.UnpackTaskWithShift
import com.sytecs.unisteel.databinding.RowUnpackTaskBinding
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.format
import java.text.SimpleDateFormat
import java.util.*

class UnpackTaskAdapter :
    ListAdapter<UnpackTaskWithShift, UnpackTaskAdapter.VH>(UnpackTaskDiffCallback()), Filterable {

    private val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
    private var list = listOf<UnpackTaskWithShift>()
    var eventClick = SingleLiveEvent<UnpackTaskWithShift>()
    var eventClickSync = SingleLiveEvent<UnpackTaskWithShift>()

    fun setItems(list: List<UnpackTaskWithShift>) {
        this.list = list
        submitList(list)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding: RowUnpackTaskBinding =
            RowUnpackTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val filteredList = mutableListOf<UnpackTaskWithShift>()
                if (constraint == null || constraint.isEmpty()) {
                    filteredList.addAll(list)
                } else {
                    list
                        .filter {
                            /*it.task.comment.contains(constraint, true) ||*/
                            it.task.code.contains(constraint, true)
                        }
                        .forEach { filteredList.add(it) }
                }
                return FilterResults().also { it.values = filteredList }
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                submitList(results?.values as MutableList<UnpackTaskWithShift>)
            }
        }
    }

    private class UnpackTaskDiffCallback : DiffUtil.ItemCallback<UnpackTaskWithShift>() {
        override fun areItemsTheSame(
            oldItem: UnpackTaskWithShift,
            newItem: UnpackTaskWithShift
        ): Boolean {
            return oldItem.task.id == newItem.task.id
        }

        override fun areContentsTheSame(
            oldItem: UnpackTaskWithShift,
            newItem: UnpackTaskWithShift
        ): Boolean {
            return oldItem.task == newItem.task
        }
    }

    inner class VH(private val itemBinding: RowUnpackTaskBinding) :
        RecyclerView.ViewHolder(itemBinding.root), View.OnClickListener {

        private lateinit var item: UnpackTaskWithShift

        init {
            itemBinding.root.setOnClickListener(this)
        }

        fun bind(item: UnpackTaskWithShift) {
            this.item = item
            val withError = item.task.itemCountError > 0

            val resId: Int =
                when {
                    withError -> {
                        R.color.status_container_error
                    }
                    item.task.itemCountScanned > 0 -> {
                        R.color.status_container_success
                    }
                    else -> {
                        R.color.status_container_empty
                    }
                }

            itemBinding.viewMark.setBackgroundResource(resId)

            itemBinding.viewRoot.setBackgroundResource(
                when {
                    item.task.itemCountScanned == item.task.itemCount -> R.drawable.background_green
                    item.task.itemCountScanned > 0 -> R.drawable.background_yellow
                    else -> R.drawable.background_empty
                })

            val sb = StringBuilder()

            sb.append("${dateFormat.format(item.task.date)}\n")
            sb.append("НЕТТО, т: ${item.task.weight.format(3)}\n")
            sb.append("${item.shiftGroup.name} ${item.shift.name}")

            itemBinding.text1.text = item.task.code
            itemBinding.text2.text = sb.toString()
            itemBinding.itemCount.text = item.task.itemCount.toString()
            itemBinding.itemSuccessCount.text = item.task.itemCountScanned.toString()
            itemBinding.itemErrorCount.text = item.task.itemCountError.toString()
            itemBinding.buttonSync.visibility =
                if (item.task.itemCountScanned > 0) View.VISIBLE else View.GONE

            itemBinding.itemErrorDelimiter.visibility = if (withError) View.VISIBLE else View.GONE
            itemBinding.itemErrorCount.visibility = if (withError) View.VISIBLE else View.GONE

            itemBinding.buttonSync.setOnClickListener { eventClickSync.postValue(item) }
        }

        override fun onClick(v: View?) {
            eventClick.postValue(item)
        }
    }
}
