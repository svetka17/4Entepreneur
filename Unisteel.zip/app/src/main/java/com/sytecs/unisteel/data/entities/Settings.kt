package com.sytecs.unisteel.data.entities

class Settings(
    var isProd: Boolean,
    var apiUrlProd: String,
    var apiUrlQas: String,
    var isCameraScan: Boolean,
    var aadClientId: String,
    var adTenantId: String,
    var aadClientIdQas: String,
    var adTenantIdQas: String
) {

    companion object {
        fun newEmpty() = Settings(false, "", "", false,
            "","","","")
    }
}
