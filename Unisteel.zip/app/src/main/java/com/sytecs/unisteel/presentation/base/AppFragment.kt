package com.sytecs.unisteel.presentation.base

import android.app.DatePickerDialog
import android.content.Context
import android.os.Parcelable
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavDirections
import androidx.navigation.fragment.findNavController
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.sytecs.unisteel.databinding.LayoutFilterBinding
//import com.sytecs.unisteel.device.UpdateService
import com.sytecs.unisteel.presentation.MainActivity
import com.sytecs.unisteel.presentation.dialog.*
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.startSound
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.*

open class AppFragment : Fragment() {

    protected val mainActivity: MainActivity?
        get() {
            return if (requireActivity() is MainActivity) requireActivity() as MainActivity
            else null
        }

    protected val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())

    override fun onResume() {
        super.onResume()
        mainActivity?.checkCameraBarcode()
    }

    override fun onStart() {
        super.onStart()
        mainActivity?.setCurrentFragment(this)

        filterBinding?.let { if (it.textFilter.length() > 0) toggleFilter() }
    }

    override fun onStop() {
        super.onStop()
        mainActivity?.setCurrentFragment(null)
    }

    open fun onBarcodeText(text: String) {}

    open fun onPinChecked(success: Boolean) {}

    fun showInput(options: Options, listener: IDialogInputListener? = null) {
        DialogInput.show(parentFragmentManager, options)?.run {
            observeEvent(onClickPositive) {
                Timber.w("showInput->onClickPositive(\"$it\")")
                listener?.onClickPositive(it)
            }
        }
    }

    fun showAlert(options: Options, listener: IDialogListener? = null) {
        DialogAlert.show(parentFragmentManager, options)?.run {
            observeEvent(onClickPositive) {
                Timber.w("showAlert->onClickPositive()")
                listener?.onClickPositive()
            }
        }
    }

    protected fun showConfirm(options: Options, listener: IDialogListener? = null) {
        DialogConfirm.show(parentFragmentManager, options)?.run {
            observeEvent(onClickPositive) {
                Timber.w("showConfirm->onClickPositive()")
                listener?.onClickPositive()
            }
            observeEvent(onClickNegative) { Timber.w("showConfirm->onClickNegative()") }
        }
    }

    protected fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    protected fun showDatePicker(
        selectedDate: Date? = null,
        listener: DialogDatePicker.DatePickerListener
    ) {

        val cal = Calendar.getInstance()
        selectedDate?.let { cal.time = it }
        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH)
        val day = cal.get(Calendar.DAY_OF_MONTH)
        DatePickerDialog(
                requireContext(),
                { _, _year, _month, _dayOfMonth ->
                    listener.onDateSelected(
                        Calendar.getInstance().also { it.set(_year, _month, _dayOfMonth) }.time)
                },
                year,
                month,
                day)
            .show()
    }

    protected fun <T> observe(liveData: LiveData<T>, observer: Observer<in T>) {
        liveData.observe(viewLifecycleOwner, observer)
    }

    protected fun <T> observeEvent(liveData: SingleLiveEvent<T>, observer: Observer<in T>) {
        liveData.observeEvent(viewLifecycleOwner, observer)
    }

    protected fun goBack() {
        findNavController().popBackStack()
    }

    protected fun navigate(navDirections: NavDirections) {
        findNavController().navigate(navDirections)
    }

    protected fun playScanError() =
        startSound(lifecycleScope, requireContext(), "scan_error.mp3", 500)
/*
    open fun onNewVersion(versionInfo: UpdateService.VersionInfo) {
        Timber.d(versionInfo.toString())

        val content =
            if (versionInfo.changelog.isEmpty())
                "Виявлена нова версія програми ${versionInfo.name}. Бажаєте оновити?"
            else
                "Виявлена нова версія програми ${versionInfo.name}.<br>${versionInfo.changelog}<br>Бажаєте оновити?"

        showConfirm(Options(messageHtml = content, title = "Оновлення ПО")) {
            mainActivity?.startUpdate(versionInfo)
        }
    }

 */

    protected val onListItemSelected = SingleLiveEvent<Any>()

    protected fun <T : Parcelable> showList(items: List<T>, currentItem: T? = null) {
        DialogList.show(parentFragmentManager, items, currentItem)?.run {
            observeEvent(onItemSelected) {
                Timber.d("onItemSelected $it")
                onListItemSelected.postValue(it)
            }
        }
    }

    // Filter zone
    private var buttonFilter: FloatingActionButton? = null
    private var filterBinding: LayoutFilterBinding? = null
    private var filterQueryCurrent: String? = null
    var eventFilterQuery = SingleLiveEvent<String?>()
    val filterQuery: String?
        get() = filterQueryCurrent

    protected fun initFilter(
        filterBinding: LayoutFilterBinding,
        buttonFilter: FloatingActionButton
    ) {
        this.filterBinding = filterBinding
        this.buttonFilter = buttonFilter

        // filterBinding.textFilter.text = null
        // this.filterQueryCurrent = null

        filterBinding.viewFilter.visibility = View.GONE
        filterBinding.textFilter.addTextChangedListener {
            filterQueryCurrent = it?.toString()
            eventFilterQuery.postValue(filterQuery)
        }
        filterBinding.buttonFilterClear.setOnClickListener {
            filterBinding.textFilter.text = null
            toggleFilter()
        }
        buttonFilter.setOnClickListener { toggleFilter() }
    }

    private fun toggleFilter() {
        filterBinding?.let {
            val filterVisible = it.viewFilter.visibility == View.VISIBLE
            it.viewFilter.visibility = if (filterVisible) View.GONE else View.VISIBLE
            if (filterVisible) {
                buttonFilter?.show()
                hideKeyboard()
            } else {
                buttonFilter?.hide()
                it.textFilter.requestFocus()
            }
        }
    }

    private fun hideKeyboard() {
        val imm = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE)
        if (imm is InputMethodManager) {
            imm.hideSoftInputFromWindow(activity?.currentFocus?.windowToken, 0)
        }
    }

    protected val isDialogVisible: Boolean
        get() = AppDialog.IsDialogShow
}
