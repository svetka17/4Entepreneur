package com.sytecs.unisteel.presentation.dialog

interface IDialogConfirm {
    fun onClickPositive()
    fun onClickNegative()
}
