package com.sytecs.unisteel.presentation.ship.edit

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import com.sytecs.unisteel.R
import com.sytecs.unisteel.databinding.ShipEditFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ShipEditFragment : AppFragment() {

    private val args by navArgs<ShipEditFragmentArgs>()

    private var binding: ShipEditFragmentBinding by autoCleared()
    private val viewModel: ShipEditViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = ShipEditFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        setupObservers()

        binding.image1.visibility = if (!args.task.isCar) View.VISIBLE else View.GONE
        binding.image2.visibility = if (args.task.isCar) View.VISIBLE else View.GONE
        binding.label1.setText(
            if (args.task.isCar) R.string.ship_car_label else R.string.ship_not_car_label)
        binding.textTransport.setText(args.task.transportName)
        binding.textDriver.setText(args.task.driverName)

        binding.buttonBack.setOnClickListener { goBack() }

        binding.buttonSave.setOnClickListener {
            viewModel.save(
                binding.textTransport.text.toString(), binding.textDriver.text.toString())
        }
    }

    private fun setupObservers() {
        observeEvent(viewModel.eventSaved) {
            showToast(getString(R.string.text_saved))
            goBack()
        }
    }
}
