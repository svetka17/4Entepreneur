package com.sytecs.unisteel.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sytecs.unisteel.data.entities.db.InItem
import com.sytecs.unisteel.data.entities.embedded.InItemWithCertTransport
import com.sytecs.unisteel.data.entities.embedded.InItemWithCertificate

@Dao
interface InItemDao {

    @Query("SELECT count(1) FROM in_items") fun getCount(): Long

    @Query("SELECT * FROM in_items") fun getAll(): List<InItem>

    @Query("SELECT * FROM in_items WHERE certificateId = :certificateId")
    fun getByCertificate(certificateId: Long): List<InItem>

    @Query("SELECT * FROM in_items WHERE transportId = :transportId")
    fun getByTransport(transportId: Long): List<InItem>

    @Query(
        "SELECT i.* " +
            "from in_items i " +
            "JOIN in_transports t ON t.id = i.transportId AND t.name = :transportName")
    fun getByTransport(transportName: String): List<InItem>

    @Transaction
    @Query(
        "SELECT * FROM in_items WHERE transportId = :transportId order by inCreated is null, serial")
    fun getWithCertificate(transportId: Long): List<InItemWithCertificate>

    @Transaction
    @Query(
        "SELECT * FROM in_items WHERE transportId = :transportId order by inCreated is null, serial")
    fun getWithCertificateLiveData(transportId: Long): LiveData<List<InItemWithCertificate>>

    @Transaction
    @Query("SELECT * FROM in_items WHERE qr = :qr OR qrId = :qrId")
    fun findItemByQr(qr: String, qrId: String?): InItemWithCertTransport?

    @Transaction
    @Query("SELECT * FROM in_items WHERE barcode = :barcode")
    fun findItemByBarcode(barcode: String): InItemWithCertTransport?

    @Query("SELECT * FROM in_items WHERE (qr = :qr OR qrId = :qrId) AND transportId = :transportId")
    fun findItemByQrTransport(qr: String, qrId: String?, transportId: Long): InItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<InItem>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: InItem): Long

    @Update fun update(row: InItem)

    @Query("DELETE FROM in_items WHERE transportId = :id") fun deleteByTransport(id: Long)

    @Delete fun delete(row: InItem)

    @Query("DELETE FROM in_items") fun truncate()
}
