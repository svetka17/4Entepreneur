package com.sytecs.unisteel.data.entities.embedded

import android.os.Parcelable
import androidx.room.Embedded
import androidx.room.Relation
import com.sytecs.unisteel.data.entities.db.InCertificate
import com.sytecs.unisteel.data.entities.db.InItem
import com.sytecs.unisteel.data.entities.db.InTransport
import kotlinx.parcelize.Parcelize

@Parcelize
class InItemWithCertTransport(
    @Embedded val item: InItem,
    @Relation(parentColumn = "transportId", entityColumn = "id") val transport: InTransport,
    @Relation(parentColumn = "certificateId", entityColumn = "id") val certificate: InCertificate
) : Parcelable
