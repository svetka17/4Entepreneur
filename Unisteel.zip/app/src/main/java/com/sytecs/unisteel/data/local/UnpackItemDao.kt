package com.sytecs.unisteel.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sytecs.unisteel.data.entities.db.UnpackItem
import com.sytecs.unisteel.data.entities.embedded.UnpackItemWithTask
import java.util.*

@Dao
interface UnpackItemDao {

    @Query("SELECT count(1) FROM unpack_items") fun getCount(): Long

    @Query("SELECT * FROM unpack_items") fun getAll(): List<UnpackItem>

    @Query("SELECT * FROM unpack_items WHERE taskId = :taskId")
    fun getByTask(taskId: Long): List<UnpackItem>

    @Query("SELECT * FROM unpack_items WHERE taskId = :taskId")
    fun getByTaskLiveData(taskId: Long): LiveData<List<UnpackItem>>

    @Query("SELECT * FROM unpack_items WHERE taskId = :taskId AND unpackCreated IS NOT NULL")
    fun getByTaskFact(taskId: Long): List<UnpackItem>

    @Transaction
    @Query("SELECT * FROM unpack_items WHERE taskId = :taskId")
    fun getWithTask(taskId: Long): List<UnpackItemWithTask>

    @Transaction
    @Query("SELECT * FROM unpack_items WHERE taskId = :taskId")
    fun getWithTaskLiveData(taskId: Long): LiveData<List<UnpackItemWithTask>>

    @Transaction
    @Query("SELECT * FROM unpack_items WHERE qr = :qr OR qrId = :qrId")
    fun findItemByQr(qr: String, qrId: String?): UnpackItemWithTask?

    @Transaction
    @Query("SELECT * FROM unpack_items WHERE barcode = :barcode")
    fun findItemByBarcode(barcode: String): UnpackItemWithTask?

    @Query("SELECT * FROM unpack_items WHERE (qr = :qr OR qrId = :qrId) AND taskId = :taskId")
    fun findItemByQrTask(qr: String, qrId: String?, taskId: Long): UnpackItem?

    @Query(
        "UPDATE unpack_items SET unpackCreated = NULL, unpackBarcode = NULL, errorMessage = NULL WHERE id = :id")
    fun removeFact(id: Long)

    @Query("UPDATE unpack_items SET unpackCreated = :date, unpackBarcode = :barcode WHERE id = :id")
    fun addFact(id: Long, date: Date, barcode: String? = null)

    @Query(
        "UPDATE unpack_items SET unpackCreated = NULL, unpackBarcode = NULL, errorMessage = NULL WHERE taskId = :taskId")
    fun removeFactByTask(taskId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<UnpackItem>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: UnpackItem): Long

    @Update fun update(row: UnpackItem)

    @Query("DELETE FROM unpack_items WHERE taskId = :taskId") fun deleteByTask(taskId: Long)

    @Delete fun delete(row: UnpackItem)

    @Query("DELETE FROM unpack_items") fun truncate()
}
