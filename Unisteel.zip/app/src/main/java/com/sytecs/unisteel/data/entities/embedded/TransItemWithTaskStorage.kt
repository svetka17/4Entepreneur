package com.sytecs.unisteel.data.entities.embedded

import android.os.Parcelable
import com.sytecs.unisteel.data.entities.db.Storage
import com.sytecs.unisteel.data.entities.db.TransItem
import com.sytecs.unisteel.data.entities.db.TransTask
import kotlinx.parcelize.Parcelize

@Parcelize
data class TransItemWithTaskStorage(
    val item: TransItem,
    val task: TransTask,
    val storage: Storage
) : Parcelable
