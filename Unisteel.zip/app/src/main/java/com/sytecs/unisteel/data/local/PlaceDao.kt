package com.sytecs.unisteel.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sytecs.unisteel.data.entities.db.Place

@Dao
interface PlaceDao {

    @Query("SELECT count(1) FROM places") fun getCount(): Long

    @Query("SELECT * FROM places") fun getAll(): List<Place>

    @Query(
        "SELECT * FROM places WHERE storageCode = :storageCode AND rowNum = :rowNum AND placeNum = :placeNum")
    fun get(storageCode: String, rowNum: Int, placeNum: Int): Place?

    @Query("SELECT * FROM places WHERE storageCode = :storageCode")
    fun getByStorage(storageCode: String): List<Place>

    @Query("SELECT * FROM places WHERE storageCode = :storageCode")
    fun getByStorageLiveData(storageCode: String): LiveData<List<Place>>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<Place>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: Place)

    @Update fun update(row: Place)

    @Delete fun delete(row: Place)

    @Query("DELETE FROM places") fun truncate()
}
