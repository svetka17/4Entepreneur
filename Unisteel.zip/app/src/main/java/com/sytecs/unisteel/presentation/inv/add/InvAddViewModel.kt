package com.sytecs.unisteel.presentation.inv.add

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.Storage
import com.sytecs.unisteel.data.entities.db.StorageGroup
import com.sytecs.unisteel.data.repository.Repo
import com.sytecs.unisteel.data.repository.RepoInv
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

@HiltViewModel
class InvAddViewModel
@Inject
constructor(
    private val repoInv: RepoInv,
    private val repo: Repo,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _storageGroups = MutableLiveData<List<StorageGroup>>()
    val storageGroups: LiveData<List<StorageGroup>> = _storageGroups

    private val _storages = MutableLiveData<List<Storage>>()
    val storages: LiveData<List<Storage>> = _storages

    val eventSaved = SingleLiveEvent<Unit>()
    val eventStorages = SingleLiveEvent<List<Storage>>()
    val eventAlert = SingleLiveEvent<Pair<String, String?>>()
    val eventBeep = SingleLiveEvent<Boolean>()

    fun save(date: Date, storage: Storage) {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)

            val inv = repoInv.findTask(date, storage)
            if (inv == null) {
                repoInv.addTask(date, storage)
                eventSaved.postValue(Unit)
            } else {
                eventAlert.postValue(
                    Pair(
                        res.getString(
                            R.string.inv_task_date_storage_exist,
                            dateFormat.format(date),
                            storage.name),
                        null))
                eventBeep.postValue(true)
            }

            _isLoading.postValue(false)
        }
    }

    fun showStorages(group: StorageGroup) {
        viewModelScope.launch(Dispatchers.IO) {
            val res =
                if (storages.value == null) listOf()
                else storages.value!!.filter { it.groupCode == group.code }

            eventStorages.postValue(res)
        }
    }

    init {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            _storageGroups.postValue(repo.getStorageGroups())
            _storages.postValue(repo.getStorages())
            _isLoading.postValue(false)
        }
    }
}
