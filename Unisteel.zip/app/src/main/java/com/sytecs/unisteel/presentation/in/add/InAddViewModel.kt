package com.sytecs.unisteel.presentation.`in`.add

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.data.repository.RepoIn
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@HiltViewModel
class InAddViewModel
@Inject
constructor(
    private val repoIn: RepoIn,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    val eventSaved = SingleLiveEvent<Resource<Boolean>>()

    fun save(certificate: String?, transport: String?, ttn: String?) {
        viewModelScope.launch(Dispatchers.Main) {
            _isLoading.value = true
            eventSaved.value = repoIn.loadCertificate(certificate, transport, ttn)
            _isLoading.value = false
        }
    }
}
