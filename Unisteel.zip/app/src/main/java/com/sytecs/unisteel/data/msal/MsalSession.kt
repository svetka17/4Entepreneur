package com.sytecs.unisteel.data.msal

class MsalSession {

    companion object {
        @Volatile private var instance: MsalSession? = null

        fun getInstance(): MsalSession =
            instance ?: synchronized(this) { instance ?: MsalSession().also { instance = it } }
    }

    var user: MsalResult.MsalUser? = null
    val isSignedIn
        get() = user != null
}
