package com.sytecs.unisteel.data.entities.db

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.util.*

@Parcelize
@Entity(
    tableName = "in_transports",
    indices = [Index(value = ["activeCode", "ttn", "name"], unique = true)])
data class InTransport(
    @PrimaryKey(autoGenerate = true) var id: Long,
    val activeCode: String,
    val ttn: String,
    val name: String,
    val weight: Double,
    val created: Date,
    val itemCount: Int,
    val itemCountScanned: Int,
    val itemCountError: Int,
) : Parcelable
