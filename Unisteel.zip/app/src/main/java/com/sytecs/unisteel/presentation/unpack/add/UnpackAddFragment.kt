package com.sytecs.unisteel.presentation.unpack.add

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.viewModels
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.Shift
import com.sytecs.unisteel.data.entities.db.ShiftGroup
import com.sytecs.unisteel.databinding.UnpackAddFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class UnpackAddFragment : AppFragment() {

    companion object {
        var lastGroup: String? = null
        var lastShift: String? = null
    }

    private var binding: UnpackAddFragmentBinding by autoCleared()
    private val viewModel: UnpackAddViewModel by viewModels()
    private var currentGroup: ShiftGroup? = null
    private var currentShift: Shift? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = UnpackAddFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        setupObservers()

        binding.buttonBack.setOnClickListener { goBack() }

        binding.buttonSave.setOnClickListener {
            currentShift?.let { shift ->
                lastGroup = currentGroup?.code
                lastShift = shift.code
                viewModel.save(binding.textName.text.toString(), shift)
            }
        }

        binding.textName.addTextChangedListener { updateValidation() }

        binding.buttonGroup.setOnClickListener {
            viewModel.shiftGroups.value?.let { showList(it, currentGroup) }
        }

        binding.buttonShift.setOnClickListener {
            if (currentGroup == null) {
                showAlert(Options(getString(R.string.unpack_shifts_empty)))
            } else {
                viewModel.showShifts(currentGroup!!)
            }
        }

        setGroup(null)
    }

    private fun setupObservers() {

        if (lastGroup != null && lastShift != null) {
            observe(viewModel.shifts) { shifts ->
                viewModel.shiftGroups.value?.let { groups ->
                    val group = groups.firstOrNull { it.code == lastGroup }
                    val storage = shifts.firstOrNull { it.code == lastShift }
                    if (group != null && storage != null) {
                        setGroup(group, storage)
                    }
                }
            }
        } else {
            observe(viewModel.shiftGroups) {
                if (it.size == 1) {
                    setGroup(it.first())
                }
            }
        }

        observeEvent(viewModel.eventShifts) { showList(it, currentShift) }

        observeEvent(onListItemSelected) {
            when (it) {
                is ShiftGroup -> setGroup(it)
                is Shift -> setShift(it)
            }
        }

        observeEvent(viewModel.eventSaved) {
            if (it.isSuccess) {
                showToast(getString(R.string.text_saved))
                goBack()
            } else {
                showAlert(Options(it.message))
            }
        }

        observeEvent(viewModel.eventAlert) { event ->
            showAlert(Options(event.first, event.second))
        }
    }

    private fun setGroup(group: ShiftGroup?, shift: Shift? = null) {
        this.currentGroup = group
        binding.buttonGroup.text = group?.name ?: getString(R.string.spinner_placeholder)
        binding.buttonShift.isEnabled = group != null
        setShift(shift)
    }

    private fun setShift(shift: Shift?) {
        this.currentShift = shift
        binding.buttonShift.text = shift?.name ?: getString(R.string.spinner_placeholder)
        updateValidation()
    }

    private fun updateValidation() {
        val valid =
            currentGroup != null &&
                currentShift != null &&
                binding.textName.text.isNotEmpty() &&
                viewModel.isLoading.value != true
        binding.buttonSave.visibility = if (valid) View.VISIBLE else View.GONE
    }
}
