package com.sytecs.unisteel.presentation.unpack.items

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.UnpackItem
import com.sytecs.unisteel.data.entities.db.UnpackTask
import com.sytecs.unisteel.data.repository.RepoUnpack
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.parseItemQr
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class UnpackItemsViewModel
@Inject
constructor(
    private val repoUnpack: RepoUnpack,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {

    private val task: UnpackTask
        get() = savedStateHandle.get<UnpackTask>("task")!!

    val data: LiveData<List<UnpackItem>> = repoUnpack.itemList(task)

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    val eventBack = SingleLiveEvent<Boolean>()
    val eventBeep = SingleLiveEvent<Boolean>()
    val eventScrollUp = SingleLiveEvent<Boolean>()
    val eventToast = SingleLiveEvent<String>()
    val eventAlert = SingleLiveEvent<Pair<String, String?>>()
    val eventSync = SingleLiveEvent<Resource<Boolean>>()

    fun onBarcodeText(text: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val item = parseItemQr(text)

            if (item == null) {
                eventAlert.postValue(Pair(text, res.getString(R.string.unpack_item_invalid)))
                eventBeep.postValue(true)
                return@launch
            }

            val itemUnpack = repoUnpack.findItem(item)

            if (itemUnpack == null) {
                eventAlert.postValue(Pair(text, res.getString(R.string.unpack_item_not_found)))
                eventBeep.postValue(true)
                return@launch
            }

            if (itemUnpack.task.id != task.id) {
                eventAlert.postValue(
                    Pair(
                        res.getString(
                            R.string.unpack_item_already_scanned_in_task, itemUnpack.task.code),
                        null))
                eventBeep.postValue(true)
                return@launch
            }

            val isShipped = itemUnpack.item.unpackCreated != null

            if (isShipped) {
                eventAlert.postValue(
                    Pair(res.getString(R.string.unpack_item_already_scanned), null))
                eventBeep.postValue(true)
                return@launch
            }

            repoUnpack.unpackItemAdd(itemUnpack.item, item)
        }
    }

    fun addItem(item: UnpackItem) {
        viewModelScope.launch(Dispatchers.IO) { repoUnpack.unpackItemAdd(item) }
    }

    fun removeItem(item: UnpackItem) {
        viewModelScope.launch(Dispatchers.IO) { repoUnpack.unpackItemRemove(item) }
    }

    fun removeItems() {
        viewModelScope.launch(Dispatchers.IO) { repoUnpack.unpackItemsRemove(task) }
    }

    fun removeTask() {
        viewModelScope.launch(Dispatchers.IO) {
            repoUnpack.removeTask(task)
            eventBack.postValue(true)
        }
    }

    fun syncData(task: UnpackTask) {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            val res = repoUnpack.uploadItems(task)
            _isLoading.postValue(false)
            eventSync.postValue(res)
        }
    }
}
