package com.sytecs.unisteel.presentation.base

import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.startSound
import timber.log.Timber

open class AppDialog : DialogFragment() {

    companion object {
        var IsDialogShow = false
            private set
    }

    override fun onStart() {
        super.onStart()
        Timber.d("onStart")
        IsDialogShow = true

        dialog?.window?.let { window ->
            getDisplaySize()?.let { size ->
                val lp = WindowManager.LayoutParams()
                lp.copyFrom(window.attributes)
                if (getWidthPercent() > 0) {
                    lp.width =
                        (size.widthPixels.toFloat() * getWidthPercent().toFloat() / 100.0f).toInt()
                }
                if (getHeightPercent() > 0) {
                    lp.height =
                        (size.heightPixels.toFloat() * getHeightPercent().toFloat() / 100.0f)
                            .toInt()
                }
                window.attributes = lp
            }
        }
    }

    override fun onStop() {
        super.onStop()
        Timber.d("onStop")
        IsDialogShow = false
    }

    protected fun goBack() {
        findNavController().popBackStack()
    }

    protected fun <T> observe(liveData: LiveData<T>, observer: Observer<in T>) {
        liveData.observe(viewLifecycleOwner, observer)
    }

    protected fun <T> observeEvent(liveData: SingleLiveEvent<T>, observer: Observer<in T>) {
        liveData.observeEvent(viewLifecycleOwner, observer)
    }

    protected fun playScanError() =
        startSound(lifecycleScope, requireContext(), "scan_error.mp3", 500)

    protected fun getDisplaySize(): DisplayMetrics? {
        return try {
            context?.resources?.displayMetrics
        } catch (e: Exception) {
            Timber.e(e, "get display size")
            null
        }
    }

    protected open fun getWidthPercent() = 95
    protected open fun getHeightPercent() = 0
}
