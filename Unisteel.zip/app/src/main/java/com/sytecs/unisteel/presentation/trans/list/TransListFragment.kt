package com.sytecs.unisteel.presentation.trans.list

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import com.sytecs.unisteel.R
import com.sytecs.unisteel.data.entities.db.Storage
import com.sytecs.unisteel.data.entities.db.TransTask
import com.sytecs.unisteel.databinding.TransListFragmentBinding
import com.sytecs.unisteel.presentation.base.AppFragment
import com.sytecs.unisteel.presentation.dialog.Options
import com.sytecs.unisteel.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class TransListFragment : AppFragment() {

    private val args by navArgs<TransListFragmentArgs>()
    private var binding: TransListFragmentBinding by autoCleared()
    private val viewModel: TransListViewModel by viewModels()
    private lateinit var adapter: TransTaskAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = TransListFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        binding.textHead.text =
            getString(if (args.process == 4) R.string.trans_head_4 else R.string.trans_head_5)

        binding.buttonBack.setOnClickListener { goBack() }
        binding.buttonAdd.setOnClickListener {
            navigate(
                TransListFragmentDirections.actionTransListFragmentToTransAddFragment(args.process))
        }
        binding.buttonRefresh.setOnClickListener {
            showConfirm(Options(getString(R.string.trans_upload_all_confirm))) {
                viewModel.syncData()
            }
        }
        binding.buttonClear.setOnClickListener {
            showConfirm(Options(getString(R.string.trans_clear_all_confirm))) {
                viewModel.removeItems()
            }
        }

        setupRecyclerView()
        setupObservers()

        initFilter(binding.searchLayout, binding.buttonFilter)
    }

    private fun setupRecyclerView() {
        adapter = TransTaskAdapter()
        binding.listRv.adapter = adapter
    }

    private fun setupObservers() {
        observe(viewModel.data) {
            adapter.setItems(it)
            adapter.filter.filter(filterQuery)

            val itemCount = it.sumOf { item -> item.task.itemCount }
            val itemErrorCount = it.sumOf { item -> item.task.itemCountError }

            binding.itemCount.text = itemCount.toString()

            binding.itemErrorCount.text = itemErrorCount.toString()
            binding.itemErrorCount.visibility = if (itemErrorCount > 0) View.VISIBLE else View.GONE
            binding.itemErrorCountDelimiter.visibility =
                if (itemErrorCount > 0) View.VISIBLE else View.GONE

            binding.buttonRefresh.visibility = if (itemCount > 0) View.VISIBLE else View.GONE
            binding.buttonClear.visibility = if (it.isNotEmpty()) View.VISIBLE else View.GONE
        }

        observeEvent(adapter.eventClick) { openTask(it.task, it.storage) }

        observeEvent(adapter.eventClickSync) { item ->
            showConfirm(Options(getString(R.string.trans_upload_confirm))) {
                viewModel.syncData(item.task)
            }
        }

        observeEvent(viewModel.eventSync) {
            if (it.isSuccess) {
                showAlert(Options(getString(R.string.text_upload_success)))
            } else if (it.isError) {
                showAlert(Options(it.message))
            }
        }

        observeEvent(eventFilterQuery) { adapter.filter.filter(it) }
    }

    private fun openTask(task: TransTask, storage: Storage) {
        navigate(
            TransListFragmentDirections.actionTransListFragmentToTransItemsFragment(
                args.process, task, storage))
    }

    override fun onBarcodeText(text: String) {
        playScanError()
    }
}
