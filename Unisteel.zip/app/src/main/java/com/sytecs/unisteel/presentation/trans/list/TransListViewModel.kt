package com.sytecs.unisteel.presentation.trans.list

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.sytecs.unisteel.data.entities.db.TransTask
import com.sytecs.unisteel.data.entities.embedded.TransTaskWithStorage
import com.sytecs.unisteel.data.repository.RepoTrans
import com.sytecs.unisteel.presentation.base.AppViewModel
import com.sytecs.unisteel.utils.Resource
import com.sytecs.unisteel.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TransListViewModel
@Inject
constructor(
    private val repoTrans: RepoTrans,
    private val savedStateHandle: SavedStateHandle,
    @ApplicationContext appContext: Context
) : AppViewModel(appContext) {

    private val process: Int
        get() = savedStateHandle.get<Int>("process")!!

    val data: LiveData<List<TransTaskWithStorage>> = repoTrans.taskList(process)

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    val eventSync = SingleLiveEvent<Resource<Boolean>>()

    fun syncData(task: TransTask? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)
            val res = repoTrans.uploadItems(process, task)
            _isLoading.postValue(false)
            eventSync.postValue(res)
        }
    }

    fun removeItems() {
        viewModelScope.launch(Dispatchers.IO) { repoTrans.deleteTasks(process) }
    }
}
