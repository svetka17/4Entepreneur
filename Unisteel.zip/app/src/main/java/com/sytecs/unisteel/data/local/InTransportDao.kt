package com.sytecs.unisteel.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sytecs.unisteel.data.entities.db.InTransport
import com.sytecs.unisteel.data.entities.embedded.InTransportWithCertificates

@Dao
interface InTransportDao {

    @Query("SELECT count(1) FROM in_transports") fun getCount(): Long

    @Query("SELECT * FROM in_transports") fun getAll(): List<InTransport>

    @Query("SELECT * FROM in_transports WHERE id = :id") fun get(id: Long): InTransport?

    @Query(
        "SELECT * FROM in_transports WHERE activeCode = :activeCode AND name = :name AND ttn = :ttn")
    fun get(activeCode: String, name: String, ttn: String): InTransport?

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(rows: List<InTransport>)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(row: InTransport): Long

    @Update fun update(row: InTransport)

    @Delete fun delete(row: InTransport)

    @Query("DELETE FROM in_transports") fun truncate()

    @Transaction
    @Query(
        "SELECT * FROM in_transports order by case when itemCountScanned = 0 then 1 else 0 end, name")
    fun getWithCertificates(): List<InTransportWithCertificates>

    @Transaction
    @Query(
        "SELECT * FROM in_transports order by case when itemCountScanned = 0 then 1 else 0 end, name")
    fun getWithCertificatesLiveData(): LiveData<List<InTransportWithCertificates>>

    @Query(
        "UPDATE in_transports SET " +
            "weight = (SELECT TOTAL(weight) FROM in_certificates WHERE in_certificates.transportId = in_transports.id), " +
            "itemCount = (SELECT TOTAL(itemCount) FROM in_certificates WHERE in_certificates.transportId = in_transports.id), " +
            "itemCountScanned = (SELECT TOTAL(itemCountScanned) FROM in_certificates WHERE in_certificates.transportId = in_transports.id), " +
            "itemCountError = (SELECT TOTAL(itemCountError) FROM in_certificates WHERE in_certificates.transportId = in_transports.id) ")
    fun updateStat()

    @Query("DELETE FROM in_transports WHERE itemCount = 0") fun cleanEmpty()

    @Query("DELETE FROM in_transports WHERE itemCount = 0 AND id = :id")
    fun cleanEmptyByTransport(id: Long)
}
