package com.sytecs.unisteel.data.entities

enum class ItemType(val value: Int) {
    QR(1),
    BARCODE(2)
}
