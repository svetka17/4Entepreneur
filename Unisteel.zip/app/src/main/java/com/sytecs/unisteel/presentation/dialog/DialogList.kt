package com.sytecs.unisteel.presentation.dialog

import android.os.Bundle
import android.os.Parcelable
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.RecyclerView
import com.sytecs.unisteel.data.entities.db.*
import com.sytecs.unisteel.databinding.DialogListBinding
import com.sytecs.unisteel.databinding.RowRadioBinding
import com.sytecs.unisteel.presentation.base.AppDialog
import com.sytecs.unisteel.utils.SingleLiveEvent
import com.sytecs.unisteel.utils.autoCleared

class DialogList<T : Parcelable> : AppDialog() {

    companion object {
        fun <T : Parcelable> show(
            manager: FragmentManager,
            items: List<T>,
            currentItem: T?
        ): DialogList<T>? {
            if (IsDialogShow) return null
            return newInstance(items, currentItem).apply { show(manager, null) }
        }

        fun <T : Parcelable> newInstance(items: List<T>, currentItem: T?): DialogList<T> {
            return DialogList<T>().apply {
                arguments = bundleOf("items" to items, "item" to currentItem)
            }
        }
    }

    private var binding: DialogListBinding by autoCleared()
    val onItemSelected = SingleLiveEvent<T>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        savedInstanceState?.let { dismiss() }

        binding = DialogListBinding.inflate(inflater, container, false)

        val items =
            arguments?.getParcelableArrayList<T>("items")
                ?: throw IllegalStateException("Items fetch error")

        val item = arguments?.getParcelable<T>("item")

        dialog?.run {
            setCanceledOnTouchOutside(false)
            setCancelable(false)
            setOnKeyListener { _, keyCode, _ -> keyCode == KeyEvent.KEYCODE_BACK }
        }

        binding.buttonYes.isEnabled = false

        val adapter = Adapter<T>()
        adapter.setItems(items, item)
        adapter.eventCurrentItem.observeEvent(this) { currentItem ->
            binding.buttonYes.isEnabled = currentItem != null
        }
        binding.storagesRv.adapter = adapter

        binding.buttonNo.setOnClickListener { dismiss() }

        binding.buttonYes.setOnClickListener {
            dismiss()
            adapter.currentItem?.let { item -> onItemSelected.postValue(item) }
        }

        return binding.root
    }

    class Adapter<T> : RecyclerView.Adapter<Adapter<T>.VH<T>>() {

        private var items = ArrayList<T>()
        private var currentIndex: Int = -1
        val eventCurrentItem = SingleLiveEvent<T?>()

        val currentItem: T?
            get() = if (currentIndex == -1) null else items[currentIndex]

        fun setItems(items: List<T>, currentItem: T? = null) {
            this.items = items as ArrayList<T>
            currentIndex = -1

            currentItem?.let { currentIndex = items.indexOf(it) }

            notifyDataSetChanged()
            eventCurrentItem.postValue(currentItem)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH<T> {
            val binding: RowRadioBinding =
                RowRadioBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return VH(binding)
        }

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(holder: VH<T>, position: Int) {
            holder.bind(items[position])
        }

        inner class VH<T>(private val itemBinding: RowRadioBinding) :
            RecyclerView.ViewHolder(itemBinding.root), View.OnClickListener {

            private var item: T? = null

            fun bind(item: T) {
                this.item = item

                val title =
                    when (item) {
                        is Storage -> item.name
                        is StorageGroup -> item.name
                        is Place -> item.name
                        is ShiftGroup -> item.name
                        is Shift -> item.name
                        else -> item.toString()
                    }

                itemBinding.radio1.text = "${adapterPosition + 1}. $title"
                itemBinding.radio1.isChecked = currentIndex == adapterPosition
                itemBinding.radio1.setOnClickListener(this)
            }

            override fun onClick(v: View?) {
                if (currentIndex != -1 && currentIndex != adapterPosition) {
                    notifyItemChanged(currentIndex)
                }

                currentIndex = adapterPosition
                notifyItemChanged(currentIndex)
                eventCurrentItem.postValue(currentItem)
            }
        }
    }
}
