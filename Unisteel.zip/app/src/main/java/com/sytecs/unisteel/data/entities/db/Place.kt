package com.sytecs.unisteel.data.entities.db

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.util.*

@Parcelize
@Entity(tableName = "places"/*, primaryKeys = ["storageCode", "rowNum", "placeNum"]*/)
data class Place(
    @PrimaryKey val name: String,
    @ColumnInfo(index = true) val storageCode: String,
    val storageName: String,
    val rowNum: Int,
    val placeNum: Int,
    val barcode: String,
    val created: Date,
) : Parcelable
