package com.sytecs.unisteel.presentation.dialog

fun interface IDialogInputListener {
    fun onClickPositive(text: String)
}
