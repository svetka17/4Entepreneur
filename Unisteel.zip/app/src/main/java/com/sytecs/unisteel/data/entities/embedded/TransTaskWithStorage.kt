package com.sytecs.unisteel.data.entities.embedded

import android.os.Parcelable
import androidx.room.Embedded
import androidx.room.Relation
import com.sytecs.unisteel.data.entities.db.Storage
import com.sytecs.unisteel.data.entities.db.TransTask
import kotlinx.parcelize.Parcelize

@Parcelize
data class TransTaskWithStorage(
    @Embedded val task: TransTask,
    @Relation(parentColumn = "storageCode", entityColumn = "code") val storage: Storage
) : Parcelable
