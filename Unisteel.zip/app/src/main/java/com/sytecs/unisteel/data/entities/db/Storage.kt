package com.sytecs.unisteel.data.entities.db

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.util.*

@Parcelize
@Entity(tableName = "storages")
data class Storage(
    @PrimaryKey val code: String,
    val name: String,
    @ColumnInfo(index = true) val groupCode: String,
    val groupName: String,
    val created: Date
) : Parcelable
