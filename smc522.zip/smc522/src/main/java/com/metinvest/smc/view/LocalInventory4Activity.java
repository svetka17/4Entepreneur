package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Inventory;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import java.util.Calendar;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LocalInventory4Activity extends MyActivity {

    @BindView(R.id.textWeightNetto)
    EditText textWeightNetto;
    @BindView(R.id.textWeightPack)
    EditText textWeightPack;
    @BindView(R.id.textContent)
    TextView textContent;

    private ScanItem scanItem;
    private Date date;

    private String locationCode;
    private long labelId;
    private long datePrint;
    private int netto, pack;
    private String batch, ozm, matt;
    private float width, length, thickness;
    private long localId;
    private boolean autoAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local_inventory4);
        ButterKnife.bind(this);

        autoAdd = getIntent().getBooleanExtra("autoAdd", false);
        date = new Date(getIntent().getLongExtra("date", 0));
        locationCode = getIntent().getStringExtra("locationCode");
        String data = getIntent().getStringExtra("data");
        localId = getIntent().getLongExtra("localId", 0);
        log("Date: %s", app.getDateFormat().format(date));
        scanItem = new ScanItem(data);

        netto = 0;
        pack = 0;
        labelId = 0;
        datePrint = 0;
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    private void beginLoad() {

        if (scanItem.getType() == ScanItem.ScanItemType.SMC02) {

            try {
				netto = Utils.parseInt(scanItem.getData(0));
				pack = Utils.parseInt(scanItem.getData(1));
				batch = scanItem.getData(4);
				matt = Utils.base64decode(scanItem.getData(3));
				length = Utils.parseFloat(scanItem.getData(5));
				width = Utils.parseFloat(scanItem.getData(6));
				thickness = Utils.parseFloat(scanItem.getData(7));
				ozm = "";
				datePrint = app.getTimeStampFormat().parse(scanItem.getData(8)).getTime();
			} catch (Exception e) {
				log(e, "beginLoad()");
			}
        }

        if (scanItem.getType() == ScanItem.ScanItemType.SMC06) {

            try {
				netto = Utils.parseInt(scanItem.getData(6));
				pack = Utils.parseInt(scanItem.getData(9));
				batch = scanItem.getData(11);
				ozm = scanItem.getData(8);
				matt = scanItem.getData(2);
				length = Utils.parseFloat(scanItem.getData(3));
				width = Utils.parseFloat(scanItem.getData(4));
				thickness = Utils.parseFloat(scanItem.getData(5));
				labelId = Utils.parseLong(scanItem.getData(0));
				datePrint = app.getTimeStampFormat().parse(scanItem.getData(13)).getTime();
			} catch (Exception e) {
				log(e, "beginLoad()");
			}
        }

        if (localId > 0) {
            Inventory inventory = db.inventoryDao().getById(localId);
            if (inventory != null) {
                netto = inventory.getNetto();
                pack = inventory.getPack();
            }
        }

        refreshInfo();
        if (autoAdd) {
            buttonAcceptClick();
        }

    }

    private void refreshInfo() {
        textWeightNetto.setText(String.valueOf(netto));
        textWeightPack.setText(String.valueOf(pack));

        String text = Utils.format("<b>%s</b><br>Партія: %s<br>Розмір: %s", matt, batch, app.sizeToString(width, length, thickness));
        textContent.setText(app.fromHtml(text));

        textContent.post(() -> textContent.requestFocus());
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    private void buttonAcceptClick() {
        if (isLoading()) return;

        netto = Utils.parseInt(textWeightNetto.getText().toString());
        pack = Utils.parseInt(textWeightPack.getText().toString());

        if (netto <= 0) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_netto_zero, null);
            textWeightNetto.post(() -> textWeightNetto.requestFocus());
            return;
        }

        try {

            Intent intent = new Intent();
            Inventory inventory = null;

            long insertedId = -1;

            if (localId > 0) {
                inventory = db.inventoryDao().getById(localId);
            } else if (labelId > 0) {
                inventory = db.inventoryDao().getByLabelIdAndLocation(date.getTime(), labelId, locationCode);
            }

            if (inventory == null) {
                inventory = db.inventoryDao().getByLabelQrAndLocation(date.getTime(), scanItem.getLine(), locationCode);
            }

            if (inventory == null) {
                inventory = new Inventory(
                        0, date.getTime(), locationCode, labelId, scanItem.getLine(),
                        Calendar.getInstance().getTime().getTime(), datePrint,
                        netto, pack, batch, ozm, matt, width, length, thickness
                );
                insertedId = db.inventoryDao().insert(inventory);
                showToast(R.string.inv_success);
            } else {
                inventory.setDate(date.getTime());
                inventory.setLocationCode(locationCode);
                inventory.setLabelId(labelId);
                inventory.setQr(scanItem.getLine());
                inventory.setDateScan(Calendar.getInstance().getTime().getTime());
                inventory.setDatePrint(datePrint);
                inventory.setNetto(netto);
                inventory.setPack(pack);
                inventory.setNetto(netto);
                inventory.setPack(pack);
                inventory.setBatch(batch);
                inventory.setOzm(ozm);
                inventory.setMatt(matt);
                inventory.setWidth(width);
                inventory.setLength(length);
                inventory.setThickness(thickness);
				db.inventoryDao().update(inventory);
				insertedId = inventory.getId();
				showToast(R.string.inv_success_repeat);
				app.beepRepeat();
			}

			setResult(RESULT_OK, intent);
			intent.putExtra("id", insertedId);
			finish();

		} catch (Exception e) {
			log(e, "buttonAcceptClick()");
		}
    }
}
