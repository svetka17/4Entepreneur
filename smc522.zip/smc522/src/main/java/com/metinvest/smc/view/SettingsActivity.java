package com.metinvest.smc.view;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Utils;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SettingsActivity extends MyActivity implements IScan/*, Updater.UpdaterListener*/ {

    @BindView(R.id.textUrlApi) EditText textUrlApi;
    @BindView(R.id.textUrlApiEO) EditText textUrlApiEO;
    @BindView(R.id.textUrlUpdater) EditText textUrlUpdater;
    @BindView(R.id.textSmcId) EditText textSmcId;
    @BindView(R.id.buttonTest) View buttonTest;
    @BindView(R.id.checkNav) CheckBox checkNav;

    @BindView(R.id.checkEO) CheckBox checkEO;
    @BindView(R.id.checkAutoBatch) CheckBox checkAutoBatch;
    @BindView(R.id.checkShipRestTransfer) CheckBox checkShipRestTransfer;
    /*@BindView(R.id.buttonUpdate)
    View buttonUpdate;*/

    //private Updater updater;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        ButterKnife.bind(this);

        textUrlApi.setText(config.getUrlApi());
        textUrlApiEO.setText(config.getUrlApiEO());
        textUrlUpdater.setText(config.getUrlUpdater());
        textSmcId.setText(config.getSmcId());
        checkAutoBatch.setEnabled(isAutoBatchAvailable());
        checkAutoBatch.setChecked(config.isAutoBatch());
        checkAutoBatch.setVisibility(View.GONE);
        checkEO.setChecked(config.isEo());
        checkNav.setChecked(config.isNavigationVisible());
        checkShipRestTransfer.setChecked(config.isShipRestTransfer());

        /*updater = new Updater(
                this, this,
                config.getUrlUpdater() + "/com.metinvest.smc.txt",
                config.getUrlUpdater() + "/com.metinvest.smc.apk",
                app.getApkVersion()
        );*/

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                checkTextFields();
                checkSmcIdChanged(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        };
        textUrlApi.addTextChangedListener(textWatcher);
        textUrlUpdater.addTextChangedListener(textWatcher);
        textSmcId.addTextChangedListener(textWatcher);

        setActionDone(textUrlApi, this::hideKeyboard);
        setActionDone(textUrlUpdater, this::hideKeyboard);
        setActionDone(textSmcId, this::hideKeyboard);
    }

    private void checkSmcIdChanged(String newSmcId) {
        boolean e = isAutoBatchAvailable(newSmcId);
        checkAutoBatch.setChecked(e);
        checkAutoBatch.setEnabled(e);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        if (getIntent().getBooleanExtra("focusSmcId", false)) {
            textSmcId.post(() -> textSmcId.requestFocus());
        }

        checkTextFields();
    }

    @Override
    protected void onFunctionKey(int number) {
        switch (number) {
            case 2:
                buttonSaveClick();
                break;
            case 3:
                buttonResetClick();
                break;
            case 4:
                buttonTestClick();
                break;
            /*case 5:
                buttonUpdateClick();
                break;*/
        }
    }

    private void buttonTestClick() {
        if (isLoading() || !buttonTest.isEnabled()) return;
        buttonTest.setEnabled(false);
        showLoading(R.string.text_please_wait);
        String url = config.getUrlApi() + "ping";
        reqGet(url, this::endTest);
    }

	private void endTest(JsonResult result) {
		runOnUiThread(() -> {
			hideLoading();
			buttonTest.setEnabled(true);

			if (result.isOk()) {
				showDialog(R.drawable.ic_info_24dp, R.string.text_information, R.string.ping_result_ok, null);
			} else {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, Utils.format(getString(R.string.ping_result_error), result.getDescription()), null);
			}
		});
    }

    @Override
    protected String getHelpContent() {
        return "Екран налаштування з'єдання з сервером\r\n\r\nF2 - зберегти налаштування";
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {
        runOnUiThread(() -> {

            if (textUrlUpdater.isFocused()) {
                textUrlUpdater.setText("");
                textUrlUpdater.setText(barcodeData);
            } else if (textUrlApi.isFocused()) {
                textUrlApi.setText("");
                textUrlApi.setText(barcodeData);
            } else if (textSmcId.isFocused()) {
                textSmcId.setText("");
                textSmcId.setText(barcodeData);
            }
        });
    }

    public void buttonSaveClick() {
        config.setUrlApi(textUrlApi.getText().toString());
        config.setUrlApiEO(textUrlApiEO.getText().toString());
        config.setUrlUpdater(textUrlUpdater.getText().toString());
        config.setSmcId(textSmcId.getText().toString());
        config.setNavigationVisible(checkNav.isChecked());
        config.setAutoBatch(checkAutoBatch.isChecked());
        config.setEo(checkEO.isChecked());
        config.setShipRestTransfer(checkShipRestTransfer.isChecked());
        config.saveConfig();
        //app.sendFaSmcId();
        setResult(RESULT_OK);
        finish();
    }

    public void buttonResetClick() {
        config.resetConfig();
        setResult(RESULT_OK);
        finish();
    }

    private void checkTextFields() {
        setCorrectTint(textUrlApi, !textUrlApi.getText().toString().isEmpty());
        setCorrectTint(textUrlUpdater, !textUrlUpdater.getText().toString().isEmpty());
        setCorrectTint(textSmcId, !textSmcId.getText().toString().isEmpty());
    }
}
