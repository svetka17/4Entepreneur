package com.metinvest.smc.net;

import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.db.NameStore;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.db.Printed;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.LabelStat;
import com.metinvest.smc.tools.StoreItem;
import com.metinvest.smc.tools.Utils;
import com.microsoft.identity.client.IAuthenticationResult;
import com.microsoft.identity.client.SilentAuthenticationCallback;
import com.microsoft.identity.client.exception.MsalException;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class Network {

    private final App app;
    //private int DEFAULT_TIMEOUT = 120000 * 4;

    private long lastPacketId;

    public long getLastPacketId() {
        return lastPacketId;
    }

    private SilentAuthenticationCallback getAuthSilentCallback() {
        return new SilentAuthenticationCallback() {
            @Override
            public void onSuccess(IAuthenticationResult authenticationResult) {
                //log("Successfully authenticated silently ");
                app.getConfig().setAccount(authenticationResult.getAccount());
                app.getConfig().setExpiresOn(authenticationResult.getExpiresOn());
                app.getConfig().setToken(authenticationResult.getAccessToken());
            }

            @Override
            public void onError(MsalException exception) {
                /* Failed to acquireToken */
                log("Authentication failed: " + exception.toString());
            }
        };
    }

    protected void log(@NonNull String message, Object... args) {
        app.log(this, Utils.format(message, args));
    }

    public void updateToken() {
        if (app.getConfig().getSingleAccountApp() != null /*&& app.getConfig().getAccount() != null*/) {
            app.getConfig().getSingleAccountApp().acquireTokenSilentAsync(app.getConfig().MSAL_SCOPES,
                    app.getConfig().getSingleAccountApp().getConfiguration().getAuthorities().get(0).getAuthorityURL().toString(), getAuthSilentCallback());
        }
    }

    public StringResult requestString(String url, boolean post, boolean put, String data, long packetId) {

        lastPacketId = packetId;
        RequestOpt options = new RequestOpt();
        options.setApiUrl(app.getConfig().getUrlApi());
        options.setNetworkType(networkType);
        options.setPacketId(packetId);
        options.setPost(post);
        options.setPut(put);
        options.setPostData(data);
        options.setUrl(url);
        options.setDeviceId(app.getDeviceId());
        options.setVersion(app.getConfig().getVersion());
        options.setUserId(app.getConfUserId());
        if (app.getConfig().isAuthMSAL())
            options.setMsal(true);
        options.setToken(app.getUserToken());
        options.setSmcId(app.getSmcIdCurrent());
        if (app.getConfig().isAuthMSAL() && app.getConfig().getExpiresOn() != null
                && app.getConfig().getExpiresOn().before(new Date(System.currentTimeMillis() + 60 * 2 * 1000))) {
            updateToken();
        }

            StringResult result = new NetworkRequest(options).requestString();
            if (!result.isOk()) {
                if (app.getConfig().isAuthMSAL() && app.getConfig().getExpiresOn() != null)
                    updateToken();
                else result = new NetworkRequest(options).requestString();
            }
            return result;
    }

    private String networkType;

    public void setNetworkType(String networkType) {
        this.networkType = networkType;
    }

    public Network() {
        this.app = App.getInstance();

        try {
            disableSSLCertCheck();
        } catch (Exception e) {
            app.log(this, e, "disableSSLCertCheck()");
        }

    }

    private void disableSSLCertCheck() throws NoSuchAlgorithmException, KeyManagementException {
        // Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) {

            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) {

            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }
        }
        };

        // Install the all-trusting trust manager
        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

        // Create all-trusting host name verifier
        HostnameVerifier allHostsValid = (hostname, session) -> true;

        // Install the all-trusting host verifier
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
    }

    public static Network getInstance() {
        return App.getInstance().getNetwork();
    }

    public String addUrlParam(String url, String key, String value) {
        /*if (key == "SAP_Matt_Descr")
        return Uri.parse(url == null ? "" : url).buildUpon().
                appendEncodedPath("SAP_Matt_Descr="+value).
                //appendQueryParameter(key, value).
                //appendQueryParameter(key, encode(value)).
                        //appendQueryParameter(key, key=="SAP_Matt_Descr"?decode(value):value).
                build().toString();
        else*/
            return Uri.parse(url == null ? "" : url).buildUpon().
                    appendQueryParameter(key, value).
                    build().toString();
    }

    public String addUrlParam(String url, String key, int value) {
        return addUrlParam(url, key, String.valueOf(value));
    }

    public String addUrlParam(String url, String key, float value) {
        return addUrlParam(url, key, String.valueOf(value).replace(',', '.'));
    }

    public JsonUploadTask uploadJson(JsonUploadTask.JsonUploadTaskParam param, JsonUploadTask.JsonUploadTaskListener jsonUploadTaskListener) {
        JsonUploadTask task = new JsonUploadTask(jsonUploadTaskListener);
        task.execute(param);
        return task;
    }

    public JsonResult downloadJson(String url) {
        return request(url, false, false, null, 0);
    }

    public JsonResult downloadJson(String url, long packetId) {
        return request(url, false, false, null, packetId);
    }

    public JsonResult uploadJson(String url, String data) {
        return request(url, true, false, data, 0);
    }

    public JsonResult uploadJson(String url, boolean put, String data) {
        return request(url, true, put, data, 0);
    }

    public JsonResult uploadJson(String url, String data, long packetId) {
        return request(url, true, false, data, packetId);
    }

    public JsonResult requestProxy(String url, boolean post, @Nullable Map<String, String> headers, @Nullable String body) {

        String finalUrl = app.getConfig().getUrlApi() + "proxy";

        StringBuilder sb = new StringBuilder();
        sb.append("[\n");

        if (headers != null && !headers.isEmpty()) {
            String[] keys = new String[headers.keySet().size()];
            headers.keySet().toArray(keys);
            for (int i = 0; i < keys.length; i++) {
                String key = keys[i];
                String value = headers.get(key);
                sb.append(Utils.format("    [\"%s\",\"%s\"]", key, value));
                if (i < keys.length - 1) sb.append(",\n");
                else sb.append("\n");
            }
        }

        sb.append("]\n");

        String finalData = Utils.format("{\n" +
                " \"method\":\"%s\",\n" +
                " \"url\":\"%s\",\n" +
                " \"body\":\"%s\",\n" +
                " \"headers\":%s\n" +
                "}\n", post ? "post" : "get", url, (body == null ? "" : body), sb.toString());

        return request(finalUrl, true, false, finalData, 0);
    }

    public JsonResult request(String url, boolean post, boolean put, String data, long packetId) {

        StringResult stringResult = requestString(url, post, put, data, packetId == 0 ? Calendar.getInstance().getTime().getTime() : packetId);
        JsonResult result = new JsonResult(stringResult.getPacketId(), stringResult.getStatus(), stringResult.getDescription(), null);
        result.setFunctionName(stringResult.getFunctionName());

        if (stringResult.isOk()) {
            try {
                JSONObject json = new JSONObject(stringResult.getData());
                LoadResultStatus status = parseStatus(Utils.getJsonString(json, "result"));
                //if (app.getConfig().isEo())
                String statusEO = Utils.getJsonString(json, "isSuccess");
                if (statusEO.equalsIgnoreCase("true"))
                    status = LoadResultStatus.OK;
                result.setStatus(status);
                result.setData(json);
                if (status != LoadResultStatus.OK) {
                    app.log(this, (Exception) null, json.toString());
                }
            } catch (JSONException e) {
                app.log(this, e, "[JSONException] %s %s", url, e);
                result.setStatus(LoadResultStatus.PARSE_ERROR);
                result.setDescription(app.getString(R.string.network_error_json));
            }
        }

        return result;
    }

    public String getUrlFunctionName(String url) {
        //url.replace(app.config.getUrlApi(), "").substring(0,9)
        String v = url.replace(app.getConfig().getUrlApi(), "");
        int i = v.indexOf('?');
        if (i == -1) return url;
        v = v.substring(0, i);
        return v;
    }

    private LoadResultStatus parseStatus(String status) {

        if (status.equalsIgnoreCase("A001")) return LoadResultStatus.A001;
        else if (status.equalsIgnoreCase("A002")) return LoadResultStatus.A002;
        else if (status.equalsIgnoreCase("A003")) return LoadResultStatus.A003;
        else if (status.equalsIgnoreCase("A004")) return LoadResultStatus.A004;
        else if (status.equalsIgnoreCase("H004")) return LoadResultStatus.H004;
        else if (status.equalsIgnoreCase("-1")) return LoadResultStatus.MINUS1;
        else if (status.equalsIgnoreCase("1")) return LoadResultStatus.OK;
        else if (status.equalsIgnoreCase("2")) return LoadResultStatus.PLUS2;
        else if (status.equalsIgnoreCase("3")) return LoadResultStatus.PLUS3;
        else if (status.equalsIgnoreCase("0")) return LoadResultStatus.ZERO;
        else if (status.equalsIgnoreCase("S000")) return LoadResultStatus.S000;
        else if (status.equalsIgnoreCase("S001")) return LoadResultStatus.S001;
        else if (status.equalsIgnoreCase("S002")) return LoadResultStatus.S002;
        else if (status.equalsIgnoreCase("S003")) return LoadResultStatus.S003;
        else if (status.equalsIgnoreCase("S004")) return LoadResultStatus.S004;
        else if (status.equalsIgnoreCase("S005")) return LoadResultStatus.S005;
        else if (status.equalsIgnoreCase("S006")) return LoadResultStatus.S006;
        else if (status.equalsIgnoreCase("S007")) return LoadResultStatus.S007;
        else if (status.equalsIgnoreCase("S008")) return LoadResultStatus.S008;
        else if (status.equalsIgnoreCase("S009")) return LoadResultStatus.S009;
        //else if (status.equalsIgnoreCase("true")) return LoadResultStatus.OK;
        return LoadResultStatus.H004;
    }


    public enum ftpUploadResult {
        OK, CONNECT_ERROR, LOGIN_ERROR, CONFIG_ERROR, WRITE_ERROR
    }

    public ftpUploadResult uploadFtpFile(File file) {

        app.log(this, "beginUploadFtpFile(%s)", file);

        FTPClient ftpClient = new FTPClient();

        try {
            //ftpClient.connect("od.sytecs.com.ua");
            ftpClient.connect("od.sytecs.com.ua", 10021);
            //ftpClient.connect("192.168.0.5", 10021);
        } catch (Exception e) {
            app.log(this, e, "ftpClient.connect()");
            return ftpUploadResult.CONNECT_ERROR;
        }

        try {
            ftpClient.login("MBS", "pass");
        } catch (Exception e) {
            app.log(this, e, "ftpClient.login()");
            return ftpUploadResult.LOGIN_ERROR;
        }

        try {
            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
            ftpClient.enterLocalPassiveMode();
        } catch (Exception e) {
            app.log(this, e, "ftpClient.enterLocalPassiveMode()");
            return ftpUploadResult.CONFIG_ERROR;
        }

        try {
            String outFileName = Utils.format("/MBS/SMC_BACKUP/%s_%s", app.getDeviceId(), file.getName());

            FileInputStream in = new FileInputStream(file);
            boolean result = ftpClient.storeFile(outFileName, in);
            in.close();

            if (!result) return ftpUploadResult.WRITE_ERROR;

        } catch (Exception e) {
            app.log(this, e, "ftpClient.storeFile()");
            return ftpUploadResult.WRITE_ERROR;
        }

        try {
            ftpClient.logout();
            ftpClient.disconnect();
        } catch (Exception e) {
            app.log(this, e, "ftpClient.disconnect()");
        }

        return ftpUploadResult.OK;

    }

    public static class NetworkResultValue<T> {
        private JsonResult result;
        private T value;

        public NetworkResultValue() {
        }

        public NetworkResultValue(JsonResult result, T value) {
            this.result = result;
            this.value = value;
        }

        public JsonResult getResult() {
            return result;
        }

        public boolean isOk() {
            return result != null && result.isOk();
        }

        public void setResult(JsonResult result) {
            this.result = result;
        }

        public T getValue() {
            return value;
        }

        public void setValue(T value) {
            this.value = value;
        }
    }

    //Network utils
    public Network.NetworkResultValue<String> loadServiceVersion() {
        String url = app.getConfig().getUrlApi() + "ping";
        JsonResult jsonResult = downloadJson(url);
        if (jsonResult.isOk()) {
            JSONObject pingData = Utils.getJsonObject(jsonResult.getJson(), "pingData");
            String version = Utils.getJsonStringIgnoreCase(pingData, "service_version");
            return new Network.NetworkResultValue<>(jsonResult, version);
        }
        return new Network.NetworkResultValue<>(jsonResult, null);
    }

    public Network.NetworkResultValue<Boolean> checkLocation(String locationCode) {
        String url = app.getConfig().getUrlApi() + "checklocation";
        url = addUrlParam(url, "location_code", locationCode);
        JsonResult result = downloadJson(url);
        return result.isOk() ? new Network.NetworkResultValue<>(result, true) : new Network.NetworkResultValue<>(result, false);
    }

    public String getLocationId(String locationCode) {
        String url = app.getConfig().getUrlApi() + "getlocationinfo";
        url = addUrlParam(url, "location_code", locationCode);
        JsonResult result = downloadJson(url);
        if (result.isOk()) {
            JSONObject json = Utils.getJsonObject(result.getJson(), "data");
            return Utils.getJsonStringIgnoreCase(json, "location_id");
        } else {
            return null;
        }
    }

    public String getLocationCode(String locationId) {
        if (locationId == null) return null;
        String url = app.getConfig().getUrlApi() + "getlocationcode";
        url = addUrlParam(url, "location_id", locationId);
        JsonResult result = downloadJson(url);
        if (result.isOk()) {
            JSONObject json = Utils.getJsonObject(result.getJson(), "data");
            return Utils.getJsonStringIgnoreCase(json, "location_code");
        } else {
            return null;
        }
    }

    public Network.NetworkResultValue<String> getLocationCodeNet(String locationId) {
        if (locationId == null) return null;
        String url = app.getConfig().getUrlApi() + "getlocationcode";
        url = addUrlParam(url, "location_id", locationId);
        JsonResult result = downloadJson(url);
        if (result.isOk()) {
            JSONObject json = Utils.getJsonObject(result.getJson(), "data");
            String code = Utils.getJsonStringIgnoreCase(json, "location_code");
            return new Network.NetworkResultValue<>(result, code);
        } else {
            return new Network.NetworkResultValue<>(result, null);
        }
    }

    public Network.NetworkResultValue<String> getLocationIdWithCreate(String locationCode) {
        Network.NetworkResultValue<Boolean> networkResultValue = checkLocation(locationCode);
        if (!networkResultValue.isOk() && networkResultValue.getResult().getStatus() != LoadResultStatus.ZERO) {
            return new Network.NetworkResultValue<>(networkResultValue.getResult(), null);
        }

        if (!networkResultValue.getValue()) {
            String url = app.getConfig().getUrlApi() + "createlocation";
            JsonResult result = uploadJson(url, "\"" + locationCode + "\"");
            if (!result.isOk()) {
                return new Network.NetworkResultValue<>(result, null);
            }
        }

        String url = app.getConfig().getUrlApi() + "getlocationinfo";
        url = addUrlParam(url, "location_code", locationCode);
        JsonResult result = downloadJson(url);
        if (!result.isOk()) return new Network.NetworkResultValue<>(result, null);

        JSONObject json = Utils.getJsonObject(result.getJson(), "data");
        String locationId = Utils.getJsonString(json, "location_id");

        return new Network.NetworkResultValue<>(result, locationId);
    }

    public Network.NetworkResultValue<Integer> loadTheorCount(String labelId) {
        int count = 0;
        String url = app.getConfig().getUrlApi() + "getlabelinfo";
        url = app.getNetwork().addUrlParam(url, "label_id", labelId);

        JsonResult jsonResult = app.getNetwork().downloadJson(url);
        if (!jsonResult.isOk()) return new NetworkResultValue<>(jsonResult, count);

        Label labelBase = Label.fromJson(Utils.getJsonObject(jsonResult.getJson(), "data"));
        if (labelBase == null) return new NetworkResultValue<>(jsonResult, count);

        NetworkResultValue<String> resultLoc = app.getNetwork().getLocationCodeNet(String.valueOf(labelBase.getLocationId()));
        if (!resultLoc.isOk()) return new NetworkResultValue<>(resultLoc.getResult(), count);

        String locationCode = resultLoc.value;

        url = app.getConfig().getUrlApi() + "getlocationinfo2";
        url = addUrlParam(url, "location_code", locationCode);
        url = addUrlParam(url, "ozm", labelBase.getOzm());
        url = addUrlParam(url, "length", String.valueOf(labelBase.getLength()));
        url = addUrlParam(url, "width", String.valueOf(labelBase.getWidth()));
        url = addUrlParam(url, "thickness", String.valueOf(labelBase.getThickness()));
        url = addUrlParam(url, "nett_weight", String.valueOf(labelBase.getWeightNetto()));
        url = addUrlParam(url, "teor_weight", "1");

        jsonResult = downloadJson(url);
        if (!jsonResult.isOk()) return new NetworkResultValue<>(jsonResult, count);

        JSONObject jsonData = Utils.getJsonObject(jsonResult.getJson(), "data");
        JSONArray array = Utils.getJsonArray(jsonData, "labels");
        if (array != null) {
            count = array.length();
        }

        return new NetworkResultValue<>(jsonResult, count);

    }

    public NetworkResultValue<List<StoreItem>> loadStorageList(String smcId) {
        String url = app.getConfig().getUrlApi() + "GetStore";
        url = addUrlParam(url, "smc_id", smcId);
        JsonResult result = downloadJson(url);
        if (!result.isOk()) return new NetworkResultValue<>(result, null);

        List<StoreItem> storageList = new ArrayList<>();
        JSONArray jsonArray = Utils.getJsonArray(result.getJson(), "data");
        if (jsonArray != null) {
            for (int i = 0; i < jsonArray.length(); i++) {
                //Utils.getJsonString(jsonArray, i)
                JSONObject row = Utils.getJsonObject(jsonArray, i);
                if (row == null) continue;
                String rowSmcId = Utils.getJsonStringIgnoreCase(row, "smc");
                boolean rowSource = Utils.getJsonStringIgnoreCase(row, "source").equalsIgnoreCase("true");
                List<String> rowStoreList = new ArrayList<>();
                JSONArray rowStoreArr = Utils.getJsonArray(row, "store");
                if (rowStoreArr != null) {
                    for (int j = 0; j < rowStoreArr.length(); j++) {
                        rowStoreList.add(Utils.getJsonString(rowStoreArr, j));
                    }
                }
                storageList.add(new StoreItem(rowSmcId, rowSource, rowStoreList));
            }
        }
        return new NetworkResultValue<>(result, storageList);
    }

    public JsonResult loadLabelInfo(String labelId) {
        return loadLabelInfo(null, labelId, null);
    }

    public JsonResult loadLabelInfo(String labelId, LabelStat labelStat) {
        return loadLabelInfo(null, labelId, labelStat);
    }

    public JsonResult loadLabelInfo(String smcId, String labelId) {
        return loadLabelInfo(smcId, labelId, null);
    }

    public JsonResult loadLabelInfo(String smcId, String labelId, @Nullable LabelStat labelStat) {
        String url = app.getConfig().getUrlApi() + "getlabelinfo";
        url = addUrlParam(url, "label_id", labelId);
        if (smcId != null) url = addUrlParam(url, "smc_id", smcId);
        if (labelStat != null) {
            url = addUrlParam(url, "is_manual", String.valueOf(labelStat.isManual()));
            url = addUrlParam(url, "app_view", labelStat.getAppView());
        }
        return downloadJson(url);
    }

    public JsonResult uploadInbound() {
        String url = app.getConfig().getUrlApi() + "inbound";

        StringBuilder sb = new StringBuilder();

        sb.append("{");

        sb.append(Utils.format("%n%s%n%s%n%s%n%s%n"
                , Utils.format("\"Type\":\"%d\",", 1)
                , Utils.format("\"Smc_Id\":\"%s\",", app.getConfig().getSmcId())
                , Utils.format("\"Date_Printed\":\"%s\",", app.getDateTimeFormat().format(Calendar.getInstance().getTime()))
                , Utils.format("\"User_id\":\"%d\",", app.getConfUserId())
        ));

        sb.append("\"positions\":");

        sb.append("[");

        List<Printed> printedList = app.getDb().printedDao().getAllNew();

        for (int i = 0; i < printedList.size(); i++) {

            Printed printed = printedList.get(i);
            OnTheWay way = app.getDb().onTheWayDao().getById(printed.getOnTheWayId());
            NameStore name = app.getDb().nameStoreDao().getById(way.getNameId());
            String locationCode = app.fixLocation(printed.getLocation());
            if (Objects.equals(locationCode, "-1-1")) {
                locationCode = "1-1-1";
            }

            sb.append(Utils.format("{%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n}"
                    , Utils.format("\"id\":\"%s\",", printed.getOnTheWayId())
                    , Utils.format("\"labelid\":\"%s\",", printed.getId())
                    , Utils.format("\"external_id\":\"%s\",", "")
                    , Utils.format("\"netto_weight\":\"%s\",", printed.getWeightNetto())
                    , Utils.format("\"pack_weight\":\"%s\",", printed.getWeightPack())
                    , Utils.format("\"tara_weight\":\"%s\",", printed.getWeightTara())
                    , Utils.format("\"temporary\":\"%s\",", printed.isTemporary())
                    , Utils.format("\"locationCode\":\"%s\",", locationCode)
                    , Utils.format("\"date_printed\":\"%s\",", app.getDateTimeFormat().format(printed.getDate()))
                    , Utils.format("\"line_ID\":\"%s\",", way.getLineId())
                    , Utils.format("\"SAP_Ozm\":\"%s\",", printed.getSapOzm())
                    , Utils.format("\"SAP_Batch\":\"%s\",", way.getSapBatch())
                    , Utils.format("\"SAP_Matt_Descr\":\"%s\",", printed.getSapMattDescr())
                    , Utils.format("\"SAP_Weight_NETT\":\"%.3f\",", way.getSapWeightNett() / 1000.0f)
                    , Utils.format("\"SAP_Id1\":\"%s\",", way.getSapId1())
                    , Utils.format("\"SAP_Id2\":\"%s\",", way.getSapId2())
                    , Utils.format("\"Length\":\"%s\",", name.getLength())
                    , Utils.format("\"Width\":\"%s\",", name.getWidth())
                    , Utils.format("\"Thickness\":\"%s\",", name.getThickness())
                    , Utils.format("\"TTN_Num\":\"%s\",", way.getTtnNum())
                    , Utils.format("\"TTN_Carier_ID\":\"%s\",", way.getTtnCarrierId())
                    , Utils.format("\"TTN_Date\":\"%s\",", way.getTtnDate())
                    , Utils.format("\"DateUpload\":\"%s\",", way.getDateUpload())
                    , Utils.format("\"TEOR_Weight\":%s,", printed.isTheor() ? "true" : "false")
                    , Utils.format("\"LGORT\":\"%s\"", way.getStorage())
            ));

            if (i + 1 < printedList.size()) sb.append(",");

        }

        sb.append("]");

        sb.append("}");

        JsonResult result = uploadJson(url, sb.toString());

        if (result.isOk()) {
            app.getDb().printedDao().updateNewToOld();
            app.getDb().weighingDao().truncate();
            //db.printedDao().truncate();
        }

        return result;
    }
}
