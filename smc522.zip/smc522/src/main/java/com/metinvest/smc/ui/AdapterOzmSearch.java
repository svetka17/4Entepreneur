package com.metinvest.smc.ui;

import android.view.View;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.tools.Location;
import com.metinvest.smc.tools.Utils;

import org.json.JSONObject;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterOzmSearch extends AbstractFlexibleItem<AdapterOzmSearch.ViewHolder> {

    public interface Listener {
        void onNameClick(AdapterOzmSearch item);

        void onLocationClick(AdapterOzmSearch item);
    }

    private final long id;
    private final float width;
    private final float length;
    private final float thickness;
    private final String name, ozm;
    private final JSONObject json;
    private final Listener listener;
    private List<Location> locationList;

    public AdapterOzmSearch(long id, JSONObject json, Listener listener) {
        this.id = id;
        this.json = json;
        this.listener = listener;
        this.name = Utils.jsonExist(json, "sap_matt_descr") ? Utils.getJsonStringIgnoreCase(json, "sap_matt_descr") : Utils.getJsonStringIgnoreCase(json, "name");
        this.width = Utils.getJsonFloatIgnoreCase(json, "width");
        this.length = Utils.getJsonFloatIgnoreCase(json, "length");
        this.thickness = Utils.getJsonFloatIgnoreCase(json, "thickness");
        this.ozm = Utils.jsonExist(json, "saP_Ozm") ? Utils.getJsonStringIgnoreCase(json, "saP_Ozm") : Utils.getJsonStringIgnoreCase(json, "ozm");
    }

    public long getId() {
        return id;
    }

    public float getWidth() {
        return width;
    }

    public float getLength() {
        return length;
    }

    public float getThickness() {
        return thickness;
    }

    public String getName() {
        return name;
    }

    public String getOzm() {
        return ozm;
    }

    public JSONObject getJson() {
        return json;
    }

    public void setLocationList(List<Location> locationList) {
        this.locationList = locationList;
    }

    public List<Location> getLocationList() {
        return locationList;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterOzmSearch && ((AdapterOzmSearch) o).getId() == getId();
    }

    @Override
    public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new ViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {

        holder.textTitle.setText(name);

        StringBuilder sb = new StringBuilder();

        sb.append(Utils.format("ОЗМ: %s", ozm));

        String size = App.getInstance().sizeToString(width, length, thickness);
        if (size.length() > 0)
            sb.append(Utils.format("<br>%s", size));

        holder.textContent.setText(App.getInstance().fromHtml(sb.toString()));

        StringBuilder sb1 = new StringBuilder();
        StringBuilder sb2 = new StringBuilder();

        if (locationList.isEmpty()) {
            sb1.append(App.getInstance().getString(R.string.ozm_not_in_stock));
        } else {
            for (int i = 0; i < locationList.size(); i++) {
                sb1.append(Utils.format((i + 1 == locationList.size() ? "%s" : "%s%n"), locationList.get(i).getCode()));
                sb2.append(Utils.format((i + 1 == locationList.size() ? "%.3f т" : "%.3f т%n"), (locationList.get(i).getWeight() / 1000.0f)));
            }
        }

        holder.textLocation.setText(sb1.toString());
        holder.textLocationWeight.setText(sb2.toString());

        View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
        holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
        refreshBackground(holder, holder.itemView.isFocused());

        if (listener != null) {
            holder.viewLocations.setOnClickListener(v -> listener.onLocationClick(this));
        }
    }

    private void refreshBackground(ViewHolder holder, boolean hasFocus) {
        holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_adapter_light));
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_ozm_search;
    }

    static class ViewHolder extends FlexibleViewHolder {

        @BindView(R.id.textTitle)
        TextView textTitle;
        @BindView(R.id.textContent)
        TextView textContent;
        @BindView(R.id.viewLocations)
        View viewLocations;
        @BindView(R.id.textLocation)
        TextView textLocation;
        @BindView(R.id.textLocationWeight)
        TextView textLocationWeight;

        ViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            ButterKnife.bind(this, view);
        }
    }
}
