package com.metinvest.smc.tools;

import androidx.annotation.NonNull;

public class ScalesConfig {
	private String name, mac;

	public ScalesConfig(String name, String mac) {
		this.name = name;
		this.mac = mac;
	}

	public String getName() {
		return name;
	}

	public String getMac() {
		return mac;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}

	@NonNull
	@Override
	public String toString() {
		return Utils.format("%s %s %s", getName(), getMac());
	}
}
