package com.metinvest.smc.view;

import static android.content.DialogInterface.BUTTON_POSITIVE;

import static com.metinvest.smc.tools.Utils.parseLocation;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.metinvest.smc.App;
import com.metinvest.smc.Config;
import com.metinvest.smc.R;
import com.metinvest.smc.db.Db;
import com.metinvest.smc.inc.Ozm;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.net.NetworkListener;
import com.metinvest.smc.tools.Connectivity;
import com.metinvest.smc.tools.INfc;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.NFC;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.PrinterConfig;
import com.metinvest.smc.tools.Scales;
import com.metinvest.smc.tools.ScalesConfig;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SuppressLint("Registered")
public class MyActivity extends AppCompatActivity implements INfc, NfcAdapter.ReaderCallback {

    public static final int REQUEST_DEFAULT = 1;
    public static final int REQUEST_SEARCH = 2;
    public static final int REQUEST_LOCATION_SELECT = 3;
    public static final int REQUEST_LOGIN = 4;
    public static final int REQUEST_ACTION = 5;
    public static final int REQUEST_SPLIT = 6;
    public static final int REQUEST_ADD = 7;
    public static final int REQUEST_PERMISSION = 8;
    public static final int REQUEST_EDIT = 9;
    public static final int REQUEST_VIEW = 12;
    public static final int REQUEST_SELECT_CRANE = 13;
    public static final int REQUEST_SELECT_SMC = 14;
    public static final int REQUEST_INC_CLOSE = 15;
    public static final int REQUEST_LOCATION_SELECT2 = 16;
    public static final int REQUEST_COUNT_SELECT = 17;
    public static final int REQUEST_LABEL_ID_INPUT = 18;

    public static final int REQUEST_CLOSE_NARAD = 19;

    public static final int REQUEST_PART_CLOSE_NARAD = 20;
    public static final int RESULT_NEED_REFRESH = 10;
    public static final int RESULT_DELETED = 11;

    protected final App app;
    protected final Network net;
    protected final Config config;
    protected final Db db;

    private View viewError, viewMessage;
    private TextView textTime, textTitle, textMessage, textError, textEsc;
    protected View viewLoading, viewContent, viewContentFooter;
    private NfcAdapter adapter;
    private boolean loading;

    protected Handler handler;
    private ImageView imagePrinterStatus, imageNetwork, imageBattery;
    private Button buttonCancel;

    public MyActivity() {
        app = App.getInstance();
        net = app.getNetwork();
        config = app.getConfig();
        config.setAuthMSAL(true);
        
        db = app.getDb();
        handler = new Handler(Looper.getMainLooper());
    }

    protected String getHelpContent() {
        return getString(R.string.default_help_content);
    }

    protected void openHelp() {
        if (isLoading() || this instanceof HelpActivity) return;
        String content = getHelpContent();
        if (content != null && content.length() > 0) {

            String smcId = app.getSmcIdCurrent();

            content += "\n\nTerminalID: [" + app.getDeviceId() + "]";
            content += "\nSMC_ID: [" + smcId + "]";
            if (!(this instanceof LoginActivity) && !(this instanceof SettingsActivity))
                content += "\nСклад: [" + config.getStorage() + "]";

            Intent intent = new Intent(this, HelpActivity.class);
            intent.putExtra("content", content);
            startActivity(intent);
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        //выключаем темную тему
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        //app.onCreate(this);
        adapter = NfcAdapter.getDefaultAdapter(this);
    }

    protected void refreshHeader() {
        if (textTitle != null) {
            //textTitle.setText(getTitle());
            if (this instanceof LoginActivity)
                textTitle.setText(R.string.f1_for_help);
            else
                textTitle.setText(Utils.format("SMC %s%s", app.getSmcIdCurrent(), (Utils.isNullOrEmpty(config.getStorage()) ? "" : Utils.format(" (%s)", config.getStorage()))));
        }

        if (textEsc != null) {
            textEsc.setVisibility(
                    this instanceof MainActivity ||
                            this instanceof Main2Activity ||
                            this instanceof LoginActivity
                            ? View.GONE : View.VISIBLE);
        }
    }

    public boolean isLoading() {
        return loading;
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        viewLoading = findViewById(R.id.viewLoading);
        viewContent = findViewById(R.id.viewContent);
        viewContentFooter = findViewById(R.id.viewContentFooter);

        textEsc = findViewById(R.id.textEsc);
        textTime = findViewById(R.id.textTime);
        imageBattery = findViewById(R.id.imageBattery);
        imageNetwork = findViewById(R.id.imageNetwork);
        imagePrinterStatus = findViewById(R.id.imagePrinterStatus);
        textTitle = findViewById(R.id.textTitle);
        viewError = findViewById(R.id.viewError);
        viewMessage = findViewById(R.id.viewMessage);
        textMessage = findViewById(R.id.textMessage);
        textError = findViewById(R.id.textError);
        buttonCancel = findViewById(R.id.buttonCancel);

        if (textTime != null) textTime.setVisibility(View.VISIBLE);
        if (imagePrinterStatus != null) imagePrinterStatus.setVisibility(View.VISIBLE);
        if (imageNetwork != null) imageNetwork.setVisibility(View.VISIBLE);
        if (imageBattery != null) imageBattery.setVisibility(View.VISIBLE);

        timerEventWork();

        if (buttonCancel != null) {
            buttonCancel.setOnClickListener(v -> onButtonCancelClick());
        }

        refreshHeader();

        hideMessage();
        hideError();

        //buttonBack.setVisibility(this instanceof MainActivity || this instanceof LoginActivity ? View.GONE : View.VISIBLE);

        getWindow().getDecorView().setBackgroundColor(getColor(R.color.color_background));

        View viewCrane = findViewById(R.id.buttonCrane);
        if (viewCrane instanceof ImageButton) {
            //boolean e = app.getSmcIdCurrent().equalsIgnoreCase("1404");
            boolean e = isCraneAvailable();
            ImageButton buttonCrane = (ImageButton) viewCrane;
            if (e) {
                buttonCrane.setBackground(ContextCompat.getDrawable(this, R.drawable.button_enabled));
                buttonCrane.setEnabled(true);
            } else {
                buttonCrane.setBackground(ContextCompat.getDrawable(this, R.drawable.image_button_disabled));
                buttonCrane.setEnabled(false);
            }
        }
    }

    protected boolean isCraneAvailable() {
        //String smcIdCurrent = app.getSmcIdCurrent();
        //if (smcIdCurrent.equalsIgnoreCase("1404")) return true;
        //if (smcIdCurrent.equalsIgnoreCase("1406")) return true;
        //if (smcIdCurrent.equalsIgnoreCase("1407")) return true;
        return true;
    }

    protected boolean isAutoBatchAvailable() {
        return isAutoBatchAvailable(app.getSmcIdCurrent());
    }

    protected boolean isAutoBatchAvailable(String smcId) {
        if (smcId.equalsIgnoreCase("1440")) return true;
        return false;
    }

    protected void onButtonCancelClick() {

    }

    public void showDialogConfirm(@StringRes final int title, @StringRes final int message, final DialogInterface.OnClickListener listener) {
        showDialogConfirm(title, getString(message), listener);
    }

    public void showDialogConfirm(@StringRes final int title, String message, final DialogInterface.OnClickListener listenerYes) {
        showDialogConfirm(title == 0 ? null : getString(title), message, listenerYes, null);
    }

    public void showDialogConfirm(String title, String message, final DialogInterface.OnClickListener listenerYes) {
        showDialogConfirm(title, message, listenerYes, null);
    }

    public void showDialogConfirm(String title, String message, final DialogInterface.OnClickListener listenerYes, final DialogInterface.OnClickListener listenerNo) {
        if (isFinishing()) return;
        AlertDialog.Builder builder = new AlertDialog.Builder(MyActivity.this);
        builder.setIcon(R.drawable.ic_question_24dp);
        if (title != null) builder.setTitle(title);
        builder.setMessage(message + "\n\nTerminalID: [" + app.getDeviceId() + "]\n" + app.getCurrentDtString());
        builder.setPositiveButton(R.string.text_yes, listenerYes);
        builder.setNegativeButton(R.string.text_no, listenerNo);
        builder.setCancelable(false);

        final AlertDialog myDialog = builder.create();
        myDialog.setOnShowListener(dialog -> {
            Button button = myDialog.getButton(AlertDialog.BUTTON_POSITIVE);
            button.setFocusable(true);
            button.setFocusableInTouchMode(true);
            button.requestFocus();
            app.hideUi(this);
        });
        myDialog.show();
    }

    public void showDialogConfirm(@StringRes final int title, String message, String textYes, String textNo, final DialogInterface.OnClickListener listenerYes, final DialogInterface.OnClickListener listenerNo) {
        if (isFinishing()) return;
        AlertDialog.Builder builder = new AlertDialog.Builder(MyActivity.this);
        builder.setIcon(R.drawable.ic_question_24dp);
        builder.setTitle(title);
        builder.setMessage(message + "\n\nTerminalID: [" + app.getDeviceId() + "]\n" + app.getCurrentDtString());
        builder.setPositiveButton(textYes, listenerYes);
        builder.setNegativeButton(textNo, listenerNo);
        builder.setCancelable(false);

        final AlertDialog myDialog = builder.create();
        myDialog.setOnShowListener(dialog -> {
            Button button = myDialog.getButton(AlertDialog.BUTTON_POSITIVE);
            button.setFocusable(true);
            button.setFocusableInTouchMode(true);
            button.requestFocus();
            app.hideUi(this);
        });
        myDialog.show();
    }

    public void showDialogConfirmNoButton(@StringRes final int title, String message, String textYes, String textNo, final DialogInterface.OnClickListener listenerYes, final DialogInterface.OnClickListener listenerNo) {
        if (isFinishing()) return;
        AlertDialog.Builder builder = new AlertDialog.Builder(MyActivity.this);
        builder.setIcon(R.drawable.ic_question_24dp);
        builder.setTitle(title);
        builder.setMessage(message + "\n\nTerminalID: [" + app.getDeviceId() + "]\n" + app.getCurrentDtString());
        builder.setPositiveButton(App.getInstance().fromHtml(textYes), listenerYes);
        builder.setNegativeButton(App.getInstance().fromHtml(textNo), listenerNo);
        builder.setCancelable(false);
        final AlertDialog myDialog = builder.create();
        myDialog.setOnShowListener(dialog -> {
            Button button = myDialog.getButton(AlertDialog.BUTTON_POSITIVE);
            //button.setBackgroundColor(ContextCompat.getColor(this, R.color.snackbar_background));
            button.setBackground(ContextCompat.getDrawable(this, R.drawable.button_style_background1));
            button.setFocusable(true);
            button.setFocusableInTouchMode(true);
            //button.requestFocus();
            Button button1 = myDialog.getButton(AlertDialog.BUTTON_NEGATIVE);
            //button1.setBackgroundColor(ContextCompat.getColor(this, R.color.snackbar_background));
            button1.setBackground(ContextCompat.getDrawable(this, R.drawable.button_style_background1));
            button1.setFocusable(true);
            button1.setFocusableInTouchMode(true);
            //button1.requestFocus();
            app.hideUi(this);
        });
        myDialog.show();
        myDialog.getButton(AlertDialog.BUTTON_POSITIVE).setAllCaps(false);
        myDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
    }

    public AlertDialog showDialogRetry(@DrawableRes final int icon, @StringRes final int title, String message, final DialogInterface.OnClickListener listener) {
        return showDialogRetry(icon, getString(title), message, listener, null);
    }

    public AlertDialog showDialogRetry(@DrawableRes final int icon, @StringRes final int title, @StringRes final int message, final DialogInterface.OnClickListener listener) {
        return showDialogRetry(icon, getString(title), getString(message), listener, null);
    }

    public AlertDialog showDialogRetry(@DrawableRes final int icon, @StringRes final int title, String message, final DialogInterface.OnClickListener listenerRetry, final DialogInterface.OnClickListener listenerOk) {
        return showDialogRetry(icon, getString(title), message, listenerRetry, listenerOk);
    }

    public AlertDialog showDialogRetry(@DrawableRes final int icon, @StringRes final int title, @StringRes final int message, final DialogInterface.OnClickListener listenerRetry, final DialogInterface.OnClickListener listenerOk) {
        return showDialogRetry(icon, getString(title), getString(message), listenerRetry, listenerOk);
    }

    public AlertDialog showDialogRetry(@DrawableRes final int icon, String title, String message,
                                       String textRetry, String textCancel,
                                       final DialogInterface.OnClickListener listenerRetry,
                                       final DialogInterface.OnClickListener listenerOk) {
        if (isFinishing()) return null;
        AlertDialog.Builder builder = new AlertDialog.Builder(MyActivity.this);
        builder.setIcon(icon);
        builder.setTitle(title);
        String finalMessage = message.replaceAll("\n", "<br>");
        builder.setMessage(app.fromHtml(Utils.format("%s<br><i>TerminalId: %s</i><br><i>RequestId: %d</i><br>%s", finalMessage, app.getDeviceId(), net.getLastPacketId(), app.getCurrentDtString())));
        builder.setPositiveButton(textRetry, listenerRetry);
        builder.setNegativeButton(textCancel, listenerOk);
        builder.setCancelable(false);

        final AlertDialog myDialog = builder.create();
        myDialog.setOnShowListener(dialog -> {
            Button button = myDialog.getButton(AlertDialog.BUTTON_POSITIVE);
            button.setFocusable(true);
            button.setFocusableInTouchMode(true);
            button.requestFocus();
            app.hideUi(this);
        });
        myDialog.show();

        return myDialog;
    }

    public AlertDialog showDialogRetry(@DrawableRes final int icon, String title, String message,
                                       final DialogInterface.OnClickListener listenerRetry,
                                       final DialogInterface.OnClickListener listenerOk) {
        if (isFinishing()) return null;
        AlertDialog.Builder builder = new AlertDialog.Builder(MyActivity.this);
        builder.setIcon(icon);
        builder.setTitle(title);
        String finalMessage = message.replaceAll("\n", "<br>");
        builder.setMessage(app.fromHtml(Utils.format("%s<br><i>TerminalId: %s</i><br><i>RequestId: %d</i><br>%s", finalMessage, app.getDeviceId(), net.getLastPacketId(), app.getCurrentDtString())));
        builder.setPositiveButton(R.string.text_retry, listenerRetry);
        builder.setNegativeButton(R.string.text_ok, listenerOk);
        builder.setCancelable(false);

        final AlertDialog myDialog = builder.create();
        myDialog.setOnShowListener(dialog -> {
            Button button = myDialog.getButton(AlertDialog.BUTTON_POSITIVE);
            button.setFocusable(true);
            button.setFocusableInTouchMode(true);
            button.requestFocus();
            app.hideUi(this);
        });
        myDialog.show();

        return myDialog;
    }

    public AlertDialog showDialog(@DrawableRes final int icon, @StringRes final int title, String message, final DialogInterface.OnClickListener listener) {
        if (isFinishing()) return null;
        AlertDialog.Builder builder = new AlertDialog.Builder(MyActivity.this);
        builder.setIcon(icon);
        builder.setTitle(title);
        builder.setCancelable(false);

        String finalMessage = message.replaceAll("\n", "<br>");
        builder.setMessage(app.fromHtml(Utils.format("%s<br><i>TerminalId: %s</i>%s<br>%s", finalMessage, app.getDeviceId(), (net.getLastPacketId() > 0 ? Utils.format("<br><i>RequestId: %d</i>", net.getLastPacketId()) : ""), app.getCurrentDtString())));

        //builder.setMessage(message + "\n\nTerminalID: [" + app.getDeviceId() + "]");

        builder.setPositiveButton(R.string.text_ok, listener);

        final AlertDialog myDialog = builder.create();
        myDialog.setOnShowListener(dialog -> {
            Button button = myDialog.getButton(AlertDialog.BUTTON_POSITIVE);
            button.setFocusable(true);
            button.setFocusableInTouchMode(true);
            button.requestFocus();
            app.hideUi(this);
        });
        myDialog.show();

        return myDialog;
    }

    public AlertDialog showDialog(@DrawableRes final int icon, @StringRes final int title, @StringRes final int message, final DialogInterface.OnClickListener listener) {
        return showDialog(icon, title, getString(message), listener);
    }

    public void showToast(@StringRes final int message) {
        showToast(getString(message));
    }

    public void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    public void timerFullscreenEvent() {
        if (app.isPaused()) return;

        runOnUiThread(() -> app.hideUi(MyActivity.this));
    }

    public void timerEvent() {
        if (app.isPaused()) return;
        runOnUiThread(this::timerEventWork);
    }

    protected boolean isPrinterZebra() {
        return app.isPrinterZebra();
    }

    private void timerEventWork() {
        if (textTime != null && textTime.getVisibility() == View.VISIBLE)
            textTime.setText(app.getTimeFormat().format(Calendar.getInstance().getTime()));

        if (imagePrinterStatus != null) {
            imagePrinterStatus.setImageResource(app.isPrinterAvailable() ? R.drawable.ic_print_24dp : R.drawable.ic_print_red_24dp);
        }

        if (imageNetwork != null) {
            if (Connectivity.isConnectedWifi(MyActivity.this)) {
                imageNetwork.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_wifi_24dp));
                net.setNetworkType("wifi");
            } else if (Connectivity.isConnectedMobile(MyActivity.this)) {
                if (Connectivity.getNetworkClass(MyActivity.this).equalsIgnoreCase("4G")) {
                    imageNetwork.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_4g_24dp));
                    net.setNetworkType("4g");
                } else {
                    imageNetwork.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_3g_24dp));
                    net.setNetworkType("3g");
                }
            } else {
                imageNetwork.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_no_network_24dp));
                net.setNetworkType("none");
            }
        }

        if (imageBattery != null) {

            int battery = app.getBatteryLevel();
            boolean charging = app.isBatteryCharging();

            int batteryImage = charging ? R.drawable.ic_charging_100 : R.drawable.ic_battery_100;

            if (charging) {
                if (battery < 20) batteryImage = R.drawable.ic_charging_20;
                else if (battery < 30) batteryImage = R.drawable.ic_charging_30;
                else if (battery < 50) batteryImage = R.drawable.ic_charging_50;
                else if (battery < 60) batteryImage = R.drawable.ic_charging_60;
                else if (battery < 80) batteryImage = R.drawable.ic_charging_80;
                else if (battery < 90) batteryImage = R.drawable.ic_charging_90;
            } else {
                if (battery < 20) batteryImage = R.drawable.ic_battery_20;
                else if (battery < 30) batteryImage = R.drawable.ic_battery_30;
                else if (battery < 50) batteryImage = R.drawable.ic_battery_50;
                else if (battery < 60) batteryImage = R.drawable.ic_battery_60;
                else if (battery < 80) batteryImage = R.drawable.ic_battery_80;
                else if (battery < 90) batteryImage = R.drawable.ic_battery_90;
            }

            imageBattery.setImageDrawable(ContextCompat.getDrawable(this, batteryImage));
        }
    }

    public void showLoading(@StringRes final int message) {
        showLoading(message, false);
    }

    public void showLoading(@StringRes final int message, final boolean showCancel) {
        showLoading(getString(message), showCancel);
    }

    public void showLoading(final String message) {
        showLoading(message, false);
    }

    public void showLoading(final String message, final boolean showCancel) {

        loading = true;

        hideKeyboard();

        if (viewLoading != null && viewContent != null) {
            runOnUiThread(() -> {
                TextView textLoadingMessage = findViewById(R.id.textLoadingMessage);
                if (textLoadingMessage != null) textLoadingMessage.setText(message);
                viewLoading.setVisibility(View.VISIBLE);
                viewContent.setVisibility(View.GONE);
                if (viewContentFooter != null)
                    viewContentFooter.setVisibility(View.GONE);
                if (buttonCancel != null)
                    buttonCancel.setVisibility(showCancel ? View.VISIBLE : View.GONE);
            });
        }
    }

    public void showMessage(@StringRes int resid) {
        showMessage(getString(resid));
    }

    public void showMessage(final String message) {
        if (viewMessage != null && textMessage != null) {
            textMessage.post(() -> {
                viewMessage.setVisibility(View.VISIBLE);
                textMessage.setText(message);
            });
        }
    }

    public void showError(@StringRes int resid) {
        showError(getString(resid));
    }

    public void showError(final String message) {
        if (viewError != null && textError != null) {
            textError.post(() -> {
                viewError.setVisibility(View.VISIBLE);
                textError.setText(message);
            });
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        app.hideUi(this);

        if (keyCode >= KeyEvent.KEYCODE_F1 && keyCode <= KeyEvent.KEYCODE_F10) {
            onNumericKey(keyCode == KeyEvent.KEYCODE_F10 ? 0 : keyCode - KeyEvent.KEYCODE_F1 + 1);
            return true;
        }

        if (keyCode >= KeyEvent.KEYCODE_0 && keyCode <= KeyEvent.KEYCODE_9) {
            onNumericKey(keyCode - KeyEvent.KEYCODE_0);
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }

    public void hideLoading() {

        loading = false;

        if (viewLoading != null && viewContent != null) {
            runOnUiThread(() -> {
                viewLoading.setVisibility(View.GONE);
                viewContent.setVisibility(View.VISIBLE);
                if (viewContentFooter != null)
                    viewContentFooter.setVisibility(View.VISIBLE);
            });
        }
    }

    public void hideMessage() {
        if (viewMessage != null) {
            viewMessage.post(() -> viewMessage.setVisibility(View.GONE));
        }
    }

    public void hideError() {
        if (viewError != null) {
            viewError.post(() -> viewError.setVisibility(View.GONE));
        }
    }

    @Override
    public void setTitle(CharSequence title) {
        super.setTitle(title);
        refreshHeader();
    }

    @Override
    public void setTitle(int titleId) {
        super.setTitle(titleId);
        refreshHeader();
    }

    @Override
    protected void onPause() {
        super.onPause();
        app.onPause(this);

        if (adapter != null) {
            try {
                adapter.disableReaderMode(this);
            } catch (Exception ignored) {
                ignored.printStackTrace();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        app.onResume(this);

        if (adapter != null) {
            try {
                int readerFlags = NfcAdapter.FLAG_READER_NFC_A;
                adapter.enableReaderMode(this, this, readerFlags, null);
            } catch (Exception ignored) {
                ignored.printStackTrace();
            }
        }

        timerEventWork();

        /*app.getInApp().start();

        app.getInApp().getAppUpdateManager().getAppUpdateInfo().addOnSuccessListener(new OnSuccessListener<AppUpdateInfo>() {
            @Override
            public void onSuccess(AppUpdateInfo appUpdateInfo) {
                if (appUpdateInfo.installStatus() == InstallStatus.DOWNLOADED) {
                    log("DOWNLOADED");
                    Toast.makeText(MyActivity.this, "DOWNLOADED", Toast.LENGTH_SHORT).show();
                    app.getInApp().getAppUpdateManager().completeUpdate();
                }
            }
        });

        if (app.getInApp().isUpdateAvailable()) {
            app.getInApp().startUpdate();
        }*/

        initUpdate();
    }

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_UPDATE) {
            if (resultCode != RESULT_OK) {
                log("Update flow failed! Result code: " + resultCode);
            } else {
                log("Update flow ok!");
            }
        }
    }*/

    @Override
    protected void onDestroy() {
        super.onDestroy();
        app.onDestroy(this);
    }

    protected void log(@Nullable Exception e, @Nullable String message, Object... args) {
        app.log(this, e, Utils.format(message, args));
    }

    protected void log(@NonNull String message, Object... args) {
        app.log(this, Utils.format(message, args));
    }

    public void buttonClick(View view) {
        Object tag = view.getTag();
        if (tag != null && TextUtils.isDigitsOnly(tag.toString())) {
            int number = Utils.parseInt(tag.toString());
            if (number >= 0) this.onNumericKey(number);
        }
    }

    protected void onFunctionKey(int number) {
        log("onFunctionKey %d", number);
    }

    private void onNumericKey(int number) {

        if (number == 0) {
            if (this instanceof MainActivity) {
                onFunctionKey(0);
            } else {
                onBackPressed();
            }
        } else if (number == 1) {
            openHelp();
        } else {
            onFunctionKey(number);
        }
    }

    @Override
    public void onTagDiscovered(Tag tag) {
        if (!isLoading()) app.onNfcEvent(new NFC(tag));
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    public void buttonBackClick(View view) {
        onBackPressed();
    }

    public <T extends View> T findViewById(String id) {
        int i = getResources().getIdentifier(id, "id", getPackageName());
        if (i == 0) return null;
        return findViewById(i);
    }

    public void viewMessageOnClick(View view) {
        hideMessage();
    }

    public void viewErrorOnClick(View view) {
        hideError();
    }

    public void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(this);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    //UPDATER
    private boolean updateWarningShowed;

    private void initUpdate() {
        if (!(this instanceof MainActivity)) return;

        AppUpdateManager appUpdateManager = AppUpdateManagerFactory.create(this);

        appUpdateManager.getAppUpdateInfo().addOnSuccessListener(appUpdateInfo -> {
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE) {
                onUpdateAvailable(appUpdateInfo.availableVersionCode());
            }
        });

    }

    private void onUpdateAvailable(int availableVersionCode) {
        if (updateWarningShowed) return;
        updateWarningShowed = true;
        showUpdateWarning(availableVersionCode);
    }

    private void showUpdateWarning(int availableVersionCode) {
        log("availableVersionCode: %d", availableVersionCode);

        runOnUiThread(() -> showDialog(R.drawable.ic_warning_24dp,
                R.string.text_warning,
                getString(R.string.newversion, availableVersionCode),
                (dialog, which) -> {
                    //openGooglePlay()
                }
        ));
    }

    public void openGooglePlay() {
        final String appPackageName = getPackageName(); // getPackageName() from Context or Activity object
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
        } catch (android.content.ActivityNotFoundException anfe) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
        }
    }

    public void showShack(@StringRes int message) {
        showShack(getString(message));
    }

    public void showShack(String message) {

        View viewRoot = findViewById(R.id.viewRoot);

        if (viewRoot != null) {
            Snackbar snackbar = Snackbar.make(viewRoot, message, Snackbar.LENGTH_LONG);
            snackbar.show();
            snackbar.getView().setBackgroundColor(ContextCompat.getColor(this, R.color.snackbar_background));
        }
    }

    @Override
    public void onNfcEvent(NFC nfc) {
        PrinterConfig printerConfig = Printer.detectPrinter(nfc);

        runOnUiThread(() -> {
            if (printerConfig == null) {
                Toast.makeText(this, R.string.text_printer_scanned_error, Toast.LENGTH_SHORT).show();
            } else {
                connectPrinter(printerConfig);
            }
        });
    }

    private void connectPrinter(PrinterConfig printerConfig) {
        config.setPrinter(new PrinterConfig(printerConfig.getType(), printerConfig.getModel(), Utils.formatMacAddress(printerConfig.getMac())));
        config.saveConfig();
        Toast.makeText(this, R.string.text_printer_scanned_success, Toast.LENGTH_SHORT).show();
    }

    public void setCorrectTint(View view, boolean correct) {
        Utils.setCorrectTint(view, correct);
    }

    public enum ShowInfoType {
        BY_ID_QR, BY_LABEL_ID, BY_LABEL_ID_LIST, BY_LABEL_ID_THEOR, BY_LOCATION_ID, BY_LOCATION_CODE, BY_JSON_LIST, BY_LOCATION_CODE_BATCH, BY_LOCATION_CODE_OZM, BY_ZAPOR, BY_KOMINMET, BY_TRUBOSTAL, BY_ARCELOR
    }

    public void showInfoByLabelList(String title, List<JSONObject> labelList) {

        ArrayList<String> jsonList = new ArrayList<>(labelList.size());
        for (JSONObject jsonObject : labelList) {
            jsonList.add(jsonObject.toString());
        }

        Intent intent = new Intent(this, BarcodeResultActivity.class);
        intent.putExtra("type", ShowInfoType.BY_JSON_LIST);
        intent.putStringArrayListExtra("jsonList", jsonList);
        intent.putExtra("title", title);
        intent.putExtra("useResult", true);
        startActivityForResult(intent, REQUEST_DEFAULT);
    }

    public void showInfoByIdQr(String idQr) {
        Intent intent = new Intent(this, BarcodeResultActivity.class);
        intent.putExtra("type", ShowInfoType.BY_ID_QR);
        intent.putExtra("idQr", idQr);
        startActivity(intent);
    }

    public void showInfoByLabelId(String labelId, ScanItem scanItem) {
        Intent intent = new Intent(this, BarcodeResultActivity.class);
        intent.putExtra("type", ShowInfoType.BY_LABEL_ID);
        if (scanItem != null) intent.putExtra("scanItem", scanItem.getLine());
        intent.putExtra("labelId", labelId);
        startActivity(intent);
    }

    public void showInfoByLabelId(String labelId) {
        showInfoByLabelId(labelId, null);
    }

    public void showInfoByLabelIdList(String... labelIdList) {
        ArrayList<String> list = new ArrayList<>(Arrays.asList(labelIdList));
        Intent intent = new Intent(this, BarcodeResultActivity.class);
        intent.putExtra("type", ShowInfoType.BY_LABEL_ID_LIST);
        intent.putStringArrayListExtra("labelIdList", list);
        intent.putExtra("showGroups", false);
        startActivity(intent);
    }

    public void showInfoByLabelIdTheor(String labelId) {
        Intent intent = new Intent(this, BarcodeResultActivity.class);
        intent.putExtra("type", ShowInfoType.BY_LABEL_ID_THEOR);
        intent.putExtra("labelId", labelId);
        startActivity(intent);
    }

    public void showInfoByZapor(ScanItem scanItem) {
        Intent intent = new Intent(this, BarcodeResultActivity.class);
        intent.putExtra("type", ShowInfoType.BY_ZAPOR);
        intent.putExtra("data", scanItem.getLine());
        startActivity(intent);
    }

    public void showInfoByKominmet(ScanItem scanItem) {
        Intent intent = new Intent(this, BarcodeResultActivity.class);
        intent.putExtra("type", ShowInfoType.BY_KOMINMET);
        intent.putExtra("data", scanItem.getLine());
        startActivity(intent);
    }

    public void showInfoByTrubostal(ScanItem scanItem) {
        Intent intent = new Intent(this, BarcodeResultActivity.class);
        intent.putExtra("type", ShowInfoType.BY_TRUBOSTAL);
        intent.putExtra("data", scanItem.getLine());
        startActivity(intent);
    }

    public void showInfoByArcelor(ScanItem scanItem) {
        Intent intent = new Intent(this, BarcodeResultActivity.class);
        intent.putExtra("type", ShowInfoType.BY_ARCELOR);
        intent.putExtra("data", scanItem.getLine());
        startActivity(intent);
    }

    public void showInfoByLocationId(String locationId) {
        Intent intent = new Intent(this, BarcodeResultActivity.class);
        intent.putExtra("type", ShowInfoType.BY_LOCATION_ID);
        intent.putExtra("locationId", locationId);
        startActivity(intent);
    }

    public void showInfoByLocationCode(String locationCode) {
        showInfoByLocationCode(locationCode, null, 0, 0, 0, null, config.isEo()?config.getSmcId():null);
    }

    /*public void showInfoByLocationCode(String locationCode, ArrayList<String> checkedLabelList) {
        showInfoByLocationCode(locationCode, null, 0, 0, 0, checkedLabelList);
    }*/

    public void showInfoByLocationCode(String locationCode, String ozm, float length, float width, float thickness) {
        showInfoByLocationCode(locationCode, ozm, length, width, thickness, null, null);
    }

    public void showInfoByLocationCode(String locationCode, String ozm, float length, float width, float thickness, ArrayList<String> checkedLabelList, String storage) {
        Intent intent = new Intent(this, BarcodeResultActivity.class);
        intent.putExtra("type", ShowInfoType.BY_LOCATION_CODE);
        if (locationCode != null && locationCode.length() > 15)
            locationCode = parseLocation(locationCode);
        intent.putExtra("locationCode", locationCode);
        if (ozm != null) {
            intent.putExtra("ozm", ozm);
            intent.putExtra("length", length);
            intent.putExtra("width", width);
            intent.putExtra("thickness", thickness);
        }
        if (checkedLabelList != null) {
            intent.putStringArrayListExtra("checkedList", checkedLabelList);
            intent.putExtra("canScan", false);
        }
        intent.putExtra("storage", storage);
        startActivityForResult(intent, REQUEST_VIEW);
    }

	/*public void showInfoByOzm(String ozmName) {
		showInfoByOzm(ozmName, true);
	}*/

    public void showInfoByOzm(String ozmName, boolean fullName, float length, float width, float thickness) {
        Intent intent = new Intent(this, SearchOzmResultActivity.class);
        intent.putExtra("text", ozmName);
        intent.putExtra("fullName", fullName);
        intent.putExtra("length", length);
        intent.putExtra("width", width);
        intent.putExtra("thickness", thickness);
        startActivityForResult(intent, REQUEST_DEFAULT);
    }

    public void showInfoByBatch(String batch) {
        Intent intent = new Intent(this, SearchBatchResultActivity.class);
        intent.putExtra("text", batch);
        startActivityForResult(intent, REQUEST_DEFAULT);
    }

    public void showInfoByLocationCodeBatch(String batch, String locationCode) {
        Intent intent = new Intent(this, BarcodeResultActivity.class);
        intent.putExtra("type", ShowInfoType.BY_LOCATION_CODE_BATCH);
        intent.putExtra("locationCode", locationCode);
        intent.putExtra("batch", batch);
        startActivity(intent);
    }

    public void showInfoByLocationCodeOzm(List<Ozm> ozmList, String locationCode) {
        Intent intent = new Intent(this, BarcodeResultActivity.class);
        intent.putExtra("type", ShowInfoType.BY_LOCATION_CODE_OZM);
        intent.putExtra("locationCode", locationCode);
        intent.putParcelableArrayListExtra("ozmList", new ArrayList<>(ozmList));
        startActivity(intent);
    }

    private String lastCallPhone, lastCallFio;

    public void makeCall(String phone, String fio) {
        if (phone == null || phone.isEmpty()) return;
        lastCallPhone = phone;
        lastCallFio = fio;

        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, REQUEST_PERMISSION);
        } else {
            showDialogConfirm(fio, getString(R.string.call_dialog_message, phone), (dialog, which) -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_CALL);
                    char getPlus = phone.charAt(0);
                    if (getPlus == '+')
                        intent.setData(Uri.parse("tel:" + phone));
                    else
                        intent.setData(Uri.parse("tel:" + '+' + phone));
                    startActivity(intent);
                } catch (Exception e) {
                    log(e, "Intent.ACTION_CALL(%s)", phone);
                }
            });
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION && permissions.length > 0) {
            if (permissions[0].equalsIgnoreCase(Manifest.permission.CALL_PHONE) && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                makeCall(lastCallPhone, lastCallFio);
            }
        }
    }

    public Thread reqGet(String url, NetworkListener listener) {
        return Utils.runOnBackground(() -> {
            JsonResult result = net.downloadJson(url);
            runOnUiThread(() -> listener.onNetworkLoaded(result));
        });
    }

    protected void loadCraneTara() {
        loadCraneTara(config.getCraneId());
    }

    protected void loadCraneTara(long craneId) {
        if (craneId == 0) {
            showDialogConfirm(R.string.text_warning, R.string.inc_crane_not_set, (dialog, which) -> {
                Intent intent = new Intent(MyActivity.this, CranesActivity.class);
                intent.putExtra("isTara", true);
                startActivityForResult(intent, REQUEST_SELECT_CRANE);
            });
        } else {

            showLoading(R.string.text_please_wait);

            Utils.runOnBackground(() -> {

                Network.NetworkResultValue<Integer> result = processLoadWeight(craneId);

                runOnUiThread(() -> {

                    hideLoading();

                    if (result.isOk()) {
                        String message = getString(R.string.text_crane_current_weight, result.getValue());
                        showDialogConfirm(R.string.text_warning, message, getString(R.string.button_tara), getString(R.string.button_cancel), (dialog, which) -> beginLoadTara(craneId), null);
                    } else {
                        showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result.getResult()), (dialog, which) -> loadCraneTara(craneId));
                    }

                });

            });

        }
    }

    protected void loadCraneWeight() {
        loadCraneWeight(config.getCraneId());
    }

    protected void loadScalesWeight(byte cmd) {
        //showDiagResult(config.getScales().getMac()+"/"+config.getScales().getName());
        loadScalesWeight(config.getScales(), cmd);
    }

    protected void loadCraneWeight(long craneId) {
        if (craneId == 0) {
            showDialogConfirm(R.string.text_warning, R.string.inc_crane_not_set, (dialog, which) -> {
                Intent intent = new Intent(MyActivity.this, CranesActivity.class);
                startActivityForResult(intent, REQUEST_SELECT_CRANE);
            });
        } else {
            beginLoadWeight(craneId);
        }
    }

    protected void loadScalesWeight(ScalesConfig scales, byte cmd) {
        if (scales == null) {
            showDialogConfirm(R.string.text_warning, R.string.inc_scales_not_set, (dialog, which) -> {
                Intent intent = new Intent(MyActivity.this, ScalesActivity.class);
                startActivityForResult(intent, REQUEST_SELECT_CRANE);
            });
        } else {
            beginLoadWeight(scales, cmd);
        }
    }

    private void beginLoadTara(long craneId) {
        log("beginLoadTara crane#%d", craneId);

        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {
            String url = "http://dc00-apps-16.metinvest.ua:8088/Api/RegisterTaring";

            Map<String, String> headers = new HashMap<>();
            headers.put("AuthHeader", "Basic dXNlcm5hbWUKUGFzc3dvcmQ=");

            String body = Utils.format("{id: %d}", craneId);

            JsonResult result = net.requestProxy(url, false, headers, body);
            int res = 0;

            if (result.isOk()) {
                log("RES: %s", result.getJson().toString());

                try {
                    res = Utils.getJsonIntIgnoreCase(new JSONObject(Utils.getJsonStringIgnoreCase(result.getJson(), "data")), "status");
                } catch (Exception e) {
                    log(e, "beginLoadTara()");
                }
            }

            int finalRes = res;
            runOnUiThread(() -> endLoadTara(result, craneId, finalRes));
        });
    }

    private void endLoadTara(JsonResult result, long craneId, int value) {

        hideLoading();

        if (result.isOk()) {
            onCraneTara(craneId, value);
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoadTara(craneId));
        }
    }

    private Network.NetworkResultValue<Integer> processLoadWeight(long craneId) {
        String url = "http://dc00-apps-16.metinvest.ua:8088/Api/WeighScale_List";

        Map<String, String> headers = new HashMap<>();
        headers.put("AuthHeader", "Basic dXNlcm5hbWUKUGFzc3dvcmQ=");

        JsonResult result = net.requestProxy(url, false, headers, null);
        int res = 0;

        if (result.isOk()) {
            log("RES: %s", result.getJson().toString());

            JSONArray jsonArray = Utils.getJsonArray(Utils.getJsonStringIgnoreCase(result.getJson(), "data"), "data");
            for (int i = 0; jsonArray != null && i < jsonArray.length(); i++) {
                JSONObject jsonCrane = Utils.getJsonObject(jsonArray, i);
                if (jsonCrane != null) {
                    long itemCraneId = Utils.getJsonLongIgnoreCase(jsonCrane, "id");
                    int weight = Utils.getJsonIntIgnoreCase(jsonCrane, "weight");
                    String craneName = Utils.getJsonStringIgnoreCase(jsonCrane, "name");
                    log("%s = %d кг.", craneName, weight);

                    if (craneId == itemCraneId) res = weight;
                }
            }

            /*if (BuildConfig.DEBUG) {
                res = 12345;
            }*/
        }

        return new Network.NetworkResultValue<>(result, res);
    }

    private void beginLoadWeight(long craneId) {
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {
            Network.NetworkResultValue<Integer> result = processLoadWeight(craneId);
            runOnUiThread(() -> endLoadWeight(result.getResult(), craneId, result.getValue()));
        });

    }

    private void beginLoadWeight(ScalesConfig scales, byte cmd) {
        showLoading(R.string.text_please_wait);
        Utils.runOnBackground(() -> {
            Scales.ScalesResult finalResult = Scales.sendCommand(scales, cmd,false);
            runOnUiThread(() -> endLoadWeight(finalResult, scales, cmd, finalResult.getScalesResult().getWeight()));
        });
    }

    private void endLoadWeight(JsonResult result, long craneId, int value) {

        hideLoading();

        if (result.isOk()) {
            onCraneWeight(craneId, value);
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoadWeight(craneId));
        }
    }

    private void endLoadWeight(Scales.ScalesResult result, ScalesConfig scales, byte cmd, long value) {

        hideLoading();
        //showDiagResult(result.getStatus() + "/" + result.getScalesResult().getStatus() + "/" + result.getScalesResult().toString());
        if (result.getStatus() == Scales.ScalesResultStatus.OK) {
            onScalesWeight(scales, value);
        } else {
            if (result.getStatus() != null)
                showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, result.getScalesResult().getStatus()+"/"+result.getStatus(), (dialog, which) -> beginLoadWeight(scales, cmd));
        }
    }

    private void showDiagResult(String text) {
        if (isFinishing()) return;

        app.copyToClipboard(text);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(R.drawable.ic_warning_24dp);
        builder.setTitle(R.string.diag_result_dialog_title);

        String finalMessage = text.replaceAll("\n", "<br>");
        builder.setMessage(app.fromHtml(Utils.format("%s<br><br><i>TerminalId: %s</i><br><i>Версія:</i> %s", finalMessage, app.getDeviceId(), app.getApkVersionName())));
        builder.setPositiveButton(R.string.text_ok, null);

        final AlertDialog myDialog = builder.create();
        myDialog.setOnShowListener(dialog -> {
            Button button = myDialog.getButton(BUTTON_POSITIVE);
            button.setFocusable(true);
            button.setFocusableInTouchMode(true);
            button.requestFocus();
            app.hideUi(this);
        });
        myDialog.show();

        TextView textView = myDialog.findViewById(android.R.id.message);
        if (textView != null) textView.setTextSize(12);
    }

    protected void onCraneTara(long craneId, int value) {
        log("onCraneTara(%d, %d)", craneId, value);
    }

    protected void onCraneWeight(long craneId, int value) {
        log("onCraneWeight(%d, %d)", craneId, value);
    }

    protected void onScalesWeight(ScalesConfig scales, long value) {
        log("onCraneWeight(%s, %d)", scales.getName(), value);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_SELECT_CRANE && resultCode == RESULT_OK) {
            if (data != null && data.getBooleanExtra("isTara", false)) {
                loadCraneTara(config.getCraneId());
            } else {
                loadCraneWeight(config.getCraneId());
            }
        }
    }

    protected String getLabelIdFromUnknown(ScanItem scanItem) {
        if (scanItem.getType() != ScanItem.ScanItemType.SMC05 && scanItem.getType() != ScanItem.ScanItemType.SMC07) {
            return null;
        }

        JSONArray array = Utils.getJsonArray(scanItem.getData(2));
        if (array == null) return null;

        JSONObject object = Utils.getJsonObject(array, 0);
        String labelId = Utils.getJsonStringIgnoreCase(object, "id");
        if (labelId.isEmpty()) return null;

        return labelId;
    }

    protected void onIsUnknown(ScanItem scanItem, boolean unknown, @Nullable Label label) {
        log("onIsUnknown(%s, %s)", (label == null ? "null" : label.getId()), unknown);
    }

    protected void checkIsUnknown(ScanItem scanItem) {

        if (scanItem.getType() != ScanItem.ScanItemType.SMC05 && scanItem.getType() != ScanItem.ScanItemType.SMC07) {
            onIsUnknown(scanItem, false, null);
            return;
        }

        JSONArray array = Utils.getJsonArray(scanItem.getData(2));
        if (array == null) {
            onIsUnknown(scanItem, false, null);
            return;
        }

        JSONObject object = Utils.getJsonObject(array, 0);
        String labelId = Utils.getJsonStringIgnoreCase(object, "id");
        if (labelId.isEmpty()) {
            onIsUnknown(scanItem, false, null);
            return;
        }

        if (labelId.equalsIgnoreCase("0")) {
            onIsUnknown(scanItem, true, null);
            return;
        }

        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            String url = config.getUrlApi() + "getlabelinfo";
            url = net.addUrlParam(url, "label_id", labelId);
            JsonResult result = net.downloadJson(url);

            if (result.isOk()) {
                Label label = Label.fromJson(Utils.getJsonObject(result.getJson(), "data"));
                if (label == null) {
                    runOnUiThread(() -> {
                        hideLoading();
                        onIsUnknown(scanItem, false, null);
                    });
                } else {
                    label.setId(labelId);
                    runOnUiThread(() -> {
                        hideLoading();
                        onIsUnknown(scanItem, label.getBatch().equalsIgnoreCase("TEMP"), label);
                    });
                }
            } else {
                runOnUiThread(() -> {
                    hideLoading();
                    showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> checkIsUnknown(scanItem));
                });
            }
        });
    }

    protected boolean checkLocationPermit(String locationCode) {
        if (!app.isLocationPermitted(locationCode)) {
            showDialog(R.drawable.ic_error_24dp, R.string.text_error, getString(R.string.location_not_permitted_message, locationCode, app.getSmcIdCurrent()), null);
            return false;
        }
        return true;
    }

    protected void setActionDone(EditText editText, Button button) {
        editText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                if (button.isEnabled()) button.performClick();
                return true;
            }
            return false;
        });
    }

    protected void setActionDone(EditText editText, ImageButton button) {
        editText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                if (button.isEnabled()) button.performClick();
                return true;
            }
            return false;
        });
    }

    protected void setActionDone(EditText editText, Runnable runnable) {
        editText.setRawInputType(InputType.TYPE_CLASS_TEXT);
        editText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                runnable.run();
                return true;
            }
            return false;
        });
    }
}
