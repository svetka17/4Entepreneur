package com.metinvest.smc.view;

import android.os.Bundle;
import android.widget.CheckBox;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SettingsOtherActivity extends MyActivity {

    @BindView(R.id.checkPrintLabelRestShip) CheckBox checkPrintLabelRestShip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_other);
        ButterKnife.bind(this);

        checkPrintLabelRestShip.setChecked(config.isPrintLabelRestShip());
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
    }

    @Override
    protected void onFunctionKey(int number) {
        switch (number) {
            case 5:
                buttonSaveClick();
                break;
        }
    }

    private void buttonSaveClick() {
        config.setPrintLabelRestShip(checkPrintLabelRestShip.isChecked());
        config.saveConfig();
        setResult(RESULT_OK);
        finish();
    }

}
