package com.metinvest.smc.ui;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.metinvest.smc.R;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemInUnknown extends AbstractFlexibleItem<AdapterItemInUnknown.ViewHolder> {

    public interface Listener {
        void onNettoChanged(AdapterItemInUnknown item);

        void onPackChanged(AdapterItemInUnknown item);
    }

    private int index;
    private String qr;
    private int pack, netto;
    private final Listener listener;

    public AdapterItemInUnknown(int index, String qr, int pack, int netto, Listener listener) {
        this.index = index;
        this.qr = qr;
        this.pack = pack;
        this.netto = netto;
        this.listener = listener;
    }

    public int getIndex() {
        return index;
    }

    public String getQr() {
        return qr;
    }

    public int getPack() {
        return pack;
    }

    public int getNetto() {
        return netto;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof AdapterItemInUnknown)
            return ((AdapterItemInUnknown) o).getIndex() == getIndex() &&
                    ((AdapterItemInUnknown) o).getQr().equalsIgnoreCase(getQr());
        else
            return false;
    }

    @Override
    public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new ViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {

        holder.textIndex.setText(Utils.format("Позиція №:%s", getIndex() + 1));
        holder.textQr.setText(getQr().isEmpty() ? "" : "ID_QR");

        holder.textWeightPack.setText(String.valueOf(getPack()));
        holder.textWeightNetto.setText(String.valueOf(getNetto()));

        holder.textWeightPack.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                pack = Utils.parseInt(s.toString());
                if (listener != null) listener.onNettoChanged(AdapterItemInUnknown.this);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        holder.textWeightNetto.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                netto = Utils.parseInt(s.toString());
                if (listener != null) listener.onPackChanged(AdapterItemInUnknown.this);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_unknown_row;
    }

    public class ViewHolder extends FlexibleViewHolder {

        @BindView(R.id.textIndex)
        TextView textIndex;
        @BindView(R.id.textQr)
        TextView textQr;
        @BindView(R.id.textWeightPack)
        EditText textWeightPack;
        @BindView(R.id.textWeightNetto)
        EditText textWeightNetto;

        public ViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            ButterKnife.bind(this, view);
        }
    }
}
