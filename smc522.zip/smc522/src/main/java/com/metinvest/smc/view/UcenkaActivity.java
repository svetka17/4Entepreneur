package com.metinvest.smc.view;


import static com.metinvest.smc.tools.Utils.parseDiscount;
import static com.metinvest.smc.tools.Utils.parseInt;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterLabel;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.IFlexible;

public class UcenkaActivity extends MyActivity implements AdapterLabel.IListener {

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    @BindView(R.id.buttonRefresh)
    Button buttonRefresh;
    @BindView(R.id.buttonAction)
    Button buttonAction;
    @BindView(R.id.viewRefresh)
    View viewRefresh;
    @BindView(R.id.viewAction)
    View viewAction;

    @BindView(R.id.checkAll)
    CheckBox checkAll;

    private FlexibleAdapter<IFlexible> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ucenka);
        ButterKnife.bind(this);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
        listView.setLayoutManager(layoutManager);
        listView.addItemDecoration(dividerItemDecoration);
        checkAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                beginLoad();
            }
        });

    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            beginLoad();
        } else if (number == 4) {
            beginAction();
        }
    }

    private void  beginLoad(){
        showLoading(R.string.text_please_wait);
        buttonRefresh.setEnabled(false);

        Utils.runOnBackground(() -> {
            String url = config.getUrlApi() + "getucenkainfo";
            url = net.addUrlParam(url, "STATUS_OUT", checkAll.isChecked()?0:100);
            url = net.addUrlParam(url, "LGORT", config.getStorage());

            JsonResult result = net.downloadJson(url);

            List<Label> list = new ArrayList<>();

            if (result.isOk()) {
                JSONArray array = Utils.getJsonArray(result.getJson(), "data");
                if (array != null) {
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject json = Utils.getJsonObject(array, i);
                        if (json != null) {

                            //boolean exist = Utils.jsonExist(json, "line_id");
                            String id_doc = Utils.getJsonStringIgnoreCase(json, "id_doc");
                            String id_pos = Utils.getJsonStringIgnoreCase(json, "id_pos");
                            String sap_batch = Utils.getJsonStringIgnoreCase(json, "sap_batch");
                            String discount = Utils.getJsonStringIgnoreCase(json, "discount");
                            float discountF = parseDiscount(discount);
                            int line_id = Utils.getJsonIntIgnoreCase(json, "line_id");
                            int vo = Utils.getJsonIntIgnoreCase(json, "vo");
                            float sap_weight_nett = Utils.getJsonFloatIgnoreCase(json, "sap_weight_nett");
                            JSONArray labels = Utils.getJsonArray(json, "labels");
                            if (labels != null && discountF > 0) {
                                for (int j = 0; j < labels.length(); j++) {
                                    JSONObject jsonLabel = Utils.getJsonObject(labels, j);
                                    int labelId = Utils.getJsonIntIgnoreCase(jsonLabel, "labelId");
                                    int printLabel = Utils.getJsonIntIgnoreCase(jsonLabel, "printLabel");
                                    String smc_id = Utils.getJsonStringIgnoreCase(jsonLabel, "smc_id");
                                    String plan_line_id = Utils.getJsonStringIgnoreCase(jsonLabel, "plan_line_id");
                                    String label_weight_nett = Utils.getJsonStringIgnoreCase(jsonLabel, "label_weight_nett");
                                    String low_price_percent = Utils.getJsonStringIgnoreCase(jsonLabel, "low_price_percent");
                                    if (low_price_percent == "") low_price_percent = "0";
                                    //java.util.function.Predicate<? super Label> predicateLabel = e -> parseInt(e.getId()) == labelId;
                                    Predicate<Label> predicateLabel = e -> parseInt(e.getId()) == labelId;
                                    if (( (!checkAll.isChecked() && printLabel != 3 && (parseDiscount(low_price_percent) != discountF)) || (checkAll.isChecked() && ( /*low_price_percent != "0" ||*/ printLabel == 3) ) )
                                            && labelId > 0
                                            //&& list.stream().noneMatch(predicateLabel)
                                    ) {
                                        Label label = null;
                                        Optional<Label> label1 = list.stream().filter(predicateLabel).findFirst();
                                                //.orElse(new Label());
                                        if (label1.isPresent()){
                                            label = label1.get();
                                        } else {
                                                String urlLabel = config.getUrlApi() + "getlabelinfo";
                                                urlLabel = net.addUrlParam(urlLabel, "label_id", labelId);
                                                urlLabel = net.addUrlParam(urlLabel, "smc_id", "NULL");
                                                JsonResult resultLabel = net.downloadJson(urlLabel);
                                                if (resultLabel.isOk()) {
                                                    //GET LABEL
                                                    JSONObject jsonLabelData = Utils.getJsonObject(resultLabel.getJson(), "data");
                                                    label = Label.fromJson(jsonLabelData, String.valueOf(labelId));
                                                    label.setLineId(String.valueOf(line_id));
                                                    list.add(label);
                                                }
                                        }

                                        label.setLowPricePercent(discount);
                                        if (vo == 61) {
                                            label.setDiscount(low_price_percent);
                                            label.setBatchUcenka(sap_batch);
                                            label.setLineId(String.valueOf(line_id));
                                        } else if (vo == 62) {
                                            label.setDiscount("0");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            runOnUiThread(() -> endLoad(list, result));
        });
    }

    private void endLoad(List<Label> list, JsonResult result) {
        hideLoading();
        buttonRefresh.setEnabled(true);

        if (result.isOk()) {
            showContent(list);
        } else {
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
        }
    }

    private void showContent(List<Label> list) {

        showLoading(R.string.text_please_wait);
        buttonRefresh.setEnabled(false);

        Utils.runOnBackground(() -> {

            long s1 = System.currentTimeMillis();

            List<IFlexible> flexibleList = new ArrayList<>();

            for (int i = 0; i < list.size(); i++) {

                Label item = list.get(i);

                AdapterLabel itemLabel = new AdapterLabel(null, item, true, false,
                        false, true, true, this);

                flexibleList.add(itemLabel);
            }

            adapter = new FlexibleAdapter<>(flexibleList);

            long s2 = System.currentTimeMillis();
            log("ms: %d ms", s2 - s1);

            runOnUiThread(() -> {

                listView.setAdapter(adapter);
                if (adapter != null && adapter.getItemCount() > 0)
                    adapter.smoothScrollToPosition(0);
                textNotFound.setVisibility(flexibleList.isEmpty() ? View.VISIBLE : View.GONE);
                //listView.setVisibility(flexibleList.isEmpty() ? View.GONE : View.VISIBLE);

                hideLoading();
                buttonRefresh.setEnabled(true);
            });
        });

    }

    private void beginAction() {
        if (adapter != null) {
            List<IFlexible> list = adapter.getCurrentItems();
            //List<AdapterLabel> listToPrint = new ArrayList<>();
            for (IFlexible itemFlexible : list) {
                runOnUiThread(() ->
                {
                    if (itemFlexible instanceof AdapterLabel) {
                    AdapterLabel listSub = (AdapterLabel) itemFlexible;
                    //listToPrint.add(listSub);
                    //runOnUiThread(() -> listSub.getListener().onPrintClicked(listSub));
                    //Utils.runOnBackground(() -> listSub.getListener().onPrintClicked(listSub));
                    listSub.getListener().onPrintClicked(listSub);
                }
            });
            }
        }
    }

    @Override
    public void onPrintClicked(AdapterLabel item) {

        Utils.runOnBackground(() -> {
            String url = config.getUrlApi() + "setdiscount";
            url = net.addUrlParam(url, "LABEL_ID", item.getLabel().getId());
            url = net.addUrlParam(url, "LINE_ID", item.getLabel().getLineId());
            url = net.addUrlParam(url, "DISCOUNT", parseDiscount(item.getLabel().getLowPricePercent()));
            StringBuilder sb = new StringBuilder();
            sb.append("[");
            sb.append("]");
            //если успешно напечатано, то в labels обновляем printLabel = 3 по label_id
            JsonResult resultPrintLabel = net.uploadJson(url, sb.toString());
            //final Printer.PrintResult result = Printer.sendCommand(title, config.getPrinter(), content);
            //if (result.getStatus() == Printer.PrintResultStatus.OK)
            if (resultPrintLabel.getStatus() == LoadResultStatus.OK) {
                //Utils.runOnBackground(() -> {
                runOnUiThread(() -> {
                String content;
                String dplTitle = "";

                int theorCount = item.getLabel().isTheor() && item.getGroup() != null ? item.getGroup().getTheorCount() : 0;
                String bath = item.getLabel().getBatch();
                if (item.getLabel().getBatchUcenka() != null && item.getLabel().getBatchUcenka().length() > 0)
                    bath = item.getLabel().getBatchUcenka();
                content = app.generateDplLabel(
                        item.getLabel().getId(), new Date(), item.getLabel().getName(),
                        item.getLabel().getWidth(), item.getLabel().getLength(), item.getLabel().getThickness(), item.getLabel().getWeightNetto(), item.getLabel().getWeightPack(),
                        0, item.getLabel().getOzm(), bath,
                        item.getLabel().getCarrier(), 0, item.getLabel().isTheor(), theorCount, item.getLabel().getLocationCode(), item.getLabel().getZavBatch(), item.getLabel().getZavPlavka(), item.getLabel().getZavOdin(),
                        item.getLabel().getLowPricePercent(), item.getLabel().getManufacturer(), item.getLabel().getSortCriterion()
                        , item.getLabel().getStorage()
                );

                dplTitle += Utils.format("<b>%s</b><br>", item.getLabel().getName());
                dplTitle += Utils.format("Розмір: %s<br>", app.sizeToString(item.getLabel().getWidth(), item.getLabel().getLength(), item.getLabel().getThickness()));
                dplTitle += Utils.format("Вага нетто: %s<br>", item.getNettoFact() == -1 ? item.getLabel().getWeightNetto() : item.getNettoFact());
                dplTitle += Utils.format("Партія: %s", bath);

                beginPrint(dplTitle, content/*, item.getLabel().getId(), item.getLabel().getLowPricePercent(), item.getLabel().getLineId()*/);
            });
            } else {
                String message = getString(R.string.text_error_uchenka, item.getLabel().getId());
                runOnUiThread(() -> showToast(message));
            }
            //endPrint(title, content, result, labelId, discount, line_id);
        });

    }

    public void beginPrint(/*Label label, JsonResult res*/String title, String content ) {

        final Printer.PrintResult result = Printer.sendCommand(title, config.getPrinter(), content);
        //if (result.getStatus() == Printer.PrintResultStatus.OK) {
            runOnUiThread(() -> endPrint(title, content, result/*, labelId, discount, line_id*/));
        //} else
          //  runOnUiThread(() -> showToast(R.string.text_error_uchenka));
    }

    private void endPrint(/*Utils.NetworkPrintResult result, Label label*/String title, String content, Printer.PrintResult result) {
        hideLoading();
        if (result.getStatus() == Printer.PrintResultStatus.OK) {
            showToast(R.string.text_print_result_succeeded);
            //@StringRes final int message = app.getPrintResultMessage(result.getPrintResult());
            //showDialog(message);
            //beginLoad();
            //app.sendFaPrint();
        } else if (result.getStatus() == Printer.PrintResultStatus.ERROR_NO_PRINTER) {
            showToast(R.string.text_print_result_no_printer);
        } else {
            @StringRes final int message = app.getPrintResultMessage(result);
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> beginPrint(title, content));
        }

    }

    @Override
    public void onEditClicked(AdapterLabel item) {

    }

    @Override
    public void onSplitClicked(AdapterLabel item) {

    }

    @Override
    public void onOzmViewClicked(AdapterLabel item) {

    }

    @Override
    public void onTransferClicked(AdapterLabel item) {

    }
}
