package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface IdQrStoreDao {
    @Query("SELECT * FROM idqrstore ORDER BY name")
    List<IdQrStore> getAll();

    @Query("SELECT * FROM idqrstore WHERE id = :id")
    IdQrStore getById(long id);

    @Query("SELECT * FROM idqrstore WHERE name = :name")
    IdQrStore getByName(String name);

    @Query("SELECT * FROM idqrstore WHERE lower(name) LIKE lower(:name)")
    List<IdQrStore> getByNameLike(String name);

    @Insert
    long insert(IdQrStore idQrStore);

    @Insert
    void insertAll(List<IdQrStore> idQrStore);

    @Update
    void update(IdQrStore idQrStore);

    @Delete
    void delete(IdQrStore idQrStore);

    @Query("DELETE FROM idqrstore")
    void truncate();
}