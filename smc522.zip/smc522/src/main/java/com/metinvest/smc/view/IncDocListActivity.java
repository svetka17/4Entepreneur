package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.inc.AdapterItemDoc;
import com.metinvest.smc.inc.SohFilter;
import com.metinvest.smc.inc.TTN;
import com.metinvest.smc.inc.Transport;
import com.metinvest.smc.inc.TransportDoc;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.Utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class IncDocListActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.buttonRefresh)
    Button buttonRefresh;
    @BindView(R.id.frameButtonRefresh)
    View frameButtonRefresh;
    @BindView(R.id.viewContentData)
    View viewContentData;
    @BindView(R.id.textNotFound)
    TextView textNotFound;

    private Date dateFrom, dateTo;
    private String transportName;
    private FlexibleAdapter<AdapterItemDoc> adapter;
    private boolean isManager;
	private String sohSmcId;
	private SohFilter sohFilter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inc_doc_list);
        ButterKnife.bind(this);

		sohSmcId = getIntent().getStringExtra("sohSmcId");
		sohFilter = sohSmcId == null ? SohFilter.NotSoh() : SohFilter.SohInc(sohSmcId);
		dateFrom = (Date) getIntent().getSerializableExtra("dateFrom");
        dateTo = (Date) getIntent().getSerializableExtra("dateTo");
        transportName = getIntent().getStringExtra("transportName");
        textContentTitle.setText(R.string.title_inc_doc_list);
        isManager = getIntent().getBooleanExtra("isManager", false);
        if (isManager) log("isManager");

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
    }

    @Override
    protected String getHelpContent() {
        return getString(R.string.inc_transport_list_help);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) buttonRefreshClick();
    }

    private void buttonRefreshClick() {
        if (isLoading()) return;

        beginLoad();
    }

    @Override
    public boolean onItemClick(View view, int position) {
        AdapterItemDoc item = adapter.getItem(position);
        if (item != null) {
            openDoc(item);
        }
        return false;
    }

    private void openDoc(AdapterItemDoc item) {
        Intent intent = new Intent(this, IncDocActivity.class);
        intent.putExtra("dateFrom", dateFrom);
        intent.putExtra("dateTo", dateTo);
        intent.putExtra("date", item.getDoc().getTransport().getDate());
        intent.putExtra("transportName", item.getDoc().getTransport().getName());
        intent.putExtra("ttn", item.getDoc().getTtn());
        intent.putExtra("isNew", getIntent().getBooleanExtra("isNew", false));
        intent.putExtra("isManager", isManager);
        intent.putExtra("sohSmcId", sohSmcId);
        startActivityForResult(intent, REQUEST_DEFAULT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_DEFAULT) {
            if (resultCode == RESULT_OK) {
                beginLoad();
            } else if (resultCode == RESULT_DELETED) {
                setResult(RESULT_DELETED);
                finish();
            }
        }
    }

    private void beginLoad() {

        if (isLoading()) return;

        showLoading(R.string.text_please_wait);
        frameButtonRefresh.setVisibility(View.GONE);

        Utils.runOnBackground(() -> {

			Network.NetworkResultValue<Transport> result = app.loadIncTransport(dateFrom, dateTo, transportName, sohFilter);

            List<AdapterItemDoc> list = new ArrayList<>();

            if (result.getResult().isOk()) {
                Transport transport = result.getValue();
                if (transport != null) {
                    List<TTN> ttnList = transport.getTtnList();

                    for (TTN ttn : ttnList) {
                        TransportDoc doc = TransportDoc.fromTransport(transport, ttn);
                        list.add(new AdapterItemDoc(doc, isManager));
                    }
                }
            }

            runOnUiThread(() -> endLoad(result.getResult(), list));
        });
    }

    private void endLoad(JsonResult result, List<AdapterItemDoc> list) {
        hideLoading();
        frameButtonRefresh.setVisibility(View.VISIBLE);

        adapter = new FlexibleAdapter<>(list);
        adapter.addListener(this);
        listView.setAdapter(adapter);
        viewContentData.setVisibility(result.isOk() && !list.isEmpty() ? View.VISIBLE : View.GONE);
        textNotFound.setVisibility(!result.isOk() || list.isEmpty() ? View.VISIBLE : View.GONE);
        scrollView.post(() -> scrollView.scrollTo(0, 0));

        if (!result.isOk()) {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
        }

    }

    public class AdapterItem extends AbstractFlexibleItem<AdapterItem.ViewHolder> {

        private final TransportDoc transportDoc;

        AdapterItem(TransportDoc transportDoc) {
            this.transportDoc = transportDoc;
        }

        public TransportDoc getTransportDoc() {
            return transportDoc;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof AdapterItem && ((AdapterItem) o).getTransportDoc().equals(getTransportDoc());
        }

        @Override
        public int hashCode() {
            return getTransportDoc().hashCode();
        }

        @Override
        public int getLayoutRes() {
            return R.layout.adapter_inc_transport;
        }

        @Override
        public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
            return new ViewHolder(view, adapter);
        }

        @Override
        public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {
            String title = Utils.format("<b>%s</b>", transportDoc.getTransport().getName());

            StringBuilder sb = new StringBuilder();
            sb.append(Utils.format("План, тн: %.3f<br>", transportDoc.getTotalWeightPlan() / 1000.0f));
            sb.append(Utils.format("Факт, тн: %s %s<br>", Utils.factToString(transportDoc.getTotalWeightFact()), transportDoc.getTotalWeightPercentString()));
            if (transportDoc.getTotalWeightFactTemp() > 0) {
                sb.append(Utils.format("<font color=\"red\">з них тимчасових, тн: %.3f</font><br>", transportDoc.getTotalWeightFactTemp() / 1000.0f));
            }
            sb.append(Utils.format("Статус: %s<br>", transportDoc.getStatusString()));

            sb.append(Utils.format("ТТН: %s", transportDoc.getTtn().getNum()));

            holder.textTitle.setText(app.fromHtml(title));
            holder.textContent.setText(app.fromHtml(sb.toString()));

            View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
            holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
            refreshBackground(holder, holder.itemView.isFocused());
        }

        private void refreshBackground(ViewHolder holder, boolean hasFocus) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_adapter_light));
        }

        class ViewHolder extends FlexibleViewHolder {

            @BindView(R.id.textTitle)
            TextView textTitle;
            @BindView(R.id.textContent)
            TextView textContent;

            ViewHolder(View view, FlexibleAdapter adapter) {
                super(view, adapter);
                ButterKnife.bind(this, view);
            }
        }
    }
}
