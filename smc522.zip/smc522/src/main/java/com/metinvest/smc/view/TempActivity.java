package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;

import com.metinvest.smc.R;

public class TempActivity extends MyActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temp);
    }

    @Override
    protected String getHelpContent() {
        return getString(R.string.select_operation_help);
    }

    @Override
    protected void onFunctionKey(int number) {
        switch (number) {
            case 2:
                startActivity(new Intent(this, UnknownActivity.class));
                break;
            case 3:
                startActivity(new Intent(this, CatalogTempActivity.class));
                break;
            case 4:
                Intent intent = new Intent(this, SearchBatchActivity.class);
                intent.putExtra("search", "TEMP");
                startActivity(intent);
                break;
        }
    }
}
