package com.metinvest.smc.ui;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.tools.IValue;

import java.util.List;

public class ValueAdapter extends RecyclerView.Adapter<ValueAdapter.StringViewHolder> {
    private List<IValue> items;

    // Provide a suitable constructor (depends on the kind of dataset)
    public ValueAdapter(List<IValue> list) {
        items = list;
    }

    // Create new views (invoked by the layout manager)
    @NonNull
    @Override
    public StringViewHolder onCreateViewHolder(ViewGroup parent,
                                               int viewType) {
        // create a new view
        TextView v = (TextView) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.my_text_view, parent, false);

        StringViewHolder vh = new StringViewHolder(v);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(StringViewHolder holder, int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        holder.textView.setText(items.get(position).getName());

    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return items.size();
    }

    // Provide a reference to the views for each items item
    // Complex items items may need more than one view per item, and
    // you provide access to all the views for a items item in a view holder
    public static class StringViewHolder extends RecyclerView.ViewHolder {
        // each items item is just a string in this case
        public TextView textView;

        public StringViewHolder(TextView v) {
            super(v);
            textView = v;
        }
    }
}