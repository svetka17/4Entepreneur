package com.metinvest.smc.net;

public class RequestOpt {
	private String apiUrl;
	private String url;
	private boolean post;
	private boolean put;
	private String postData;
	private long packetId;
	private String networkType;
	private int userId;
	private String smcId;
	private String deviceId;
	private int version;
	private String token;

	private boolean msal;

	public RequestOpt() {
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public boolean isMsal() {
		return msal;
	}

	public void setMsal(boolean msal) {
		this.msal = msal;
	}

	public String getApiUrl() {
		return apiUrl;
	}

	public void setApiUrl(String apiUrl) {
		this.apiUrl = apiUrl;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public boolean isPost() {
		return post;
	}

	public void setPost(boolean post) {
		this.post = post;
	}

	public boolean isPut() {
		return put;
	}

	public void setPut(boolean put) {
		this.put = put;
	}

	public String getPostData() {
		return postData;
	}

	public void setPostData(String postData) {
		this.postData = postData;
	}

	public long getPacketId() {
		return packetId;
	}

	public void setPacketId(long packetId) {
		this.packetId = packetId;
	}

	public String getNetworkType() {
		return networkType;
	}

	public void setNetworkType(String networkType) {
		this.networkType = networkType;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getSmcId() {
		return smcId;
	}

	public void setSmcId(String smcId) {
		this.smcId = smcId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}
}
