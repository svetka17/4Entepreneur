package com.metinvest.smc.ui;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemIn2 extends AbstractFlexibleItem<AdapterItemIn2.AdapterItemIn2ViewHolder> {

    private final OnTheWay onTheWay;
    private int w1, w2, w3;
    private int index;

    public AdapterItemIn2(int index, OnTheWay onTheWay, int w1, int w2, int w3) {
        this.index = index;
        this.onTheWay = onTheWay;
        this.w1 = w1;
        this.w2 = w2;
        this.w3 = w3;
    }

    public int getIndex() {
        return index;
    }

    public OnTheWay getOnTheWay() {
        return onTheWay;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof AdapterItemIn2)
            return ((AdapterItemIn2) o).getIndex() == getIndex();
        else
            return false;
    }

    public int getW1() {
        return w1;
    }

    public int getW2() {
        return w2;
    }

    public int getW3() {
        return w3;
    }

    @Override
    public AdapterItemIn2ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new AdapterItemIn2ViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemIn2ViewHolder holder, int position, List<Object> payloads) {

        StringBuilder sb = new StringBuilder();
        sb.append(Utils.format("<b>Позиція №:%s</b>", getIndex() + 1));

        if (onTheWay != null) {
            sb.append("<br>");
            sb.append(Utils.format("Партія: %s<br>", onTheWay.getSapBatch()));
            sb.append(Utils.format("Очікувана вага: %s кг.<br>", onTheWay.getSapWeightNett()));
            sb.append(Utils.format("Склад: %s", onTheWay.getStorage()));
        }

        holder.textContent.setText(App.getInstance().fromHtml(sb.toString()));

        holder.textW1.setText(String.valueOf(getW1()));
        holder.textW2.setText(String.valueOf(getW2()));
        holder.textW3.setText(String.valueOf(getW3()));

        holder.textW1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                w1 = Utils.parseInt(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        holder.textW2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                w2 = Utils.parseInt(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        holder.textW3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                w3 = Utils.parseInt(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //App.getInstance().log(this, "bindViewHolder %s", position);
    }

    @Override
    public void unbindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemIn2ViewHolder holder, int position) {
    }

    @Override
    public void onViewAttached(FlexibleAdapter<IFlexible> adapter, AdapterItemIn2ViewHolder holder, int position) {
    }

    @Override
    public void onViewDetached(FlexibleAdapter<IFlexible> adapter, AdapterItemIn2ViewHolder holder, int position) {
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_in2_row;
    }

    /**
     * The ViewHolder used by this item.
     * Extending from FlexibleViewHolder is recommended especially when you will use
     * more advanced features.
     */
    public class AdapterItemIn2ViewHolder extends FlexibleViewHolder {

        private final TextView textContent;
        private final View view;
        private final EditText textW1, textW2, textW3;

        public AdapterItemIn2ViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.view = view;
            this.textContent = view.findViewById(R.id.textContent);
            this.textW1 = view.findViewById(R.id.textW1);
            this.textW2 = view.findViewById(R.id.textW2);
            this.textW3 = view.findViewById(R.id.textW3);
        }
    }
}
