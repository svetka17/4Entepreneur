package com.metinvest.smc.tools;

import com.metinvest.smc.App;
import com.metinvest.smc.db.Carrier;
import com.metinvest.smc.db.Db;
import com.metinvest.smc.db.NameStore;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.db.Printed;
import com.metinvest.smc.db.Weighing;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

public class DplGeneratorTransport {

    private final App app;
    private final Db db;
    private final long carrierId;

    private List<Printed> printedList;
    private int printedY;
    private StringBuilder printedData;
    private int printedPage, printedPageCount;
    private String printedCarrier, printedTtnNum, printedTtnDate;

    //private final String font1 = "S51";
    //private final String font2 = "S52";
    private final String font1 = "S53";
    private final String font2 = "S53";
    private final int maxY = 1400;// 1440;

    public DplGeneratorTransport(long carrierId) {
        this.app = App.getInstance();
        this.db = app.getDb();
        this.carrierId = carrierId;
    }

    public String generateTitle() {
        Carrier carrier = db.carrierDao().getById(carrierId);
        return "<b>Звіт по транспорту</b><br>" + carrier.getName();
    }

    public String generateDpl() {

        long t1 = Calendar.getInstance().getTime().getTime();

        printedList = new ArrayList<>();
        printedData = new StringBuilder();
        printedY = 0;
        printedPage = 0;
        printedPageCount = 0;

        List<Printed> printedListNew = db.printedDao().getAllNew();
        for (Printed printed : printedListNew) {
            OnTheWay way = db.onTheWayDao().getById(printed.getOnTheWayId());
            if (way.getCarrierId() == carrierId) {
                printedList.add(printed);
            }
        }

        if (printedList.isEmpty()) {
            return "";
        }

        Carrier carrier = db.carrierDao().getById(carrierId);
        OnTheWay wayMain = db.onTheWayDao().getById(printedList.get(0).getOnTheWayId());
        printedCarrier = carrier.getName();
        printedTtnNum = wayMain.getTtnNum();
        printedTtnDate = wayMain.getTtnDate();

        processItems();

        long t2 = Calendar.getInstance().getTime().getTime();

        app.log(this, "TIME FOR GENERATE DPL: %d ms", t2 - t1);

        return printedData.toString();
    }

    private void processItems() {

        //Сортируем по ОЗМ
        /*Collections.sort(printedList, (o1, o2) -> {
            return o1.getSapOzm().compareTo(o2.getSapOzm());
        });*/

        //DPL
        printedData.append("\u0002m\n\u0002L\nD11\nPA\nySU8\n");

        //HEADER
        addHeader();

        int totalWeighingCount = 0;
        int totalBruttoFact = 0;
        int totalNettoFact = 0;

        int totalWayWeight = 0;
        int totalOzmFactWeight = 0;

        int totalR = 0;

        //CONTENT
        for (int i = 0; i < printedList.size(); i++) {

            Printed printed = printedList.get(i);
            OnTheWay way = db.onTheWayDao().getById(printed.getOnTheWayId());
            NameStore nameStore = db.nameStoreDao().getById(way.getNameId());
            Weighing weighing = db.weighingDao().getById(printed.getWeighingId());

            Printed printedPrev = i == 0 ? null : printedList.get(i - 1);
            OnTheWay wayPrev = printedPrev == null ? null : db.onTheWayDao().getById(printedPrev.getOnTheWayId());
            NameStore nameStorePrev = wayPrev == null ? null : db.nameStoreDao().getById(wayPrev.getNameId());

            Printed printedNext = i + 1 == printedList.size() ? null : printedList.get(i + 1);
            Weighing weighingPrev = i == 0 ? null : db.weighingDao().getById(printedList.get(i - 1).getWeighingId());

            OnTheWay wayNext = printedNext == null ? null : db.onTheWayDao().getById(printedNext.getOnTheWayId());
            NameStore nameStoreNext = wayNext == null ? null : db.nameStoreDao().getById(wayNext.getNameId());

            if (printedPrev != null && !printedPrev.isTemporary() && printed.isTemporary()) {
                //addNewPage();
            }

            boolean printOzm = nameStorePrev == null || nameStorePrev.getId() != nameStore.getId();
            boolean printOzmFooter = nameStoreNext == null || nameStoreNext.getId() != nameStore.getId();
            boolean printWeighing = weighingPrev == null || weighingPrev.getId() != weighing.getId();

            if (printWeighing) {
                totalWeighingCount++;
            }

            //Группировка ОЗМ
            if (printOzm) {
                addOzm(nameStore);
            }

            totalBruttoFact += printed.getWeightNetto() + printed.getWeightTara() + printed.getWeightPack();
            totalOzmFactWeight += printed.getWeightNetto();

            //----------------------------- Список позиций

            printedData.append(Utils.format(
                    "3911%s%04d0980P010P010%s\n" +
                            "3911%s%04d0915P010P010%s\n" +
                            "3911%s%04d0730P010P010%s\n" +
                            "3911%s%04d0520P010P010%s\n" +
                            "3911%s%04d0140P010P010%s\n",
                    font2, printedY, printWeighing ? Utils.format("%02d", weighing.getNumber()) : "",
                    font2, printedY, printWeighing ? Utils.format("%.3f тн", weighing.getWeightCrane() / 1000.0f) : "",
                    font2, printedY, printed.isTemporary() ? "-" : way.getSapBatch(),
                    font2, printedY, Utils.format("%.3f/%.3f/%.3f",
                            (printed.getWeightTag() + printed.getWeightPack() + printed.getWeightTara()) / 1000.0f,
                            (printed.getWeightPack() + printed.getWeightTara()) / 1000.0f,
                            (printed.getWeightTag()) / 1000.0f
                    ),
                    font2, printedY, Utils.format("%.3f", (printed.getWeightNetto()) / 1000.0f
                    )
            ));
            addY(40);

            if (printOzmFooter) {

                int wayWeight = db.onTheWayDao().getTotalWeightByCarrierAndName(carrierId, nameStore.getId());
                totalWayWeight += wayWeight;
                app.log(this, "totalWayWeight +%s", String.valueOf(wayWeight));

                int r = totalOzmFactWeight - wayWeight;
                totalR += r;

                String ozmFooter = Utils.format(
                        "Сума НЕТТО по ОЗМ план/факт: %.3f/%.3f тн (%s кг)",
                        wayWeight / 1000.0f, totalOzmFactWeight / 1000.0f, (r > 0 ? "+" : "") + String.valueOf(r)
                );
                printedData.append(Utils.format("3911%s%04d0980P010P010%s%n", font1, printedY, ozmFooter));
                addY(15);
                addLine();
                addY(40);

                totalNettoFact += totalOzmFactWeight;
                totalOzmFactWeight = 0;
            }
        }

        //FOOTER BATCH LIST
        Collections.sort(printedList, (o1, o2) -> {
            OnTheWay w1 = db.onTheWayDao().getById(o1.getOnTheWayId());
            OnTheWay w2 = db.onTheWayDao().getById(o2.getOnTheWayId());
            return w1.getSapBatch().compareTo(w2.getSapBatch());
        });

        //USER
        if (printedY > maxY - 40 * 4) {
            addNewPage();
        }

        printedY = maxY - 40 * 4;

        printedData.append(Utils.format("3911%s%04d0980P010P010%s%n", font1, printedY,
                Utils.format("Всього підйомів %d, пачок %d", totalWeighingCount, printedList.size()
                )));
        addY(40);

        printedData.append(Utils.format("3911%s%04d0980P010P010%s%n", font1, printedY,
                Utils.format("Оператор: %s (%s)", app.getConfig().getUserName(), app.getDateTimeFormat().format(Calendar.getInstance().getTime()))
        ));
        addY(40);

        printedData.append(Utils.format("3911%s%04d0980P010P010%s%n", font1, printedY,
                Utils.format("Разом по ТС НЕТТО план/факт: %.3f/%.3f (%s кг)",
                        totalWayWeight / 1000.0f,
                        totalNettoFact / 1000.0f,
                        (totalR > 0 ? "+" : "") + String.valueOf(totalR)
                )
        ));
        addY(40);

        printedData.append(Utils.format("3911%s%04d0980P010P010%s%n", font1, printedY,
                Utils.format("Сумма БРУТТО факт по ТС: %.3f тн", totalBruttoFact / 1000.0f)
        ));

        printedData.append("Q0001 \n E \n");

        Utils.replaceAll(printedData, "{{PAGE_COUNT}}", String.valueOf(printedPageCount));
        Utils.replaceAll(printedData, "P010P010", "P010P007");
        Utils.replaceAll(printedData, "P011P011", "P010P009");
    }

    private void addNewPage() {
        printedData.append("Q0001 \n E \n");
        printedData.append("\u0002m\n\u0002L\nD11\nPA\nySU8\n");

        printedY = 0;
        addHeader();
    }

    private void addOzm(NameStore nameStore) {
        String nameLine = nameStore.getMatt().substring(0, Math.min(nameStore.getMatt().length(), 45));
        String sizeLine = Utils.format("%.3fx%.3fx%.3f", nameStore.getWidth(), nameStore.getLength(), nameStore.getThickness());

        if (nameLine.length() + sizeLine.length() + 1 <= 45) {
            nameLine += " " + sizeLine;
            sizeLine = "";
        }

        printedData.append(Utils.format("3911%s%04d0980P010P010%s%n", font1, printedY, nameLine));
        addY(40);

        if (sizeLine.length() > 0) {
            printedData.append(Utils.format("3911%s%04d0980P010P010%s%n", font1, printedY, sizeLine));
            addY(40);
        }
    }

    private void addHeader() {

        printedPage++;
        printedPageCount++;

        addY(5);
        addLine();

        printedData.append(Utils.format(
                "3911%s00500980P011P011Транспорт №: %s\n" +
                        "3911%s00900980P011P011ТТН: %s від %s\n" +
                        "3911%s00700250P011P011Лист %d з {{PAGE_COUNT}}\n",
                font1, printedCarrier,
                font1, printedTtnNum, printedTtnDate,
                font2, printedPage
                )
        );

        addY(100);
        addLine();
        addY(40);

        //"БРУТ. ПАРТІЯ БІРКА БРУТ./УПАК./НЕТ.  Ф.НЕТ."
        printedData.append(Utils.format(
                "3911%s%04d0980P010P010%s\n" +
                        "3911%s%04d0915P010P010%s\n" +
                        "3911%s%04d0730P010P010%s\n" +
                        "3911%s%04d0520P010P010%s\n" +
                        "3911%s%04d0140P010P010%s\n",
                font2, printedY, "",
                font2, printedY, "БРУТ.",
                font2, printedY, "ПАРТІЯ",
                font2, printedY, "БІРКА БРУТ./УПАК./НЕТ.",
                font2, printedY, "Ф.НЕТ "
                )
        );

        addY(10);
        addLine();
        addY(45);

    }

    private void addY(int value) {
        printedY += value;

        if (value > 0 && printedY > maxY) {
            addNewPage();
        }
    }

    private void addLine() {
        printedData.append(Utils.format("1X11000%04d0010l10000006%n", printedY));
    }

}
