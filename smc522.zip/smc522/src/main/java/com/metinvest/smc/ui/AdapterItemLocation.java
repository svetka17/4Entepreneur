package com.metinvest.smc.ui;

import android.view.View;
import android.widget.TextView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemLocation extends AbstractFlexibleItem<AdapterItemLocation.AdapterItemInventoryViewHolder> {

    private final IAdapterItemLocationListener listener;
    private final int itemCount;

    public interface IAdapterItemLocationListener {
        void OnViewClick(int position);
    }

    private final String location;

    public AdapterItemLocation(String location, int itemCount, IAdapterItemLocationListener listener) {
        this.location = location;
        this.itemCount = itemCount;
        this.listener = listener;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterItemLocation && ((AdapterItemLocation) o).getLocation().equalsIgnoreCase(getLocation());
    }

    public String getLocation() {
        return location;
    }

    @Override
    public AdapterItemInventoryViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new AdapterItemInventoryViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemInventoryViewHolder holder, int position, List<Object> payloads) {

        String data = Utils.format("<b>Локація: %s</b><br>Кількість позицій: %d", getLocation(), itemCount);

        holder.textTitle.setText(App.getInstance().fromHtml(data));
        holder.buttonView.setOnClickListener(v -> {
            if (listener != null) listener.OnViewClick(position);
        });
    }

    @Override
    public void unbindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemInventoryViewHolder holder, int position) {
        //empty
    }

    @Override
    public void onViewAttached(FlexibleAdapter<IFlexible> adapter, AdapterItemInventoryViewHolder holder, int position) {
        //empty
    }

    @Override
    public void onViewDetached(FlexibleAdapter<IFlexible> adapter, AdapterItemInventoryViewHolder holder, int position) {
        //empty
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_location_row;
    }

    /**
     * The ViewHolder used by this item.
     * Extending from FlexibleViewHolder is recommended especially when you will use
     * more advanced features.
     */
    public class AdapterItemInventoryViewHolder extends FlexibleViewHolder {

        private final View view;
        private final View buttonView;

        public TextView textTitle;

        public AdapterItemInventoryViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.view = view;
            this.textTitle = view.findViewById(R.id.textTitle);
            this.buttonView = view.findViewById(R.id.buttonView);
        }
    }
}
