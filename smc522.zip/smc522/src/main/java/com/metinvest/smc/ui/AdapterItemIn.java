package com.metinvest.smc.ui;

import android.view.View;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemIn extends AbstractFlexibleItem<AdapterItemIn.AdapterItemInViewHolder> {

    private final int index;

    public int getIndex() {
        return index;
    }

    public interface AdapterItemInListener {
        void onCheckChanged(AdapterItemIn item, boolean checked);
    }

    private OnTheWay onTheWay;
    private AdapterItemInListener listener;

    private boolean checked;

    public AdapterItemIn(int index, OnTheWay onTheWay, AdapterItemInListener listener) {
        this.index = index;
        this.onTheWay = onTheWay;
        this.listener = listener;
        this.setEnabled(true);
    }

    public OnTheWay getOnTheWay() {
        return onTheWay;
    }

    public boolean isChecked() {
        return checked;
    }

    private void setChecked(boolean isChecked) {
        checked = isChecked;
        if (listener != null) listener.onCheckChanged(this, checked);
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof AdapterItemIn)
            return getIndex() == ((AdapterItemIn) o).getIndex();
        else
            return false;
    }

    @Override
    public AdapterItemInViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new AdapterItemInViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemInViewHolder holder, int position, List<Object> payloads) {

        int availableNetto = onTheWay.getSapWeightNett() - onTheWay.getWeightAccepted();
        if (availableNetto < 0) availableNetto = 0;

        StringBuilder sb = new StringBuilder();
        sb.append(Utils.format("Склад: %s", onTheWay.getStorage()));
        sb.append(Utils.format("<br>Очікувана вага: %s кг.", onTheWay.getSapWeightNett()));

        if (onTheWay.getWeightAccepted() > 0)
            sb.append(Utils.format("<br>Прийнято: %s кг.", onTheWay.getWeightAccepted()));

        holder.textTitle.setText(Utils.format("%s. Партія: %s", index + 1, onTheWay.getSapBatch()));
        holder.textContent.setText(App.getInstance().fromHtml(sb.toString()));

        String textButton = Utils.format("%d кг", availableNetto);
        holder.buttonToggle.setText(textButton);
        holder.buttonToggle.setTextOn(textButton);
        holder.buttonToggle.setTextOff(textButton);
        holder.buttonToggle.setEnabled(isEnabled());
        holder.view.setEnabled(isEnabled());
        holder.textTitle.setEnabled(isEnabled());
        holder.textContent.setEnabled(isEnabled());
        //holder.buttonToggle.setBackgroundColor(App.getInstance().getColor(R.color.color_toggle_free));
        holder.buttonToggle.setEnabled(availableNetto > 0);
        holder.buttonToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                setChecked(isChecked);
                App.getInstance().log(this, "button #%s", index);
            }
        });

        //App.getInstance().log(this, "bindViewHolder %s", position);
    }

    @Override
    public void unbindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemInViewHolder holder, int position) {
        //App.getInstance().log(this, "unbindViewHolder %s", position);
    }

    @Override
    public void onViewAttached(FlexibleAdapter<IFlexible> adapter, AdapterItemInViewHolder holder, int position) {
        //App.getInstance().log(this, "onViewAttached %s", position);
    }

    @Override
    public void onViewDetached(FlexibleAdapter<IFlexible> adapter, AdapterItemInViewHolder holder, int position) {
        //App.getInstance().log(this, "onViewDetached %s", position);
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_in_row;
    }

    /**
     * The ViewHolder used by this item.
     * Extending from FlexibleViewHolder is recommended especially when you will use
     * more advanced features.
     */
    public class AdapterItemInViewHolder extends FlexibleViewHolder {

        public View view;
        public TextView textTitle, textContent;
        public ToggleButton buttonToggle;

        public AdapterItemInViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.view = view;
            this.textTitle = view.findViewById(R.id.textTitle);
            this.textContent = view.findViewById(R.id.textContent);
            this.buttonToggle = view.findViewById(R.id.buttonToggle);
        }
    }
}
