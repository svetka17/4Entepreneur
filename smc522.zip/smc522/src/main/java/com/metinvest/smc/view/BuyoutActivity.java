package com.metinvest.smc.view;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.tools.Utils;

import java.util.Calendar;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Это экран, который позволяет пользователю выбрать диапазон дат, а затем показывает список выкупов
 * для этого диапазона дат.
 */
public class BuyoutActivity extends MyActivity {

    @BindView(R.id.buttonDateFrom)
    Button buttonDateFrom;
    @BindView(R.id.buttonDateTo)
    Button buttonDateTo;

    private Date dateFrom, dateTo;
    private boolean permis = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buyout);
        ButterKnife.bind(this);

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -14);
        dateFrom = calendar.getTime();

        calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, 14);
        dateTo = calendar.getTime();

        refreshButtons();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_ACTION && resultCode == RESULT_OK && data != null) {

            String intentAction = data.getStringExtra("action");

            if (intentAction != null && intentAction.equalsIgnoreCase("load")) {
                permis = true;
                buttonAcceptClick();
            }

        }
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) buttonDateFromClick();
        else if (number == 3) buttonDateToClick();
        else if (number == 5) buttonAcceptClick();
    }

    private void refreshButtons() {
        buttonDateFrom.setText(app.getDateFormat().format(dateFrom));
        buttonDateTo.setText(app.getDateFormat().format(dateTo));
    }

    private void buttonDateFromClick() {
        Calendar calendar = Utils.toCalendar(dateFrom);

        DatePickerDialog dialog = new DatePickerDialog(this,
                (view1, year, month, dayOfMonth) -> {
                    Calendar calendar1 = Calendar.getInstance();
                    calendar1.set(year, month, dayOfMonth);
                    dateFrom = calendar1.getTime();
                    refreshButtons();
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DATE));
        dialog.show();
    }

    private void buttonDateToClick() {
        Calendar calendar = Utils.toCalendar(dateTo);

        DatePickerDialog dialog = new DatePickerDialog(this,
                (view1, year, month, dayOfMonth) -> {
                    Calendar calendar1 = Calendar.getInstance();
                    calendar1.set(year, month, dayOfMonth);
                    dateTo = calendar1.getTime();
                    refreshButtons();
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DATE));
        dialog.show();
    }

    private void buttonAcceptClick() {
        if (!permis) {
            Intent intent = new Intent(this, PincodeActivity.class);
            intent.putExtra("action", "load");
            startActivityForResult(intent, REQUEST_ACTION);
            return;
        }

        Intent intent = new Intent(this, BuyoutListActivity.class);
        intent.putExtra("dateFrom", dateFrom);
        intent.putExtra("dateTo", dateTo);
        startActivity(intent);
    }
}
