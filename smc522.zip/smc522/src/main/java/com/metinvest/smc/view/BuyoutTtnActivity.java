package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.inc.TTN;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractExpandableItem;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.ExpandableViewHolder;
import eu.davidea.viewholders.FlexibleViewHolder;

public class BuyoutTtnActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

	@BindView(R.id.textContentTitle)
	TextView textContentTitle;
	@BindView(R.id.viewButtons)
	View viewButtons;
	@BindView(R.id.viewContentData)
	View viewContentData;
	@BindView(R.id.textNotFound)
	TextView textNotFound;
	@BindView(R.id.scrollView)
	NestedScrollView scrollView;
	@BindView(R.id.listView)
	RecyclerView listView;
	@BindView(R.id.buttonSendSap)
	Button buttonSendSap;
	@BindView(R.id.buttonAccept)
	Button buttonAccept;
	@BindView(R.id.viewButtonSendSap)
	View viewButtonSendSap;
	@BindView(R.id.viewButtonAccept)
	View viewButtonAccept;

	private Date date;
	private String transportName;
	private FlexibleAdapter<IFlexible> adapter;
	private TTN ttn;
	private String locationCode;
	private List<String> labelList;
	private String status = "-1";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_buyout_ttn);
		ButterKnife.bind(this);

		date = (Date) getIntent().getSerializableExtra("date");
		transportName = getIntent().getStringExtra("transportName");
		ttn = (TTN) getIntent().getSerializableExtra("ttn");

		textContentTitle.setText(getString(R.string.title_activity_buyout_ttn, ttn.getNum()));

		listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		beginLoad();
	}

	private void beginLoad() {
		if (isLoading()) return;

		showLoading(R.string.text_please_wait);
		viewButtons.setVisibility(View.GONE);
		buttonAccept.setEnabled(false);

		status = "-1";
		refreshButtons();

		Utils.runOnBackground(() -> {

			String loc = null;
			boolean locCorrect = true;
			labelList = new ArrayList<>();

			String url = config.getUrlApi() + "getinboundozmreportsoh";
			url = net.addUrlParam(url, "TTN_DATE", app.getDateFormat().format(date));
			url = net.addUrlParam(url, "TTN_CARRIER_ID", transportName);
			url = net.addUrlParam(url, "TTN_NUM", ttn.getNum());

			JsonResult result = net.downloadJson(url);

			if (result.isOk()) {

				List<IFlexible> list = new ArrayList<>();

				JSONArray array = Utils.getJsonArray(result.getJson(), "data");
				if (array != null) {
					int groupCount = array.length();
					for (int i = 0; i < groupCount; i++) {
						JSONObject jsonGroup = Utils.getJsonObject(array, i);

						if (jsonGroup != null) {

							if (Objects.equals(status, "-1")) {
								String itemStatus = Utils.getJsonStringIgnoreCase(jsonGroup, "status_out");
								status = itemStatus.isEmpty() ? null : itemStatus;
							}
							String name = Utils.getJsonStringIgnoreCase(jsonGroup, "saP_MATT_DESCR");
							String ozm = Utils.getJsonStringIgnoreCase(jsonGroup, "saP_OZM");
							float width = Utils.getJsonFloatIgnoreCase(jsonGroup, "width");
							float length = Utils.getJsonFloatIgnoreCase(jsonGroup, "length");
							float thickness = Utils.getJsonFloatIgnoreCase(jsonGroup, "thickness");
							int plan = Utils.getJsonWeightKgIgnoreCase(jsonGroup, "plaN_Nett");
							int fact = Utils.getJsonWeightKgIgnoreCase(jsonGroup, "facT_Nett");
							JSONArray arrayLabels = Utils.getJsonArray(jsonGroup, "labelsList");
							JSONArray arrayLocations = Utils.getJsonArray(jsonGroup, "locations");

							List<Location> locationList = new ArrayList<>();

							if (arrayLocations != null) {
								int locationCount = arrayLocations.length();
								for (int j = 0; j < locationCount; j++) {
									JSONObject jsonLocation = Utils.getJsonObject(arrayLocations, j);
									if (jsonLocation != null) {
										String code = Utils.getJsonStringIgnoreCase(jsonLocation, "location_code");
										boolean check = Utils.getJsonStringIgnoreCase(jsonLocation, "check").equalsIgnoreCase("true");
										locationList.add(new Location(code, check));
									}
								}
							}

							if (locationList.size() != 1) locCorrect = false;
							if (locCorrect && (loc == null || locationList.get(0).code.equalsIgnoreCase(loc))) {
								loc = locationList.get(0).code;
							}

							AdapterGroup group = new AdapterGroup(
									name, ozm,
									width, length, thickness,
									plan, fact, locationList
							);

							if (arrayLabels != null) {
								int labelCount = arrayLabels.length();
								for (int j = 0; j < labelCount; j++) {
									JSONObject jsonLabel = Utils.getJsonObject(arrayLabels, j);
									if (jsonLabel != null) {
										String labelId = Utils.getJsonStringIgnoreCase(jsonLabel, "labelId");
										String batch = Utils.getJsonStringIgnoreCase(jsonLabel, "batch");
										int labelNetto = Utils.getJsonWeightKgIgnoreCase(jsonLabel, "mengE_FACT");
										if (labelNetto > 0) {
											labelList.add(labelId);
											Adapter label = new Adapter(labelId, batch, labelNetto);
											group.addSubItem(label);
										}
									}
								}
							}

							list.add(group);
						}
					}

					locationCode = loc;
				}

				adapter = new FlexibleAdapter<>(list);
				adapter.addListener(this);

			}

			runOnUiThread(() -> endLoad(result));
		});
	}

	private void endLoad(JsonResult result) {

		hideLoading();
		viewButtons.setVisibility(result.isOk() ? View.VISIBLE : View.GONE);
		viewContentData.setVisibility(result.isOk() ? View.VISIBLE : View.GONE);
		refreshButtons();

		if (result.isOk()) {
			buttonAccept.setEnabled(adapter.getItemCount() > 0);
			textNotFound.setVisibility(adapter.getItemCount() == 0 ? View.VISIBLE : View.GONE);
			listView.setAdapter(adapter);
			scrollView.post(() -> scrollView.scrollTo(0, 0));
		} else {
			textNotFound.setVisibility(View.VISIBLE);
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
		}
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 4) {
			buttonSendClick();
		} else if (number == 5) {
			buttonAcceptClick();
		}
	}

	private void buttonSendClick() {
		if (isLoading() || !buttonSendSap.isEnabled()) return;
		showDialogConfirm(R.string.text_warning, R.string.send_sap_confirm, (dialog, which) -> beginSend());
	}

	private void buttonAcceptClick() {
		if (isLoading() || !buttonAccept.isEnabled()) return;

		showDialogConfirm(R.string.text_warning, R.string.buyout_confirm, (dialog, which) -> selectLocation());
	}

	private void selectLocation() {
		Intent intent = new Intent(this, LocationSelectActivity.class);
		intent.putExtra("locationCode", locationCode);
		startActivityForResult(intent, REQUEST_LOCATION_SELECT);
	}

	@Override
	public void onBackPressed() {
		setResult(RESULT_OK);
		super.onBackPressed();
	}

	@Override
	public boolean onItemClick(View view, int position) {
		return false;
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == REQUEST_LOCATION_SELECT && resultCode == RESULT_OK && data != null) {
			String locationCode = data.getStringExtra("locationCode");
			if (locationCode != null) {
				beginTransfer(locationCode);
			}
		}
	}

	private void beginTransfer(String locationCode) {

		if (isLoading()) return;

		showLoading(R.string.text_please_wait);
		buttonAccept.setEnabled(false);

		Utils.runOnBackground(() -> {

			StringBuilder sb = new StringBuilder();
			sb.append("[");

			for (int i = 0; i < labelList.size(); i++) {
				String labelId = labelList.get(i);
				sb.append(Utils.format(
						"{\"Label_Id\":%s,\n" +
								"\t \"Location_Code\":\"%s\",\n" +
								"\t \"Date_FV\":\"%s\"\t}",
						labelId, locationCode, app.getDateTimeFormat().format(Calendar.getInstance().getTime())
				));
				if (i < labelList.size() - 1) sb.append(",");
			}
			sb.append("]");
			//todo (smcId == null ? "" : Utils.format("\t \"SMC_DEST\":\"%s\",\n", smcId)),
			String url = config.getUrlApi() + "sapchangelocation";
			JsonResult result = net.uploadJson(url, sb.toString());

			runOnUiThread(() -> endTransfer(locationCode, result));

		});
	}

	private void endTransfer(String locationCode, JsonResult result) {
		hideLoading();
		buttonAccept.setEnabled(true);
		if (result.isOk()) {
			/*showToast(getString(R.string.label_transfer_complete, locationCode));
			setResult(RESULT_OK);
			finish();*/
			beginAccept();
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.label_transfer_error, result.getStatus().name()), (dialog, which) -> beginTransfer(locationCode));
		}
	}

	private void beginAccept() {
		showLoading(R.string.text_please_wait);
		buttonAccept.setEnabled(false);

		Utils.runOnBackground(() -> {
			String url = config.getUrlApi() + "inboundsoh";

			url = net.addUrlParam(url, "TTN_NUM", ttn.getNum());
			url = net.addUrlParam(url, "TTN_CARRIER_ID", transportName);
			url = net.addUrlParam(url, "TTN_DATE", app.getDateFormat().format(date));

			JsonResult result = net.uploadJson(url, "");
			runOnUiThread(() -> endAccept(result));
		});
	}

	private void endAccept(JsonResult result) {
		hideLoading();
		buttonAccept.setEnabled(true);

		if (result.isOk()) {
			showToast(R.string.buyout_send_sucessfull);
			setResult(RESULT_OK);
			finish();
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginAccept());
		}
	}

	private void beginSend() {
		showLoading(R.string.text_please_wait);
		buttonSendSap.setEnabled(false);

		Utils.runOnBackground(() -> {
			String url = config.getUrlApi() + "setinboundstatus";
			url = net.addUrlParam(url, "TTN_DATE", app.getDateFormat().format(date));
			url = net.addUrlParam(url, "TTN_CARRIER_ID", transportName);
			url = net.addUrlParam(url, "TTN_NUM", ttn.getNum());
			url = net.addUrlParam(url, "STATUS", 1);

			JsonResult result = net.downloadJson(url);

			runOnUiThread(() -> endSend(result));
		});
	}

	private void endSend(JsonResult result) {
		hideLoading();
		buttonSendSap.setEnabled(true);

		if (result.isOk()) {
			showToast("Відправлено в SAP!");
			setResult(RESULT_OK);
			finish();
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginSend());
		}
	}

	private void onPrintClick(Adapter item) {
		log("Print %s", item.getLabelId());
		beginPrint(item.getLabelId());
	}

	private void beginPrint(String labelId) {

		showLoading(R.string.text_printing_title);

		Utils.runOnBackground(() -> {
			Utils.NetworkPrintResult result = Utils.printLabel(labelId, "NULL");
			runOnUiThread(() -> endPrint(result, labelId));
		});
	}

	private void endPrint(Utils.NetworkPrintResult result, String labelId) {

		hideLoading();

		if (result.getNetworkResult().isOk()) {

			if (result.getPrintResult().getStatus() == Printer.PrintResultStatus.OK) {
				//showDialog(R.drawable.ic_info_24dp, R.string.text_information, R.string.text_print_result_succeeded, null).setCanceledOnTouchOutside(false);
				showToast(R.string.text_print_result_succeeded);
				//app.sendFaPrint();
			} else {
				final int message = app.getPrintResultMessage(result.getPrintResult());
				showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> beginPrint(labelId));
			}

		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result.getNetworkResult()), (dialog, which) -> beginPrint(labelId));
		}

	}

	private void refreshButtons() {
		boolean canAccept = status == null;
		boolean canSend = status != null && !status.equals("-1") && status.equals("97");
		buttonAccept.setEnabled(canAccept);
		buttonSendSap.setEnabled(canSend);
		viewButtonAccept.setVisibility(canAccept ? View.VISIBLE : View.GONE);
		viewButtonSendSap.setVisibility(canSend ? View.VISIBLE : View.GONE);
	}

	private static class Location {
		private String code;
		private boolean check;

		public Location(String code, boolean check) {
			this.code = code;
			this.check = check;
		}

		public String getCode() {
			return code;
		}

		public boolean isCheck() {
			return check;
		}
	}

	public class Adapter extends AbstractFlexibleItem<Adapter.ViewHolder> {

		private final String labelId;
		private final String batch;
		private final int netto;
		private final String content;

		Adapter(String labelId, String batch, int netto) {
			this.labelId = labelId;
			this.batch = batch;
			this.netto = netto;

			StringBuilder sb = new StringBuilder();
			sb.append(Utils.format("<b>LabelID: %s</b><br>", labelId));
			sb.append(Utils.format("Партія: %s<br>", this.batch));
			sb.append(Utils.format("Вага НЕТТО, тн: %.3f", this.netto / 1000.0f));
			this.content = sb.toString();
		}

		public String getLabelId() {
			return labelId;
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof Adapter && ((Adapter) o).getLabelId().equalsIgnoreCase(getLabelId());
		}

		@Override
		public int hashCode() {
			return getLabelId().hashCode();
		}

		@Override
		public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
			return new ViewHolder(view, adapter);
		}

		@Override
		public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {
			holder.textContent.setText(App.getInstance().fromHtml(content));
			View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
			holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
			refreshBackground(holder, holder.itemView.isFocused());

			holder.buttonEdit.setVisibility(View.GONE);
			holder.buttonDelete.setVisibility(View.GONE);

			holder.buttonPrint.setOnClickListener(v -> onPrintClick(Adapter.this));
		}

		private void refreshBackground(ViewHolder holder, boolean hasFocus) {
			holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_adapter_light));
		}

		@Override
		public int getLayoutRes() {
			return R.layout.adapter_inc_report;
		}

		class ViewHolder extends FlexibleViewHolder {

			@BindView(R.id.textContent)
			TextView textContent;
			@BindView(R.id.buttonPrint)
			ImageButton buttonPrint;
			@BindView(R.id.buttonEdit)
			ImageButton buttonEdit;
			@BindView(R.id.buttonDelete)
			ImageButton buttonDelete;

			ViewHolder(View view, FlexibleAdapter adapter) {
				super(view, adapter);
				ButterKnife.bind(this, view);
			}
		}
	}

	public class AdapterGroup extends AbstractExpandableItem<AdapterGroup.ViewHolder, Adapter> {

		private final String name;
		private final String ozm;
		private final float width;
		private final float length;
		private final float thickness;
		private final int plan;
		private final int fact;
		private final List<Location> locationList;
		private final String content;
		private final String contentLocations;

		public AdapterGroup(String name, String ozm, float width, float length, float thickness, int plan, int fact, List<Location> locationList) {
			this.name = name;
			this.ozm = ozm;
			this.width = width;
			this.length = length;
			this.thickness = thickness;
			this.plan = plan;
			this.fact = fact;
			this.locationList = locationList;

			StringBuilder sb = new StringBuilder();
			sb.append(Utils.format("<b>%s</b><br>", Html.escapeHtml(name)));
			//sb.append(Utils.format("<b>%s</b><br>", name));
			if (app.sizeToString(width, length, thickness).trim().length() > 0)
				sb.append(Utils.format("%s<br>", app.sizeToString(width, length, thickness)));
			sb.append(Utils.format("ОЗМ: %s<br>", ozm));
			sb.append(Utils.format("План, тн: %.3f<br>", plan / 1000.0f));
			sb.append(Utils.format("Факт, тн: %s %s", Utils.factToString(fact), Utils.getTotalWeightPercentString(plan, fact)));
			this.content = sb.toString();

			sb = new StringBuilder();
			if (locationList.isEmpty()) {
				sb.append("—");
			} else {
				for (int i = 0; i < locationList.size(); i++) {
					Location location = locationList.get(i);
					sb.append(Utils.format("%s %s",
							Html.escapeHtml(location.code),
							location.check ? "<font color=\"#007000\">✓</font>" : "<font color=\"red\">✗</font>"
					));
					if (i + 1 < locationList.size()) sb.append("<br>");
				}
			}
			this.contentLocations = sb.toString();
		}

		public String getName() {
			return name;
		}

		public String getOzm() {
			return ozm;
		}

		public float getWidth() {
			return width;
		}

		public float getLength() {
			return length;
		}

		public float getThickness() {
			return thickness;
		}

		public int getPlan() {
			return plan;
		}

		public int getFact() {
			return fact;
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof AdapterGroup && (((AdapterGroup) o).getName().equals(getName()));
		}

		@Override
		public int hashCode() {
			return getName().hashCode();
		}

		@Override
		public int getLayoutRes() {
			return R.layout.adapter_buyout_group;
		}

		@Override
		public ViewHolder createViewHolder(View view, FlexibleAdapter adapter) {
			return new ViewHolder(view, adapter);
		}

		@Override
		public void bindViewHolder(FlexibleAdapter adapter, ViewHolder holder, int position, List payloads) {
			holder.textTitle.setText(app.fromHtml(content));
			holder.textLocations.setText(app.fromHtml(contentLocations));
			View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
			holder.itemView.setOnFocusChangeListener(onFocusChangeListener);

			refreshBackground(holder, holder.itemView.isFocused());
			View.OnClickListener headerListener = v -> {
				holder.toggleExpansion();
				refreshExpand(holder);
			};

			holder.itemView.setOnClickListener(headerListener);
			holder.imageExpand.setVisibility(hasSubItems() ? View.VISIBLE : View.INVISIBLE);
			holder.imageExpand.setOnClickListener(headerListener);
			holder.textTitle.setOnClickListener(headerListener);

			refreshExpand(holder);
		}

		private void refreshExpand(ViewHolder holder) {
			holder.imageExpand.setImageDrawable(ContextCompat.getDrawable(holder.itemView.getContext(),
					isExpanded() ? R.drawable.ic_keyboard_arrow_down_black_24dp : R.drawable.ic_keyboard_arrow_right_black_24dp));
		}

		private float getTotalWeightPercent() {
			return plan == 0 ? 0 : fact * 100.0f / plan;
		}

		private void refreshBackground(ViewHolder holder, boolean hasFocus) {
			holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_adapter_light));
		}

		class ViewHolder extends ExpandableViewHolder {

			@BindView(R.id.textTitle)
			TextView textTitle;
			@BindView(R.id.imageExpand)
			ImageView imageExpand;
			@BindView(R.id.textLocations)
			TextView textLocations;

			ViewHolder(View view, FlexibleAdapter adapter) {
				super(view, adapter);
				ButterKnife.bind(this, view);
			}

			@Override
			public void toggleExpansion() {
				super.toggleExpansion();
			}
		}
	}

}
