package com.metinvest.smc.view;

import android.os.Bundle;
import android.widget.TextView;

import com.metinvest.smc.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ContentActivity extends MyActivity {

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.textContent)
    TextView textContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);
        ButterKnife.bind(this);

        String title = getIntent().getStringExtra("title");
        String content = getIntent().getStringExtra("content");
        setTitle(title);
        showContent(title, content);
    }

    private void showContent(String title, String content) {
        textContentTitle.setText(title);
        textContent.setText(app.fromHtml(content));
    }
}
