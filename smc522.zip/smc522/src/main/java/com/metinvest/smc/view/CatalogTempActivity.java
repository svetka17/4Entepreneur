package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.App;
import com.metinvest.smc.BuildConfig;
import com.metinvest.smc.R;
import com.metinvest.smc.inc.TTN;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.IAdapterInfoListener;
import com.metinvest.smc.ui.ITransportListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractExpandableItem;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.ExpandableViewHolder;
import eu.davidea.viewholders.FlexibleViewHolder;

public class CatalogTempActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener, IAdapterInfoListener, ITransportListener {

	@BindView(R.id.textContentTitle)
	TextView textContentTitle;
	@BindView(R.id.listView)
	RecyclerView listView;
	@BindView(R.id.viewContentData)
	View viewContentData;
	@BindView(R.id.textNotFound)
	TextView textNotFound;
	@BindView(R.id.viewButtons)
	View viewButtons;
	@BindView(R.id.textFilter)
	EditText textFilter;
	@BindView(R.id.buttonFilterClear)
	ImageButton buttonFilterClear;

	private FlexibleAdapter<IFlexible> adapter;
	private List<IFlexible> listItems;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_catalog_temp);
		ButterKnife.bind(this);

		listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

		textFilter.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				applyFilter();
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		});
	}

	@Override
	protected String getHelpContent() {
		return getString(R.string.catalog_temp_help);
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		beginLoad();
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 2) buttonRefreshClick();
		else if (number == 3) buttonFilterClearClick();
	}

	private void buttonRefreshClick() {
		if (isLoading()) return;
		beginLoad();
	}

	@Override
	public boolean onItemClick(View view, int position) {
		IFlexible item = adapter.getItem(position);
		if (item == null) return false;
		//openTtn(item);
		return true;
	}

	private void beginLoad() {

		if (isLoading()) return;

		showLoading(R.string.text_please_wait);
		viewButtons.setVisibility(View.GONE);
		setAdapter(null);

		Utils.runOnBackground(() -> {
			String url = config.getUrlApi() + "templabelreport";
			JsonResult result = net.downloadJson(url);

			listItems = new ArrayList<>();
			JSONArray carArray = Utils.getJsonArray(result.getJson(), "data");

			if (result.isOk() && carArray != null) {

				List<AdapterGroup> groups = new ArrayList<>();

				for (int i = 0; i < carArray.length(); i++) {
					JSONObject jCar = Utils.getJsonObject(carArray, i);
					String carName = Utils.getJsonString(jCar, "car");
					String carNum = Utils.getJsonString(jCar, "num");
					String carDate = Utils.getJsonString(jCar, "date");

					String ttnCarrierId = Utils.getJsonString(jCar, "ttn_carrier_id");
					Date ttnDate = app.parseDfDate(Utils.getJsonString(jCar, "ttn_date"));
					String ttnNum = Utils.getJsonString(jCar, "ttn_num");

					if (BuildConfig.DEBUG) {
						//planExist = true;
					}

					AdapterGroup adapterGroup = null;

					for (AdapterGroup group : groups) {
						if (Objects.equals(group.carName, carName)
								&& Objects.equals(group.carNum, carNum)
								&& Objects.equals(group.carDate, carDate)) {
							adapterGroup = group;
							break;
						}
					}

					if (adapterGroup == null) {
						adapterGroup = new AdapterGroup(carName, carNum, carDate, ttnCarrierId, ttnNum, ttnDate, this);
						groups.add(adapterGroup);
					}

					JSONArray jLabels = Utils.getJsonArray(jCar, "lids");

					for (int j = 0; jLabels != null && j < jLabels.length(); j++) {
						JSONObject jsonObject = Utils.getJsonObject(jLabels, j);
						if (jsonObject == null) continue;
						String labelId = Utils.getJsonString(jsonObject, "id");
						String loc = Utils.getJsonString(jsonObject, "loc");
						int netto = Utils.getJsonInt(jsonObject, "netto");
						String name = Utils.getJsonString(jsonObject, "name");
						adapterGroup.addSubItem(new AdapterLabel(labelId, loc, netto, name, this));
					}

				}

				listItems.addAll(groups);
			}

			runOnUiThread(() -> endLoad(result, listItems));
		});
	}

	private void endLoad(JsonResult result, List<IFlexible> listItems) {
		hideLoading();
		viewButtons.setVisibility(View.VISIBLE);

		setAdapter(listItems);
		viewContentData.setVisibility(result.isOk() && !listItems.isEmpty() ? View.VISIBLE : View.GONE);
		textNotFound.setVisibility(!result.isOk() || listItems.isEmpty() ? View.VISIBLE : View.GONE);

		if (result.isOk() && !listItems.isEmpty()) {
			buttonFilterClick();
		}

		if (!result.isOk()) {
			if (result.getStatus() == LoadResultStatus.TIMEOUT) {
				showDialog(R.drawable.ic_error_24dp, R.string.text_error, R.string.inc_timeout_transport_list, (dialog, which) -> onBackPressed());
			} else {
				showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
			}
		}

	}

	private void buttonFilterClick() {
		listView.post(() -> listView.requestFocus());
		applyFilter();
	}

	private void applyFilter() {
		String filterText = textFilter.getText().toString().toLowerCase();
		if (adapter == null) return;

		List<IFlexible> list = new ArrayList<>();

		for (IFlexible item : listItems) {
			if (item instanceof AdapterGroup) {
				if (filterText.length() == 0
						|| ((AdapterGroup)item).getCarName().toLowerCase().contains(filterText)
						|| ((AdapterGroup)item).getCarNum().toLowerCase().contains(filterText)
				) {
					list.add(item);
				}
			}
		}

		setAdapter(list);
		textNotFound.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
	}

	private void buttonFilterClearClick() {
		hideKeyboard();
		textFilter.setText(null);
		buttonFilterClick();
	}

	private void setAdapter(List<IFlexible> list) {
		if (list == null) {
			adapter = null;
		} else {
			adapter = new FlexibleAdapter<>(list);
			adapter.addListener(this);
		}
		listView.setAdapter(adapter);
	}

	@Override
	public void onInfoClicked(AdapterLabel item) {
		log("LabelId: %s", item.getLabelId());
		showInfoByLabelId(item.getLabelId());
	}

	@Override
	public void onTransportClicked(String ttnCarrierId, Date ttnDate, String ttnNum) {
		log("onTransportClicked(\"%s\", \"%s\"", ttnCarrierId, ttnDate);

		Intent intent = new Intent(this, IncDocActivity.class);
		intent.putExtra("dateFrom", ttnDate);
		intent.putExtra("dateTo", ttnDate);
		intent.putExtra("date", ttnDate);
		intent.putExtra("transportName", ttnCarrierId);
		intent.putExtra("ttn", new TTN(ttnNum, null));
		//intent.putExtra("ttn", item.getDoc().getTtn());
		//intent.putExtra("isNew", getIntent().getBooleanExtra("isNew", false));
		//intent.putExtra("isManager", isManager);
		//intent.putExtra("sohSmcId", sohSmcId);
		startActivityForResult(intent, REQUEST_DEFAULT);
	}

	public static class AdapterGroup extends AbstractExpandableItem<AdapterGroup.ViewHolder, AdapterLabel> {

		private final String carName, carNum, carDate;
		private final String ttnCarrierId, ttnNum;
		private final Date ttnDate;
		private final ITransportListener listener;

		public AdapterGroup(String carName, String carNum, String carDate, String ttnCarrierId, String ttnNum, Date ttnDate, ITransportListener listener) {
			this.carName = carName;
			this.carNum = carNum;
			this.carDate = carDate;
			this.ttnCarrierId = ttnCarrierId;
			this.ttnNum = ttnNum;
			this.ttnDate = ttnDate;
			this.listener = listener;
		}

		public String getTtnNum() {
			return ttnNum;
		}

		public String getCarName() {
			return carName;
		}

		public String getCarNum() {
			return carNum;
		}

		public String getCarDate() {
			return carDate;
		}

		public String getTtnCarrierId() {
			return ttnCarrierId;
		}

		public Date getTtnDate() {
			return ttnDate;
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof AdapterGroup &&
					Objects.equals(((AdapterGroup) o).getCarName(), getCarName())
					&& Objects.equals(((AdapterGroup) o).getCarNum(), getCarNum())
					&& Objects.equals(((AdapterGroup) o).getCarDate(), getCarDate());
		}

		public boolean isPlanExist() {
			return ttnCarrierId != null && ttnDate != null && ttnCarrierId.length() > 0;
		}

		@Override
		public int hashCode() {
			return Objects.hash(carName, carNum, carDate);
		}

		@Override
		public int getLayoutRes() {
			return R.layout.adapter_catalog_transport;
		}

		@Override
		public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
			return new ViewHolder(view, adapter);
		}

		@Override
		public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {

			holder.textName.setText(Utils.format("%s", Utils.isNullOrEmpty(carName) ? "-" : carName.replace("  ", " ")));
			holder.textTtn.setText(Utils.format("ТТН: %s", Utils.isNullOrEmpty(carNum) ? "-" : carNum));

			StringBuilder sb = new StringBuilder();
			if (!Utils.isNullOrEmpty(carDate)) {
				if (sb.length() > 0)
				{
					sb.append("<br>");
				}
				sb.append(Utils.format("Розвантажено: %s", carDate));
			}
			if (isPlanExist()) {
				if (sb.length() > 0)
				{
					sb.append("<br>");
				}
				sb.append("<font color=\"#005000\">✓</font> План отримано");
			}
			sb.append(Utils.format("<br>Кі-сть бірок: %d", getSubItemsCount()));

			holder.textContent.setText(App.getInstance().fromHtml(sb.toString()));

			View.OnClickListener headerListener = v -> {
				holder.toggleExpansion();
				refreshExpand(holder);
			};

			holder.imageExpand.setVisibility(hasSubItems() ? View.VISIBLE : View.INVISIBLE);
			holder.imageExpand.setOnClickListener(headerListener);
			holder.textContent.setOnClickListener(headerListener);

			if (isPlanExist()) {
				holder.imageTrain.setVisibility(View.VISIBLE);
				holder.buttonInfo.setOnClickListener(v -> listener.onTransportClicked(ttnCarrierId, ttnDate, ttnNum));
				holder.buttonInfo.setVisibility(View.VISIBLE);
			} else {
				holder.imageTrain.setVisibility(View.INVISIBLE);
				holder.buttonInfo.setVisibility(View.INVISIBLE);
			}
			refreshExpand(holder);
		}

		private void refreshExpand(AdapterGroup.ViewHolder holder) {
			holder.imageExpand.setImageDrawable(ContextCompat.getDrawable(holder.itemView.getContext(),
					isExpanded() ? R.drawable.ic_keyboard_arrow_down_black_24dp : R.drawable.ic_keyboard_arrow_right_black_24dp));
		}

		static class ViewHolder extends ExpandableViewHolder {

			@BindView(R.id.textName)
			TextView textName;
			@BindView(R.id.textTtn)
			TextView textTtn;
			@BindView(R.id.textContent)
			TextView textContent;
			@BindView(R.id.imageExpand)
			ImageView imageExpand;
			@BindView(R.id.buttonInfo)
			ImageButton buttonInfo;
			@BindView(R.id.imageTrain)
			ImageView imageTrain;

			ViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
				super(view, adapter);
				ButterKnife.bind(this, view);
			}

			@Override
			public void toggleExpansion() {
				super.toggleExpansion();
			}
		}
	}

	public static class AdapterLabel extends AbstractFlexibleItem<AdapterLabel.ViewHolder> {
		private final String labelId, locationCode, name;
		private final int netto;
		private final IAdapterInfoListener listener;

		public AdapterLabel(String labelId, String locationCode, int netto, String name, IAdapterInfoListener listener) {
			this.labelId = labelId;
			this.listener = listener;
			this.locationCode = locationCode;
			this.netto = netto;
			this.name = name;
		}

		public String getLabelId() {
			return labelId;
		}

		public String getLocationCode() {
			return locationCode;
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof AdapterLabel &&
					Objects.equals(((AdapterLabel) o).getLabelId(), getLabelId());
		}

		@Override
		public int hashCode() {
			return Objects.hash(labelId);
		}

		@Override
		public int getLayoutRes() {
			return R.layout.adapter_catalog_label;
		}

		@Override
		public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
			return new ViewHolder(view, adapter);
		}

		@Override
		public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {
			holder.textId.setText(Utils.format("LabelId: %s", getLabelId()));
			holder.textLocation.setText(getLocationCode());
			holder.textNetto.setText(Utils.format("%.3f", netto / 1000.0f));
			holder.textOzm.setText(name != null && name.length() > 15 ? name.substring(0, 15) + "..." : name);
			holder.buttonInfo.setOnClickListener(v -> {
				listener.onInfoClicked(this);
			});
		}

		static class ViewHolder extends FlexibleViewHolder {

			@BindView(R.id.textId)
			TextView textId;
			@BindView(R.id.textLocation)
			TextView textLocation;
			@BindView(R.id.textOzm)
			TextView textOzm;
			@BindView(R.id.textNetto)
			TextView textNetto;
			@BindView(R.id.buttonInfo)
			ImageButton buttonInfo;

			ViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
				super(view, adapter);
				ButterKnife.bind(this, view);
			}
		}
	}
}
