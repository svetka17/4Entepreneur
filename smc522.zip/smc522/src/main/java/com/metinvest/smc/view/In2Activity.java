package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Carrier;
import com.metinvest.smc.db.NameStore;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemIn;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class In2Activity extends MyActivity implements AdapterItemIn.AdapterItemInListener {

    private static final int DEFAULT_REQUEST = 1;

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;
    @BindView(R.id.buttonManual)
    Button buttonManual;

    private Carrier carrier;
    private NameStore name;
    private FlexibleAdapter<AdapterItemIn> adapter;
    private int weightCrane, packCount;
    private boolean hasWeightList;
    private ArrayList<Integer> weightList1, weightList2, weightList3;
    private String locationCode;
    private boolean isTheor;
    private int totalPackAndTheor = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in2);
        ButterKnife.bind(this);

        long carrierId = getIntent().getLongExtra("carrierId", 0);
        long nameId = getIntent().getLongExtra("nameId", 0);
        isTheor = getIntent().getBooleanExtra("isTheor", false);
        weightCrane = getIntent().getIntExtra("weightCrane", 0);
        packCount = getIntent().getIntExtra("packCount", 0);
        locationCode = getIntent().getStringExtra("locationCode");

        hasWeightList = getIntent().getBooleanExtra("hasWeightList", false);
        if (hasWeightList) {
            weightList1 = (ArrayList<Integer>) getIntent().getSerializableExtra("weightList1");
            weightList2 = (ArrayList<Integer>) getIntent().getSerializableExtra("weightList2");
            weightList3 = (ArrayList<Integer>) getIntent().getSerializableExtra("weightList3");
        }

        for (int i = 0; i < packCount; i++) {
            totalPackAndTheor += weightList2.get(i) + weightList3.get(i);
        }

        carrier = db.carrierDao().getById(carrierId);
        name = db.nameStoreDao().getById(nameId);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
        listView.setLayoutManager(layoutManager);
        listView.addItemDecoration(dividerItemDecoration);

        refreshTitle();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 4) {
            buttonManualClick();
        } else if (number == 5) {
            buttonAcceptClick();
        }
    }

    private void buttonManualClick() {
        if (isLoading() || !buttonManual.isEnabled()) return;

        Intent intent = new Intent(this, In4Activity.class);
        intent.putExtra("carrierId", carrier.getId());
        intent.putExtra("nameId", name.getId());
        intent.putExtra("weightCrane", weightCrane);
        intent.putExtra("packCount", packCount);
        intent.putExtra("locationCode", locationCode);
        ArrayList<Long> list = new ArrayList<>();
        for (int i = 0; i < packCount; i++) list.add((long) 0);
        intent.putExtra("wayList", list);
        intent.putExtra("tempWayId", adapter.getCurrentItems().get(0).getOnTheWay().getId());

        if (hasWeightList) {
            intent.putExtra("weightList1", weightList1);
            intent.putExtra("weightList2", weightList2);
            intent.putExtra("weightList3", weightList3);
        }

        startActivityForResult(intent, DEFAULT_REQUEST);
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        Intent intent = new Intent(this, hasWeightList ? In4Activity.class : In3Activity.class);
        intent.putExtra("carrierId", carrier.getId());
        intent.putExtra("nameId", name.getId());
        intent.putExtra("weightCrane", weightCrane);
        intent.putExtra("packCount", packCount);
        intent.putExtra("locationCode", locationCode);
        intent.putExtra("isTheor", isTheor);

        if (hasWeightList) {
            intent.putExtra("weightList1", weightList1);
            intent.putExtra("weightList2", weightList2);
            intent.putExtra("weightList3", weightList3);
        }

        ArrayList<Long> list = new ArrayList<>();

        List<AdapterItemIn> checkedList = getCheckedItems();
        for (int i = 0; i < packCount; i++)
            list.add(checkedList.get(checkedList.size() == 1 ? 0 : i).getOnTheWay().getId());

        intent.putExtra("wayList", list);
        intent.putExtra("bigOne", packCount > 1 && checkedList.size() == 1);

        startActivityForResult(intent, DEFAULT_REQUEST);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoadList();
        refreshTitle();
    }

    private int getTotalSelectedWeight() {
        int weight = 0;
        for (int i = 0; i < (adapter == null ? 0 : adapter.getItemCount()); i++) {

            AdapterItemIn item = adapter.getItem(i);

            if (item != null && item.isChecked()) {
                OnTheWay onTheWay = item.getOnTheWay();
                if (onTheWay != null) {
                    weight += onTheWay.getSapWeightNett() - onTheWay.getWeightAccepted();
                }
            }
        }
        return weight;
    }

    private void refreshTitle() {

        textContentTitle.setText(Utils.format("Рознесено: %d з %d кг.", getTotalSelectedWeight(), weightCrane - (isTheor ? 0 : totalPackAndTheor)));
    }

    private void beginLoadList() {
        showLoading(R.string.text_please_wait);

        buttonAccept.setEnabled(false);

        Utils.runOnBackground(() -> {
            List<OnTheWay> list = db.onTheWayDao().getByCarrierAndName(carrier.getId(), name.getId());

            List<AdapterItemIn> items = new ArrayList<>(list.size());
            for (int i = 0; i < list.size(); i++) {
                if (isTheor) {
                    if (list.get(i).getSapWeightNett() - list.get(i).getWeightAccepted() == weightList1.get(0)) {
                        items.add(new AdapterItemIn(i, list.get(i), this));
                    }
                } else {
                    items.add(new AdapterItemIn(i, list.get(i), this));
                }
            }

            Collections.sort(items, (o1, o2) ->
                    Integer.compare(o2.getOnTheWay().getSapWeightNett() - o2.getOnTheWay().getWeightAccepted(),
                            o1.getOnTheWay().getSapWeightNett() - o1.getOnTheWay().getWeightAccepted())
            );

            adapter = new FlexibleAdapter<>(items);

            endLoadList();
        });
    }

    private void endLoadList() {
        hideLoading();

        runOnUiThread(() -> {
            listView.setAdapter(adapter);
            scrollView.post(() -> scrollView.scrollTo(0, 0));
        });
    }

    private int getCheckedCount() {
        int count = 0;
        for (AdapterItemIn item : adapter.getCurrentItems()) {
            if (item.isChecked()) count++;
        }
        return count;
    }

    private List<AdapterItemIn> getCheckedItems() {
        List<AdapterItemIn> list = new ArrayList<>();
        for (AdapterItemIn item : adapter.getCurrentItems()) {
            if (item.isChecked()) list.add(item);
        }
        return list;
    }

    @Override
    public void onCheckChanged(AdapterItemIn item, boolean checked) {
        refreshTitle();
        int checkedCount = getCheckedCount();

        for (AdapterItemIn itemIn : adapter.getCurrentItems()) {
            if (!itemIn.isChecked()) {
                //itemIn.setEnabled(checkedCount < packCount);
            }
        }

        boolean ready = !isTheor && checkedCount == 1 || checkedCount == packCount;

        if (isTheor && getTotalSelectedWeight() != weightCrane/* - totalPackAndTheor*/) {
            ready = false;
        }

        //adapter.notifyDataSetChanged();
        buttonAccept.setEnabled(ready);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == DEFAULT_REQUEST && resultCode == RESULT_OK) {
            setResult(RESULT_OK);
            finish();
        }
    }
}
