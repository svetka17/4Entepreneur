package com.metinvest.smc.view;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterSimple;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class InvReportActivity extends MyActivity {

    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.textNotFound)
    TextView textNotFound;

    private FlexibleAdapter<AdapterSimple> adapter;
    private Date date;
    private String storage;
    private Thread thread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inv_report);
        ButterKnife.bind(this);

        date = (Date) getIntent().getSerializableExtra("date");
        storage = getIntent().getStringExtra("storage");

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
    }

    @Override
    protected void onStop() {
        super.onStop();
        Utils.killThread(thread);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    private List<Label> getLabelList(List<Label> labelList, String category) {
        List<Label> result = new ArrayList<>();
        for (Label label : labelList) {
            long count = db.invDao().inCategory(storage, category, label.getOzm(), label.getLength(), label.getWidth(), label.getThickness());
            if (count > 0) result.add(label);
        }
        return result;
    }

    private List<String> getBatchList(List<Label> labelList) {
        List<String> batchList = new ArrayList<>();
        for (Label label : labelList) {
            String batch = label.getBatch();
            if (!batchList.contains(batch)) {
                batchList.add(batch);
            }
        }
        return batchList;
    }

    private int getLabelListPlan(List<Label> labelList) {
        int result = 0;
        for (Label label : labelList) {
            int value = Utils.getJsonWeightKgIgnoreCase(Utils.getJsonObject(label.getData()), "netT_Weight_Label");
            result += value;
        }
        return result;
    }

    private int getLabelListFact(List<Label> labelList) {
        int result = 0;
        for (Label label : labelList) {
            int value = Utils.getJsonWeightKgIgnoreCase(Utils.getJsonObject(label.getData()), "netT_Weight_Fact");
            result += value;
        }
        return result;
    }

    private void beginLoad() {
        if (isLoading()) return;

        showLoading(R.string.text_please_wait);

        thread = Utils.runOnBackground(() -> {

            adapter = null;

            String url = config.getUrlApi() + "getinventoryonlinedeltas";
            url = net.addUrlParam(url, "wh_type", storage);
            url = net.addUrlParam(url, "inv_date", app.getDateFormat2().format(date));
            JsonResult result = net.downloadJson(url);

            if (result.isOk() || result.getStatus() == LoadResultStatus.PLUS2) {

                List<Label> labelList = new ArrayList<>();

                JSONArray array = Utils.getJsonArray(result.getJson(), "data");
                for (int i = 0; array != null && i < array.length(); i++) {
                    JSONObject json = Utils.getJsonObject(array, i);
                    if (json != null) {
                        Label label = Label.fromJson(json);
                        if (label != null) {
                            labelList.add(label);
                        }
                    }
                }

                List<String> categoryList = db.invDao().getCategoryList(storage);

                List<AdapterSimple> list = new ArrayList<>();

                for (int i = 0; i < categoryList.size(); i++) {
                    String category = categoryList.get(i);
                    List<Label> labelListCategory = getLabelList(labelList, category);

                    //List<String> batchList = getBatchList(labelListCategory);
                    int plan = db.invDao().getPlanByCategory(storage, category); //getLabelListPlan(labelListCategory);
                    int fact = getLabelListFact(labelListCategory);
                    float delta = (fact - plan) / 1000.0f;
                    //float deltaPercent = labelListPlan == 0 ? 0 : ((float) labelListFact * 100.0f / (float) labelListPlan) - 100;
                    //if (deltaPercent < 0) deltaPercent *= -1;

                    //int batchCountPlan = db.invDao().getBatchCountByCategory(storage, category);
                    //int batchCountFact = batchList.size();

                    int planPercent = db.invDao().getPercentByCategory(storage, category);
                    //int countPlan = db.invDao().getCountByCategory(storage, category);
					//int countFact = labelListCategory.size();
					//float factPercent = batchCountPlan == 0 ? 0 : (float) batchCountFact * 100.0f / (float) batchCountPlan;
					float factPercent = plan == 0 ? 0 : (float) fact / (float) plan * 100.0f;
					log("%s %.3f/%.3f %.5fp",
							category,
							//batchCountPlan, batchCountFact,
							//countPlan, countFact,
							plan / 1000.0f, fact / 1000.0f, factPercent);

                    float deltaPercent = fact == 0 ? 0 : Math.abs((float) (fact - plan) / (float) fact);

                    /*
                    //Контроль 10%&ensp; Факт 86%
                    //Відхилення: +0,015 тн або 1,49%

                    //факт - план вес / факт вес
                    */
                    String sb = Utils.format(
                            "План,тн: %.3f&nbsp;&nbsp;&nbsp;Факт,тн: %.3f<br>Контроль: %d%%&nbsp;&nbsp;&nbsp;Факт: %.2f%%<br>Відхилення: %s%.3f тн або %.2f%%",
                            plan / 1000.0f, fact / 1000.0f,
                            planPercent, factPercent,
                            (delta > 0 ? "+" : ""), delta, deltaPercent
                    );


                    /*String sb = Utils.format(
                            "Контрольний тоннаж: %.1f з %d %%<br>Відхилення: %s%.3f тн або %.1f %%",
                            factPercent, daoPercent, (delta > 0 ? "+" : ""), delta, deltaPercent);*/
                    list.add(new AdapterSimple(String.valueOf(i), category, sb));
                }

                adapter = new FlexibleAdapter<>(list);
            }

            runOnUiThread(() -> endLoad(result));
        });
    }

    private void endLoad(JsonResult result) {
        hideLoading();

        listView.setAdapter(adapter);
        textNotFound.setVisibility(adapter != null && adapter.getItemCount() > 0 ? View.GONE : View.VISIBLE);
        scrollView.post(() -> scrollView.scrollTo(0, 0));

        if (!result.isOk() && result.getStatus() != LoadResultStatus.PLUS2) {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
        }
    }
}
