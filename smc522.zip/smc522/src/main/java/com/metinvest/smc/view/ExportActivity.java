package com.metinvest.smc.view;

import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;

import com.metinvest.smc.R;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.Utils;

import java.io.File;
import java.util.Calendar;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ExportActivity extends MyActivity {

    @BindView(R.id.buttonExport)
    Button buttonExport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_export);
        ButterKnife.bind(this);
    }

    @Override
    protected String getHelpContent() {
        return getString(R.string.text_export_prompt);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonExportClick();
        }
    }

    private void buttonExportClick() {
        if (isLoading() || !buttonExport.isEnabled()) return;

        showLoading(R.string.text_please_wait);
        buttonExport.setEnabled(false);

        Utils.runOnBackground(this::beginExport);
    }

    public File exportDb() {

        try {

            File oldDb = getApplicationContext().getDatabasePath("database");

            File sdCard = Environment.getExternalStorageDirectory();

            String newPath = Utils.format("%s/%s%s",
                    sdCard.getAbsolutePath(),
					app.getTimeStampFormat().format(Calendar.getInstance().getTime()),
					"smc.db"
			);

			File newDb = new File(newPath);

			Utils.copy(oldDb, newDb);

			return newDb;

		} catch (Exception e) {
			log(e, "exportDb()");
			return null;
		}

    }

    private void beginExport() {

        String error = null;

        File file = exportDb();
        Network.ftpUploadResult uploadResult;

        if (file != null) {
            uploadResult = net.uploadFtpFile(file);

			try {
				file.delete();
			} catch (Exception e) {
				log(e, "file.delete()");
			}

            if (uploadResult == Network.ftpUploadResult.CONNECT_ERROR)
                error = "Не вдалося з'єднатися з FTP сервером!";
            else if (uploadResult == Network.ftpUploadResult.LOGIN_ERROR)
                error = "Не вдалося авторизуватися на FTP!";
            else if (uploadResult == Network.ftpUploadResult.CONFIG_ERROR)
                error = "Не вдалося ініціювати передачу по FTP!";
            else if (uploadResult == Network.ftpUploadResult.WRITE_ERROR)
                error = "Не вдалося відправити файл по FTP!";
        } else
            error = "Не вдалося експортувати базу данних!";

        String finalError = error;
        runOnUiThread(() -> endExport(finalError));
    }

    private void endExport(String error) {

        hideLoading();
        buttonExport.setEnabled(true);

        if (error == null) {
            showToast(R.string.ftp_export_ok);
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, error, (dialog, which) -> buttonExportClick());
        }

    }
}
