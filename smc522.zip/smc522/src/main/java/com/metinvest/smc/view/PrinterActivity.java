package com.metinvest.smc.view;

import static android.content.DialogInterface.BUTTON_POSITIVE;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;

import com.metinvest.smc.BuildConfig;
import com.metinvest.smc.Config;
import com.metinvest.smc.R;
import com.metinvest.smc.tools.INfc;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.IValue;
import com.metinvest.smc.tools.NFC;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.PrinterConfig;
import com.metinvest.smc.tools.PrinterType;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.tools.Value;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PrinterActivity extends MyActivity implements INfc, IScan {

    @BindView(R.id.viewContentData)
    View viewContentData;
    @BindView(R.id.textMac)
    EditText textMac;
    @BindView(R.id.spinnerPrinterType)
    Spinner spinnerPrinterType;
    @BindView(R.id.spinnerPaperType)
    Spinner spinnerPaperType;
    @BindView(R.id.buttonCalibrate)
    TextView buttonCalibrate;
    @BindView(R.id.buttonTest)
    TextView buttonTest;
    @BindView(R.id.buttonDiag)
    TextView buttonDiag;
    @BindView(R.id.buttonReset)
    TextView buttonReset;

    @BindView(R.id.viewBrightness)
    View viewBrightness;
    @BindView(R.id.seekBrightness)
    SeekBar seekBrightness;
    @BindView(R.id.textBrightness)
    TextView textBrightness;

    private enum DplFunc {
        CALIBRATE, PAPER_TYPE, TEST, DIAG, RESET
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_printer);
        ButterKnife.bind(this);
    }

    private void fillPrinterType() {
        List<IValue> listPrinterType = new ArrayList<>(3);
        listPrinterType.add(new Value(0, "[Не обрано]"));
        listPrinterType.add(new Value(1, "Honeywell"));
        listPrinterType.add(new Value(2, "Zebra"));
        Utils.fillData(spinnerPrinterType, listPrinterType);
    }

    private void fillPaperType(PrinterType printerType) {
        List<IValue> list = new ArrayList<>();
        if (printerType == PrinterType.HONEYWELL) {
            list.add(new Value(0, "[Не обрано]"));
            list.add(new Value(1, "Сіра"));
            list.add(new Value(2, "Біла"));
        } else if (printerType == PrinterType.ZEBRA) {
            list.add(new Value(0, "[Не обрано]"));
            list.add(new Value(1, "Етикетка (gap)"));
            list.add(new Value(2, "Бірка (mark)"));
        } else {
            list.add(new Value(0, "Звичайна"));
        }
        Utils.fillData(spinnerPaperType, list);
    }

    private boolean spinnerPrinterTypeEvent = false;

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        seekBrightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textBrightness.setText(String.valueOf(progress));
                if (fromUser) saveZebraBrightness(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        seekBrightness.setProgress(config.getZebraBrightness());

        fillPrinterType();
        readConfig();
        textMac.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                onMacChanged(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        Utils.runOnBackground(() -> {
            Utils.sleep(1000);
            runOnUiThread(() -> {
                spinnerPrinterType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        if (spinnerPrinterTypeEvent) {
                            spinnerPrinterTypeEvent = false;
                            return;
                        }
                        onPrinterTypeChanged();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                spinnerPaperType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        onPaperTypeChanged();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
            });
        });
    }

    private void saveZebraBrightness(int progress) {
        config.setZebraBrightness(progress);
        config.saveConfig();
    }

    private void onMacChanged(String mac) {
        spinnerPrinterType.setEnabled(!Utils.isNullOrEmpty(mac));
    }

    private void onPaperTypeChanged() {
        int i = getSpinnerPaperType();
        log("onPaperTypeChanged: %d", i);
        beginPaperType();
    }

    private void onPrinterTypeChanged() {
        int i = getSpinnerPrinterType();
        log("onPrinterTypeChanged: %d", i);
        PrinterType printerType = PrinterType.values()[i];
        fillPaperType(printerType);

        PrinterConfig printerConfig = config.getPrinter();
        if (printerConfig != null) {
            config.setPrinter(new PrinterConfig(printerType, printerConfig.getModel(), printerConfig.getMac()));
        }

        refreshViewBrightness(printerType);
    }

    private void refreshViewBrightness(PrinterType printerType) {
        viewBrightness.setVisibility(printerType == PrinterType.ZEBRA ? View.VISIBLE : View.GONE);
    }

    private void readConfig() {
        PrinterConfig printer = config.getPrinter();
        fillPaperType(printer == null ? PrinterType.UNKNOWN : printer.getType());

        textMac.setText(printer == null ? null : printer.getMac());
        //spinnerPrinterTypeEvent = true;
        setSpinnerPrinterType(printer == null ? PrinterType.UNKNOWN : printer.getType());
        if (printer != null && printer.getType() != PrinterType.UNKNOWN) {
            setSpinnerPaperType(config.getPrinterPaperType());
        }
        viewContentData.setVisibility(config.isPrinterConnected() ? View.VISIBLE : View.GONE);
        refreshButtons();

        refreshViewBrightness(printer == null ? PrinterType.UNKNOWN : printer.getType());
    }

    @Override
    protected String getHelpContent() {
        return getString(R.string.text_printer_prompt_message);
    }

    @Override
    protected void onFunctionKey(int number) {
        switch (number) {
            case 2:
                beginPaperType();
                break;
            case 3:
                beginCalibrate();
                break;
            case 4:
                beginTest();
                break;
            case 5:
                beginDiag();
                break;
            case 6:
                beginReset();
                break;
        }
    }

    private void beginDiag() {
        if (canSendDpl()) {

            showLoading(R.string.text_diag_title);

            Utils.runOnBackground(() -> {

                List<String> dplList = new ArrayList<>();

                dplList.add(((char) 2) + "KC\r");

                Printer.PrintResult result = null;

                for (String dpl : dplList) {

                    //log("DPL: \"%s\"", dpl);

                    result = Printer.sendCommand(null, config.getPrinter(), dpl, false, true);
                    if (result.getStatus() != Printer.PrintResultStatus.OK) {
                        break;
                    }
                }

                Printer.PrintResult finalResult = result;
                runOnUiThread(() -> endPrint(DplFunc.DIAG, finalResult));

            });

        }
    }

    private void beginReset() {

        config.setZebraBrightness(Config.DEFAULT_ZEBRA_BRIGHTNESS);
        config.saveConfig();

        if (canSendDpl()) {

            showLoading(R.string.text_reset_title);

            Utils.runOnBackground(() -> {

                String dpl;
                PrinterType printerType = config.getPrinter().getType();
                if (printerType == PrinterType.ZEBRA) {
                    dpl = "~JR";
                } else {
                    //dpl = (((char) 2) + "KcSTR;");
                    dpl = ((char) 2) + "KFA";
                }


                final Printer.PrintResult finalResult = Printer.sendCommand(null, config.getPrinter(), dpl, false, true);
                runOnUiThread(() -> endPrint(DplFunc.RESET, finalResult));

            });

        }
    }

    private void beginTest() {
        if (canSendDpl()) {

            showLoading(R.string.text_printing_title);

            Utils.runOnBackground(() -> {

                String dpl = app.processTemplate(Config.TemplateType.TEMPLATE_TEST, null);

                final Printer.PrintResult finalResult = Printer.sendCommand(null, config.getPrinter(), dpl, false, true);
                runOnUiThread(() -> endPrint(DplFunc.TEST, finalResult));

            });

        }
    }

    private void refreshButtons() {
        boolean enabled = config.isPrinterConnected() && config.getPrinterPaperType() > 0;

        buttonCalibrate.setEnabled(enabled);
        buttonTest.setEnabled(enabled);
        buttonDiag.setEnabled(enabled);
        buttonReset.setEnabled(true);
    }

    private void beginPaperType() {
        if (!canSendDpl()) return;
        int paperType = getSpinnerPaperType();
        if (paperType == 0) return;

        if (config.getPrinter() != null && config.getPrinter().getType() == PrinterType.UNKNOWN)
            return;

        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            List<String> dplList = new ArrayList<>();

            //dplList.add(((char) 2) + Utils.format("KcPC60;HE%d;DK60;BSA;SSA;FSA\r", config.getPrinterContrast()));

            if (isPrinterZebra()) {
                if (paperType == 1) { //Етикетка
                    dplList.add("^XA^JUF^XZ");
                } else if (paperType == 2) { //Бірка
                    dplList.add("^XA\n" +
                            "^MNM,40\n" +
                            "^JUS\n" +
                            "^XZ\n" +
                            "^XA\n" +
                            "~JR\n" +
                            "^XZ");
                }
            } else {
                if (paperType == 1) {
                    //Термолок (летняя, серая)
                    dplList.add(((char) 2) + "KcUMM;SLT;STR;");
                    dplList.add(((char) 2) + "KcpSA;BSA;SSA;FSA;");
                    dplList.add(((char) 2) + "KcPC64;HE30;DK64");
                    dplList.add(((char) 2) + "KcTPY;");
                } else if (paperType == 2) {
                    //Обычная бумага (Зимняя, белая)
                    dplList.add((char) 2 + "KcUMM;SLT;STG;");
                    dplList.add((char) 2 + "KcpSA;BSA;SSA;FSA;");
                    dplList.add((char) 2 + "KcTPY;");
                    dplList.add((char) 2 + "KcCL1524;");
                }
            }

            Printer.PrintResult result = null;

            if (BuildConfig.DEBUG) {
                result = new Printer.PrintResult(Printer.PrintResultStatus.OK);
            } else {
                for (String dpl : dplList) {

                    //log("DPL: \"%s\"", dpl);

                    result = Printer.sendCommand(null, config.getPrinter(), dpl, false, true);
                    if (result.getStatus() != Printer.PrintResultStatus.OK) {
                        break;
                    }

                    Utils.sleep(500);
                }
            }

            if (result != null && result.getStatus() == Printer.PrintResultStatus.OK) {
                savePaperType();
            }

            final Printer.PrintResult finalResult = result;
            runOnUiThread(() -> endPrint(DplFunc.PAPER_TYPE, finalResult));

        });

    }

    private void beginCalibrate() {
        if (canSendDpl()) {

            showLoading(R.string.text_printer_calibrating);

            Utils.runOnBackground(() -> {

                List<String> dplList = new ArrayList<>();

                PrinterType printerType = config.getPrinter().getType();
                if (printerType == PrinterType.ZEBRA) {
                    dplList.add("! U1 do \"zpl.calibrate\" \"\"");
                } else {
                    dplList.add(((char) 2) + "K}q");
                }

                Printer.PrintResult result = null;

                for (String dpl : dplList) {

                    //log("DPL: \"%s\"", dpl);

                    result = Printer.sendCommand(null, config.getPrinter(), dpl, false, true);
                    if (result.getStatus() != Printer.PrintResultStatus.OK) {
                        break;
                    }
                }

                Printer.PrintResult finalResult = result;
                runOnUiThread(() -> endPrint(DplFunc.CALIBRATE, finalResult));

            });
        }
    }

    private boolean canSendDpl() {
        return !isLoading() && viewContentData.getVisibility() == View.VISIBLE;
    }

    private void endPrint(DplFunc func, Printer.PrintResult result) {
        hideLoading();

        if (result.getStatus() == Printer.PrintResultStatus.OK) {
            if (func == DplFunc.DIAG) {
                showDiagResult(result.getData());
            } else if (func == DplFunc.PAPER_TYPE) {
                if (config.getPrinter().getType() == PrinterType.ZEBRA) {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.warning_after_set_paper_type_zebra, null);
                } else {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.warning_after_set_paper_type, (dialog, which) -> onFunctionKey(3));
                }
                refreshButtons();
            } else if (func == DplFunc.RESET) {
                setSpinnerPaperType(0);
            } else if (func == DplFunc.TEST) {
                //app.sendFaPrint();
            }
            showToast(R.string.text_print_result_succeeded);
        } else {
            @StringRes final int message = app.getPrintResultMessage(result);

            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> {
                if (func == DplFunc.CALIBRATE) beginCalibrate();
                else if (func == DplFunc.PAPER_TYPE) beginPaperType();
                else if (func == DplFunc.DIAG) beginDiag();
                else if (func == DplFunc.TEST) beginTest();
                else if (func == DplFunc.RESET) beginReset();
            });

        }
    }

    public void buttonAddMacClick(View view) {
        beginDetectPrinterByScan(textMac.getText().toString());
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {
        beginDetectPrinterByScan(barcodeData);
    }

    @Override
    public void onNfcEvent(NFC nfc) {
        runOnUiThread(() -> beginDetectPrinterByNfc(nfc));
    }

    private void resetPrinter() {
        config.setPrinter(null);
        config.setPrinterPaperType(0);
        config.saveConfig();
    }

    private void beginDetectPrinterByScan(String barcodeData) {
        PrinterConfig printerConfig = new PrinterConfig(null, null, barcodeData);
        beginDetectPrinter(printerConfig);
    }

    private void beginDetectPrinterByNfc(NFC nfc) {
        PrinterConfig printerConfig = Printer.detectPrinter(nfc);
        if (printerConfig == null) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_printer_scanned_error, null);
        } else {
            beginDetectPrinter(printerConfig);
        }
    }

    private void beginDetectPrinter(PrinterConfig printerConfig) {
        if (isLoading()) return;
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            resetPrinter();

            boolean result = Utils.isCorrectMacAddress(printerConfig.getMac());

            if (result) {
                config.setPrinter(new PrinterConfig(printerConfig.getType(), printerConfig.getModel(), Utils.formatMacAddress(printerConfig.getMac())));
                config.saveConfig();
            }

            runOnUiThread(() -> endDetectPrinter(result));

        });
    }

    private void endDetectPrinter(boolean result) {
        readConfig();
        hideLoading();

        if (!result)
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_print_result_bluetooth_mac_invalid, null);

        refreshButtons();
    }

    private int getSpinnerPrinterType() {
        try {
            long id = spinnerPrinterType.getSelectedItemId();
            return (int) id;
        } catch (Exception e) {
            log(e, "getSpinnerPrinterType()");
            return 0;
        }
    }

    private int getSpinnerPaperType() {
        try {
            long id = spinnerPaperType.getSelectedItemId();
            return (int) id;
        } catch (Exception e) {
            log(e, "getSpinnerPaperType()");
            return 0;
        }
    }

    private void setSpinnerPrinterType(PrinterType value) {
        try {
            spinnerPrinterType.setSelection(value == null ? 0 : value.getValue());
        } catch (Exception e) {
            log(e, "spinnerPrinterType.setSelection(%s)", value);
        }
    }

    private void setSpinnerPaperType(int value) {
        try {
            spinnerPaperType.setSelection(value);
        } catch (Exception e) {
            log(e, "spinnerPaperType.setSelection(%s)", value);
        }
    }

    private void savePaperType() {
        config.setPrinterPaperType(getSpinnerPaperType());
        config.saveConfig();
    }

    private void showDiagResult(String text) {
        if (isFinishing()) return;

        app.copyToClipboard(text);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(R.drawable.ic_warning_24dp);
        builder.setTitle(R.string.diag_result_dialog_title);

        String finalMessage = text.replaceAll("\n", "<br>");
        builder.setMessage(app.fromHtml(Utils.format("%s<br><br><i>TerminalId: %s</i><br><i>Версія:</i> %s", finalMessage, app.getDeviceId(), app.getApkVersionName())));
        builder.setPositiveButton(R.string.text_ok, null);

        final AlertDialog myDialog = builder.create();
        myDialog.setOnShowListener(dialog -> {
            Button button = myDialog.getButton(BUTTON_POSITIVE);
            button.setFocusable(true);
            button.setFocusableInTouchMode(true);
            button.requestFocus();
            app.hideUi(this);
        });
        myDialog.show();

        TextView textView = myDialog.findViewById(android.R.id.message);
        if (textView != null) textView.setTextSize(12);
    }
}
