package com.metinvest.smc.inc;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Objects;

public class TransportDoc {

	private final Transport transport;
	private final TTN ttn;
	private String status;
	private boolean processing;
	private int totalWeightPlan, totalWeightFact, totalWeightFactTemp;
	private boolean vhp;
	private String storage;

	private TransportDoc(Transport transport, TTN ttn) {
		this.transport = transport;
		this.ttn = ttn;
		this.status = null;
		this.totalWeightPlan = this.totalWeightFact = this.totalWeightFactTemp = 0;
	}

	public String getStorage() {
		return storage;
	}

	public boolean isProcessing() {
		return processing;
	}

	public void setProcessing(boolean processing) {
		this.processing = processing;
	}

	public boolean isVhp() {
		return vhp;
	}

	public TTN getTtn() {
		return ttn;
	}

	public Transport getTransport() {
		return transport;
	}

	public int getTotalWeightPlan() {
        return totalWeightPlan;
    }

    public int getTotalWeightFact() {
        return totalWeightFact;
    }

    public int getTotalWeightFactTemp() {
        return totalWeightFactTemp;
    }

    public String getTotalWeightPercentString() {
        return Utils.getTotalWeightPercentString(totalWeightPlan, totalWeightFact);
	}

	public String getStatus() {
		return status;
	}

	public String getStatusString() {
		return Utils.format("%s%s", getStatusString(status), status == null || status.length() == 0 ? "" : Utils.format(" (%s)", status));
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		TransportDoc that = (TransportDoc) o;

		if (!Objects.equals(transport, that.transport))
			return false;
		return Objects.equals(ttn, that.ttn);
	}

	@Override
	public int hashCode() {
		int result = transport != null ? transport.hashCode() : 0;
		result = 31 * result + (ttn != null ? ttn.hashCode() : 0);
		return result;
	}

	public static int compareStatus(String status1, String status2) {

		String[] s = {
				"99", "97", "0", "", "1", "2", "3", "4", "5", "7", "8"
		};

		int i1 = Utils.getArrayIndex(s, status1);
		int i2 = Utils.getArrayIndex(s, status2);

		return Integer.compare(i1, i2);
	}

	private static String getStatusString(String status) {
		switch (status) {
			case "0":
				return App.getInstance().getString(R.string.inc_status_0);
			case "1":
				return App.getInstance().getString(R.string.inc_status_1);
			case "3":
				return App.getInstance().getString(R.string.inc_status_3);
			case "2":
			case "4":
				return App.getInstance().getString(R.string.inc_status_2);
			case "5":
				return App.getInstance().getString(R.string.inc_status_5);
			case "7":
				return App.getInstance().getString(R.string.inc_status_7);
			case "8":
				return App.getInstance().getString(R.string.inc_status_8);
			case "99":
				return App.getInstance().getString(R.string.inc_status_99);
			case "97":
				return App.getInstance().getString(R.string.inc_status_97);
			default:
				return App.getInstance().getString(R.string.inc_status_null);
        }
    }

    public static TransportDoc fromTransport(String transportJson, TTN ttn) {
        Transport transport = Transport.fromJson(transportJson, null);
        if (transport == null) {
            return null;
        } else {
            return fromTransport(transport, ttn);
        }
    }

    public static TransportDoc fromTransport(Transport transport, TTN ttn) {

        JSONArray arrayTtn = Utils.getJsonArray(transport.getJson(), "ttN_NUMBERS");

        if (arrayTtn != null && arrayTtn.length() > 0) {
            for (int j = 0; j < arrayTtn.length(); j++) {

                JSONObject jsonTtn = Utils.getJsonObject(arrayTtn, j);
                String ttnNumItem = Utils.getJsonStringIgnoreCase(jsonTtn, "ttN_NUM");
				//String ttnIdItem = Utils.getJsonStringIgnoreCase(jsonTtn, "ttN_ID");

                if (ttnNumItem.equalsIgnoreCase(ttn.getNum())/* && ttnIdItem.equalsIgnoreCase(ttn.getId())*/) {

					Boolean ttnSoh = null;
					String sohStr = Utils.getJsonStringIgnoreCase(jsonTtn, "soh");
					if (sohStr.equalsIgnoreCase("true")) ttnSoh = true;
					else if (sohStr.equalsIgnoreCase("false")) ttnSoh = false;

					TransportDoc transportDoc = new TransportDoc(transport, new TTN(/*ttnIdItem, */ttnNumItem, ttnSoh));
					transportDoc.setProcessing(Utils.getJsonStringIgnoreCase(jsonTtn, "autO_BATCH_PROCC").equalsIgnoreCase("true"));
					//transportDoc.setProcessing(true);
					transportDoc.status = Utils.getJsonStringIgnoreCase(jsonTtn, "statuS_OUT");
					transportDoc.totalWeightPlan = Utils.getJsonWeightKgIgnoreCase(jsonTtn, "suM_PLAN_WEIGHT");
					transportDoc.totalWeightFact = Utils.getJsonWeightKgIgnoreCase(jsonTtn, "suM_FACT_WEIGHT");
					transportDoc.totalWeightFactTemp = Utils.getJsonWeightKgIgnoreCase(jsonTtn, "suM_FACT_TEMP_WEIGHT");
					transportDoc.vhp = Utils.getJsonStringIgnoreCase(jsonTtn, "iF_VHP").equalsIgnoreCase("true");
					transportDoc.storage = Utils.getJsonStringIgnoreCase(jsonTtn, "lgort");
					return transportDoc;
				}
            }
        }

        return null;
    }
}
