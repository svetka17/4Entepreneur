package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.inc.Order;
import com.metinvest.smc.inc.Ozm;
import com.metinvest.smc.inc.SohFilter;
import com.metinvest.smc.inc.TTN;
import com.metinvest.smc.inc.TransportDoc;
import com.metinvest.smc.inc.Weight;
import com.metinvest.smc.tools.Utils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class IncBatchActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;
    @BindView(R.id.buttonManual)
    Button buttonManual;

	private TransportDoc transportDoc;
	private String locationCode;
	private Ozm ozm;
	private boolean isTheor;
	private int weightCraneBrutto, weightCraneNetto, packCount;
	private ArrayList<Weight> weightList;
	private ArrayList<Order> orderList, orderListChecked;

	private FlexibleAdapter<Adapter> adapter;
	private int packNum;
	private String sohSmcId;
	private SohFilter sohFilter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_inc_batch);
		ButterKnife.bind(this);

		transportDoc = TransportDoc.fromTransport(
				getIntent().getStringExtra("transportJson"),
				(TTN) getIntent().getSerializableExtra("ttn")
		);

		sohSmcId = getIntent().getStringExtra("sohSmcId");
		sohFilter = sohSmcId == null ? SohFilter.NotSoh() : SohFilter.SohInc(sohSmcId);
		packNum = getIntent().getIntExtra("packNum", 1);
		ozm = (Ozm) getIntent().getSerializableExtra("ozm");
		isTheor = getIntent().getBooleanExtra("isTheor", false);
		weightCraneBrutto = getIntent().getIntExtra("weightCraneBrutto", 0);
		weightCraneNetto = getIntent().getIntExtra("weightCraneNetto", 0);
		packCount = getIntent().getIntExtra("packCount", 0);
		locationCode = getIntent().getStringExtra("locationCode");
		weightList = new ArrayList<>(getIntent().getParcelableArrayListExtra("weightList"));
		ArrayList<String> currentOrderListJson = getIntent().getStringArrayListExtra("orderList");

        orderList = new ArrayList<>();
        for (String json : currentOrderListJson) {
            orderList.add(new Order(json));
        }

        orderListChecked = new ArrayList<>();
        if (packNum > 1) {
            ArrayList<String> currentOrderListCheckedJson = getIntent().getStringArrayListExtra("orderListChecked");
            if (currentOrderListCheckedJson != null) {
                for (String json : currentOrderListCheckedJson) {
                    orderListChecked.add(new Order(json));
                }
            }
        }

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

        refreshTitle();
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 4) {
            buttonManualClick();
        } else if (number == 5) {
            buttonAcceptClick();
        }
    }

    private int getBusyWeight(Order order) {
        int value = 0;
        for (int i = 0; i < orderListChecked.size(); i++) {
            if (orderListChecked.get(i).equals(order)) {
                value += weightList.get(i).getNetto();
            }
        }
        return value;
    }

    private void beginLoad() {
        if (isLoading()) return;

        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            int foundIndex = -1;

            List<Adapter> list = new ArrayList<>();
            Weight weight = getWeightByNum();

            for (int i = 0; i < orderList.size(); i++) {
                Order order = orderList.get(i);

                list.add(new Adapter(i, order, getBusyWeight(orderList.get(i))));

                if (foundIndex == -1) {
                    //Поиск по idQr
                    if (weight.getIdQr().length() > 0 && order.getIdQr().equalsIgnoreCase(weight.getIdQr())) {
                        log("IdQr %s found!", weight.getIdQr());
                        foundIndex = i;
                    }

                    //Поиск по партии
                if (weight.getBatch() != null && weight.getBatch().length() > 0 && order.getBatch().equalsIgnoreCase(weight.getBatch())) {
                    log("Batch %s found!", weight.getBatch());
                    foundIndex = i;
                }
                }
            }

            if (foundIndex == -1 && orderList.size() == 1) {
                foundIndex = 0;
                log("Single batch in ozm: %s", ozm.toString());
            }

            try {
                Collections.sort(list, (o1, o2) -> {
					if (o1.getOrder().getAvailableNetto() == 0) return 1;
					if (o2.getOrder().getAvailableNetto() == 0) return -1;

					int a = getWeightByNum().getNetto();
					int diff1 = o1.getOrder().getAvailableNetto() - a;
					int diff2 = o2.getOrder().getAvailableNetto() - a;
					if (diff1 < 0) diff1 *= -1;
					if (diff2 < 0) diff2 *= -1;
					return Integer.compare(diff1, diff2);
				});
			} catch (Exception e) {
				log(e, "Collections.sort()");
			}

            adapter = new FlexibleAdapter<>(list);
            adapter.addListener(this);

            int finalFoundIndex = foundIndex;
            runOnUiThread(() -> endLoad(finalFoundIndex));

        });
    }

    private void checkButtonAccept() {
        boolean ready = getCheckedCount() == 1;
        buttonAccept.setEnabled(ready);
    }

    @Override
    public boolean onItemClick(View view, int position) {

        Adapter item = adapter.getItem(position);
        if (item != null) {

            boolean checked = item.isChecked();

            if (!checked) {
                List<Adapter> list = adapter.getCurrentItems();
                for (Adapter listItem : list) {
                    if (!listItem.equals(item)) {
                        listItem.setChecked(false);
                        adapter.updateItem(listItem);
                    }
                }
            }

            item.setChecked(!checked && (item.getOrder().getAvailableNetto() - item.getBusyWeight() > 0));
            adapter.updateItem(item);
            refreshTitle();
            checkButtonAccept();
            return true;
        }

        return false;
    }

    private void endLoad(int foundIndex) {
        hideLoading();

        runOnUiThread(() -> {
            textNotFound.setVisibility(adapter == null || adapter.isEmpty() ? View.VISIBLE : View.GONE);
            listView.setAdapter(adapter);
            scrollView.post(() -> scrollView.scrollTo(0, 0));
            checkButtonAccept();

            if (foundIndex != -1) {
                log("Found plan #%d", orderList.get(foundIndex).getLineId());
                goNext(orderList.get(foundIndex));
            }
        });
    }

    private Weight getWeightByNum() {
        return weightList.get(packNum - 1);
    }

    private void refreshTitle() {
        String text = Utils.format("Партія пачки №%d, %d кг", packNum, getWeightByNum().getNetto());
        textContentTitle.setText(text);
    }

    private int getCheckedCount() {
        int count = 0;
        if (adapter != null) {
            for (Adapter item : adapter.getCurrentItems()) {
                if (item.isChecked()) count++;
            }
        }
        return count;
    }

    private List<Adapter> getCheckedItems() {
        List<Adapter> list = new ArrayList<>();
        if (adapter != null) {
            for (Adapter item : adapter.getCurrentItems()) {
                if (item.isChecked()) list.add(item);
            }
        }
        return list;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ACTION && resultCode == RESULT_OK) {
            setResult(RESULT_OK);
            finish();
        }

        if (requestCode == REQUEST_ACTION && resultCode == RESULT_NEED_REFRESH) {
            setResult(RESULT_NEED_REFRESH);
            finish();
        }

        if (requestCode == REQUEST_ACTION && resultCode == RESULT_DELETED) {
            setResult(RESULT_DELETED);
            finish();
        }
    }

    private Order getLargerOrder() {

        Order largerOrder = null;

        for (int i = 0; i < orderList.size(); i++) {
            if (largerOrder == null || orderList.get(0).getWeightPlan() > largerOrder.getWeightPlan()) {
                largerOrder = orderList.get(0);
            }
        }

        return largerOrder;
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled() || getCheckedCount() == 0) return;
        goNext(getCheckedItems().get(0).getOrder());
    }

    private void buttonManualClick() {
        if (isLoading() || !buttonManual.isEnabled()) return;

        Order order = getLargerOrder();

        if (order != null)
            goNext(order);
    }

    private void goNext(@NonNull Order checkedOrder) {

        ArrayList<String> currentOrderListCheckedJson = new ArrayList<>();
        for (Order order : orderListChecked) {
            currentOrderListCheckedJson.add(order.getJson().toString());
        }
        currentOrderListCheckedJson.add(checkedOrder.getJson().toString());

        if (packNum < packCount) {

            ArrayList<String> currentOrderListJson = new ArrayList<>();
            for (Order order : orderList) currentOrderListJson.add(order.getJson().toString());

            Intent intent = new Intent(this, IncBatchActivity.class);
            intent.putExtra("transportJson", transportDoc.getTransport().getJson().toString());
            intent.putExtra("ttn", transportDoc.getTtn());
            intent.putExtra("ozm", (Serializable) ozm);
            intent.putExtra("isTheor", isTheor);
            intent.putExtra("weightCraneBrutto", weightCraneBrutto);
            intent.putExtra("weightCraneNetto", weightCraneNetto);
            intent.putExtra("packCount", packCount);
            intent.putExtra("locationCode", locationCode);
            intent.putExtra("packNum", packNum + 1);
            intent.putParcelableArrayListExtra("weightList", new ArrayList<>(weightList));
            intent.putStringArrayListExtra("orderList", currentOrderListJson);
            intent.putStringArrayListExtra("orderListChecked", currentOrderListCheckedJson);
			intent.putExtra("isNew", getIntent().getBooleanExtra("isNew", false));
			intent.putExtra("sohSmcId", sohSmcId);
			startActivityForResult(intent, REQUEST_ACTION);
        } else {
            Intent intent = new Intent(this, IncResultActivity.class);
            intent.putExtra("transportJson", transportDoc.getTransport().getJson().toString());
            intent.putExtra("ttn", transportDoc.getTtn());
            intent.putExtra("ozm", (Serializable) ozm);
            intent.putExtra("isTheor", isTheor);
            intent.putExtra("weightCraneBrutto", weightCraneBrutto);
            intent.putExtra("weightCraneNetto", weightCraneNetto);
            intent.putExtra("packCount", packCount);
            intent.putExtra("locationCode", locationCode);
            intent.putParcelableArrayListExtra("weightList", new ArrayList<>(weightList));
            intent.putStringArrayListExtra("orderList", currentOrderListCheckedJson);
			intent.putExtra("isNew", getIntent().getBooleanExtra("isNew", false));
			intent.putExtra("sohSmcId", sohSmcId);
			startActivityForResult(intent, REQUEST_ACTION);
        }
    }

    public static class Adapter extends AbstractFlexibleItem<Adapter.ViewHolder> {

        private final int index;
        private final Order order;
        private final int busyWeight;
        private boolean checked;

        Adapter(int index, Order order, int busyWeight) {
            this.index = index;
            this.order = order;
            this.busyWeight = busyWeight;
            this.setEnabled(true);
        }

        public int getIndex() {
            return index;
        }

        public boolean isChecked() {
            return checked;
        }

        private void setChecked(boolean checked) {
            this.checked = checked;
        }

        public Order getOrder() {
            return order;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof Adapter && ((Adapter) o).getOrder().equals(getOrder());
        }

        @Override
        public int hashCode() {
            return getOrder().hashCode();
        }

        @Override
        public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
            return new ViewHolder(view, adapter);
        }

        @Override
        public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {

            int v = order.getAvailableNetto() - busyWeight;
            if (v < 0) v = 0;

            holder.textTitle.setText(order.getBatch());
            holder.textWeight.setText(String.valueOf(v));
            holder.textWeight.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), v > 0 ? R.color.batch_enabled : R.color.batch_disabled));

            refreshBackground(holder);
        }

        public int getBusyWeight() {
            return busyWeight;
        }

        private void refreshBackground(ViewHolder holder) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), isChecked() ? R.color.batch_selected : R.color.color_adapter_light));
        }

        @Override
        public int getLayoutRes() {
            return R.layout.adapter_inc_batch_row;
        }

        class ViewHolder extends FlexibleViewHolder {

            @BindView(R.id.textTitle)
            TextView textTitle;
            @BindView(R.id.textContent)
            TextView textContent;
            @BindView(R.id.textWeight)
            TextView textWeight;

            ViewHolder(View view, FlexibleAdapter adapter) {
                super(view, adapter);
                ButterKnife.bind(this, view);
            }
        }
    }

}
