package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ShipmentDocumentDao {
    @Query("SELECT * FROM ShipmentDocument ORDER BY docNumber")
    List<ShipmentDocument> getAll();

    @Query("SELECT * FROM ShipmentDocument WHERE id = :id")
    ShipmentDocument getById(long id);

    @Query("SELECT * FROM ShipmentDocument WHERE lower(docNumber) = lower(:docNumber) AND lower(transportName) LIKE lower(:transportName)")
    ShipmentDocument getByName(String docNumber, String transportName);

    @Query("SELECT * FROM ShipmentDocument WHERE transportId = :transportId ORDER BY docNumber")
    List<ShipmentDocument> getByTransportId(long transportId);

    @Query("SELECT * FROM ShipmentDocument WHERE lower(transportName) LIKE lower(:transportName)")
    List<ShipmentDocument> getByTransportName(String transportName);

    @Query("SELECT * FROM ShipmentDocument WHERE lower(docNumber) LIKE lower(:docNumber)")
    List<ShipmentDocument> getByNameLike(String docNumber);

    @Query("SELECT * FROM ShipmentDocument WHERE lower(docNumber) LIKE lower(:docNumber) AND transportName = :transportName")
    List<ShipmentDocument> getByNameLikeAndTransport(String docNumber, String transportName);

    @Insert
    long insert(ShipmentDocument shipmentDocument);

    @Insert
    void insertAll(List<ShipmentDocument> shipmentDocument);

    @Update
    void update(ShipmentDocument shipmentDocument);

    @Delete
    void delete(ShipmentDocument shipmentDocument);

    @Query("DELETE FROM ShipmentDocument")
    void truncate();
}