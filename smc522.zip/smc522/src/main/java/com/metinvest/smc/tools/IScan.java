package com.metinvest.smc.tools;

/**
 * Интерфейс, используемый для реализации метода onBarcodeEvent.
 */
public interface IScan {
    void onBarcodeEvent(String barcodeData);
}
