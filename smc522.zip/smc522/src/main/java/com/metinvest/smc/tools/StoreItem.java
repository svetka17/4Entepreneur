package com.metinvest.smc.tools;

import java.util.List;

public class StoreItem {
	private final String smcId;
	private final boolean source;
	private final List<String> storeList;

	public StoreItem(String smcId, boolean source, List<String> storeList) {
		this.smcId = smcId;
		this.source = source;
		this.storeList = storeList;
	}

	public String getSmcId() {
		return smcId;
	}

	public boolean isSource() {
		return source;
	}

	public List<String> getStoreList() {
		return storeList;
	}
}
