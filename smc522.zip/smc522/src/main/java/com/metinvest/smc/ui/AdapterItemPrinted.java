package com.metinvest.smc.ui;

import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.db.NameStore;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.db.Printed;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemPrinted extends AbstractFlexibleItem<AdapterItemPrinted.AdapterItemPrintedViewHolder> {

    private final IAdapterItemPrintedListener listener;

    public interface IAdapterItemPrintedListener {
        void onEditClicked(int position);

        void onDeleteClicked(int position);
    }

    private final Printed printed;
    private final OnTheWay onTheWay;
    private final NameStore nameStore;

    public AdapterItemPrinted(Printed printed, IAdapterItemPrintedListener listener) {
        this.listener = listener;
        this.printed = printed;
        this.onTheWay = App.getInstance().getDb().onTheWayDao().getById(printed.getOnTheWayId());
        this.nameStore = App.getInstance().getDb().nameStoreDao().getById(onTheWay.getNameId());
    }

    public Printed getPrinted() {
        return printed;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterItemPrinted && ((AdapterItemPrinted) o).getPrinted().getId() == getPrinted().getId();
    }

    @Override
    public AdapterItemPrintedViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new AdapterItemPrintedViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemPrintedViewHolder holder, int position, List<Object> payloads) {

        holder.textTitle.setText(Utils.format("LabelID: %s", printed.getId()));

        StringBuilder sb = new StringBuilder();

        sb.append(Utils.format("Прийнято: %s кг.<br>", printed.getWeightNetto()));
        sb.append(Utils.format("Упаковка/тара: %s/%s кг.", printed.getWeightPack(), printed.getWeightTara()));

        holder.buttonEdit.setVisibility(View.GONE);
        holder.buttonDelete.setVisibility(View.GONE);
        holder.imageLock.setVisibility(View.VISIBLE);

        if (!printed.isOld()) {
            holder.imageLock.setVisibility(View.GONE);
            holder.buttonEdit.setVisibility(View.VISIBLE);
            holder.buttonDelete.setVisibility(View.VISIBLE);

            holder.buttonEdit.setOnClickListener(v -> {
                if (listener != null) listener.onEditClicked(position);
            });
            holder.buttonDelete.setOnClickListener(v -> {
                if (listener != null) listener.onDeleteClicked(position);
            });
        }

        holder.textContent.setText(App.getInstance().fromHtml(sb.toString()));
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_printed_row;
    }

    /**
     * The ViewHolder used by this item.
     * Extending from FlexibleViewHolder is recommended especially when you will use
     * more advanced features.
     */
    public class AdapterItemPrintedViewHolder extends FlexibleViewHolder {

        private final View view;

        public TextView textTitle, textContent;
        public ImageButton buttonEdit, buttonDelete;
        public ImageView imageLock;

        public AdapterItemPrintedViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.view = view;
            this.textTitle = view.findViewById(R.id.textTitle);
            this.textContent = view.findViewById(R.id.textContent);
            this.buttonEdit = view.findViewById(R.id.buttonEdit);
            this.buttonDelete = view.findViewById(R.id.buttonDelete);
            this.imageLock = view.findViewById(R.id.imageLock);
        }
    }
}
