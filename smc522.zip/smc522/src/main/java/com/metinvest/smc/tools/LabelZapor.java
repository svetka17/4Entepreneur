package com.metinvest.smc.tools;

public class LabelZapor extends Label {


    public static LabelZapor fromBarcode(String barcode) {
        return null;
    }
}
