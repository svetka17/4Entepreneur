package com.metinvest.smc.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.tools.IValue;

import java.util.List;

public class SpinnerAdapter extends BaseAdapter {
    private final Context context;
    private final List<IValue> data;

    public SpinnerAdapter(Context context, List<IValue> data) {
        this.context = context;
        this.data = data;
    }

    @Override
    public int getCount() {
        return data == null ? 0 : data.size();
    }

    @Override
    public IValue getItem(int position) {
		try {
			return data.get(position);
		} catch (Exception e) {
			App.getInstance().log(this, e, "getItem(%s)", position);
			return null;
		}
    }

    @Override
    public long getItemId(int position) {
		try {
			return getItem(position).getId();
		} catch (Exception e) {
			App.getInstance().log(this, e, "getItemId(%s)", position);
			return 0;
		}
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.spinner_item, parent, false);
        }

        if (convertView instanceof TextView) {
            final TextView view = (TextView) convertView;

			try {
				view.setText(getItem(position).getName());
				view.post(() -> view.setSingleLine(false));
			} catch (Exception ignored) {
				view.setText("");
			}
        }

        return convertView;
    }
}