package com.metinvest.smc.view;

import static com.metinvest.smc.tools.Utils.parseInt;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.LabelBatch;
import com.metinvest.smc.inc.Ozm;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.JsonUploadTask;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterLabel;
import com.metinvest.smc.ui.AdapterLabelGroup;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.IFlexible;

/**
 * Экран для вывода результатов поиска бирок
 */
public class BarcodeResultActivity extends MyActivity implements AdapterLabel.IListener, IScan {

	@BindView(R.id.textContentTitle)
	TextView textContentTitle;
	@BindView(R.id.listView)
	RecyclerView listView;
	@BindView(R.id.textNotFound)
	TextView textNotFound;
	@BindView(R.id.buttonRefresh)
	Button buttonRefresh;
	@BindView(R.id.buttonAction)
	Button buttonAction;
	@BindView(R.id.viewRefresh)
	View viewRefresh;
	@BindView(R.id.viewAction)
	View viewAction;

	private ShowInfoType type;
	private FlexibleAdapter<IFlexible> adapter;
	private String filterOzm;
	private float filterLength, filterWidth, filterThickness;
	private String labelId;
	private String idQr;
	private String locationId;
	private String locationCode;
	private String batch;
	private ArrayList<JSONObject> jsonList;
	private ArrayList<Ozm> ozmList;
	private String data;
	private ArrayList<String> checkedList;
	private boolean canScan;
	private boolean canRefresh, canAction;
	private String action;
	private ArrayList<String> labelIdList;
	private boolean showGroups;
	private String storageFilter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_barcode_result);
		ButterKnife.bind(this);

		LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
		DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
		listView.setLayoutManager(layoutManager);
		listView.addItemDecoration(dividerItemDecoration);

		type = (ShowInfoType) getIntent().getSerializableExtra("type");
		canScan = getIntent().getBooleanExtra("canScan", true);
		canRefresh = getIntent().getBooleanExtra("canRefresh", true);
		action = getIntent().getStringExtra("action");
		canAction = action != null && !action.isEmpty();
		showGroups = getIntent().getBooleanExtra("showGroups", true);
		storageFilter = getIntent().getStringExtra("storage");

		String actionTitle = getIntent().getStringExtra("actionTitle");
		if (actionTitle != null) buttonAction.setText(actionTitle);

		viewRefresh.setVisibility(canRefresh ? View.VISIBLE : View.GONE);
		viewAction.setVisibility(canAction ? View.VISIBLE : View.GONE);

		if (type == ShowInfoType.BY_LABEL_ID) {
			labelId = getIntent().getStringExtra("labelId");
		} else if (type == ShowInfoType.BY_LABEL_ID_THEOR) {
			labelId = getIntent().getStringExtra("labelId");
		} else if (type == ShowInfoType.BY_LABEL_ID_LIST) {
			labelIdList = getIntent().getStringArrayListExtra("labelIdList");
		} else if (type == ShowInfoType.BY_LOCATION_ID) {
			locationId = getIntent().getStringExtra("locationId");
		} else if (type == ShowInfoType.BY_LOCATION_CODE) {
			locationCode = getIntent().getStringExtra("locationCode");
		} else if (type == ShowInfoType.BY_LOCATION_CODE_BATCH) {
			batch = getIntent().getStringExtra("batch");
			locationCode = getIntent().getStringExtra("locationCode");
		} else if (type == ShowInfoType.BY_LOCATION_CODE_OZM) {
			ozmList = getIntent().getParcelableArrayListExtra("ozmList");
			locationCode = getIntent().getStringExtra("locationCode");
		} else if (type == ShowInfoType.BY_JSON_LIST) {
			List<String> list = getIntent().getStringArrayListExtra("jsonList");
			jsonList = new ArrayList<>();
			if (list != null) {
				for (String s : list) {
					try {
						jsonList.add(new JSONObject(s));
					} catch (Exception ignored) {
					}
				}
			}
		} else if (type == ShowInfoType.BY_ZAPOR || type == ShowInfoType.BY_KOMINMET
				|| type == ShowInfoType.BY_TRUBOSTAL || type == ShowInfoType.BY_ARCELOR) {
			data = getIntent().getStringExtra("data");
		} else if (type == ShowInfoType.BY_ID_QR) {
			idQr = getIntent().getStringExtra("idQr");
		}

		checkedList = getIntent().getStringArrayListExtra("checkedList");
		filterOzm = getIntent().getStringExtra("ozm");
		filterLength = getIntent().getFloatExtra("length", -1);
		filterWidth = getIntent().getFloatExtra("width", -1);
		filterThickness = getIntent().getFloatExtra("thickness", -1);
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		refreshTitle();
		beginLoad();
	}

	private void beginLoad() {
		if (isLoading() || !buttonRefresh.isEnabled()) return;

		if (type == ShowInfoType.BY_LABEL_ID) {
			beginLoadLabel(labelId);
		} else if (type == ShowInfoType.BY_LABEL_ID_LIST) {
			beginLoadLabelList();
		} else if (type == ShowInfoType.BY_LABEL_ID_THEOR) {
			beginLoadLabelTheor(labelId);
		} else if (type == ShowInfoType.BY_LOCATION_ID) {
			beginLoadLocation(locationId);
		} else if (type == ShowInfoType.BY_LOCATION_CODE) {
			beginLoadLocationByCode(locationCode);
		} else if (type == ShowInfoType.BY_LOCATION_CODE_BATCH) {
			beginLoadLocationByBatch(locationCode, batch);
		} else if (type == ShowInfoType.BY_LOCATION_CODE_OZM) {
			beginLoadLocationByOzm(locationCode, ozmList);
		} else if (type == ShowInfoType.BY_JSON_LIST) {
			beginLoadJsonList(jsonList);
		} else if (type == ShowInfoType.BY_ZAPOR) {
			beginLoadZapor(data);
		} else if (type == ShowInfoType.BY_KOMINMET) {
			beginLoadKominmet(data);
		} else if (type == ShowInfoType.BY_TRUBOSTAL) {
			beginLoadTrubostal(data);
		} else if (type == ShowInfoType.BY_ARCELOR) {
			beginLoadArcelor(data);
		} else if (type == ShowInfoType.BY_ID_QR) {
			beginLoadIdQr(idQr);
		}

	}

	private void refreshTitle() {
		String title = getString(R.string.title_activity_barcode_result);

		if (type == ShowInfoType.BY_LABEL_ID) {
			title = "Інфо по бірці";
		} else if (type == ShowInfoType.BY_LOCATION_ID) {
			title = "Інфо по локації";
		} else if (type == ShowInfoType.BY_LOCATION_CODE) {
			title = Utils.format("Локація %s", locationCode);
		} else if (type == ShowInfoType.BY_JSON_LIST) {
			title = getIntent().getStringExtra("title");
		}

		textContentTitle.setText(title);
	}

	@Override
	protected void onFunctionKey(int number) {
		if (canRefresh && number == 5) {
			beginLoad();
		} else if (canAction && number == 4) {
			beginAction();
		}
	}

	private void beginAction() {
		Intent intent = new Intent();
		intent.putExtra("action", action);
		intent.putExtra("locationCode", locationCode);
		setResult(RESULT_OK, intent);
		finish();
	}

	private void beginLoadLocationByOzm(String locationCode, List<Ozm> ozmList) {
		showLoading(R.string.text_please_wait);
		buttonRefresh.setEnabled(false);

		Utils.runOnBackground(() -> {

			String url = config.getUrlApi() + "getlocationinfo";
			url = net.addUrlParam(url, "location_code", locationCode);
			JsonResult result = net.downloadJson(url);

			List<Label> list = new ArrayList<>();

			if (result.isOk()) {
				JSONObject jsonData = Utils.getJsonObject(result.getJson(), "data");
				JSONArray array = Utils.getJsonArray(jsonData, "labels");
				if (array != null) {
					for (int i = 0; i < array.length(); i++) {
						JSONObject item = Utils.getJsonObject(array, i);
						if (item != null) {

							int netto = Utils.getJsonIntIgnoreCase(item, "netT_Weight");
							String descr = Utils.jsonExist(item, "sap_matt_descr") ? Utils.getJsonStringIgnoreCase(item, "sap_matt_descr") : Utils.getJsonStringIgnoreCase(item, "name");
							String ozm = Utils.jsonExist(item, "saP_Ozm") ? Utils.getJsonStringIgnoreCase(item, "saP_Ozm") : Utils.getJsonStringIgnoreCase(item, "ozm");
							float width = Utils.getJsonFloatIgnoreCase(item, "width");
							float length = Utils.getJsonFloatIgnoreCase(item, "length");
							float thickness = Utils.getJsonFloatIgnoreCase(item, "thickness");

							if (netto > 0 && inOzm(descr, ozm, width, length, thickness)) {
								Label label = Label.fromJson(item.toString());
								if (label != null) list.add(label);
							}
						}
					}
				}
			}

			runOnUiThread(() -> endLoadLocationByOzm(locationCode, ozmList, list, result));
		});
	}

	private void beginLoadLocationByBatch(String locationCode, String batch) {
		showLoading(R.string.text_please_wait);
		buttonRefresh.setEnabled(false);

		Utils.runOnBackground(() -> {
			String url = config.getUrlApi() + "getbatchinfo";
			url = net.addUrlParam(url, "sap_batch", batch);

			JsonResult result = net.downloadJson(url);

			List<Label> list = new ArrayList<>();

			if (result.isOk()) {
				JSONArray array = Utils.getJsonArray(result.getJson(), "data");
				if (array != null) {
					for (int i = 0; i < array.length(); i++) {
						JSONObject json = Utils.getJsonObject(array, i);
						if (json != null) {

							boolean exist = Utils.jsonExist(json, "netT_Weight");
							String itemLocationCode = Utils.getJsonStringIgnoreCase(json, "location_Code");

							if (itemLocationCode.equalsIgnoreCase(locationCode)) {
								if (exist) {
									int netto = Utils.getJsonIntIgnoreCase(json, "netT_Weight");
									if (netto > 0) {
										Label label = Label.fromJson(json.toString());
										if (label != null) list.add(label);
									}
								} else {
									Label label = Label.fromJson(json.toString());
									if (label != null) list.add(label);
								}
							}
						}
					}
				}
			}

			runOnUiThread(() -> endLoadLocationByBatch(locationCode, batch, list, result));
		});

	}

	private void endLoadLocationByOzm(String locationCode, List<Ozm> ozmList, List<Label> list, JsonResult result) {
		hideLoading();
		buttonRefresh.setEnabled(true);

		if (result.isOk()) {
			showContent("Локація " + locationCode, list);
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoadLocationByOzm(locationCode, ozmList));
		}
	}

	private boolean inOzm(String descr, String sapOzm, float width, float length, float thickness) {

		if (ozmList == null) return false;

		for (Ozm ozm : ozmList) {
			if (//ozm.getName().equalsIgnoreCase(descr) &&
					   ozm.getOzm().equalsIgnoreCase(sapOzm)
					&& ozm.getWidth() == width
					&& ozm.getLength() == length && ozm.getThickness() == thickness) {
				return true;
			}
		}

		return false;
	}

	private void endLoadLocationByBatch(String locationCode, String batch, List<Label> list, JsonResult result) {
		hideLoading();
		buttonRefresh.setEnabled(true);

		if (result.isOk()) {
			showContent("Локація " + locationCode, list);
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoadLocationByBatch(locationCode, batch));
		}
	}

	private void beginLoadLocationByCode(String locCode) {
		showLoading(R.string.text_please_wait);
		buttonRefresh.setEnabled(false);

		Utils.runOnBackground(() -> {
			String url = config.getUrlApi() + "getlocationinfo";
			url = net.addUrlParam(url, "location_code", locCode);
			if (config.isEo()){
				url = net.addUrlParam(url, "smc_id", storageFilter);
			} else {
				if (storageFilter != null) url = net.addUrlParam(url, "store", storageFilter);
				if (storageFilter != null && storageFilter.contains("0001"))
					url = net.addUrlParam(url, "smc_id", parseInt(config.getSmcId()) + 1);
			}
			JsonResult result = net.downloadJson(url);
			List<Label> list = parseLabelsFromLocationInfo(result, locCode);
			Collections.sort(list, (o1, o2) ->
					Integer.compare(
							parseInt(o1.getBatch())==0?
									parseInt(o1.getBatch().replaceAll("[[:alpha:]]","9"))>9999?parseInt(o1.getBatch().replaceAll("[[:alpha:]]","9")):Integer.MAX_VALUE
									:parseInt(o1.getBatch()),
							parseInt(o2.getBatch())==0?
									parseInt(o2.getBatch().replaceAll("[[:alpha:]]","9"))>9999?parseInt(o2.getBatch().replaceAll("[[:alpha:]]","9")):Integer.MAX_VALUE
									:parseInt(o2.getBatch())
			) );
			runOnUiThread(() -> endLoadLocation(result, locCode, list));
		});

	}

	private void beginLoadLocation(String locationId) {
		showLoading(R.string.text_please_wait);
		buttonRefresh.setEnabled(false);

		Utils.runOnBackground(() -> {
			Network.NetworkResultValue<String> resultValue = net.getLocationCodeNet(locationId);
			String locCode = resultValue.getValue();
			JsonResult result = resultValue.getResult();
			if (resultValue.isOk()) {
				String url = config.getUrlApi() + "getlocationinfo";
				url = net.addUrlParam(url, "location_code", locCode);
				result = net.downloadJson(url);
			}

			JsonResult finalResult = result;
			List<Label> list = parseLabelsFromLocationInfo(result, locCode);
			runOnUiThread(() -> endLoadLocation(finalResult, locCode, list));
		});
	}

	private List<Label> parseLabelsFromLocationInfo(JsonResult result, String locCode) {
		List<Label> list = null;

		if (result.isOk()) {

			list = new ArrayList<>();
			JSONObject json = Utils.getJsonObject(result.getJson(), "data");

			if (json != null) {
				JSONArray labels = Utils.getJsonArray(json, "labels");

				if (labels != null && labels.length() > 0) {
					for (int i = 0; i < labels.length(); i++) {

						JSONObject jsonObject = Utils.getJsonObject(labels, i);
						if (jsonObject == null) continue;

						boolean accept = !Utils.jsonExist(jsonObject, "netT_Weight") || Utils.getJsonIntIgnoreCase(jsonObject, "netT_Weight") > 0;

						if (accept) {
							Label label = Label.fromJson(jsonObject.toString());
							if (label != null) {
								label.setLocationCode(locCode);
								list.add(label);
							}
						}
					}
				}
			}
		}

		return list;
	}

	private JSONObject findInCheckedList(String findLabelId) {
		if (checkedList == null) return null;
		for (String item : checkedList) {
			JSONObject json = Utils.getJsonObject(item);
			if (json != null && Utils.getJsonStringIgnoreCase(json, "label_id").equalsIgnoreCase(findLabelId)) {
				return json;
			}
		}
		return null;
	}

	private void endLoadLocation(JsonResult result, String locCode, List<Label> list) {
		hideLoading();
		buttonRefresh.setEnabled(true);

		if (result.isOk()) {
			showContent("Локація " + (locCode == null ? "" : locCode), list);
		} else {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.location_identity_error, null);
		}
	}

	private void beginLoadKominmet(String line) {
		showLoading(R.string.text_please_wait);
		buttonRefresh.setEnabled(false);

		Utils.runOnBackground(() -> {

			List<Label> list = new ArrayList<>();

			StringBuilder sb = new StringBuilder();
			try {
				ScanItem scanItem = new ScanItem(line);

				String name = scanItem.getData(12);
				int netto = (int) Math.round(Utils.parseDouble(scanItem.getData(9)) * /**/ 1000);
				int pack = 0;
				String id = scanItem.getData(1);

				String plavka = scanItem.getData(2);
				String zavBatch = scanItem.getData(3);

				String[] size = app.stringToSize(scanItem.getData(5));

				sb.append("{");
				sb.append(Utils.format("\"%s\": \"%s\",", "id", id));
				sb.append(Utils.format("\"%s\": \"%s\",", "name", name));
				sb.append(Utils.format("\"%s\": \"%s\",", "width", size[0]));
				sb.append(Utils.format("\"%s\": \"%s\",", "length", size[1]));
				sb.append(Utils.format("\"%s\": \"%s\",", "thickness", size[2]));
				sb.append(Utils.format("\"%s\": \"%s\",", "netT_Weight", netto));
				sb.append(Utils.format("\"%s\": \"%s\",", "pacK_Weight", pack));
				sb.append(Utils.format("\"%s\": \"%s\",", "zavBatch", zavBatch));
				sb.append(Utils.format("\"%s\": \"%s\",", "plavka", plavka));
				sb.append(Utils.format("\"%s\": \"%s\",", "batch", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "ozm", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "location_id", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "ttN_Carrier_ID", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "teoR_Weight", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "statuS_OUT", ""));
				sb.append(Utils.format("\"%s\": \"%s\"", "line", line));
				sb.append("}");

				Label label = Label.fromJson(sb.toString());
				if (label != null) list.add(label);
			} catch (Exception ignored) {

			}

			runOnUiThread(() -> endLoadKominmet(line, list));

		});
	}

	private void endLoadKominmet(String line, List<Label> list) {
		hideLoading();
		buttonRefresh.setEnabled(true);
		showContent("Бірка \"Комінмет\"", list);
	}

	private void beginLoadTrubostal(String line) {
		showLoading(R.string.text_please_wait);
		buttonRefresh.setEnabled(false);

		Utils.runOnBackground(() -> {

			List<Label> list = new ArrayList<>();

			StringBuilder sb = new StringBuilder();
			try {
				ScanItem scanItem = new ScanItem(line);

				String name = scanItem.getData(1);
				int netto = 0;
				int brutto = 0;
				int pack = brutto - netto;
				String plavka = scanItem.getData(3); //№ Плавки
				String zavBatch = ""; //Заводская партия
				String zavOdin = ""; //Единица продукции
				String id = scanItem.getData(8);

				float[] size = Utils.parseSize(scanItem.getData(0));
				float thickness = size[0];
				float width = size[1];
				float length = size[2];

				sb.append("{");
				sb.append(Utils.format("\"%s\": \"%s\",", "id", id));
				sb.append(Utils.format("\"%s\": \"%s\",", "name", name));
				sb.append(Utils.format("\"%s\": \"%s\",", "width", width));
				sb.append(Utils.format("\"%s\": \"%s\",", "length", length));
				sb.append(Utils.format("\"%s\": \"%s\",", "thickness", thickness));
				sb.append(Utils.format("\"%s\": \"%s\",", "netT_Weight", netto));
				sb.append(Utils.format("\"%s\": \"%s\",", "pacK_Weight", pack));
				sb.append(Utils.format("\"%s\": \"%s\",", "zavBatch", zavBatch));
				sb.append(Utils.format("\"%s\": \"%s\",", "plavka", plavka));
				sb.append(Utils.format("\"%s\": \"%s\",", "zavOdin", zavOdin));
				sb.append(Utils.format("\"%s\": \"%s\",", "batch", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "ozm", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "location_id", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "ttN_Carrier_ID", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "teoR_Weight", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "statuS_OUT", ""));
				sb.append(Utils.format("\"%s\": \"%s\"", "line", line));
				sb.append("}");

				Label label = Label.fromJson(sb.toString());
				if (label != null) list.add(label);
			} catch (Exception ignored) {

			}

			runOnUiThread(() -> endLoadTrubostal(line, list));
		});
	}

	private void endLoadTrubostal(String line, List<Label> list) {
		hideLoading();
		buttonRefresh.setEnabled(true);
		showContent("Інфо по бірці", list);
	}

	private void beginLoadArcelor(String line) {
		showLoading(R.string.text_please_wait);
		buttonRefresh.setEnabled(false);

		Utils.runOnBackground(() -> {

			List<Label> list = new ArrayList<>();

			StringBuilder sb = new StringBuilder();
			try {
				ScanItem scanItem = new ScanItem(line);

				String name = "Арселлор";
				int netto = 0;
				int brutto = 0;
				int pack = brutto - netto;
				String plavka = ""; //№ Плавки
				String zavBatch = ""; //Заводская партия
				String zavOdin = ""; //Единица продукции
				String id = scanItem.getData(0);

				float thickness = 0;
				float width = 0;
				float length = 0;

				sb.append("{");
				sb.append(Utils.format("\"%s\": \"%s\",", "id", id));
				sb.append(Utils.format("\"%s\": \"%s\",", "name", name));
				sb.append(Utils.format("\"%s\": \"%s\",", "width", width));
				sb.append(Utils.format("\"%s\": \"%s\",", "length", length));
				sb.append(Utils.format("\"%s\": \"%s\",", "thickness", thickness));
				sb.append(Utils.format("\"%s\": \"%s\",", "netT_Weight", netto));
				sb.append(Utils.format("\"%s\": \"%s\",", "pacK_Weight", pack));
				sb.append(Utils.format("\"%s\": \"%s\",", "zavBatch", zavBatch));
				sb.append(Utils.format("\"%s\": \"%s\",", "plavka", plavka));
				sb.append(Utils.format("\"%s\": \"%s\",", "zavOdin", zavOdin));
				sb.append(Utils.format("\"%s\": \"%s\",", "batch", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "ozm", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "location_id", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "ttN_Carrier_ID", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "teoR_Weight", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "statuS_OUT", ""));
				sb.append(Utils.format("\"%s\": \"%s\"", "line", line));
				sb.append("}");

				Label label = Label.fromJson(sb.toString());
				if (label != null) list.add(label);
			} catch (Exception ignored) {

			}

			runOnUiThread(() -> endLoadArcelor(line, list));
		});
	}

	private void endLoadArcelor(String line, List<Label> list) {
		hideLoading();
		buttonRefresh.setEnabled(true);
		showContent("Інфо по бірці", list);
	}

	private void beginLoadZapor(String line) {
		showLoading(R.string.text_please_wait);
		buttonRefresh.setEnabled(false);

		Utils.runOnBackground(() -> {

			List<Label> list = new ArrayList<>();

			StringBuilder sb = new StringBuilder();
			try {
				ScanItem scanItem = new ScanItem(line);

				String name = scanItem.getData(12);
				int netto = parseInt(scanItem.getData(10));
				int brutto = parseInt(scanItem.getData(11));
				int pack = brutto - netto;
				String plavka = scanItem.getData(7); //№ Плавки
				String zavBatch = scanItem.getData(8); //Заводская партия
				String zavOdin = scanItem.getData(9); //Единица продукции
				String id = Utils.format("%s&%s&%s&%s",
						scanItem.getData(1),
						scanItem.getData(2),
						scanItem.getData(3),
						scanItem.getData(4)
				);

				float[] size = Utils.parseSize(scanItem.getData(13));
				float thickness = size[0];
				float width = size[1];
				float length = size[2];

				sb.append("{");
				sb.append(Utils.format("\"%s\": \"%s\",", "id", id));
				sb.append(Utils.format("\"%s\": \"%s\",", "name", name));
				sb.append(Utils.format("\"%s\": \"%s\",", "width", width));
				sb.append(Utils.format("\"%s\": \"%s\",", "length", length));
				sb.append(Utils.format("\"%s\": \"%s\",", "thickness", thickness));
				sb.append(Utils.format("\"%s\": \"%s\",", "netT_Weight", netto));
				sb.append(Utils.format("\"%s\": \"%s\",", "pacK_Weight", pack));
				sb.append(Utils.format("\"%s\": \"%s\",", "zavBatch", zavBatch));
				sb.append(Utils.format("\"%s\": \"%s\",", "plavka", plavka));
				sb.append(Utils.format("\"%s\": \"%s\",", "zavOdin", zavOdin));
				sb.append(Utils.format("\"%s\": \"%s\",", "batch", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "ozm", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "location_id", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "ttN_Carrier_ID", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "teoR_Weight", ""));
				sb.append(Utils.format("\"%s\": \"%s\",", "statuS_OUT", ""));
				sb.append(Utils.format("\"%s\": \"%s\"", "line", line));
				sb.append("}");

				Label label = Label.fromJson(sb.toString());
				if (label != null) list.add(label);
			} catch (Exception ignored) {

			}

			runOnUiThread(() -> endLoadZapor(line, list));
		});
	}

	private void endLoadZapor(String line, List<Label> list) {
		hideLoading();
		buttonRefresh.setEnabled(true);
		showContent("Інфо по бірці", list);
	}

	private void beginLoadLabelTheor(String labelId) {
		showLoading(R.string.text_please_wait);
		buttonRefresh.setEnabled(false);

		Utils.runOnBackground(() -> {
			String url = config.getUrlApi() + "getlabelinfo";
			url = net.addUrlParam(url, "label_id", labelId);

			List<Label> labelList = new ArrayList<>();
			JsonResult result = net.downloadJson(url);

			Label labelBase = Label.fromJson(Utils.getJsonObject(result.getJson(), "data"));

			if (result.isOk() && labelBase != null) {

				Network.NetworkResultValue<String> resultValue = net.getLocationCodeNet(String.valueOf(labelBase.getLocationId()));
				if (resultValue.isOk()) {
					String locCode = resultValue.getValue();
					log("locationCode: %s", locCode);

					url = config.getUrlApi() + "getlocationinfo2";
					url = net.addUrlParam(url, "location_code", locCode);
					url = net.addUrlParam(url, "ozm", labelBase.getOzm());
					url = net.addUrlParam(url, "length", String.valueOf(labelBase.getLength()));
					url = net.addUrlParam(url, "width", String.valueOf(labelBase.getWidth()));
					url = net.addUrlParam(url, "thickness", String.valueOf(labelBase.getThickness()));
					url = net.addUrlParam(url, "nett_weight", String.valueOf(labelBase.getWeightNetto()));
					url = net.addUrlParam(url, "teor_weight", "1");

					result = net.downloadJson(url);
					if (result.isOk()) {
						JSONObject jsonData = Utils.getJsonObject(result.getJson(), "data");
						JSONArray array = Utils.getJsonArray(jsonData, "labels");
						if (array != null) {
							for (int i = 0; i < array.length(); i++) {
								String itemLabelId = Utils.getJsonString(array, i);
								if (itemLabelId != null && itemLabelId.length() > 0) {
									Label label = labelBase.copyLabel(itemLabelId);
									if (label != null && label.isTheor()) {
										label.setLocationCode(locCode);
										labelList.add(label);
									}
								}
                                /*Label label = Label.fromJson(item);
                                if (label != null && label.isTheor()
                                        && label.getOzm().equalsIgnoreCase(labelBase.getOzm())
                                        && label.getWeightNetto() == labelBase.getWeightNetto()
                                        && label.getLength() == labelBase.getLength()
                                        && label.getWidth() == labelBase.getWidth()
                                        && label.getThickness() == labelBase.getThickness()
                                ) {
                                    labelList.add(label);
                                }*/
							}
						}
					}
				} else {
					result = resultValue.getResult();
				}
			}

			JsonResult finalResult = result;
			runOnUiThread(() -> endLoadLabelTheor(finalResult, labelId, labelList));
		});
	}

	private void endLoadLabelTheor(JsonResult result, String labelId, List<Label> labelList) {
		hideLoading();
		buttonRefresh.setEnabled(true);

		if (result.isOk()) {
			showContent("Теоретична вага", labelList);
		} else if (result.getStatus() == LoadResultStatus.S007) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_s007, null);
		} else if (result.getStatus() == LoadResultStatus.ZERO) {
			//
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoadLabelTheor(labelId));
		}
	}

	private void beginLoadLabel(String labelId) {
		showLoading(R.string.text_please_wait);
		buttonRefresh.setEnabled(false);

		Utils.runOnBackground(() -> {
			String url = config.getUrlApi() + "getlabelinfo";
			url = net.addUrlParam(url, "label_id", labelId);

			boolean isTheor = false;
			String locCode = null;
			JsonResult result = net.downloadJson(url);
			if (result.isOk()) {
				JSONObject json = Utils.getJsonObject(result.getJson(), "data");
				isTheor = Utils.getJsonStringIgnoreCase(json, "teoR_Weight").equalsIgnoreCase("true");
				String id = Utils.getJsonStringIgnoreCase(json, "location_id");
				Network.NetworkResultValue<String> resultValue = net.getLocationCodeNet(id);
				if (resultValue.isOk()) {
					locCode = resultValue.getValue();
				} else {
					result = resultValue.getResult();
				}
			} else {
				String line = getIntent().getStringExtra("scanItem");
				LabelBatch labelBatch = db.labelBatchDao().getByLabelId(labelId);
				if (labelBatch != null) {
					ScanItem scanItem = line == null ? null : new ScanItem(line);
					runOnUiThread(() -> endLoadLabelOffline(labelBatch, scanItem));
					return;
				}
			}

			String finalLocCode = locCode;

			if (result.isOk() && isTheor) {
				runOnUiThread(() -> beginLoadLabelTheor(labelId));
			} else {
				JsonResult finalResult = result;
				runOnUiThread(() -> endLoadLabel(finalResult, labelId, finalLocCode));
			}

		});

	}

	private void beginLoadIdQr(String idQr) {
		showLoading(R.string.text_please_wait);
		buttonRefresh.setEnabled(false);

		Utils.runOnBackground(() -> {
			String url = config.getUrlApi() + "getlabelinfobyqr";
			url = net.addUrlParam(url, "ID_QR", idQr).replace("%25", "%");

			String locCode = null;
			JsonResult result = net.downloadJson(url);
			if (result.isOk()) {
				JSONObject json = Utils.getJsonObject(result.getJson(), "data");
				String id = Utils.getJsonStringIgnoreCase(json, "location_id");
				Network.NetworkResultValue<String> resultValue = net.getLocationCodeNet(id);
				if (resultValue.isOk()) {
					locCode = resultValue.getValue();
				} else {
					result = resultValue.getResult();
				}
			}

			String finalLocCode = locCode;
			JsonResult finalResult = result;

			runOnUiThread(() -> endLoadIdQr(finalResult, idQr, finalLocCode));

		});

	}

	private void endLoadIdQr(JsonResult result, String idQr, String locationCode) {
		hideLoading();
		buttonRefresh.setEnabled(true);

		JSONObject json = Utils.getJsonObject(result.getJson(), "data");

		if (result.isOk() && json != null) {

			try {
				json = json.put("locationCode", locationCode);
			} catch (Exception e) {
				log(e, "endLoadLabel(%s)", result);
			}

			List<Label> list = new ArrayList<>();
			Label label = Label.fromJson(json.toString());
			if (label != null) list.add(label);

			showContent("Бірка", list);

		} else if (result.getStatus() == LoadResultStatus.S007) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_s007, null);
		} else if (result.getStatus() == LoadResultStatus.ZERO) {
			//
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoadIdQr(idQr));
		}
	}

	private void endLoadLabelOffline(LabelBatch labelBatch, ScanItem scanItem) {
		hideLoading();
		buttonRefresh.setEnabled(true);

		Label label = Label.empty();
		label.setId(labelBatch.getLabelid());
		label.setBatch(labelBatch.getBatch());
		if (scanItem != null && scanItem.getType() == ScanItem.ScanItemType.SMC06) {
			label.setWeightNetto(parseInt(scanItem.getData(6)));
			label.setWeightPack(parseInt(scanItem.getData(9)));
			label.setOzm(scanItem.getData(8));
			label.setName(scanItem.getData(2));
			label.setLength(Utils.parseFloat(scanItem.getData(3)));
			label.setWidth(Utils.parseFloat(scanItem.getData(4)));
			label.setThickness(Utils.parseFloat(scanItem.getData(5)));
		}

		List<Label> list = new ArrayList<>();
		list.add(label);
		showContent("Бірка (офлайн)", list, true);
	}

	private void endLoadLabel(JsonResult result, String labelId, String locationCode) {
		hideLoading();
		buttonRefresh.setEnabled(true);

		JSONObject json = Utils.getJsonObject(result.getJson(), "data");

		if (result.isOk() && json != null) {

			try {
				json = json.put("id", labelId);
				json = json.put("locationCode", locationCode);
			} catch (Exception e) {
				log(e, "endLoadLabel(%s)", result);
			}

			List<Label> list = new ArrayList<>();
			Label label = Label.fromJson(json.toString());
			if (label != null) list.add(label);

			showContent("Бірка", list);

		} else if (result.getStatus() == LoadResultStatus.S007) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_s007, null);
		} else if (result.getStatus() == LoadResultStatus.ZERO) {
			//
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoadLabel(labelId));
		}
	}

	private boolean isOzmFilter() {
		return filterOzm != null && filterOzm.length() > 0;
	}

	private AdapterLabelGroup findGroup(List<IFlexible> flexibleList, String name, float width, float length, float thickness) {
		for (int i = 0; i < flexibleList.size(); i++) {
			if (flexibleList.get(i) instanceof AdapterLabelGroup) {
				AdapterLabelGroup group = (AdapterLabelGroup) flexibleList.get(i);
				if (group.getName().equalsIgnoreCase(name) &&
						(group.getWidth() == width) &&
						(group.getLength() == length) &&
						(group.getThickness() == thickness)
				) {
					return group;
				}
			}
		}
		return null;
	}

	private void beginLoadJsonList(ArrayList<JSONObject> jsonList) {
		List<Label> list = new ArrayList<>();
		for (JSONObject jsonObject : jsonList) {
			Label label = Label.fromJson(jsonObject.toString());
			if (label != null) list.add(label);
		}
		showContent(null, list);
	}

	private boolean acceptFilter(String ozm, float length, float width, float thickness) {
		if (!isOzmFilter()) return true;

		return ozm.equalsIgnoreCase(filterOzm) &&
				(filterLength == -1 || filterLength == length) &&
				(filterWidth == -1 || filterWidth == width) &&
				(filterThickness == -1 || filterThickness == thickness);
	}

	private void showContent(String contentTitle, List<Label> list) {
		showContent(contentTitle, list, false);
	}

	private void showContent(String contentTitle, List<Label> list, boolean offline) {

		showLoading(R.string.text_please_wait);
		buttonRefresh.setEnabled(false);

		Utils.runOnBackground(() -> {

			long s1 = System.currentTimeMillis();

			List<IFlexible> flexibleList = new ArrayList<>();

			for (int i = 0; i < list.size(); i++) {

				Label item = list.get(i);

				if (!acceptFilter(item.getOzm(), item.getLength(), item.getWidth(), item.getThickness()))
					continue;

				JSONObject checkedJson = findInCheckedList(item.getId());

				AdapterLabel itemLabel = new AdapterLabel(null, item, list.size() == 1, list.size() > 1,
						checkedJson != null, offline, false, this
				);

				try {
					Date dtChecked = app.getDateTimeFormat().parse(Utils.getJsonStringIgnoreCase(checkedJson, "scan_DateTime"));
					if (dtChecked != null) itemLabel.setCheckedDate(dtChecked);
				} catch (Exception ignored) {
				}

				if (list.size() == 1 || !showGroups) {
					flexibleList.add(itemLabel);
				} else {

					AdapterLabelGroup group = findGroup(flexibleList, item.getName(), item.getWidth(), item.getLength(), item.getThickness());
					if (group == null) {
						group = new AdapterLabelGroup(item.getName(), item.getWidth(), item.getLength(), item.getThickness(), item.getOzm());
						flexibleList.add(group);
					}

					group.addSubItem(itemLabel);
					itemLabel.setGroup(group);

				}

			}

			Collections.sort(flexibleList, (o1, o2) -> {
				int c = 0;
				if (o1 instanceof AdapterLabelGroup && o2 instanceof AdapterLabelGroup) {
					return ((AdapterLabelGroup) o1).getOzm().compareToIgnoreCase(((AdapterLabelGroup) o2).getOzm());
				}
				return c;
			});

			if (checkedList != null) {
				for (IFlexible iFlexible : flexibleList) {
					if (iFlexible instanceof AdapterLabelGroup) {
						AdapterLabelGroup group = (AdapterLabelGroup) iFlexible;
						try {
							Collections.sort(group.getSubItems(), (o1, o2) -> {
								int c = Boolean.compare(!o1.isChecked(), !o2.isChecked());
								if (c == 0) {
									if (o1.getCheckedDate() != null && o2.getCheckedDate() != null) {
										c = Long.compare(o2.getCheckedDate().getTime(), o1.getCheckedDate().getTime());
									}
								}
								return c;
							});
						} catch (Exception ignored) {
						}
					}
				}
			}

			for (IFlexible iFlexible : flexibleList) {
				if (iFlexible instanceof AdapterLabelGroup) {
					AdapterLabelGroup group = (AdapterLabelGroup) iFlexible;
					int totalNetto = 0;
					int totalCount = 0;
					List<AdapterLabel> labels = group.getSubItems();
					if (labels != null) {
						for (AdapterLabel label : labels) {
							totalNetto += label.getLabel().getWeightNetto();
							totalCount++;
						}
					}
					group.setTotalNetto(totalNetto);
					if (contentTitle != null && contentTitle.equalsIgnoreCase("Теоретична вага")) {
						group.setTheor(totalCount);
					}
				}
			}

			adapter = new FlexibleAdapter<>(flexibleList);

			long s2 = System.currentTimeMillis();
			log("ms: %d ms", s2 - s1);

			runOnUiThread(() -> {

				listView.setAdapter(adapter);
				if (adapter != null && adapter.getItemCount() > 0)
					adapter.smoothScrollToPosition(0);
				if (contentTitle != null) textContentTitle.setText(contentTitle);
				textNotFound.setVisibility(flexibleList.isEmpty() ? View.VISIBLE : View.GONE);
				//listView.setVisibility(flexibleList.isEmpty() ? View.GONE : View.VISIBLE);

				hideLoading();
				buttonRefresh.setEnabled(true);
			});
		});

	}

	@Override
	public void onTransferClicked(AdapterLabel item) {
		log("transfer label %s", item.getLabel().getId());
        /*Intent intent = new Intent(this, TransferLabelManyActivity.class);
        intent.putExtra("labelId", item.getLabel().getId());
        startActivity(intent);*/
		Intent intent = new Intent(this, LocationSelectActivity.class);
		intent.putExtra("labelId", item.getLabel().getId());
		intent.putExtra("labelStorage", item.getLabel().getStorage());
		intent.putExtra("withSmc", true);
		intent.putExtra("withStorage", true);
		startActivityForResult(intent, REQUEST_LOCATION_SELECT);
	}

	@Override
	public void onPrintClicked(AdapterLabel item) {

		String content;
		String dplTitle = "";

		int theorCount = item.getLabel().isTheor() && item.getGroup() != null ? item.getGroup().getTheorCount() : 0;

		content = app.generateDplLabel(
				item.getLabel().getId(), Calendar.getInstance().getTime(), item.getLabel().getName(),
				item.getLabel().getWidth(), item.getLabel().getLength(), item.getLabel().getThickness(), item.getLabel().getWeightNetto(), item.getLabel().getWeightPack(),
				0, item.getLabel().getOzm(), item.getLabel().getBatch(),
				item.getLabel().getCarrier(), 0, item.getLabel().isTheor(), theorCount, item.getLabel().getLocationCode(), item.getLabel().getZavBatch(), item.getLabel().getZavPlavka(), item.getLabel().getZavOdin(),
				item.getLabel().getLowPricePercent(), item.getLabel().getManufacturer(), item.getLabel().getSortCriterion(),
				item.getLabel().getStorage()
		);

		dplTitle += Utils.format("<b>%s</b><br>", item.getLabel().getName());
		dplTitle += Utils.format("Розмір: %s<br>", app.sizeToString(item.getLabel().getWidth(), item.getLabel().getLength(), item.getLabel().getThickness()));
		dplTitle += Utils.format("Вага нетто: %s<br>", item.getNettoFact() == -1 ? item.getLabel().getWeightNetto() : item.getNettoFact());
		dplTitle += Utils.format("Партія: %s", item.getLabel().getBatch());

		beginPrint(dplTitle, content);

	}

	public void beginPrint(String title, String content) {
		if (isLoading()) return;

		showLoading(R.string.text_printing_title);

		Utils.runOnBackground(() -> {
			final Printer.PrintResult result = Printer.sendCommand(title, config.getPrinter(), content);
			runOnUiThread(() -> endPrint(title, content, result));
		});
	}

	private void endPrint(String title, String content, Printer.PrintResult result) {
		hideLoading();

		if (result.getStatus() == Printer.PrintResultStatus.OK) {
			showToast(R.string.text_print_result_succeeded);
			//app.sendFaPrint();
		} else {
			@StringRes final int message = app.getPrintResultMessage(result);
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> beginPrint(title, content));
		}
	}

	@Override
	public void onEditClicked(AdapterLabel item) {
        /*Intent intent = new Intent(this, PincodeActivity.class);
        intent.putExtra("action", "labelEdit");
        intent.putExtra("labelId", item.getLabel().getId());
        startActivityForResult(intent, REQUEST_ACTION);*/

		if (item != null) {
			Intent intent = new Intent(this, LabelEditActivity.class);
			intent.putExtra("labelId", item.getLabel().getId());
			intent.putExtra("name", item.getLabel().getName());
			intent.putExtra("netto", item.getLabel().getWeightNetto());
			intent.putExtra("pack", item.getLabel().getWeightPack());
			intent.putExtra("batch", item.getLabel().getBatch());
			intent.putExtra("lowPricePercent", item.getLabel().getLowPricePercent());
			intent.putExtra("release", item.getLabel().isRelease());
			startActivityForResult(intent, REQUEST_DEFAULT);
		}
	}

	private AdapterLabel findByLabel(String labelId) {
		if (adapter == null) return null;
		List<IFlexible> list = adapter.getCurrentItems();
		for (IFlexible itemFlexible : list) {
			if (itemFlexible instanceof AdapterLabelGroup) {
				List<AdapterLabel> listSub = ((AdapterLabelGroup) itemFlexible).getSubItems();
				for (AdapterLabel item : listSub) {
					if (item.getLabel().getId().equalsIgnoreCase(labelId)) return item;
				}
			} else if (itemFlexible instanceof AdapterLabel) {
				if (((AdapterLabel) itemFlexible).getLabel().getId().equalsIgnoreCase(labelId))
					return (AdapterLabel) itemFlexible;
			}
		}
		return null;
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == REQUEST_SPLIT && resultCode == RESULT_OK && data != null) {
			String oldLabelId = data.getStringExtra("labelId");
			String newLabelId = data.getStringExtra("newLabelId");
			showInfoByLabelIdList(oldLabelId, newLabelId);
			beginLoad();
		}

		if (requestCode == REQUEST_ACTION && resultCode == RESULT_OK && data != null) {

			String intentAction = data.getStringExtra("action");
			String itemLabelId = data.getStringExtra("labelId");

			if (intentAction != null && intentAction.equalsIgnoreCase("labelEdit")) {

				AdapterLabel item = findByLabel(itemLabelId);

				if (item != null) {
					Intent intent = new Intent(this, LabelEditActivity.class);
					intent.putExtra("labelId", item.getLabel().getId());
					intent.putExtra("name", item.getLabel().getName());
					intent.putExtra("netto", item.getLabel().getWeightNetto());
					intent.putExtra("pack", item.getLabel().getWeightPack());
					intent.putExtra("batch", item.getLabel().getBatch());
					intent.putExtra("lowPricePercent", item.getLabel().getLowPricePercent());
					intent.putExtra("release", item.getLabel().isRelease());
					startActivityForResult(intent, REQUEST_DEFAULT);
				}

			}

		}

		if (requestCode == REQUEST_DEFAULT && resultCode == RESULT_OK) {
			beginLoad();
		}

		if (requestCode == REQUEST_LOCATION_SELECT && resultCode == RESULT_OK && data != null) {
			String labelIdNew = data.getStringExtra("labelId");
			String locationCodeNew = data.getStringExtra("locationCode");
			String smcId = data.getStringExtra("smcId");
			String storage = data.getStringExtra("storage");
			beginTransferLabel(labelIdNew, locationCodeNew, smcId, storage);
		}
	}

	@Override
	public void onSplitClicked(AdapterLabel item) {
		if (!item.getLabel().isRelease()) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_label_not_released, null);
			return;
		}

		String splitLabelId = item.getLabel().getId();
		AdapterLabelGroup group = item.getGroup();
		if (group != null && group.isTheor()) {
			for (AdapterLabel subItem : group.getSubItems()) {
				if (!subItem.getLabel().getId().equalsIgnoreCase(splitLabelId)) {
					splitLabelId = subItem.getLabel().getId();
					log("Theor label id: %s", splitLabelId);
					break;
				}
			}
		}

		Intent intent = new Intent(this, SplitActivity.class);
		intent.putExtra("labelId", splitLabelId);
		intent.putExtra("weight", item.getLabel().getWeightNetto());
		startActivityForResult(intent, REQUEST_SPLIT);
	}

	@Override
	public void onOzmViewClicked(AdapterLabel item) {
		log("OZM VIEW: %s", item.getLabel().getOzm());
	}

	@Override
	public void onBackPressed() {
		if (getIntent().getBooleanExtra("useResult", false)) {
			setResult(RESULT_OK);
		}
		super.onBackPressed();
	}

	@Override
	public void onBarcodeEvent(String barcodeData) {
		if (isLoading()) return;

		if (!(canScan && (type != ShowInfoType.BY_LOCATION_CODE && type != ShowInfoType.BY_LOCATION_ID)))
			return;

		runOnUiThread(() -> {

			ScanItem scanItem = new ScanItem(barcodeData);
			if (!scanItem.isCorrect()) {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_label, null);
				return;
			}

			if ((scanItem.getType() == ScanItem.ScanItemType.LABELID || scanItem.getType() == ScanItem.ScanItemType.SMC06)) {
				beginScanLabel(scanItem.getData(0), parseInt(scanItem.getData(6)));
			}
		});
	}

	private void beginScanLabel(String scannedLabelId, int nettoFact) {
		if (labelExist(scannedLabelId)) {
			setLabelScanned(scannedLabelId, nettoFact);
		} else {
			beginCheckLabel(scannedLabelId);
		}
	}

	private void beginCheckLabel(String scannedLabelId) {
		showLoading(R.string.text_please_wait);

		Utils.runOnBackground(() -> {
			JsonResult result = net.loadLabelInfo(scannedLabelId);
			JSONObject json = Utils.getJsonObject(result.getJson(), "data");
			String scannedLocationCode = null;

			if (result.isOk() && json != null) {
				String scannedLocationId = Utils.getJsonStringIgnoreCase(json, "location_id");
				Network.NetworkResultValue<String> resultValue = net.getLocationCodeNet(scannedLocationId);
				if (resultValue.isOk()) {
					scannedLocationCode = resultValue.getValue();
				} else {
					result = resultValue.getResult();
				}
			}

			String finalScannedLocationCode = scannedLocationCode;
			JsonResult finalResult = result;
			runOnUiThread(() -> endCheckLabel(finalResult, scannedLabelId, finalScannedLocationCode));

		});
	}

	private void endCheckLabel(JsonResult result, String scannedLabelId, String scannedLocationCode) {
		hideLoading();

		if (result.isOk()) {
			showDialogConfirm(R.string.text_warning, getString(R.string.label_in_another_loc_confirm, scannedLocationCode), (dialog, which) -> beginTransferLabel(scannedLabelId, locationCode, null, storageFilter));
		} else if (result.getStatus() == LoadResultStatus.ZERO) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_id_not_found, null);
		} else if (result.getStatus() == LoadResultStatus.S007) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_s007, null);
		} else {
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginCheckLabel(scannedLabelId));
		}
	}

	private void setLabelScanned(String labelId, int nettoFact) {
		log("setLabelScanned(%s)", labelId);

		AdapterLabel label = findByLabel(labelId);

		if (label != null) {
			AdapterLabelGroup group = label.getGroup();
			if (group != null) {

				label.setChecked(true, nettoFact);

				adapter.collapseAll();
				refreshGroupFact(group);
				adapter.updateItem(label);
				adapter.expand(group);
				listView.scrollToPosition(adapter.getGlobalPositionOf(label));
			}
		}
	}

	private void refreshGroupFact(AdapterLabelGroup group) {

		int totalFact = 0;
		List<AdapterLabel> labels = group.getSubItems();
		for (AdapterLabel label : labels) {
			totalFact += label.getNettoFact() == -1 ? 0 : label.getNettoFact();
		}
		group.setTotalFact(totalFact);

		adapter.updateItem(group);
	}

	private void beginTransferLabel(String transferLabelId, String toLocationCode, String smcId, String storage) {
		log("beginTransferLabel(%s, %s)", transferLabelId, toLocationCode);

		showLoading(R.string.text_please_wait);

		StringBuilder sb = new StringBuilder();
		sb.append("[");
		sb.append(Utils.format(
				"{\"Label_Id\":%s,\n" +
						"\"Location_Code\":\"%s\",\n" +
						"%s" + "%s" +
						"\"Date_FV\":\"%s\"\t}",
				transferLabelId,
				toLocationCode,
				(smcId == null ? "" : Utils.format("\t \"SMC_DEST\":\"%s\",\n", smcId)),
				(storage == null ? "" : Utils.format("\t \"LGORT\":\"%s\",\n", storage)),
				app.getDateTimeFormat().format(Calendar.getInstance().getTime())
		));
		sb.append("]");

		String url = config.getUrlApi() + "sapchangelocation";
		net.uploadJson(new JsonUploadTask.JsonUploadTaskParam(url, sb.toString()), result -> endTransferLabel(transferLabelId, toLocationCode, smcId, storage, result));

        /*String url = config.getUrlApi() + "setlabellocation";
        url = net.addUrlParam(url, "label_id", transferLabelId);
        url = net.addUrlParam(url, "location_code", toLocationCode);
        net.uploadJson(new JsonUploadTask.JsonUploadTaskParam(url, ""), result -> endTransferLabel(transferLabelId, toLocationCode, result));
    */
	}

	private void endTransferLabel(String transferLabelId, String toLocationCode, String smcId, String storage, JsonResult result) {
		hideLoading();

		if (result.isOk()) {
			Toast.makeText(this, getString(R.string.label_transfer_complete, toLocationCode), Toast.LENGTH_SHORT).show();
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginTransferLabel(transferLabelId, toLocationCode, smcId, storage));
		}
	}

	private boolean labelExist(String labelId) {
		return findByLabel(labelId) != null;
	}

	private void beginLoadLabelList() {
		showLoading(R.string.text_please_wait);
		buttonRefresh.setEnabled(false);
		Utils.runOnBackground(() -> {

			List<Label> labelList = new ArrayList<>();
			JsonResult result = null;

			for (String itemLabelId : labelIdList) {

				String url = config.getUrlApi() + "getlabelinfo";
				url = net.addUrlParam(url, "label_id", itemLabelId);

				result = net.downloadJson(url);

				if (result.isOk()) {
					JSONObject json = Utils.getJsonObject(result.getJson(), "data");
					String labelLocationId = Utils.getJsonStringIgnoreCase(json, "location_id");
					Network.NetworkResultValue<String> resultValue = net.getLocationCodeNet(labelLocationId);
					if (resultValue.isOk()) {
						Label label = Label.fromJson(json);
						if (label != null) {
							label.setId(itemLabelId);
							label.setLocationCode(resultValue.getValue());
							labelList.add(label);
						}
					} else {
						result = resultValue.getResult();
						break;
					}
				}

			}


			JsonResult finalResult = result;
			runOnUiThread(() -> endLoadLabelList(finalResult, labelList));

		});
	}

	private void endLoadLabelList(JsonResult result, List<Label> labelList) {
		hideLoading();
		buttonRefresh.setEnabled(true);

		if (result != null && result.isOk()) {
			showContent("Інфо по біркам", labelList);
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoadLabelList());
		}
	}
}

