package com.metinvest.smc.tools;

import androidx.annotation.NonNull;

public class PrinterConfig {
	private PrinterType type;
	private String model, mac;

	public PrinterConfig(PrinterType type, String model, String mac) {
		this.type = type;
		this.model = model;
		this.mac = mac;
	}

	public PrinterType getType() {
		return type;
	}

	public String getModel() {
		return model;
	}

	public String getMac() {
		return mac;
	}

	@NonNull
	@Override
	public String toString() {
		return Utils.format("%s %s %s", getType(), getModel(), getMac());
	}
}
