package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.JsonUploadTask;
import com.metinvest.smc.tools.Utils;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ShipmentNewActivity extends MyActivity {

    @BindView(R.id.textNumber)
    EditText textNumber;
    @BindView(R.id.textCar)
    EditText textCar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shipment_new);
        ButterKnife.bind(this);

        textNumber.setText(getIntent().getStringExtra("number"));
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        textCar.requestFocus();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    private void buttonAcceptClick() {
        if (isLoading()) return;

        if (textCar.getText().length() == 0) {
            textCar.requestFocus();
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, "Будь-ласка, заповніть номер транспорту!", null);
            return;
        }

        showLoading(R.string.text_please_wait);

        beginLoad();
    }

    private void beginLoad() {
        String url = config.getUrlApi() + "addshipment";

        String data = Utils.format(
                "{ \"ShipmentNumber\":\"%s\", \"CarNumber\":\"%s\" } ",
                textNumber.getText().toString(), textCar.getText().toString());

        net.uploadJson(new JsonUploadTask.JsonUploadTaskParam(url, data), this::endLoad);
    }

    private void endLoad(JsonResult result) {

        hideLoading();

        if (result.isOk()) {
            beginView();
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> buttonAcceptClick());
        }
    }

    private void beginView() {

        showLoading(R.string.text_please_wait);

        String url = config.getUrlApi() + "shipmentinfo";
        url = net.addUrlParam(url, "shipment_number", textNumber.getText().toString());
        reqGet(url, this::endView);
    }

    private void endView(JsonResult result) {

        hideLoading();

        if (result.isOk()) {
            Intent intent = new Intent();
            intent.putExtra("number", textNumber.getText().toString());
            intent.putExtra("json", Utils.jsonToString(result.getJson()));
            setResult(RESULT_OK, intent);
            finish();
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginView());
        }
    }
}
