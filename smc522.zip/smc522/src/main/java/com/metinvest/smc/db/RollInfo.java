package com.metinvest.smc.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.metinvest.smc.App;
import com.metinvest.smc.tools.Utils;

import java.util.Date;

@Entity
public class RollInfo {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private long rollDate, rollCount, rollOzmCount;

    public RollInfo() {
    }

    @Ignore
    public RollInfo(long id, long rollDate, long rollCount, long rollOzmCount) {
        this.id = id;
        this.rollDate = rollDate;
        this.rollCount = rollCount;
        this.rollOzmCount = rollOzmCount;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getRollDate() {
        return rollDate;
    }

    public void setRollDate(long rollDate) {
        this.rollDate = rollDate;
    }

    public long getRollCount() {
        return rollCount;
    }

    public void setRollCount(long rollCount) {
        this.rollCount = rollCount;
    }

    public long getRollOzmCount() {
        return rollOzmCount;
    }

    public void setRollOzmCount(long rollOzmCount) {
        this.rollOzmCount = rollOzmCount;
    }

    @NonNull
    @Override
    public String toString() {
        return Utils.format("[%s] %s/%s", App.getInstance().getDateTimeFormat().format(new Date(getRollDate())), getRollCount(), getRollOzmCount());
    }
}
