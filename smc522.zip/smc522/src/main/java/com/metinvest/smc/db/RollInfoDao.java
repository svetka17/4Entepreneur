package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface RollInfoDao {
    @Query("SELECT * FROM rollinfo")
    List<RollInfo> getAll();

    @Query("SELECT * FROM rollinfo WHERE id = :id")
    RollInfo getById(long id);

    @Query("SELECT count(1) FROM rollinfo")
    long getCount();

    @Insert
    long insert(RollInfo rollInfo);

    @Update
    void update(RollInfo rollInfo);

    @Delete
    void delete(RollInfo rollInfo);

    @Query("DELETE FROM rollinfo")
    void truncate();
}