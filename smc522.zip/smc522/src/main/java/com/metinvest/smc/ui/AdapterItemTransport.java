package com.metinvest.smc.ui;

import static com.metinvest.smc.view.MyActivity.REQUEST_PERMISSION;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.db.ShipmentDocument;
import com.metinvest.smc.db.ShipmentTransport;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.view.MyActivity;

import java.util.Date;
import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemTransport extends AbstractFlexibleItem<AdapterItemTransport.AdapterItemCarViewHolder>
                                    implements View.OnClickListener  {
    private final ShipmentTransport shipmentTransport;
    private final List<ShipmentDocument> documentList;
    private boolean highlighted;
    private Date planTimeMin;
    private int finalStatus;

    public AdapterItemTransport(ShipmentTransport shipmentTransport, List<ShipmentDocument> documentList) {
        this.shipmentTransport = shipmentTransport;
        this.documentList = documentList;
        this.highlighted = false;

        planTimeMin = null;
        for (ShipmentDocument document : documentList) {
            if (document.getPlanTime() != 0 && (planTimeMin == null || document.getPlanTime() < planTimeMin.getTime())) {
                planTimeMin = new Date(document.getPlanTime());
            }
        }

        boolean same = true;
        if (documentList.size() > 1) {
            for (int i = 0; i < documentList.size(); i++) {
                ShipmentDocument document = documentList.get(i);

                ShipmentDocument documentPrev = i == 0 ? null : documentList.get(i - 1);
                if (documentPrev != null && document.getStatus() != documentPrev.getStatus()) {
                    same = false;
                    break;
                }
            }
        }

        if (same) {
            finalStatus = shipmentTransport.getStatus();
        } else {
            finalStatus = 0;
        }
    }

    public Date getPlanTimeMin() {
        return planTimeMin;
    }

    public ShipmentTransport getShipmentTransport() {
        return shipmentTransport;
    }

    public boolean containsDocument(String docId) {
        if (documentList != null && !documentList.isEmpty()) {
            for (int i = 0; i < documentList.size(); i++) {
                if (documentList.get(i).getDocNumber().toLowerCase().contains(docId)) return true;
            }
        }
        return false;
    }

    public ShipmentDocument getDocument(String docId) {
        if (documentList != null && !documentList.isEmpty()) {
            for (int i = 0; i < documentList.size(); i++) {
                if (documentList.get(i).getDocNumber().equalsIgnoreCase(docId)) return documentList.get(i);
            }
        }

        return null;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterItemTransport && ((AdapterItemTransport) o).getShipmentTransport().getId() == getShipmentTransport().getId();
    }

    @Override
    public AdapterItemCarViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new AdapterItemCarViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemCarViewHolder holder, int position, List<Object> payloads) {
        StringBuilder content = new StringBuilder(Utils.format("<b>%s</b>", shipmentTransport.getName()));

        StringBuilder sb = new StringBuilder();
        SpannableStringBuilder sb1 = new SpannableStringBuilder();
        //Spanned text;
        if (App.getInstance().getConfig().isEo()){
            holder.textTitle.setText(App.getInstance().fromHtml(content.toString()));
            if (shipmentTransport.getLastDate() != 0 ) { //бронь bookingSetDate
                if (shipmentTransport.getEoStatus().contains("Брон")) {
                    sb.append(Utils.format("<font color=\"#43A047\"><i>%s на %s</i></font>", shipmentTransport.getEoStatus(),
                            App.getInstance().longToTimeString(shipmentTransport.getLastDate())));
                } else {
                    sb.append(Utils.format("<font color=\"#43A047\"><i>%s (бронь на %s)</i></font>", shipmentTransport.getEoStatus(),
                            App.getInstance().longToTimeString(shipmentTransport.getLastDate())));
                }
                //sb.append(Utils.format("<i> на %s</i>", App.getInstance().longToTimeString(shipmentTransport.getLastDate())));
            } else
                sb.append(Utils.format("<font color=\"blue\"><i>%s</i></font>", shipmentTransport.getEoStatus()));

            sb.append(Utils.format("<br><b>Рейс: </b>%s", shipmentTransport.getMinTurnId()));
            if (shipmentTransport.getFirstDate() != 0) //queueStatusSetDate
                sb.append(Utils.format("<i> (%s)</i>", App.getInstance().longToTimeString(shipmentTransport.getFirstDate())));
            sb.append(Utils.format("<br><img src=\"%s\" />", "@drawable/ic_location_on_black_24dp" /*R.drawable.ic_location_on_black_24dp*/ ));
            //<img src="https://od.sytecs.com.ua/files/smc_doc/res/view/Unknown2Activity.png"/>
            sb.append(shipmentTransport.getCurrentLocation());
            //text = App.getInstance().fromHtmlImg(sb.toString(), R.drawable.ic_location_on_black_24dp);
            sb1.append(App.getInstance().fromHtmlImg(sb.toString(), R.drawable.ic_location_on_black_24dp));
            for (ShipmentDocument document : documentList) {
                sb = new StringBuilder();
                String status = "";
                int int_img = 0;
                String status_img = "@drawable/ic_car_0_eo";
                switch (document.getStatus()){
                    case 0:
                        status = App.getInstance().getString(R.string.text_status_eo_0);
                        status_img = "@drawable/ic_car_0_eo";
                        int_img = R.drawable.ic_car_0_eo;
                        break;
                    case 2:
                        status = App.getInstance().getString(R.string.text_status_eo_2);
                        status_img = "@drawable/ic_car_black_eo";
                        int_img = R.drawable.ic_car_black_eo;
                        break;
                    case 3:
                        status = App.getInstance().getString(R.string.text_status_eo_3);
                        status_img = "@drawable/ic_car_green_eo";
                        int_img = R.drawable.ic_car_green_eo;
                        break;
                    case 1:
                        status = App.getInstance().getString(R.string.text_status_eo_1);
                        status_img = "@drawable/ic_car_blanc_eo";
                        int_img = R.drawable.ic_car_blanc_eo;
                        break;
                    default:
                        status = "";
                }

                sb.append(Utils.format("<br><img src=\"%s\" />", status_img ));
                //sb.append(Utils.format(" <b>%s</b> <i>%s</i>", document.getDocNumber(), status));
                sb.append(Utils.format(" <b>%s</b>", document.getDocNumber()));
                sb.append(Utils.format(" <font color=\"#AAAAAA\"><i>%s</i></font>", document.getEoLocationName() ));
                sb1.append(App.getInstance().fromHtmlImg(sb.toString(), int_img));
            }

            holder.textContent.setText(sb1);

            int color;
            switch (shipmentTransport.getStatus()){
                case 1: //жива черга
                    color = R.drawable.ic_car_blue;
                    break;
                case 2: //машина смц
                    color = R.drawable.ic_car_lilo;
                    break;
                case 3: //бронь приоритет
                    color = R.drawable.ic_car_green;
                    break;
                case 4: //завантажено, вантажиться на инший локации
                    color = R.drawable.ic_car_black;
                    break;
                default:
                    color = R.drawable.ic_car_red;
            }

            holder.imageView.setImageResource(color);
            holder.orderCount.setVisibility(View.GONE);
            holder.callDriver.setVisibility(View.VISIBLE);
            holder.callDriver.setOnClickListener(this);
        }
        else {
            holder.callDriver.setVisibility(View.GONE);
            if (documentList != null && !documentList.isEmpty()) {
                for (int i = 0; i < documentList.size(); i++) {
                    content.append(Utils.format("<br>%s", documentList.get(i).getDocNumber()));
                }
            }
            holder.textTitle.setText(App.getInstance().fromHtml(content.toString()));
        if (shipmentTransport.getMinTurnId() != 0) {
            sb.append(Utils.format("№%d в черзі (%d нар.)<br>", shipmentTransport.getMinTurnId(), shipmentTransport.getDocumentCount()));
        } else {
            sb.append(Utils.format("В живій черзі (%d нар.)<br>", shipmentTransport.getDocumentCount()));
        }

        if (shipmentTransport.isDeleted()) {
            sb.append("ВП видалено<br>");
        } else {
            if (finalStatus == 0) {
                sb.append(Utils.format("%s..", App.getInstance().longToTimeString(shipmentTransport.getFirstDate())));
            } else if (finalStatus >= 1) {
                sb.append(Utils.format("%s - %s", App.getInstance().longToTimeString(shipmentTransport.getFirstDate()), App.getInstance().longToTimeString(shipmentTransport.getLastDate())));
            } else {
                if (planTimeMin == null) {
                    sb.append("Очікується");
                } else {
                    sb.append(Utils.format("Очікується о %s", App.getInstance().getTimeFormat().format(planTimeMin)));
                }
            }
        }
        /*
        0   - in progress
        >=1 - ready
        -1  - new
        */
            holder.textContent.setText(App.getInstance().fromHtml(sb.toString()));

            holder.imageView.setImageResource(shipmentTransport.isDeleted() ? R.drawable.ic_car_black : (finalStatus == -1 && planTimeMin != null ? R.drawable.ic_car_blue : Utils.shipStatusToImageCar(finalStatus)));
            holder.orderCount.setText(String.valueOf(shipmentTransport.getOrderCount()));
    }

        View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
        holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
        refreshBackground(holder, holder.itemView.isFocused());
    }

    private void refreshBackground(AdapterItemCarViewHolder holder, boolean hasFocus) {
        if (highlighted) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.imageView.getContext(), R.color.item_highlighted));
        } else {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.imageView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_adapter_light));
        }
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_car;
    }

    public void setHighlighted(boolean highlighted) {
        this.highlighted = highlighted;
    }

    @Override
    public void onClick(View v) {
        if (shipmentTransport.getDriverPhoneNumber() == null || shipmentTransport.getDriverPhoneNumber().isEmpty()) return;

        if (v.getContext().checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions((MyActivity)v.getContext(), new String[]{Manifest.permission.CALL_PHONE}, REQUEST_PERMISSION);
        } else {
            ((MyActivity)v.getContext()).showDialogConfirm(shipmentTransport.getDriverName(), v.getContext().getString(R.string.call_dialog_message, shipmentTransport.getDriverPhoneNumber()), (dialog, which) -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_CALL);
                    char getPlus = shipmentTransport.getDriverPhoneNumber().charAt(0);
                    if (getPlus == '+')
                        intent.setData(Uri.parse("tel:" + shipmentTransport.getDriverPhoneNumber()));
                    else
                        intent.setData(Uri.parse("tel:" + '+'+shipmentTransport.getDriverPhoneNumber()));
                    v.getContext().startActivity(intent);
                } catch (Exception e) {
                    //log(e, "Intent.ACTION_CALL(%s)", phone);
                }
            });
        }
    }


    public static class AdapterItemCarViewHolder extends FlexibleViewHolder {

        private TextView textTitle, textContent;
        private ImageView imageView;

        private ImageButton callDriver;
        private TextView orderCount;

        public AdapterItemCarViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.textTitle = view.findViewById(R.id.textTitle);
            this.textContent = view.findViewById(R.id.textContent);
            this.imageView = view.findViewById(R.id.imageView);
            this.callDriver = view.findViewById(R.id.callDriver);
            this.orderCount = view.findViewById(R.id.orderCount);
        }
    }
}
