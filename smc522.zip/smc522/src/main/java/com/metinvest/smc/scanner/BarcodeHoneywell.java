package com.metinvest.smc.scanner;

import com.honeywell.aidc.AidcManager;
import com.honeywell.aidc.BarcodeFailureEvent;
import com.honeywell.aidc.BarcodeReadEvent;
import com.honeywell.aidc.BarcodeReader;
import com.honeywell.aidc.InvalidScannerNameException;
import com.honeywell.aidc.ScannerUnavailableException;
import com.honeywell.aidc.TriggerStateChangeEvent;
import com.honeywell.aidc.UnsupportedPropertyException;
import com.metinvest.smc.App;
import com.metinvest.smc.tools.Utils;

import java.util.HashMap;
import java.util.Map;

public class BarcodeHoneywell implements BarcodeReader.BarcodeListener, BarcodeReader.TriggerListener {

	private final App app;
	private BarcodeReader barcodeReader;
	private AidcManager manager;

	public BarcodeHoneywell(App app) {
		this.app = app;

		this.app.log(this, "()");

		AidcManager.create(this.app, new AidcManager.CreatedCallback() {
			@Override
			public void onCreated(AidcManager aidcManager) {
				manager = aidcManager;
				try {
					barcodeReader = manager.createBarcodeReader();
					//Barcode.this.app.log(this, "Barcode created!");
					initBarcode();
				} catch (InvalidScannerNameException e) {
					BarcodeHoneywell.this.app.log(this, e, "createBarcodeReader()");
				} catch (Exception e) {
					BarcodeHoneywell.this.app.log(this, e,"createBarcodeReader()");
				}
			}
		});
	}

	private void initBarcode() {
		barcodeReader.addBarcodeListener(this);

		try {
			barcodeReader.setProperty(
					BarcodeReader.PROPERTY_TRIGGER_CONTROL_MODE,
					BarcodeReader.TRIGGER_CONTROL_MODE_AUTO_CONTROL
			);
		} catch (UnsupportedPropertyException e) {
			app.log(this, e, "initBarcode->Failed to apply properties");
		}

		barcodeReader.addTriggerListener(this);

		Map<String, Object> properties = new HashMap<>();
		//
		properties.put(BarcodeReader.PROPERTY_DATA_PROCESSOR_LAUNCH_BROWSER, false);
		//properties.put(BarcodeReader.PROPERTY_NOTIFICATION_VIBRATE_ENABLED, true);
		// Set Symbologies On/Off
		properties.put(BarcodeReader.PROPERTY_CODE_128_ENABLED, true);
		properties.put(BarcodeReader.PROPERTY_GS1_128_ENABLED, true);
		properties.put(BarcodeReader.PROPERTY_QR_CODE_ENABLED, true);
		properties.put(BarcodeReader.PROPERTY_CODE_39_ENABLED, true);
		properties.put(BarcodeReader.PROPERTY_DATAMATRIX_ENABLED, true);
		properties.put(BarcodeReader.PROPERTY_UPC_A_ENABLE, true);
		properties.put(BarcodeReader.PROPERTY_EAN_13_ENABLED, false);
		properties.put(BarcodeReader.PROPERTY_AZTEC_ENABLED, false);
		properties.put(BarcodeReader.PROPERTY_CODABAR_ENABLED, false);
		properties.put(BarcodeReader.PROPERTY_INTERLEAVED_25_ENABLED, false);
		properties.put(BarcodeReader.PROPERTY_PDF_417_ENABLED, false);
		// Set Max Code 39 barcode length
		properties.put(BarcodeReader.PROPERTY_CODE_39_MAXIMUM_LENGTH, 10);
		// Turn on center decoding
		properties.put(BarcodeReader.PROPERTY_CENTER_DECODE, true);
		// Enable bad read response
		properties.put(BarcodeReader.PROPERTY_NOTIFICATION_BAD_READ_ENABLED, true);
		// Apply the settings
		barcodeReader.setProperties(properties);

		onResume();
	}

	@Override
	public void onBarcodeEvent(BarcodeReadEvent event) {

		String barcodeData = event.getBarcodeData();
		barcodeData = Utils.iso2utf(barcodeData);

		app.onBarcodeEvent(barcodeData);
	}

	@Override
	public void onFailureEvent(BarcodeFailureEvent barcodeFailureEvent) {

	}

	@Override
	public void onTriggerEvent(TriggerStateChangeEvent triggerStateChangeEvent) {

	}

	public void onPause() {
		if (barcodeReader != null) barcodeReader.release();
	}

	public void onResume() {
		try {
			if (barcodeReader != null) barcodeReader.claim();
		} catch (ScannerUnavailableException e) {
			app.log(this, e, "Scanner unavailable");
		} catch (Exception ignored) {

		}
	}

	public void onDestroy() {
		app.log(this, "onDestroy()");
		if (barcodeReader != null) {
			barcodeReader.removeBarcodeListener(this);
			barcodeReader.removeTriggerListener(this);
		}
	}
}
