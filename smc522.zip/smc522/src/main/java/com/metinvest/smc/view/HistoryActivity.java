package com.metinvest.smc.view;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Dpl;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemDpl;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class HistoryActivity extends MyActivity implements AdapterItemDpl.IItemAction {

    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    private List<AdapterItemDpl> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        ButterKnife.bind(this);

        listView = findViewById(R.id.listView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
        listView.setLayoutManager(layoutManager);
        listView.addItemDecoration(dividerItemDecoration);

        textNotFound.setVisibility(View.VISIBLE);
        listView.setVisibility(View.GONE);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    private void beginLoad() {
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            List<Dpl> dplList = db.dplDao().getAll();

            List<AdapterItemDpl> items = new ArrayList<>();
            for (int i = 0; i < dplList.size(); i++) {
                items.add(new AdapterItemDpl(dplList.get(i), this));
            }

            runOnUiThread(() -> endLoad(items));
        });
    }

    private void endLoad(List<AdapterItemDpl> items) {

        this.items = items;

        hideLoading();
        listView.setAdapter(new FlexibleAdapter<>(items));
        scrollView.post(() -> scrollView.scrollTo(0, 0));

        textNotFound.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
        listView.setVisibility(!items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 4) {
            showDialogConfirm(R.string.text_confirm, "Ви дійсно бажаєте видалити історію друку?", (dialog, which) -> {
                db.dplDao().truncate();
                beginLoad();
            });
        }
    }

    @Override
    protected String getHelpContent() {
        return "Оберіть позицію для повторного друку.\n\n" +
                "F4 - очистити список\n\n" +
                "F10 - повернутися назад";
    }

    @Override
    public void OnPrintClick(Dpl dpl) {
        if (isLoading()) return;

        log("Print %s", dpl.toString());

        showLoading(R.string.text_printing_title);

        Utils.runOnBackground(() -> {
            final Printer.PrintResult result = Printer.sendCommand(null, config.getPrinter(), dpl.getData());
            runOnUiThread(() -> endPrint(dpl, result));
        });
    }

    private void endPrint(Dpl dpl, Printer.PrintResult result) {
        hideLoading();

        if (result.getStatus() == Printer.PrintResultStatus.OK) {
            showToast(R.string.text_print_result_succeeded);
			//app.sendFaPrint();
        } else {
            @StringRes final int message = app.getPrintResultMessage(result);
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> OnPrintClick(dpl));
        }
    }
}
