package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Carrier;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterCarrier;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class CarriersActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    @BindView(R.id.textFilter)
    EditText textFilter;

    private FlexibleAdapter<AdapterCarrier> adapter;
    private long carrierId;
    private String filter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carriers);
        ButterKnife.bind(this);

        carrierId = getIntent().getLongExtra("carrierId", 0);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        listView.setLayoutManager(layoutManager);

        textFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                applyFilter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoadCarrierList();
    }

    @Override
    public boolean onItemClick(View view, int position) {

        AdapterCarrier item = adapter.getItem(position);
        if (item != null) {
            Intent data = new Intent();
            data.putExtra("carrierId", item.getCarrier().getId());
            setResult(RESULT_OK, data);
            finish();
        }

        return false;
    }

    private void beginLoadCarrierList() {
        if (isLoading()) return;

        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            List<Carrier> list;

            if (filter != null && filter.length() > 0) {
                String searchText = "%" + filter + "%";
                list = db.carrierDao().getByNameLike(searchText);
            } else {
                list = db.carrierDao().getAll();
            }


            List<AdapterCarrier> items = new ArrayList<>(list.size());
            for (int i = 0; i < list.size(); i++) {

                List<OnTheWay> rowsTotal = db.onTheWayDao().getByCarrierId(list.get(i).getId());
                list.get(i).setName(Utils.format("%s (позицій: %d)", list.get(i).getName(), rowsTotal.size()));

                items.add(new AdapterCarrier(list.get(i)));
            }

            adapter = new FlexibleAdapter<>(items);
            adapter.addListener(this);

            runOnUiThread(this::endLoadCarrierList);
        });
    }

    private boolean isAdapterEmpty() {
        return adapter == null || adapter.getItemCount() == 0;
    }

    private void applyFilter(String filter) {
        this.filter = filter;
        beginLoadCarrierList();
    }

    private void endLoadCarrierList() {
        hideLoading();

        listView.setVisibility(isAdapterEmpty() ? View.GONE : View.VISIBLE);
        textNotFound.setVisibility(isAdapterEmpty() ? View.VISIBLE : View.GONE);

        if (!isAdapterEmpty()) {
            listView.setAdapter(adapter);
            scrollView.post(() -> scrollView.scrollTo(0, 0));
        }
    }
}
