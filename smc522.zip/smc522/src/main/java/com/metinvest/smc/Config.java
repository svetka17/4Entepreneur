package com.metinvest.smc;

import static android.content.Context.MODE_PRIVATE;
import static com.metinvest.smc.tools.Utils.addDays;

import android.content.SharedPreferences;

import com.metinvest.smc.inc.Ozm;
import com.metinvest.smc.tools.PrinterConfig;
import com.metinvest.smc.tools.PrinterType;
import com.metinvest.smc.tools.ScalesConfig;
import com.metinvest.smc.tools.StoreItem;
import com.metinvest.smc.tools.Utils;
import com.microsoft.identity.client.IAccount;
import com.microsoft.identity.client.IPublicClientApplication;
import com.microsoft.identity.client.ISingleAccountPublicClientApplication;
import com.microsoft.identity.client.PublicClientApplication;
import com.microsoft.identity.client.exception.MsalException;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Config {

    private final App app;
    private final SharedPreferences preferences;

    private static final String CONST_URL_API = "https://smcqrcode.metinvestholding.com/api/";
    private static final String CONST_URL_API_EO = "https://equeue-api.metinvestholding.com/api/";
    //15/05/2024 from ver 518 ушли от сервера обновлений sytecs
    //private static final String CONST_URL_UPDATER = "https://sytecs.com.ua/user";
    public static final String CONST_URL_UPDATER = "https://mihwesmcapp11.blob.core.windows.net/install/";
    //public static final String CONST_URL_STORAGE = "https://mihwesmcapp11.blob.core.windows.net/";

    //public static final String CONST_KEY1_STORAGE = "TInwIL8vqkfCXdzxdlhfaJbIMOeXWJ1T6OYw4VjctTyZ14b8C1dyqet+7txH2YJMTZFWf1ZRNaa6+ASt9E3YGg==";
    //public static final String CONST_NAME_STORAGE = "install";
    //public static final String CONST_ACCOUNT_STORAGE = "mihwesmcapp11";
    public static final int DEFAULT_ZEBRA_BRIGHTNESS = 15;

    //public static final String[] MSAL_SCOPES = {"api://818ba7b7-3aba-4498-a113-07c910aa230e/access_as_user"};
    public static final String[] MSAL_SCOPES = {"api://0038db9f-b7cb-457e-905c-b283fea587c3/SMCMobile_user", "api://0038db9f-b7cb-457e-905c-b283fea587c3/EQueue_user"
//    ,"https://storage.azure.com/.default"
//    ,"https://mihwesmcapp11.blob.core.windows.net/user_impersonation"
//    ,"https://mihwesmcapp11.blob.core.windows.net/.default"
    };

    public String defaultGraphResourceUrl = MSGraphRequestWrapper.MS_GRAPH_ROOT_ENDPOINT + "v1.0/me";
    //public String graphUrl = "https://login.microsoftonline.com/{tenant}/";

    // Создание нового объекта конфигурации.
    public Config(App app) {
        this.app = app;
        this.preferences = app.getSharedPreferences("config", MODE_PRIVATE);
        loadConfig();
        /*PublicClientApplication.createMultipleAccountPublicClientApplication(app,
                R.raw.auth_config_multiple_account,
                new IPublicClientApplication.IMultipleAccountApplicationCreatedListener() {
                    @Override
                    public void onCreated(IMultipleAccountPublicClientApplication application) {
                    singleAccountApp = application;
                    }
                    @Override
                    public void onError(MsalException exception) {

                    }
                }
        );*/


        // Creates a PublicClientApplication object with res/raw/auth_config_single_account.json
         PublicClientApplication.createSingleAccountPublicClientApplication(app,
                R.raw.auth_config_single_account,
                new IPublicClientApplication.ISingleAccountApplicationCreatedListener() {
                    @Override
                    public void onCreated(ISingleAccountPublicClientApplication application) {
                        /**
                         * This test app assumes that the app is only going to support one account.
                         * This requires "account_mode" : "SINGLE" in the config json file.
                         **/
                        singleAccountApp = application;
                    }

                    @Override
                    public void onError(MsalException exception) {
                        //log("Error: " + exception.toString());
                    }
                });
    }

    private PrinterType printerType;
    private String printerModel, printerMac;
    private String scalesName, scalesMac;
    private int printerContrast;
    private int zebraBrightness;
    private Date comingListPeriodFrom, comingListPeriodTo, expiresOn;

    private int eoLocationId;
    private String eoLocationName;

    private int userId;
    private String token;
    private String userName;
    private String urlApi, urlApiEO, urlUpdater, smcId, smcListJson;
    private String rollLocation;
    private String smcIdUser;
    private int tokenVersion;
    private long craneId;
    private String unknownLocation;
    private Ozm currentOzm;
    private int printerPaperType;
    private boolean autoBatch;
    private boolean eo;

    private boolean partyAUTO;//распределять партии автоматически в приемке
    private boolean navigationVisible;
    private boolean shipRestTransfer;
    private boolean printLabelRestShip;
    private String storage;
    private List<StoreItem> storeTransItems;

    private boolean authMSAL;

    private ISingleAccountPublicClientApplication singleAccountApp;
    //private IMultipleAccountPublicClientApplication singleAccountApp;
    //private IMultipleAccountPublicClientApplication multiAccountApp;

    private IAccount account;

    public static final String DEFAULT_STORAGE = "";//""S001";

    /**
     * Эта функция сбрасывает конфигурацию на значения по умолчанию
     */
    public void resetConfig() {
        urlApi = CONST_URL_API;
        urlApiEO = CONST_URL_API_EO;
        urlUpdater = CONST_URL_UPDATER;
        smcId = "";
        smcIdUser = null;
        smcListJson = "";
        userId = 0;
        token = null;
        //отнимаем один день, чтобы токен был просрочен
        expiresOn = addDays(new Date(), -1);
        //expiresOn = LocalDate.now().minusDays(1);
        tokenVersion = app.getApkVersion();
        craneId = 0;
        unknownLocation = "";
        currentOzm = null;
        printerPaperType = 1;
        navigationVisible = false;
        shipRestTransfer = true;
        eo = false;
        storage = DEFAULT_STORAGE;
        storeTransItems = new ArrayList<>();
        zebraBrightness = DEFAULT_ZEBRA_BRIGHTNESS;
        saveConfig();
    }

    public List<StoreItem> getStoreTransItems() {
        return storeTransItems;
    }

    public void setStoreTransItems(List<StoreItem> storeTransItems) {
        this.storeTransItems = storeTransItems;
    }

    public Date getExpiresOn() {
        return expiresOn;
    }

    public void setExpiresOn(Date expiresOn) {
        this.expiresOn = expiresOn;
    }

    public boolean isAuthMSAL() {
        return authMSAL;
    }

    public void setAuthMSAL(boolean authMSAL) {
        this.authMSAL = authMSAL;
    }

    public String getUrlApiEO() {
        return urlApiEO;
    }

    public void setUrlApiEO(String urlApiEO) {
        this.urlApiEO = urlApiEO;
    }
    public boolean partyAUTO() {
        return partyAUTO;
    }

    public void setAUTO(boolean partyAUTO) {
        this.partyAUTO = partyAUTO;
    }

    public boolean isEo() {
        return eo;
    }

    public void setEo(boolean eo) {
        this.eo = eo;
    }

    /*public IMultipleAccountPublicClientApplication getSingleAccountApp() {
        return singleAccountApp;
    }

    public void setSingleAccountApp(IMultipleAccountPublicClientApplication singleAccountApp) {
        this.singleAccountApp = singleAccountApp;
    }*/

    public ISingleAccountPublicClientApplication getSingleAccountApp() {
        return singleAccountApp;
    }

    public void setSingleAccountApp(ISingleAccountPublicClientApplication singleAccountApp) {
        this.singleAccountApp = singleAccountApp;
    }

    public IAccount getAccount() {
        return account;
    }

    public void setAccount(IAccount account) {
        this.account = account;
    }

    public int getPrinterPaperType() {
        return printerPaperType;
    }

    public void setPrinterPaperType(int printerPaperType) {
        this.printerPaperType = printerPaperType;
    }

    /**
     * Он сохраняет текущую конфигурацию в общих настройках.
     */
    public void saveConfig() {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("urlApi", urlApi);
        editor.putString("urlApiEO", urlApiEO);
        //editor.putString("urlUpdaterNew", urlUpdater);
        editor.putString("urlUpdaterNew", CONST_URL_UPDATER);
        editor.putString("smcId", smcId);
        editor.putString("smcListJson", smcListJson);
        editor.putString("smcIdUser", smcIdUser);
        editor.putLong("expiresOn", expiresOn == null ? 0 : expiresOn.getTime());
        editor.putString("userName", userName);
        editor.putInt("userId", userId);
        editor.putInt("tokenVersion", app.getApkVersion());
        editor.putString("token", token);
        editor.putInt("printerType", printerType == null ? 0 : printerType.getValue());
        editor.putString("printerMac", printerMac);
        editor.putString("printerModel", printerModel);
        editor.putString("scalesMac", scalesMac);
        editor.putString("scalesName", scalesName);
        editor.putInt("printerContrast", printerContrast);
        editor.putInt("zebraBrightness", zebraBrightness);
        editor.putInt("printerPaperType2", printerPaperType);
        editor.putLong("comingListPeriodFrom", comingListPeriodFrom == null ? 0 : comingListPeriodFrom.getTime());
        editor.putLong("comingListPeriodTo", comingListPeriodTo == null ? 0 : comingListPeriodTo.getTime());
        editor.putString("rollLocation", rollLocation);
        editor.putLong("craneId", craneId);
        editor.putString("unknownLocation", unknownLocation);

        if (currentOzm == null) {
            editor.putString("currentOzmOzm", null);
            editor.putString("currentOzmName", null);
            editor.putBoolean("currentOzmIsManual", false);
            editor.putFloat("currentOzmLength", 0);
            editor.putFloat("currentOzmWidth", 0);
            editor.putFloat("currentOzmThickness", 0);
        } else {
            editor.putString("currentOzmOzm", currentOzm.getOzm());
            editor.putString("currentOzmName", currentOzm.getName());
            editor.putBoolean("currentOzmIsManual", currentOzm.isManual());
            editor.putFloat("currentOzmLength", currentOzm.getLength());
            editor.putFloat("currentOzmWidth", currentOzm.getWidth());
            editor.putFloat("currentOzmThickness", currentOzm.getThickness());
        }

        editor.putBoolean("autoBatchEnabled", autoBatch);
        editor.putBoolean("eo", eo);
        editor.putBoolean("partyAUTO", partyAUTO);
        editor.putBoolean("navigationVisible", navigationVisible);
        editor.putBoolean("shipRestTransfer", shipRestTransfer);
        editor.putBoolean("printLabelRestShip", printLabelRestShip);

        editor.putString("storage", storage);

        editor.apply();
    }

    /**
     * Он загружает все настройки из общих настроек
     */
    public void loadConfig() {

        urlApi = preferences.getString("urlApi", CONST_URL_API);
        urlApiEO = preferences.getString("urlApiEO", CONST_URL_API_EO);
        //urlUpdater = preferences.getString("urlUpdaterNew", CONST_URL_UPDATER);
        urlUpdater = CONST_URL_UPDATER;

        if (urlApi == null || urlApi.length() == 0) urlApi = CONST_URL_API;
        if (urlUpdater == null || urlUpdater.length() == 0) urlUpdater = CONST_URL_UPDATER;

        smcId = preferences.getString("smcId", "");
        smcIdUser = preferences.getString("smcIdUser", null);
        smcListJson = preferences.getString("smcListJson", "");
        userName = preferences.getString("userName", "");

        tokenVersion = preferences.getInt("tokenVersion", 0);
        if (tokenVersion == app.getApkVersion()) {
            userId = preferences.getInt("userId", 0);
            token = preferences.getString("token", null);
        } else {
            userId = 0;
            token = null;
        }

        rollLocation = preferences.getString("rollLocation", "");

        scalesMac = preferences.getString("scalesMac", null);
        scalesName = preferences.getString("scalesName", null);

        printerType = PrinterType.values()[preferences.getInt("printerType", 0)];
        printerMac = preferences.getString("printerMac", null);
        printerModel = preferences.getString("printerModel", null);

        printerContrast = preferences.getInt("printerContrast", 25);
        zebraBrightness = preferences.getInt("zebraBrightness", DEFAULT_ZEBRA_BRIGHTNESS);
        printerPaperType = preferences.getInt("printerPaperType2", 0);

        long tempLong = preferences.getLong("comingListPeriodFrom", 0);
        comingListPeriodFrom = tempLong > 0 ? new Date(tempLong) : null;

        tempLong = preferences.getLong("comingListPeriodTo", 0);
        comingListPeriodTo = tempLong > 0 ? new Date(tempLong) : null;

        tempLong = preferences.getLong("expiresOn", 0);
        expiresOn = tempLong > 0 ? new Date(tempLong) : null;
            if (expiresOn != null && expiresOn.getTime() > (new Date()).getTime()) {
                userId = preferences.getInt("userId", 0);
                token = preferences.getString("token", null);
            }

        craneId = preferences.getLong("craneId", 0);
        unknownLocation = preferences.getString("unknownLocation", "");

        String temp = preferences.getString("currentOzmOzm", null);

        if (temp == null) {
            currentOzm = null;
        } else {
            currentOzm = new Ozm();
            currentOzm.setOzm(preferences.getString("currentOzmOzm", ""));
            currentOzm.setName(preferences.getString("currentOzmName", ""));
            currentOzm.setManual(preferences.getBoolean("currentOzmIsManual", false));
            currentOzm.setLength(preferences.getFloat("currentOzmLength", 0));
            currentOzm.setWidth(preferences.getFloat("currentOzmWidth", 0));
            currentOzm.setThickness(preferences.getFloat("currentOzmThickness", 0));
        }

        autoBatch = preferences.getBoolean("autoBatchEnabled", false);
        eo = preferences.getBoolean("eo", false);
        partyAUTO = false; // preferences.getBoolean("partyAUTO", true);
        navigationVisible = preferences.getBoolean("navigationVisible", false);
        shipRestTransfer = preferences.getBoolean("shipRestTransfer", true);
        printLabelRestShip = preferences.getBoolean("printLabelRestShip", false);

        storage = preferences.getString("storage", DEFAULT_STORAGE);
    }

    public String getStorage() {
        return storage;
    }

    public void setStorage(String storage) {
        this.storage = storage;
    }

    public String getEoLocationName() {
        return eoLocationName;
    }

    public void setEoLocationName(String eoLocationName) {
        this.eoLocationName = eoLocationName;
    }

    public int getEoLocationId() {
        return eoLocationId;
    }

    public void setEoLocationId(int eoLocationId) {
        this.eoLocationId = eoLocationId;
    }

    public boolean isNavigationVisible() {
        return navigationVisible;
    }

    public void setNavigationVisible(boolean navigationVisible) {
        this.navigationVisible = navigationVisible;
    }

    public long getCraneId() {
        return craneId;
    }

    public void setCraneId(long craneId) {
        this.craneId = craneId;
    }

    public int getConfigUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getRollLocation() {
        return rollLocation;
    }

    public void setRollLocation(String rollLocation) {
        this.rollLocation = rollLocation;
    }

    public int getPrinterContrast() {
        return printerContrast;
    }

    public void setPrinterContrast(int printerContrast) {
        this.printerContrast = printerContrast;
    }

    public String getSmcId() {
        return smcId;
    }

    public void setSmcId(String smcId) {
        this.smcId = smcId;
    }

    /**
     * Получите код версии приложения или 0 в случае сбоя.
     *
     * @return Код версии приложения.
     */
    public int getVersion() {
        try {
            return app.getPackageManager().getPackageInfo(app.getPackageName(), 0).versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Если в базе данных есть какие-либо записи в таблице onTheWay, то вернуть true
     *
     * @return Количество элементов в таблице onTheWay.
     */
    public boolean isComingListLoaded() {
        try {
            return app.getDb().onTheWayDao().count() > 0;
        } catch (Exception e) {
            app.log(this, e, "isComingListLoaded()");
            return false;
        }
    }

    public enum TemplateType {
        TEMPLATE_TEST(1),
        TEMPLATE_WORK(3),
        TEMPLATE_LOCATION(4),
        TEMPLATE_SHIPMENT(5);

        private final int value;

        TemplateType(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }

    public Date getComingListPeriodFrom() {
        return comingListPeriodFrom;
    }

    public void setComingListPeriodFrom(Date comingListPeriodFrom) {
        this.comingListPeriodFrom = comingListPeriodFrom;
    }

    public Date getComingListPeriodTo() {
        return comingListPeriodTo;
    }

    public void setComingListPeriodTo(Date comingListPeriodTo) {
        this.comingListPeriodTo = comingListPeriodTo;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUrlApi() {
        return urlApi;
    }

    public void setUrlApi(String urlApi) {
        this.urlApi = urlApi;
    }

    public String getUrlUpdater() {
        return urlUpdater;
    }

    public void setUrlUpdater(String urlUpdater) {
        this.urlUpdater = urlUpdater;
    }

    public String getUnknownLocation() {
        return unknownLocation;
    }

    public void setUnknownLocation(String unknownLocation) {
        this.unknownLocation = unknownLocation;
    }

    public Ozm getCurrentOzm() {
        return currentOzm;
    }

    public void setCurrentOzm(Ozm currentOzm) {
        this.currentOzm = currentOzm;
    }

    public String getSmcListJson() {
        return smcListJson;
    }

    /**
     * Если пользователь выбрал smcIdUser, которого больше нет в списке smcId, установите для smcIdUser
     * значение null.
     *
     * @param smcListJson Это строка JSON, содержащая список SMC, к которым у пользователя есть доступ.
     */
    public void setSmcListJson(String smcListJson) {
        this.smcListJson = smcListJson;

        JSONArray jsonArray = Utils.getJsonArray(smcListJson);
        if (jsonArray == null || jsonArray.length() == 0) {
            smcIdUser = null;
        } else {
            boolean found = false;
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = Utils.getJsonObject(jsonArray, i);
                String smcid = Utils.getJsonStringIgnoreCase(jsonObject, "smcid");
                if (smcid.equalsIgnoreCase(smcIdUser)) {
                    found = true;
                    break;
                }
            }
            if (!found) smcIdUser = null;
        }
    }

    public String getSmcIdUser() {
        return smcIdUser;
    }

    public void setSmcIdUser(String smcIdUser) {
        this.smcIdUser = smcIdUser;
    }

    public boolean isAutoBatch() {
        //return autoBatch;
        return partyAUTO;
    }

    public void setAutoBatch(boolean autoBatch) {
        this.autoBatch = autoBatch;
    }

    public boolean isShipRestTransfer() {
        return shipRestTransfer;
    }

    public void setShipRestTransfer(boolean shipRestTransfer) {
        this.shipRestTransfer = shipRestTransfer;
    }

    public boolean isNewLabelDpl() {
        return isAutoBatch();
    }

    public boolean isPrintLabelRestShip() {
        return printLabelRestShip;
    }

    public void setPrintLabelRestShip(boolean printLabelRestShip) {
        this.printLabelRestShip = printLabelRestShip;
    }

    /**
     * Он возвращает строку на основе значения входного параметра
     *
     * @param templateType Тип используемого шаблона.
     * @return Имя файла шаблона.
     */
    private String getTemplateFileName(TemplateType templateType) {
        switch (templateType) {
            case TEMPLATE_TEST:
                return "test.txt";
            case TEMPLATE_LOCATION:
                return "location.txt";
            case TEMPLATE_WORK:
                return "work.txt";
            case TEMPLATE_SHIPMENT:
                return "shipment.txt";
            default:
                return null;
        }
    }

    /**
     * Он читает файл шаблона из папки с ресурсами
     *
     * @param printerType  Тип используемого принтера.
     * @param templateType Тип шаблона, который необходимо получить.
     * @return Содержимое файла шаблона.
     */
    private String getTemplate(PrinterType printerType, TemplateType templateType) {
        String dir = null;
        if (printerType == PrinterType.ZEBRA) {
            dir = "zebra";
        } else if (printerType == PrinterType.HONEYWELL) {
            dir = "honeywell";
        }

        String file = getTemplateFileName(templateType);

        if (dir == null || file == null) return "";

        return app.readAssetsFile(dir + "/" + file);
    }

    /**
     * Эта функция возвращает шаблон для указанного типа принтера и типа шаблона.
     *
     * @param templateType Тип шаблона, который вы хотите получить.
     * @return Шаблон для указанного типа принтера и типа шаблона.
     */
    public String getTemplateZebra(TemplateType templateType) {
        return getTemplate(PrinterType.ZEBRA, templateType);
    }

    /**
     * Получить шаблон для указанного типа принтера и типа шаблона
     *
     * @param templateType Тип шаблона, который вы хотите получить.
     * @return Шаблон для указанного типа принтера и типа шаблона.
     */
    public String getTemplateHoneywell(TemplateType templateType) {
        return getTemplate(PrinterType.HONEYWELL, templateType);
    }

    /**
     * Возвращает true, если принтер подключен к устройству
     *
     * @return Логическое значение.
     */
    public boolean isPrinterConnected() {
        return !Utils.isNullOrEmpty(printerMac);
    }

    public boolean isScalesConnected() {
        return !Utils.isNullOrEmpty(scalesMac);
    }

    /**
     * Если принтер подключен, верните новый объект PrinterConfig с типом принтера, моделью и MAC-адресом.
     * В противном случае вернуть ноль.
     *
     * @return Объект PrinterConfig.
     */
    public PrinterConfig getPrinter() {
        return isPrinterConnected() ? new PrinterConfig(printerType, printerModel, printerMac) : null;
    }

    public ScalesConfig getScales() {
        return isScalesConnected() ? new ScalesConfig(scalesName, scalesMac) : null;
    }

    /**
     * Если принтер имеет значение null, установите для типа принтера, модели и Mac значение null. В
     * противном случае установите тип принтера, модель и Mac на тип принтера, модель и Mac.
     *
     * @param printer Используемый принтер.
     */
    public void setPrinter(PrinterConfig printer) {
        printerType = printer == null ? null : printer.getType();
        printerModel = printer == null ? null : printer.getModel();
        printerMac = printer == null ? null : printer.getMac();
    }

    public void setScales(ScalesConfig scales) {
        scalesName = scales == null ? null : scales.getName();
        scalesMac = scales == null ? null : scales.getMac();
    }

    public int getZebraBrightness() {
        return zebraBrightness;
    }

    public void setZebraBrightness(int zebraBrightness) {
        this.zebraBrightness = zebraBrightness;
    }
}
