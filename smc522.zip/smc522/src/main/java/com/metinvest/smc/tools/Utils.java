package com.metinvest.smc.tools;

import android.content.res.Resources;
import android.os.Process;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Spinner;

import androidx.annotation.ColorRes;
import androidx.annotation.DrawableRes;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.core.content.ContextCompat;

import com.metinvest.smc.App;
import com.metinvest.smc.BuildConfig;
import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.ui.SpinnerAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utils {

    private Utils() {
    }

    private final static char[] hexArray = "0123456789ABCDEF".toCharArray();

    public static class NetworkPrintResult {
        private JsonResult jsonResult;
        private Printer.PrintResult printResult;
        private Object tag;

        public NetworkPrintResult(JsonResult jsonResult, Printer.PrintResult printResult) {
            this.jsonResult = jsonResult;
            this.printResult = printResult;
            this.tag = null;
        }

        public JsonResult getNetworkResult() {
            return jsonResult;
        }

        public void setNetworkResult(JsonResult jsonResult) {
            this.jsonResult = jsonResult;
        }

        public Printer.PrintResult getPrintResult() {
            return printResult;
        }

        public void setPrintResult(Printer.PrintResult printResult) {
            this.printResult = printResult;
        }

        public Object getTag() {
            return tag;
        }

        public void setTag(Object tag) {
            this.tag = tag;
        }
    }

    public static String base64encode(String text) {
        // Sending side
		/*byte[] data = text.getBytes(StandardCharsets.UTF_8);
		return Base64.encodeToString(data, Base64.NO_WRAP);*/
        byte[] data = text.getBytes(StandardCharsets.UTF_8);
        String base64 = Base64.encodeToString(data, Base64.DEFAULT);
        return base64;
    }

    public static String base64decode(String base64) {
        // Receiving side
        //byte[] data = Base64.decode(text, Base64.NO_WRAP);
        //return new String(data, StandardCharsets.UTF_8);
        byte[] data = Base64.decode(base64, Base64.DEFAULT);
        String text = new String(data, StandardCharsets.UTF_8);
        return text;
    }

    public static boolean jsonExist(JSONObject jsonObject, String name) {
        if (jsonObject == null) return false;
        Iterator<String> iterator = jsonObject.keys();
        while (iterator.hasNext()) {
            String key = iterator.next();
            if (key.equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }

    public static int getJsonInt(JSONObject jsonObject, String name) {
        try {
            return jsonObject.getInt(name);
        } catch (Exception e) {
            return 0;
        }
    }

    public static long getJsonLong(JSONObject jsonObject, String name) {
        try {
            return jsonObject.getLong(name);
        } catch (Exception e) {
            return 0;
        }
    }

    public static int getJsonIntIgnoreCase(JSONObject jsonObject, String name) {
        if (jsonObject == null) return 0;
        Iterator<String> iterator = jsonObject.keys();
        while (iterator.hasNext()) {
            String key = iterator.next();
            if (key.equalsIgnoreCase(name)) {
                return getJsonInt(jsonObject, key);
            }
        }
        return 0;
    }

    public static long getJsonLongIgnoreCase(JSONObject jsonObject, String name) {
        if (jsonObject == null) return 0;
        Iterator<String> iterator = jsonObject.keys();
        while (iterator.hasNext()) {
            String key = iterator.next();
            if (key.equalsIgnoreCase(name)) {
                return getJsonLong(jsonObject, key);
            }
        }
        return 0;
    }

    public static float getJsonFloat(JSONObject jsonObject, String name) {
        try {
            return Utils.parseFloat(jsonObject.getString(name));
        } catch (Exception e) {
            return 0;
        }
    }

    /*public static double getJsonDouble(JSONObject jsonObject, String name) {
        try {
            return Utils.parseDouble(jsonObject.getString(name));
        } catch (Exception e) {
            return 0;
        }
    }*/

    public static int getJsonWeightKg(JSONObject jsonObject, String name) {
        try {
            return (int) Math.round(Utils.parseDouble(jsonObject.getString(name)) * /**/ 1000);
        } catch (Exception e) {
            return 0;
        }
    }

    public static int getJsonWeightKgIgnoreCase(JSONObject jsonObject, String name) {
        if (jsonObject == null) return 0;
        Iterator<String> iterator = jsonObject.keys();
        while (iterator.hasNext()) {
            String key = iterator.next();
            if (key.equalsIgnoreCase(name)) {
                return getJsonWeightKg(jsonObject, key);
            }
        }
        return 0;
    }

    public static float getJsonFloatIgnoreCase(JSONObject jsonObject, String name) {
        if (jsonObject == null) return 0;
        Iterator<String> iterator = jsonObject.keys();
        while (iterator.hasNext()) {
            String key = iterator.next();
            if (key.equalsIgnoreCase(name)) {
                return getJsonFloat(jsonObject, key);
            }
        }
        return 0;
    }

    /*public static double getJsonDoubleIgnoreCase(JSONObject jsonObject, String name) {
        if (jsonObject == null) return 0;
        Iterator<String> iterator = jsonObject.keys();
        while (iterator.hasNext()) {
            String key = iterator.next();
            if (key.equalsIgnoreCase(name)) {
                return getJsonDouble(jsonObject, key);
            }
        }
        return 0;
    }*/

    public static String getJsonString(JSONObject jsonObject, String name) {
        try {
            String value = jsonObject.getString(name);
            return value.equalsIgnoreCase("null") ? "" : value;
        } catch (Exception e) {
            return "";
        }
    }

    public static String getJsonStringIgnoreCase(@Nullable JSONObject jsonObject, String name) {
        if (jsonObject == null) return "";
        Iterator<String> iterator = jsonObject.keys();
        while (iterator.hasNext()) {
            String key = iterator.next();
            if (key.equalsIgnoreCase(name)) {
                return getJsonString(jsonObject, key);
            }
        }
        return "";
    }

    public static JSONObject getJsonObject(@Nullable JSONObject jsonObject, String name) {
        if (jsonObject == null) return null;
        try {
            return jsonObject.getJSONObject(name);
        } catch (Exception e) {
            return null;
        }
    }

    public static JSONObject getJsonObject(JSONArray jsonArray, int index) {
        try {
            return jsonArray.getJSONObject(index);
        } catch (Exception ignored) {
            return null;
        }
    }

    public static String getJsonString(JSONArray jsonArray, int index) {
        try {
            return jsonArray.getString(index);
        } catch (Exception ignored) {
            return null;
        }
    }

    public static int getJsonInt(JSONArray jsonArray, int index) {
        try {
            return jsonArray.getInt(index);
        } catch (Exception ignored) {
            return 0;
        }
    }

    public static String jsonToString(JSONObject json) {
        try {
            return json.toString();
        } catch (Exception ignored) {
            return "";
        }
    }

    public static JSONObject getJsonObject(String json) {
        try {
            return new JSONObject(json);
        } catch (Exception ignored) {
            return null;
        }
    }

    public static JSONArray getJsonArray(String json) {
        try {
            return new JSONArray(json);
        } catch (Exception ignored) {
            return null;
        }
    }

    public static JSONArray getJsonArray(String json, String name) {
        try {
            return new JSONObject(json).getJSONArray(name);
        } catch (Exception ignored) {
            return null;
        }
    }

    public static JSONArray getJsonArray(JSONObject jsonObject, String name) {
        try {
            return jsonObject.getJSONArray(name);
        } catch (Exception ignored) {
            return null;
        }
    }

    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }

    public static String reverse(String string) {
        return new StringBuilder(string).reverse().toString();
    }

    public static byte[] reverse(byte[] array) {
        try {
            byte[] res = new byte[array.length];
            for (int i = 0; i < array.length; i++) {
                res[array.length - i - 1] = array[i];
            }
            return res;
        } catch (Exception ignored) {
            return null;
        }
    }

    public static String formatMacAddress(byte[] array) {
        return array == null || array.length != 6 ? "-" : formatMacAddress(bytesToHex(array));
    }

    public static boolean isCorrectMacAddress(String macAddress) {
        if (macAddress.contains(":")) {
            return macAddress.trim().length() == 17;
        } else {
            return macAddress.trim().length() == 12;
        }
    }

    public static String formatMacAddress(String aMacAddress) {
        if (aMacAddress != null && !aMacAddress.contains(":") &&
                aMacAddress.length() == 12) {
            // If the MAC address only contains hex digits without the
            // ":" delimiter, then add ":" to the MAC address string.
            char[] cAddr = new char[17];

            for (int i = 0, j = 0; i < 12; i += 2) {
                aMacAddress.getChars(i, i + 2, cAddr, j);
                j += 2;
                if (j < 17) {
                    cAddr[j++] = ':';
                }
            }

            return new String(cAddr);
        } else {
            return aMacAddress;
        }
    }

    public static void sleep(int millis) {
        try {
            Thread.sleep(millis);
        } catch (Exception ignored) {

        }
    }

    public static Calendar toCalendar(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal;
    }

    public static Thread runOnBackground(Runnable runnable) {
        //android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);

        Thread thread = new Thread(runnable);
        try {
            thread.setPriority(Process.THREAD_PRIORITY_BACKGROUND);
        } catch (Exception ignored) {

        }
        thread.start();
        return thread;
    }

    /*public static void runOnUi(Runnable runnable) {
        if (Looper.getMainLooper().isCurrentThread()) {
            runnable.run();
        } else {
            if (App.getInstance().getActivity() != null) {
                try {
                    App.getInstance().getActivity().runOnUiThread(runnable);
                } catch (Exception ignored) {
                }
            }
        }
    }*/

    public static long parseLong(String value) {
        try {
            return Long.parseLong(value);
        } catch (Exception ignored) {
            return 0;
        }
    }

    public static int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception ignored) {
            return 0;
        }
    }

    public static float parseFloat(String value) {
        try {
            return Float.parseFloat(value);
        } catch (Exception ignored) {
            try {
                return Float.parseFloat(value.replace(',', '.'));
            } catch (Exception ignored2) {
                return 0;
            }
        }
    }

    public static double parseDouble(String value) {
        try {
            return Float.parseFloat(value);
        } catch (Exception ignored) {
            try {
                return Double.parseDouble(value.replace(',', '.'));
            } catch (Exception ignored2) {
                return 0;
            }
        }
    }

    public static char getCharAt(String value, int index, char defaultValue) {
        return value == null || index < 0 || index > value.length() - 1 ? defaultValue : value.charAt(index);
    }

	/*public static float parseDiscount(String value) {
		try {
			return Float.parseFloat(value);
		} catch (Exception ignored) {
			try {
				Pattern pattern = Pattern.compile("^([0-9]*[.,]?[0-9]+){1}"); //("-?\\d+([\\.,]\\d+)");
				//Matcher matcher = pattern.matcher(value.replaceAll ("[[:space:]]",""));
				String value_no_gap = value.replaceAll ("[[:space:]]","");
				Matcher matcher = pattern.matcher(value_no_gap);
				if (matcher.find()) {
					String numberStr = matcher.group();
					//double number = Double.parseDouble(numberStr.replaceAll(",", "."));
					//System.out.println("Found number with percent: " + number);
					try {
						return  Float.parseFloat(numberStr);
					}
					catch (Exception ignored1)
					{
						return 0;
					}
				}
				else
					return 0;
			} catch (Exception ignored2) {
				return 0;
			}
		}
	}*/

    public static float parseDiscount(String value) {
        if (value == null) return 0;
        // Удаляем пробелы и символ % в конце
        value = value.trim().replaceAll("%$", "");
        // Заменяем запятую на точку (если она используется в качестве разделителя разрядов)
        value = value.replaceAll(",", ".");
        value = value.replaceAll("[[:space:]]", "");
        try {
            return Float.parseFloat(value);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public static String parseLocation(String value) {
        if (value == null) return "";
        try{
        // <font color="yellow"><b>%s</b></font>
        value = value.trim().replaceAll("</b></font>$", "");
        value = value.trim().replaceAll("^<font color=\"blue\"><b>", "");
        value = value.replaceAll("[[:space:]]", "");
            return value;
        } catch (Exception e) {
            return "";
        }
    }

    public static String parseEmail(String value) {
        if (value == null) return "";
        if (value.split("@").length > 0) {
            return value.split("@")[0];
        } else
            return value;
    }

    public static String parsePasswordScales(String value) {
        //Pattern pattern = Pattern.compile("[[:digit:]]{4}$");
        try {
            Pattern pattern = Pattern.compile("\\d{4}$");
            Matcher matcher = pattern.matcher(value);
            if (matcher.find()) {
                return matcher.group(0);
            } else return value;
        } catch (Exception e) {
            return "";
        }
    }

    public static void fillData(Spinner spinner, List<IValue> data) {
        if (data == null || data.isEmpty()) {
            //setEmptyAdapter(spinner);
            spinner.setAdapter(null);
        } else {
            spinner.setAdapter(new SpinnerAdapter(spinner.getContext(), data));
            spinner.setEnabled(true);
        }
    }

    public static long date2long(Date date) {
        if (date == null) {
            return 0;
        } else {
            return date.getTime();
        }
    }

    public static Date long2date(long value) {
        return new Date(value);
    }

    public static String iso2utf(String text) {
        try {
            byte[] bytes = text.getBytes(StandardCharsets.ISO_8859_1);
            return new String(bytes);
        } catch (Exception e) {
            App.getInstance().log("Utils", e, "iso2utf(%s)", text);
            return text;
        }
    }

    public static void copy(File src, File dst) throws IOException {
        InputStream in = new FileInputStream(src);
        try {
            OutputStream out = new FileOutputStream(dst);
            try {
                // Transfer bytes from in to out
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
            } finally {
                out.close();
            }
        } finally {
            in.close();
        }
    }

    public static void copyFile(FileInputStream fromFile, FileOutputStream toFile) throws IOException {
        FileChannel fromChannel = null;
        FileChannel toChannel = null;
        try {
            fromChannel = fromFile.getChannel();
            toChannel = toFile.getChannel();
            fromChannel.transferTo(0, fromChannel.size(), toChannel);
        } finally {
            try {
                if (fromChannel != null) {
                    fromChannel.close();
                }
            } finally {
                if (toChannel != null) {
                    toChannel.close();
                }
            }
        }
    }

    public static int parseShipStatus(String status) {
        if (status == null || status.isEmpty()) return -1;
        int statusId = Utils.parseInt(status);
        if (statusId == 0) return 0;
        else return 1;
    }

    public static String shipStatusToStringEO(int status) {
        switch (status){
            case 0:
                return App.getInstance().getString(R.string.text_status_eo_0).toLowerCase();
            case 1:
                return App.getInstance().getString(R.string.text_status_eo_1).toLowerCase();
            case 2:
                return App.getInstance().getString(R.string.text_status_eo_2).toLowerCase();
            case 3:
                return App.getInstance().getString(R.string.text_status_eo_3).toLowerCase();
            default:
                return "";
        }
    }

    public static int shipStatusToColor(int status) {

        @ColorRes int colorRes = R.color.ship_green;

        if (status == 0)
            colorRes = R.color.ship_yellow;
        else if (status >= 1)
            colorRes = R.color.ship_red;

        return App.getInstance().getColor(colorRes);
    }

    public static String shipStatusToString(int status) {

        @StringRes int stringRes = R.string.ship_status_new;

        if (status == 0)
            stringRes = R.string.ship_status_progress;
        else if (status >= 1)
            stringRes = R.string.ship_status_completed;

        return App.getInstance().getString(stringRes).toLowerCase();
    }

    public static int shipStatusToImageCar(int status) {
        @DrawableRes int imageId = R.drawable.ic_car_green;
        if (status == 0) imageId = R.drawable.ic_car_yellow;
        else if (status == 1) imageId = R.drawable.ic_car_red;

        return imageId;
    }

    public static int shipStatusToImageCarEO(int status){
        switch (status) {
            case 0:
                return R.drawable.ic_car_0_eo;
            case 1:
                return R.drawable.ic_car_black_eo;
            case 2:
                return R.drawable.ic_car_green_eo;
            case 3:
                return R.drawable.ic_car_blanc_eo;
            default:
                return R.drawable.ic_car_0_eo;
        }
    }

    public static int shipStatusToImageShip(int status) {
        @DrawableRes int imageId = R.drawable.ic_ship_green;
        if (status == 0) imageId = R.drawable.ic_ship_yellow;
        else if (status == 1) imageId = R.drawable.ic_ship_red;

        return imageId;
    }

    public static int shipStatusToImageShipEO(int status) {
        switch (status){
            case 0:
                return R.drawable.ic_car_0_eo;
            case 1:
                //return R.drawable.ic_car_blue;
                return R.drawable.ic_car_blanc_eo;
            case 2:
                //return R.drawable.ic_car_lilo;
                return R.drawable.ic_car_black_eo;
            case 3:
                //return R.drawable.ic_car_green;
                return R.drawable.ic_car_green_eo;
            case 4:
                return R.drawable.ic_car_black;
            default:
                //return R.drawable.ic_car_red;
                return R.drawable.ic_car_0_eo;
        }
    }

    public static int shipStatusToImage(int status) {
        @DrawableRes int imageId = R.drawable.circle_green;
        if (status == 0) imageId = R.drawable.circle_yellow;
        else if (status == 1) imageId = R.drawable.circle_red;

        return imageId;
    }

    public static void replaceOne(StringBuilder builder, String from, String to) {
        int n = 0;

        int index = builder.indexOf(from);
        while (index != -1) {
            String finalTo = n == 0 ? to : "";
            builder = builder.replace(index, index + from.length(), finalTo);
            index += finalTo.length(); // Move to the end of the replacement
            index = builder.indexOf(from, index);
            n++;
        }
    }

    public static void replaceAll(StringBuilder builder, String from, String to) {
        int index = builder.indexOf(from);
        while (index != -1) {
            builder = builder.replace(index, index + from.length(), to);
            index += to.length(); // Move to the end of the replacement
            index = builder.indexOf(from, index);
        }
    }

    public static Locale getLocale() {
        return App.getInstance().getLocale();
    }

    public static Printer.PrintResult printLabel(List<String> listLabelId, List<JSONObject> listJson) {
        App app = App.getInstance();
        if (!app.isPrinterAvailable()) {
            if (!BuildConfig.DEBUG)
                return new Printer.PrintResult(Printer.PrintResultStatus.ERROR_NO_PRINTER);
        }

        int count = listLabelId.size();

        StringBuilder sbDpl = new StringBuilder();

        for (int i = 0; i < count; i++) {

            String labelId = listLabelId.get(i);
            JSONObject json = listJson.get(i);

            String name = Utils.jsonExist(json, "sap_matt_descr") ? Utils.getJsonStringIgnoreCase(json, "sap_matt_descr") : Utils.getJsonStringIgnoreCase(json, "name");
            float width = Utils.getJsonFloatIgnoreCase(json, "width");
            float length = Utils.getJsonFloatIgnoreCase(json, "length");
            float thickness = Utils.getJsonFloatIgnoreCase(json, "thickness");
            String batch = Utils.jsonExist(json, "saP_Batch") ? Utils.getJsonStringIgnoreCase(json, "saP_Batch") : Utils.getJsonStringIgnoreCase(json, "batch");
            String ozm = Utils.jsonExist(json, "saP_Ozm") ? Utils.getJsonStringIgnoreCase(json, "saP_Ozm") : Utils.getJsonStringIgnoreCase(json, "ozm");
            int netto = Utils.getJsonIntIgnoreCase(json, "netT_Weight");
            int pack = Utils.getJsonIntIgnoreCase(json, "pack_Weight");
            String locationCode = Utils.getJsonStringIgnoreCase(json, "locationCode");
            String carrier = Utils.getJsonStringIgnoreCase(json, "ttN_Carrier_ID");
            String zavBatch = Utils.getJsonStringIgnoreCase(json, "zavBatch");
            String zavPlavka = Utils.getJsonStringIgnoreCase(json, "plavka");
            String lgort = Utils.getJsonStringIgnoreCase(json, "lgort");
            String zavOdin = null;
            String lowPricePercent = Utils.getJsonString(json, "loW_PRICE_PERCENT");
            String manufacturer = Utils.getJsonStringIgnoreCase(json, "PROIZVOD");
            String sortCriterion = Utils.getJsonStringIgnoreCase(json, "PRICHINA_OTSORT");
            boolean isTheor = Utils.getJsonStringIgnoreCase(json, "teoR_Weight").equalsIgnoreCase("true");
            int theorCount = 0;
            if (isTheor) {
                theorCount = app.getNetwork().loadTheorCount(labelId).getValue();
            }

            String qrCode = Utils.getJsonStringIgnoreCase(json, "qr_code");
            if (qrCode.length() > 0) {
                ScanItem scanItem = new ScanItem(qrCode);
                if (scanItem.isCorrect()) {
                    if (scanItem.getType() == ScanItem.ScanItemType.KOMINMET) {
                        zavPlavka = scanItem.getData(2);
                        zavBatch = scanItem.getData(3);
                    } else if (scanItem.getType() == ScanItem.ScanItemType.ZAPOR) {
                        zavPlavka = scanItem.getData(7);
                        zavBatch = scanItem.getData(8);
                        zavOdin = scanItem.getData(9);
                    } else if (scanItem.getType() == ScanItem.ScanItemType.TRUBOSTAL) {
                        zavPlavka = scanItem.getData(3);
                        zavBatch = "";
                    } else if (scanItem.getType() == ScanItem.ScanItemType.ARCELOR) {
                        zavPlavka = "";
                        zavBatch = "";
                    } else if (scanItem.getType() == ScanItem.ScanItemType.GALATI) {
                        zavPlavka = "";
                        zavBatch = "";
                    }
                }
            }

            //if (netto > 0) {
            String dplTitle = Utils.format("<b>%s</b><br>", name);
            dplTitle += Utils.format("LabelId: <i>%s</i><br>", labelId);
            dplTitle += Utils.format("Розмір: <i>%s</i><br>", app.sizeToString(width, length, thickness));
            dplTitle += Utils.format("Вага нетто: <i>%s кг</i><br>", netto);
            dplTitle += Utils.format("Партія: <i>%s</i><br>", batch);
            dplTitle += Utils.format("ОЗМ: <i>%s</i><br>", ozm);
            dplTitle += Utils.format("Дата друку:<br><i>%s</i>", app.getDateTimeFormat().format(Calendar.getInstance().getTime()));

            String dplContent = app.generateDplLabel(
                    labelId, Calendar.getInstance().getTime(), name,
                    width, length, thickness, netto, pack,
                    0, ozm, batch,
                    carrier, 0, isTheor, theorCount, locationCode,
                    zavBatch, zavPlavka, zavOdin, Utils.isNullOrEmpty(lowPricePercent) ? null : lowPricePercent, manufacturer, sortCriterion
            , lgort );

            Printer.addHistory(dplTitle, dplContent);

            sbDpl.append(dplContent);
            //}
        }

        return sbDpl.length() == 0 ? new Printer.PrintResult(Printer.PrintResultStatus.OK) : Printer.sendCommand(null, app.getConfig().getPrinter(), sbDpl.toString());
    }

    public static int getNettoFromLabel(JSONObject labelJson) {
        JSONObject json = Utils.getJsonObject(labelJson, "data");
        return Utils.getJsonIntIgnoreCase(json, "netT_Weight");
    }

    public static NetworkPrintResult printLabel(List<String> listLabelId) {
        return printLabel(listLabelId, (String) null);
    }

    public static NetworkPrintResult printLabel(List<String> listLabelId, String smcId) {

        App app = App.getInstance();

        List<JSONObject> listJson = new ArrayList<>();
        JsonResult jsonResult = null;

        for (String labelId : listLabelId) {
            String url = app.getConfig().getUrlApi() + "getlabelinfo";
            url = app.getNetwork().addUrlParam(url, "label_id", labelId);
            if (smcId != null) url = app.getNetwork().addUrlParam(url, "smc_id", smcId);

            jsonResult = app.getNetwork().downloadJson(url);
            JSONObject json = Utils.getJsonObject(jsonResult.getJson(), "data");

            if (jsonResult.isOk() && json != null) {
                //
                String locationId = Utils.getJsonString(json, "location_id");
                if (!locationId.isEmpty()) {
                    String locationCode = app.getNetwork().getLocationCode(locationId);
                    if (locationCode != null) {
                        try {
                            json.put("locationCode", locationCode);
                        } catch (Exception e) {
                            app.log("Utils", e, "printLabel()");
                        }
                    }
                }
                //

                listJson.add(json);
            } else {
                return new NetworkPrintResult(jsonResult, null);
            }
        }

        return new NetworkPrintResult(jsonResult, printLabel(listLabelId, listJson));
    }

    public static NetworkPrintResult printLabel(String labelId) {
        return printLabel(labelId, null);
    }

    public static NetworkPrintResult printLabel(String labelId, String smcId) {
        List<String> list = new ArrayList<>();
        list.add(labelId);
        return printLabel(list, smcId);
    }

    public static int dpToPx(int dp) {
        return (int) (dp * Resources.getSystem().getDisplayMetrics().density);
    }

    public static int pxToDp(int px) {
        return (int) (px / Resources.getSystem().getDisplayMetrics().density);
    }

    public static int compareLocations(String locationCode1, String locationCode2) {

        //if (locationCode1.equalsIgnoreCase("8-0-0")) {
        //    locationCode1 += "";
        //}

        if (App.getInstance().isLocationCorrect(locationCode1) && App.getInstance().isLocationCorrect(locationCode2)) {
            try {
                String[] arr1 = locationCode1.split("-");
                String[] arr2 = locationCode2.split("-");

                for (int i = 0; i < arr1.length; i++) {
                    int r = Integer.compare(parseInt(arr1[i]), parseInt(arr2[i]));
                    if (r != 0) return r;
                }

            } catch (Exception ignored) {
            }
        }

        return locationCode1.compareTo(locationCode2);
    }

    /*public static int compareWeight(int weight1, int weight2) {
        return Integer.compare(weight1, weight2);
    }*/

    public static String factToString(int fact) {
        if (fact > 0) {
            return Utils.format("%.3f", fact / 1000.0f);
        } else {
            return "";
        }
    }

    public static float getTotalWeightPercent(int plan, int fact) {
        if (fact == 0) return 0;
        if (plan == 0 && fact > 0) return 100;
        if (fact == plan) return 100;

        if (fact < plan) {
            return 100.0f - (fact * 100.0f / plan);
        } else {
            return (fact * 100.0f / plan) - 100.0f;
        }
    }

    public static String getTotalWeightPercentString(int plan, int fact) {
        if (fact == 0) return "";
        if (plan == 0 && fact > 0) return "(100%)";
        if (fact == plan) return "(0%)";

        if (fact < plan) {
            return Utils.format("(-%.2f%%)", 100.0f - (fact * 100.0f / plan));
        } else {
            return Utils.format("(+%.2f%%)", (fact * 100.0f / plan) - 100.0f);
        }
    }

    public static void setOnFocusListener(View.OnFocusChangeListener listener, View... views) {
        for (View view : views) {
            view.setOnFocusChangeListener(listener);
        }
    }

    public static int compareShipStatus(int s1, int s2) {
        /*
        @DrawableRes int imageId = R.drawable.ic_car_green;
        if (status == 0) imageId = R.drawable.ic_car_yellow;
        else if (status == 1) imageId = R.drawable.ic_car_red;
         */
        int c1 = 2, c2 = 2;

        if (s1 == 0) c1 = 1;
        else if (s1 == 1) c1 = 3;

        if (s2 == 0) c2 = 1;
        else if (s2 == 1) c2 = 3;

        return Integer.compare(c1, c2);
    }

    public static void setCorrectTint(View view, boolean correct) {
        if (correct) {
            view.setBackgroundTintList(null);
        } else {
            view.setBackgroundTintList(ContextCompat.getColorStateList(App.getInstance(), R.color.tint_incorrect));
        }
    }

    public static String getArrayItem(String[] array, int index) {
        return index > array.length - 1 ? "" : array[index];
    }

    public static String getLabelStatusDescr(String statusId) {

		/*
    <string name="inc_status_0">Прийомка триває</string>
    <string name="inc_status_1">Передано у SAP</string>
    <string name="inc_status_2">Обробляється SAP</string>
    <string name="inc_status_5">Оброблено SAP EWM</string>
    <string name="inc_status_7">Оприходувано SAP</string>
    <string name="inc_status_8">Відхилено SAP</string>
    <string name="inc_status_99">Чекаю менеджера</string>
    <string name="inc_status_97">Менеджер відхилив</string>
    <string name="inc_status_null">Прийомку не розпочато</string>
		 */

        switch (statusId) {
            case "0":
            case "97":
                return "розвантаження";
            case "1":
            case "2":
                return "чекаю на приход SAP";
            case "3":
                return App.getInstance().getString(R.string.inc_status_3);
            case "5":
                return App.getInstance().getString(R.string.inc_status_5);
            case "99":
                return "триває обробка";
            case "8":
                return "видалено SAP";
            case "7":
                return "оприходувано SAP";
            case "90":
            case "91":
                return "резерв";
            default:
                return statusId;
        }
    }

    public static boolean isJSONValid(String test) {
        try {
            new JSONObject(test);
        } catch (JSONException ex) {
            try {
                new JSONArray(test);
            } catch (JSONException ex1) {
                return false;
            }
        }
        return true;
    }

    public static void killThread(Thread thread) {
        if (thread != null) {
            try {
                thread.interrupt();
            } catch (Exception ignored) {

            }
        }
    }

    public static int getArrayIndex(String[] array, String value) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].equalsIgnoreCase(value)) return i;
        }
        return -1;
    }

    @DrawableRes
    public static int getStatusDrawable(String status) {
        switch (status) {
            case "0":
            case "1":
            case "2":
                return R.drawable.ic_train_yellow;
            case "3":
                return R.drawable.ic_train_orange;
            case "4":
            case "5":
            case "7":
                return R.drawable.ic_train_black;
            case "99":
                return R.drawable.ic_train_blue;
            case "8":
            case "97":
                return R.drawable.ic_train_red;
            default:
                return R.drawable.ic_train_green;
        }
    }

    public static float[] parseSize(String sizeStr) {
        String[] sizeStrArr = App.getInstance().stringToSize(sizeStr);
        return new float[]{
                Utils.parseFloat(sizeStrArr[0]),
                Utils.parseFloat(sizeStrArr[1]),
                Utils.parseFloat(sizeStrArr[2])
        };
    }

    public static float dpToPixel(float dp) {
        return dp * ((float) App.getInstance().getResources().getDisplayMetrics().densityDpi / DisplayMetrics.DENSITY_DEFAULT);
    }

    public static float pixelsToDp(float px) {
        return px / ((float) App.getInstance().getResources().getDisplayMetrics().densityDpi / DisplayMetrics.DENSITY_DEFAULT);
    }

    public static String quoteJsonString(String value) {
        try {
            return JSONObject.quote(value);
        } catch (Exception e) {
            return "\"\"";
        }
    }

    public static String format(String format, Object... args) {
        try {
            return String.format(App.getInstance().getLocale(), format, args);
        } catch (Exception ignored) {
            return format;
        }
    }

    public static boolean equalsIgnoreCaseIn(String string, String... args) {
        for (String arg : args) {
            if (string.equalsIgnoreCase(arg)) return true;
        }
        return false;
    }

    public static Date addDays(Date date, int dayCount) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, dayCount);
        return calendar.getTime();
    }

    public static String onNullOrEmpty(String string, String onNull) {
        return string == null || string.isEmpty() ? onNull : string;
    }

    public static boolean isNullOrEmpty(String string) {
        return string == null || string.isEmpty();
    }

	/*public static <T> boolean contains(List<T> list, T item) {
		for (T obj : list) {
			if (obj.equals(item)) return true;
			//if (obj instanceof String && obj.equals(item.toString()));
		}
		return false;
	}*/

    public static boolean contains(List<String> list, String item) {
        for (String obj : list) {
            if (obj.equals(item)) return true;
        }
        return false;
    }

    public static StoreItem getSourceStoreItem(List<StoreItem> list) {
        if (list == null) return null;
        for (StoreItem item : list) {
            if (item.isSource()) return item;
        }
        return null;
    }

    public static List<StoreItem> getTransStoreItems(List<StoreItem> list) {
        List<StoreItem> res = new ArrayList<>();
        if (list != null) {
            for (StoreItem item : list) {
                if (!item.isSource()) {
                    res.add(item);
                }
            }
        }
        return res;
    }

    public static StoreItem getStoreItem(List<StoreItem> list, String smcId) {
        if (list != null) {
            for (StoreItem item : list) {
                if (item.getSmcId().equalsIgnoreCase(smcId)) {
                    return item;
                }
            }
        }
        return null;
    }

    public static String getBuyoutStatusDescr(String statusId) {

        switch (statusId) {
            case "1":
                return "Відправлено в SAP";
            case "7":
                return "Оприходувано SAP";
            case "97":
                return "Відхилено SAP";
            default:
                return "Активне завдання";
        }
    }

    @DrawableRes
    public static int getBuyoutStatusDrawable(String status) {
        switch (status) {
            case "1":
                return R.drawable.ic_archive_blue;
            case "7":
                return R.drawable.ic_archive_black;
            case "97":
                return R.drawable.ic_archive_red;
            default:
                return R.drawable.ic_archive;
        }
    }
}
