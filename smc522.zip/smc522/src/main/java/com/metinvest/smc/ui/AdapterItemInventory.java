package com.metinvest.smc.ui;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.tools.Utils;

import org.json.JSONObject;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemInventory extends AbstractFlexibleItem<AdapterItemInventory.AdapterItemInventoryViewHolder> {

    private final JSONObject json;

    public AdapterItemInventory(JSONObject json) {
        this.json = json;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterItemInventory && ((AdapterItemInventory) o).getJson().equals(getJson());
    }

    public JSONObject getJson() {
        return json;
    }

    @Override
    public AdapterItemInventoryViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new AdapterItemInventoryViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemInventoryViewHolder holder, int position, List<Object> payloads) {

        holder.textTitle.setText(Utils.getJsonStringIgnoreCase(json, "saP_Matt_Descr"));

        StringBuilder sb = new StringBuilder();

        sb.append(Utils.format("Партія: %s<br>", Utils.getJsonStringIgnoreCase(json, "sap_batch")));
        sb.append(Utils.format("Вага нетто: %s кг.<br>", Utils.getJsonStringIgnoreCase(json, "nett_Weight")));
        sb.append(Utils.format("Вага упаковки: %s кг.<br>", Utils.getJsonStringIgnoreCase(json, "pack_Weight")));
        sb.append(Utils.format("Розмір: %s", App.getInstance().sizeToString(
                Utils.getJsonFloatIgnoreCase(json, "width"),
                Utils.getJsonFloatIgnoreCase(json, "length"),
                Utils.getJsonFloatIgnoreCase(json, "thickness")
                )
        ));

        holder.textContent.setText(App.getInstance().fromHtml(sb.toString()));

        holder.textTitle.setVisibility(View.VISIBLE);
        holder.imageView.setVisibility(View.GONE);
    }

    @Override
    public void unbindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemInventoryViewHolder holder, int position) {
        //empty
    }

    @Override
    public void onViewAttached(FlexibleAdapter<IFlexible> adapter, AdapterItemInventoryViewHolder holder, int position) {
        //empty
    }

    @Override
    public void onViewDetached(FlexibleAdapter<IFlexible> adapter, AdapterItemInventoryViewHolder holder, int position) {
        //empty
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_inventory_row;
    }

    /**
     * The ViewHolder used by this item.
     * Extending from FlexibleViewHolder is recommended especially when you will use
     * more advanced features.
     */
    public class AdapterItemInventoryViewHolder extends FlexibleViewHolder {

        private final View view;

        public TextView textTitle, textContent;
        public ImageView imageView;

        public AdapterItemInventoryViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.view = view;
            this.textTitle = view.findViewById(R.id.textTitle);
            this.textContent = view.findViewById(R.id.textContent);
            this.imageView = view.findViewById(R.id.imageView);
        }
    }
}
