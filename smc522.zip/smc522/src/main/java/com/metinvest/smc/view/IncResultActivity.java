package com.metinvest.smc.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.App;
import com.metinvest.smc.BuildConfig;
import com.metinvest.smc.R;
import com.metinvest.smc.db.IdQrStore;
import com.metinvest.smc.inc.Order;
import com.metinvest.smc.inc.Ozm;
import com.metinvest.smc.inc.SohFilter;
import com.metinvest.smc.inc.TTN;
import com.metinvest.smc.inc.TransportDoc;
import com.metinvest.smc.inc.Weight;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class IncResultActivity extends MyActivity {

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.textContent)
    TextView textContent;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;
    @BindView(R.id.buttonPrint)
    Button buttonPrint;
    @BindView(R.id.viewButtonPrint)
    View viewButtonPrint;
    @BindView(R.id.viewButtonAccept)
    View viewButtonAccept;

    private TransportDoc transportDoc;
    private String locationCode;
    private Ozm ozm;
    private boolean isTheor;
    private int weightCraneBrutto, weightCraneNetto, packCount;
    private ArrayList<Weight> weightList;
    private ArrayList<Order> orderList;
    private ArrayList<Integer> weightListFinal;
    private boolean accepted;
    private FlexibleAdapter<Adapter> adapter;
    private boolean isNew = false;

    private long myPacketId = 0;

    private List<String> idQrList;
    private String sohSmcId;
    private SohFilter sohFilter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inc_result);
        ButterKnife.bind(this);

        isNew = getIntent().getBooleanExtra("isNew", false);
        if (isNew) {
            log("isNew(!)");
        }

        transportDoc = TransportDoc.fromTransport(
                getIntent().getStringExtra("transportJson"),
                (TTN) getIntent().getSerializableExtra("ttn")
        );

        sohSmcId = getIntent().getStringExtra("sohSmcId");
        sohFilter = sohSmcId == null ? SohFilter.NotSoh() : SohFilter.SohInc(sohSmcId);
        ozm = (Ozm) getIntent().getSerializableExtra("ozm");
        isTheor = getIntent().getBooleanExtra("isTheor", false);
        weightCraneBrutto = getIntent().getIntExtra("weightCraneBrutto", 0);
        weightCraneNetto = getIntent().getIntExtra("weightCraneNetto", 0);
        packCount = getIntent().getIntExtra("packCount", 0);
        locationCode = getIntent().getStringExtra("locationCode");
        weightList = new ArrayList<>(getIntent().getParcelableArrayListExtra("weightList"));
        ArrayList<String> currentOrderListJson = getIntent().getStringArrayListExtra("orderList");

        orderList = new ArrayList<>();
        if (currentOrderListJson != null) {
            for (String json : currentOrderListJson) {
                orderList.add(new Order(json));
            }
        }

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
        listView.setLayoutManager(layoutManager);
        listView.addItemDecoration(dividerItemDecoration);

        viewButtonPrint.setVisibility(View.GONE);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            if (accepted)
                buttonPrintClick();
            else
                buttonAcceptClick();
        }
    }

    private Weight getTotalWeight() {
        Weight total = new Weight(0, 0, 0);
        for (Weight weight : weightList) {
            total.setNetto(total.getNetto() + weight.getNetto());
            total.setPack(total.getPack() + weight.getPack());
            total.setTara(total.getTara() + weight.getTara());
        }
        return total;
    }

    private void beginLoad() {
        if (isLoading()) return;

        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            idQrList = new ArrayList<>();
            weightListFinal = new ArrayList<>(packCount);
            double weightExtra = 0.0d;

            Weight totalWeight = getTotalWeight();
            int weightToDivide = weightCraneBrutto - totalWeight.getBrutto();

            for (int i = 0; i < packCount; i++) {

                double weightToAdd = 0;

                if (weightToDivide != 0) {
                    double itemPercent = totalWeight.getNetto() == 0 ? 0 : (double) weightList.get(i).getNetto() * 100.0d / totalWeight.getNetto();
                    weightToAdd = itemPercent * weightToDivide / 100.0d;
                }

                weightExtra += weightToAdd - (int) weightToAdd;
                weightListFinal.add(weightList.get(i).getNetto() + (int) weightToAdd);

                idQrList.add(weightList.get(i).getIdQr());

                if (weightList.get(i).getIdQr().length() > 0)
                    log("IDQR: %s", weightList.get(i).getIdQr());
            }

            weightExtra = Math.round(weightExtra);

            log("weightExtra: %s", weightExtra);

            if (Math.abs(weightExtra) > 0) {
                int i = 0;
                while (Math.abs(weightExtra) >= 1.0d) {
                    weightListFinal.set(i, weightListFinal.get(i) + (weightExtra > 0 ? 1 : -1));
                    weightExtra -= (weightExtra > 0 ? 1 : -1);
                    i = i == weightListFinal.size() - 1 ? 0 : i + 1;
                }
            }

            log("weightExtra: %s", weightExtra);

            String sb = Utils.format("<b>%s %s</b><br>", ozm.getName(), app.sizeToString(ozm.getLength(), ozm.getWidth(), ozm.getThickness())) +
                    Utils.format("<b>Брутто, тн: </b>%.3f<br>", weightCraneBrutto / 1000.0f) +
                    Utils.format("<b>Локація: </b>%s<br>", locationCode) +
                    Utils.format("<b>Пачок, шт: </b>%d", packCount);
            runOnUiThread(() -> endLoad(sb));
        });
    }

    private void endLoad(String content) {
        hideLoading();
        textContent.setText(app.fromHtml(content));

        List<Adapter> list = new ArrayList<>();

        for (int i = 0; i < packCount; i++) {
            list.add(new Adapter(i, transportDoc, null, ozm, isTheor, isTheor ? packCount : 0,
                    ozm.isManual() ? null : orderList.get(i), weightList.get(i), weightListFinal.get(i),
                    this::onLabelPrintClicked, locationCode, weightList.get(i).getBarcode()
                    ,null, "", ""));
        }

        setAdapter(list);
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        beginAccept();
    }

    private void buttonPrintClick() {
        beginPrint(adapter.getCurrentItems(), true);
    }

    private void beginAccept() {

        showLoading(R.string.text_please_wait);
        buttonAccept.setEnabled(false);

        Utils.runOnBackground(() -> {

            String url;
            JsonResult result;
            //List<String> listLabelId = new ArrayList<>();
            List<Label> listLabelId = new ArrayList<>();

            if (ozm.isManual()) {

                url = config.getUrlApi() + "addsapinbounditemmanual";
                if (sohFilter.getSohSmcId() != null)
                    url = net.addUrlParam(url, "smc_id", sohFilter.getSohSmcId());
                if (config.getStorage() != null)
                    url = net.addUrlParam(url, "lgort", config.getStorage());
                url = net.addUrlParam(url, "is_auto", config.isAutoBatch() ? "true" : "false");
                url = net.addUrlParam(url, "CraneId", (int)config.getCraneId());

                StringBuilder sb = new StringBuilder();

                sb.append("{");

                sb.append(Utils.format("%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n"
                        , Utils.format("\"Type\":\"%d\",", 3)
                        , Utils.format("\"Smc_Id\":\"%s\",", config.getSmcId())
                        , Utils.format("\"Date_Printed\":\"%s\",", app.getDateTimeFormat().format(Calendar.getInstance().getTime()))
                        , Utils.format("\"User_id\":\"%d\",", app.getConfUserId())
                        , Utils.format("\"TTN_NUM\":\"%s\",", transportDoc.getTtn().getNum())
                        , Utils.format("\"TTN_CARRIER_ID\":\"%s\",", transportDoc.getTransport().getName())
                        , Utils.format("\"PLAN_DATE\":\"%s\",", app.getDateFormat().format(transportDoc.getTransport().getDate()))
                ));

                sb.append("\"items\":");

                sb.append("[");

                for (int i = 0; i < packCount; i++) {

                    Weight weight = weightList.get(i);
                    int weightFinal = weightListFinal.get(i);

                    sb.append(Utils.format("{%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n}"
                            , Utils.format("\"SAP_Matt_Descr\":\"%s\",", ozm.getName())
                            , Utils.format("\"Length\":\"%s\",", ozm.getLength())
                            , Utils.format("\"Width\":\"%s\",", ozm.getWidth())
                            , Utils.format("\"Thickness\":\"%s\",", ozm.getThickness())
                            , Utils.format("\"MENGE_BIRK\":\"%s\",", weight.getNetto())
                            , Utils.format("\"MENGE_FACT\":\"%s\",", weightFinal)
                            , Utils.format("\"MENGE_TARA\":\"%s\",", weight.getTara())
                            , Utils.format("\"MENGE_PACK\":\"%s\",", weight.getPack())
                            , Utils.format("\"Location\":\"%s\",", locationCode)
                            , Utils.format("\"TEOR_Weight\":%s", isTheor ? "true" : "false")
                    ));

                    if (i + 1 < packCount) sb.append(",");

                }

                sb.append("]");

                sb.append("}");

                result = net.uploadJson(url, sb.toString(), myPacketId);

                if (result.isOk()) {
                    JSONArray jsonArray = Utils.getJsonArray(Utils.getJsonObject(result.getJson(), "data"), "label_Id_List");
                    for (int i = 0; jsonArray != null && i < jsonArray.length(); i++) {
                        String labelId = Utils.getJsonString(jsonArray, i);
                        //listLabelId.add(labelId == null ? "" : labelId));
                        //Utils.runOnBackground(() -> {
                            Label label = null;
                            if (labelId != null) {
                            String urlLabel = config.getUrlApi() + "getlabelinfo";
                            urlLabel = net.addUrlParam(urlLabel, "label_id", labelId);
                            urlLabel = net.addUrlParam(urlLabel, "smc_id", "NULL");
                            JsonResult resultLabel = net.downloadJson(urlLabel);
                            if (resultLabel.isOk()) {
                                //GET LABEL
                                JSONObject json = Utils.getJsonObject(resultLabel.getJson(), "data");
                                label = Label.fromJson(json, labelId);
                            }
                            }
                        //});
                        listLabelId.add(label);
                    }
                }

            }
            else {

                url = config.getUrlApi() + "addsapinbounditem";
                if (sohFilter.getSohSmcId() != null)
                    url = net.addUrlParam(url, "smc_id", sohFilter.getSohSmcId());
                if (config.getStorage() != null)
                    url = net.addUrlParam(url, "lgort", config.getStorage());

                url = net.addUrlParam(url, "is_auto", config.isAutoBatch() ? "true" : "false");
                url = net.addUrlParam(url, "CraneId", (int)config.getCraneId());

                StringBuilder sb = new StringBuilder();

                sb.append("[");

                for (int i = 0; i < packCount; i++) {

                    Order order = orderList.get(i);
                    Weight weight = weightList.get(i);
                    int weightFinal = weightListFinal.get(i);

                    sb.append(Utils.format("{%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n}"
                            , Utils.format("\"PLAN_LINE_ID\":\"%s\",", order.getLineId())
                            , Utils.format("\"ID_FV\":%s,", "null")
                            , Utils.format("\"DATE_FV\":\"%s\",", app.getDateFormat().format(Calendar.getInstance().getTime()))
                            , Utils.format("\"MENGE_BIRK\":\"%s\",", weight.getNetto())
                            , Utils.format("\"MENGE_FACT\":\"%s\",", weightFinal)
                            , Utils.format("\"MENGE_TARA\":\"%s\",", weight.getTara())
                            , Utils.format("\"MENGE_PACK\":\"%s\",", weight.getPack())
                            , Utils.format("\"Location\":\"%s\",", locationCode)
                            , Utils.format("\"TEOR_Weight\":%s,", isTheor ? "true" : "false")
                            , Utils.format("\"ID_QR\":%s,", weight.getIdQr().isEmpty() ? "null" : Utils.format("\"%s\"", weight.getIdQr()))
                            , Utils.format("\"Parent_Temp_LabelId\":%s,", weight.getId().isEmpty() ? "null" : weight.getId())
                            , Utils.format("\"QR_CODE\":%s", weight.getBarcode().isEmpty() ? "null" : Utils.format("\"%s\"", Base64.getEncoder().encodeToString(weight.getBarcode().getBytes()) ))
                    ));

                    if (i + 1 < packCount) sb.append(",");

                }

                sb.append("]");

                result = net.uploadJson(url, sb.toString(), myPacketId);

                if (result.isOk()) {
                    JSONArray jsonArray = Utils.getJsonArray(Utils.getJsonObject(result.getJson(), "data"), "label_Id_List");
                    for (int i = 0; jsonArray != null && i < jsonArray.length(); i++) {
                        String labelId = Utils.getJsonString(jsonArray, i);
                        //listLabelId.add(labelId == null ? "" : labelId);
                        //Utils.runOnBackground(() -> {
                        Label label = null;
                        if (labelId != null) {
                            String urlLabel = config.getUrlApi() + "getlabelinfo";
                            urlLabel = net.addUrlParam(urlLabel, "label_id", labelId);
                            urlLabel = net.addUrlParam(urlLabel, "smc_id", "NULL");
                            JsonResult resultLabel = net.downloadJson(urlLabel);
                            if (resultLabel.isOk()) {
                                //GET LABEL
                                JSONObject json = Utils.getJsonObject(resultLabel.getJson(), "data");
                                label = Label.fromJson(json, labelId);
                                listLabelId.add(label);
                            }
                        }

                            //listLabelId.add(label);
                        //});
                    }
                }
            }

            JsonResult finalResult = result;
            runOnUiThread(() -> endAccept(finalResult, listLabelId));
        });
    }

    private void endAccept(JsonResult result, List<Label> listLabelId) {

        hideLoading();
        buttonAccept.setEnabled(true);

        if (result.isOk()) {
            finishAccept(listLabelId);
        } else if (result.getStatus() == LoadResultStatus.ZERO) {
            AlertDialog dialog = showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_inc_batch_to_old, (dialog1, which) -> {
                setResult(RESULT_NEED_REFRESH);
                finish();
            });
            dialog.setCanceledOnTouchOutside(false);
            dialog.setCancelable(false);

        } else if (result.getStatus() == LoadResultStatus.MINUS1) {
            AlertDialog dialog = showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_inc_status_deleted, (dialog1, which) -> {
                setResult(RESULT_DELETED);
                finish();
            });
            dialog.setCanceledOnTouchOutside(false);
            dialog.setCancelable(false);
        } else {
            myPacketId = result.getPacketId();
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginAccept());
        }
    }

    private void finishAccept(List<Label> listLabelId) {

        accepted = true;
        viewButtonPrint.setVisibility(View.VISIBLE);
        viewButtonAccept.setVisibility(View.GONE);
        textContentTitle.setText(R.string.title_activity_inc_result_accepted);

        finishIdQr();
        List<Adapter> list = new ArrayList<>();

            for (int i = 0; i < packCount; i++) {
                list.add(new Adapter(
                        i, transportDoc, listLabelId.get(i).getId(), ozm, isTheor, isTheor ? packCount : 0,
                        ozm.isManual() ? null : orderList.get(i), weightList.get(i), weightListFinal.get(i),
                        this::onLabelPrintClicked, locationCode, weightList.get(i).getBarcode(),
                        listLabelId.get(i).getLowPricePercent(), listLabelId.get(i).getManufacturer(), listLabelId.get(i).getSortCriterion()));
            }

        setAdapter(list);

    }

    private void finishIdQr() {
        if (idQrList != null) {
            for (String idQr : idQrList) {
                try {
                    if (db.idQrStoreDao().getByName(idQr) == null) {
                        IdQrStore item = new IdQrStore(0, idQr);
                        db.idQrStoreDao().insert(item);
                    }
                    log("IDQR #%s inserted", idQr);
                } catch (Exception ignored) {

                }
            }
        }
    }

    private void setAdapter(List<Adapter> items) {
        adapter = new FlexibleAdapter<>(items);
        listView.setAdapter(adapter);
        scrollView.post(() -> scrollView.scrollTo(0, 0));
    }

    @Override
    public void onBackPressed() {
        close();
        super.onBackPressed();
    }

    private void close() {
        if (accepted) {
            setResult(RESULT_OK);
        } else {
            setResult(RESULT_CANCELED);
        }
        finish();
    }

    private void onLabelPrintClicked(Adapter item) {
        List<Adapter> list = new ArrayList<>();
        list.add(item);
        beginPrint(list, false);
    }

    private void beginPrint(List<Adapter> listToPrint, boolean isPrintAll) {
        if (isLoading() || !buttonPrint.isEnabled()) return;

        showLoading(R.string.text_printing_title);
        buttonPrint.setEnabled(false);

        Utils.runOnBackground(() -> {
            StringBuilder data = new StringBuilder();

            if (isPrintAll && isTheor) {
                Adapter item = listToPrint.get(listToPrint.size() - 1);

                data.append(app.generateDplLabel(
                        item.getLabelId(), item.getDate(), item.getOzm().getName(),
                        item.getOzm().getWidth(), item.getOzm().getLength(), item.getOzm().getThickness(),
                        item.getWeightFinal(), item.getWeight().getPack(), item.getWeight().getTara(),
                        item.getOrder() == null ? "" : item.getOzm().getOzm(), "THEOR",
                        item.getTransportDoc().getTransport().getName(), 0,
                        item.isTheor(), packCount, item.getLocationCode(),
                        item.getZavBatch(), item.getZavPlavka(), item.getZavOdin(),
                        item.getLowPrice(), item.getProizvod(), item.getPostavkaMera(), null));
            } else {
                for (Adapter item : listToPrint) {

                    data.append(app.generateDplLabel(
                            item.getLabelId(), item.getDate(), item.getOzm().getName(),
                            item.getOzm().getWidth(), item.getOzm().getLength(), item.getOzm().getThickness(),
                            item.getWeightFinal(), item.getWeight().getPack(), item.getWeight().getTara(),
                            item.getOrder() == null ? "" : item.getOzm().getOzm(),
                            item.getOrder() == null ? "TEMP" : item.getBatch(),
                            item.getTransportDoc().getTransport().getName(), 0,
                            item.isTheor(), item.getTheorCount(), item.getLocationCode(),
                            item.getZavBatch(), item.getZavPlavka(), item.getZavOdin(),
                            item.getLowPrice(), item.getProizvod(), item.getPostavkaMera(), null));
                }
            }

            StringBuilder dplName = new StringBuilder("<b>Зважування</b><br>");
            dplName.append(Utils.format("%s<br>", transportDoc.getTransport().getName()));
            dplName.append(Utils.format("ТТН: %s<br>", transportDoc.getTtn().getNum()));
            dplName.append(Utils.format("Вага з крану: %s кг.<br>", weightCraneBrutto));
            dplName.append(Utils.format("Кількість позицій: %s<br>", packCount));
            if (isTheor) {
                dplName.append(Utils.format("Теоретична вага: %s", weightListFinal.get(0)));
            } else {
                for (int i = 0; i < packCount; i++) {
                    dplName.append(Utils.format("Позиція №%s: %s кг", i + 1, weightListFinal.get(i)));
                    if (i + 1 < packCount) dplName.append("<br>");
                }
            }
            final Printer.PrintResult result = Printer.sendCommand(dplName.toString(), config.getPrinter(), data.toString());
            if (result.getStatus() == Printer.PrintResultStatus.OK)
            {
                String url = config.getUrlApi() + "setPrintLabel";
                StringBuilder sb = new StringBuilder();
                sb.append("[");

                for (int i = 0; i < listToPrint.size(); i++) {
                    sb.append(Utils.format("%s", listToPrint.get(i).getLabelId()
                    ));
                    if (i + 1 < listToPrint.size()) sb.append(",");
                }

                sb.append("]");
                //если успешно напечатано, то в labels обновляем printLabel = 1 по label_id
                JsonResult resultPrintLabel = net.uploadJson(url, sb.toString(), myPacketId);
                //if (resultPrintLabel.isOk()) {}
            }

            runOnUiThread(() -> endPrint(result, isPrintAll));
        });
    }

    private void endPrint(Printer.PrintResult result, boolean closeOnSuccess) {

        buttonPrint.setEnabled(true);
        hideLoading();

        if (result.getStatus() == Printer.PrintResultStatus.OK) {
            showToast(R.string.text_print_result_succeeded);
            //app.sendFaPrint();
            if (closeOnSuccess) close();
        } else {
            @StringRes final int message = app.getPrintResultMessage(result);

            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> {
                dialog.dismiss();
                buttonPrintClick();
            });
        }

    }

    public static class Adapter extends AbstractFlexibleItem<Adapter.ViewHolder> {

        private final String labelId;
        private final Order order;
        private final Weight weight;
        private final int weightFinal;
        private final Date date;
        private final Ozm ozm;
        private final boolean theor;
        private final TransportDoc transportDoc;
        private final String locationCode;
        private final int theorCount;
        private final String qrCode;
        private String zavPlavka, zavBatch, zavOdin;
        private String proizvod, postavkaMera, lowPrice;

        public String getBatch() {
            return order == null ? "TEMP" : (App.getInstance().getConfig().isAutoBatch() ? "АВТО" : order.getBatch());
        }

        public int getTheorCount() {
            return theorCount;
        }

        public interface Listener {
            void onPrintClicked(Adapter item);
        }

        private final int index;
        private final Listener listener;

        public Adapter clone() {
            return new Adapter(index, transportDoc, labelId, ozm, theor, theorCount, order, weight, weightFinal, listener, locationCode, qrCode, lowPrice, proizvod, postavkaMera);
        }

        public Adapter(int index, TransportDoc transportDoc, String labelId, Ozm ozm, boolean theor,
                       int theorCount, Order order, Weight weight, int weightFinal, Listener listener,
                       String locationCode, String qrCode, String lowPrice, String proizvod, String postavkaMera) {
            this.date = Calendar.getInstance().getTime();
            this.transportDoc = transportDoc;
            this.ozm = ozm;
            this.theor = theor;
            this.theorCount = theorCount;
            this.index = index;
            this.labelId = labelId;
            this.order = order;
            this.weight = weight;
            this.weightFinal = weightFinal;
            this.listener = listener;
            this.locationCode = locationCode;
            this.qrCode = qrCode;
			this.lowPrice = lowPrice;
			this.proizvod = proizvod;
			this.postavkaMera = postavkaMera;

            zavPlavka = null;
            zavBatch = null;
            zavOdin = null;

            if (qrCode.length() > 0) {
                ScanItem scanItem = new ScanItem(qrCode);
                if (scanItem.isCorrect()) {
                    if (scanItem.getType() == ScanItem.ScanItemType.KOMINMET) {
                        zavPlavka = scanItem.getData(2);
                        zavBatch = scanItem.getData(3);
                        zavOdin = null;
                    } else if (scanItem.getType() == ScanItem.ScanItemType.ZAPOR) {
                        zavPlavka = scanItem.getData(7);
                        zavBatch = scanItem.getData(8);
                        zavOdin = scanItem.getData(9);
                    } else if (scanItem.getType() == ScanItem.ScanItemType.TRUBOSTAL) {
                        zavPlavka = scanItem.getData(3);
                        zavBatch = "";
                        zavOdin = null;
                    } else if (scanItem.getType() == ScanItem.ScanItemType.ARCELOR) {
                        zavPlavka = "";
                        zavBatch = "";
                        zavOdin = null;
                    }
                }
            }
        }

        public String getProizvod() {
            return proizvod;
        }

        public String getPostavkaMera() {
            return postavkaMera;
        }

        public String getLowPrice() {
            return lowPrice;
        }

        public String getZavPlavka() {
            return zavPlavka;
        }

        public String getZavBatch() {
            return zavBatch;
        }

        public String getZavOdin() {
            return zavOdin;
        }

        public String getLocationCode() {
            return locationCode;
        }

        public TransportDoc getTransportDoc() {
            return transportDoc;
        }

        public boolean isTheor() {
            return theor;
        }

        public Ozm getOzm() {
            return ozm;
        }

        public Date getDate() {
            return date;
        }

        public String getLabelId() {
            return labelId;
        }

        public Order getOrder() {
            return order;
        }

        public Weight getWeight() {
            return weight;
        }

        public int getWeightFinal() {
            return weightFinal;
        }

        public int getIndex() {
            return index;
        }

        public String getQrCode() {
            return qrCode;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof Adapter && ((Adapter) o).getLabelId().equalsIgnoreCase(getLabelId());
        }

        @Override
        public int hashCode() {
            return getLabelId().hashCode();
        }

        @Override
        public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
            return new ViewHolder(view, adapter);
        }

        @Override
        public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {

            String title;

            if (labelId == null) {
                title = Utils.format("<b><font color=\"#34326D\">Позиція №%d</font></b>", index + 1);
            } else {
                title = Utils.format("<b><font color=\"#34326D\">LabelId %s</font></b>", labelId);
            }

            holder.textTitle.setText(App.getInstance().fromHtml(title));

            StringBuilder sb = new StringBuilder();

            sb.append(Utils.format("Вага з бірки, тн: %.3f", weight.getNetto() / 1000.0f));
            sb.append(Utils.format("<br>Упаковка, кг: %d", weight.getPack() + weight.getTara()));
            sb.append(Utils.format("<br>Призначена вага, тн: %.3f", weightFinal / 1000.0f));
            sb.append(Utils.format("<br>Партія: %s", getBatch()));

            if (BuildConfig.DEBUG) {
                if (!weight.getIdQr().isEmpty())
                    sb.append(Utils.format("<br>ID_QR: %s", weight.getIdQr()));
            }

            if (listener != null) {
                holder.buttonPrint.setOnClickListener(v -> listener.onPrintClicked(this));
            }

            holder.textContent.setText(App.getInstance().fromHtml(sb.toString()));
            holder.buttonPrint.setVisibility(labelId == null || isTheor() ? View.INVISIBLE : View.VISIBLE);
        }

        @Override
        public int getLayoutRes() {
            return R.layout.adapter_inc_result;
        }

        public static class ViewHolder extends FlexibleViewHolder {

            @BindView(R.id.textTitle)
            TextView textTitle;
            @BindView(R.id.textContent)
            TextView textContent;
            @BindView(R.id.buttonPrint)
            ImageButton buttonPrint;

            public ViewHolder(View view, FlexibleAdapter adapter) {
                super(view, adapter);
                ButterKnife.bind(this, view);
            }
        }
    }
}
