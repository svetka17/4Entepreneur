package com.metinvest.smc.tools;

import androidx.annotation.NonNull;

public class Location {
    public String code;
    public int weight;

    public Location(String code, int weight) {
        this.code = code;
        this.weight = weight;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    @NonNull
    @Override
    public String toString() {
        return Utils.format("[%s] %d кг.", code, weight);
    }
}
