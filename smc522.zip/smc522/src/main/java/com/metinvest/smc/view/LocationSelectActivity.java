package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.IValue;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.StoreItem;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.tools.Value;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.BindViews;
import butterknife.ButterKnife;

public class LocationSelectActivity extends MyActivity implements IScan {

    @BindViews({R.id.location1, R.id.location2, R.id.location3}) List<EditText> textLocation;
    @BindView(R.id.viewSmc) View viewSmc;
    @BindView(R.id.viewStorage) View viewStorage;
    @BindView(R.id.spinnerSmc) Spinner spinnerSmc;
    @BindView(R.id.spinnerStorage) Spinner spinnerStorage;
    @BindView(R.id.textContentTitle) TextView textContentTitle;
    private boolean withStorage, withSmc, isSoh;
    private List<IValue> listSmc, listStorage;
    private String labelStorage;
    private String labelId;
    private List<StoreItem> storeItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_select);
        ButterKnife.bind(this);

        withSmc = getIntent().getBooleanExtra("withSmc", false);
        withStorage = getIntent().getBooleanExtra("withStorage", false);
        isSoh = getIntent().getBooleanExtra("isSoh", false);
        labelStorage = getIntent().getStringExtra("labelStorage");
        labelId = getIntent().getStringExtra("labelId");
        if (labelStorage == null) labelStorage = config.getStorage();

        viewStorage.setVisibility(withStorage ? View.VISIBLE : View.GONE);
        viewSmc.setVisibility(withSmc ? View.VISIBLE : View.GONE);
        textContentTitle.setText("Вибір локації"+(labelId==null||labelId==""?"":(" для бірки "+ (isSoh?" (СОХ) ":" (ОСН.СКЛАД) ")+labelId)));

        String locationDefault = getIntent().getStringExtra("locationCode");
        if (locationDefault != null) {
            try {
                String[] arr = app.fixLocation(locationDefault).split("-");
                for (int i = 0; i < 3; i++)
                    /*if (!arr[i].equalsIgnoreCase("0")) */
                    textLocation.get(i).setText(arr[i]);
            } catch (Exception ignored) {
            }
        }

        spinnerSmc.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                onSmcChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        if (withStorage) beginLoadStorageList();
    }

    private void beginLoadStorageList() {
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {
            storeItems = null;
            Network.NetworkResultValue<List<StoreItem>> result = net.loadStorageList(app.getSmcIdCurrent());
            runOnUiThread(() -> endLoadStorageList(result));
        });
    }

    private void endLoadStorageList(Network.NetworkResultValue<List<StoreItem>> result) {
        hideLoading();

        if (result.isOk()) {
            storeItems = result.getValue();

            StoreItem storeItem = Utils.getSourceStoreItem(storeItems);
            if (storeItem == null) {
                showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, R.string.error_data, (dialog, which) -> beginLoadStorageList(), (dialog, which) -> finish());
                return;
            }

            int selectedIndex = 0;
            listSmc = new ArrayList<>();
            for (int i = 0; i < storeItems.size(); i++) {
                if (storeItems.get(i).getSmcId().equalsIgnoreCase(app.getSmcIdCurrent())) {
                    selectedIndex = i;
                }
                if (withSmc) {
                    listSmc.add(new Value(i + 1, storeItems.get(i).getSmcId()));
                } else {
                    if (storeItems.get(i).getSmcId().equalsIgnoreCase(app.getSmcIdCurrent()))
                        listSmc.add(new Value(i + 1, storeItems.get(i).getSmcId()));
                }
            }

            Utils.fillData(spinnerSmc, listSmc);
            spinnerSmc.setSelection(selectedIndex);
            if (!withSmc) onSmcChanged();
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result.getResult()), (dialog, which) -> beginLoadStorageList(), (dialog, which) -> finish());
        }
    }

    private String getSelectedSmc() {
        if (spinnerSmc.getAdapter() != null || spinnerSmc.getSelectedItem() instanceof IValue) {
            return ((IValue) spinnerSmc.getSelectedItem()).getName();
        }
        return null;
    }

    private void onSmcChanged()
    {
        String selectedSmc = getSelectedSmc();
        if (selectedSmc == null) return;

        log("onSmcChanged(%s)", getSelectedSmc());

        StoreItem storeItem = Utils.getStoreItem(storeItems, selectedSmc);
        if (storeItem == null) return;

        int selectedIndex = 0;
        listStorage = new ArrayList<>();
        for (int i = 0; i < storeItem.getStoreList().size(); i++) {
            if (storeItem.getStoreList().get(i).equalsIgnoreCase(labelStorage)) {
                selectedIndex = i;
            }
            listStorage.add(new Value(i + 1, storeItem.getStoreList().get(i)));
        }

        Utils.fillData(spinnerStorage, listStorage);
        spinnerStorage.setSelection(selectedIndex);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number >= 2 && number <= 4) textLocation.get(number - 2).requestFocus();
        else if (number == 5) beginAccept();
    }

    private void beginAccept() {

        String locationCode = Utils.format("%s-%s-%s",
                textLocation.get(0).getText().toString(),
                textLocation.get(1).getText().toString(),
                textLocation.get(2).getText().toString()
        );

        if (!app.isLocationCorrect(locationCode) || textLocation.get(0).getText().toString().length() == 0) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.text_error_location_incorrect, null);
            textLocation.get(0).post(() -> textLocation.get(0).requestFocus());
            return;
        }

        Intent intent = new Intent();
        intent.putExtra("locationCode", app.fixLocation(locationCode));
        intent.putExtra("labelId", getIntent().getStringExtra("labelId"));
        intent.putExtra("withSmc", withSmc);
        intent.putExtra("isSoh", isSoh);
        intent.putExtra("withStorage", withStorage);
        if (withSmc) intent.putExtra("smcId", getSelectedSmc());
        if (withStorage) intent.putExtra("storage", getSelectedStorage());
        setResult(RESULT_OK, intent);
        finish();
    }

    private String getSelectedStorage() {
        int pos = spinnerStorage.getSelectedItemPosition();
        return pos >= 0 ? listStorage.get(pos).getName() : null;
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {
        if (isLoading()) return;

        runOnUiThread(() -> {

            ScanItem scanItem = new ScanItem(barcodeData);

            if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONCODE) {
                if (scanItem.isCorrect()) {
                    endLoadLocation(scanItem.getData(0));
                } else {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_location_label, null);
                }
            }

        });
    }

    private void endLoadLocation(String newLocationCode) {

        hideLoading();

        if (app.isLocationCorrect(newLocationCode)) {
            String[] arr = app.fixLocation(newLocationCode).split("-");
            textLocation.get(0).setText(arr[0]);
            textLocation.get(1).setText(arr[1]);
            textLocation.get(2).setText(arr[2]);
        } else {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.location_identity_error, null);
        }
    }
}
