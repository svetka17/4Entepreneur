package com.metinvest.smc.view;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Экран, который позволяет пользователю сканировать штрих-код, а затем отображает информацию о
 * штрих-коде.
 */
public class BarcodeInfoActivity extends MyActivity implements IScan {

	@BindView(R.id.barcodeText)
	EditText barcodeText;
	@BindView(R.id.buttonAccept)
	Button buttonAccept;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_barcode_info);
		ButterKnife.bind(this);
		setActionDone(barcodeText, buttonAccept);
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		barcodeText.requestFocus();
	}

	@Override
	protected String getHelpContent() {
		return "Відскануйте штрихкод";
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 5) {
			buttonAcceptClick();
		}
	}

	/**
	 * Если пользователь ввел штрих-код, то обработать его
	 */
	public void buttonAcceptClick() {
		if (isLoading() || !buttonAccept.isEnabled()) return;

		if (barcodeText.getText().length() == 0) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, "Відскануйте або введіть вручну штрихкод!", null);
			return;
		}

		String newLabelId = barcodeText.getText().toString();
		processLabelId(newLabelId);
	}

	@Override
	public void onBarcodeEvent(String barcodeData) {
		if (isLoading()) return;

		runOnUiThread(() -> {
			barcodeText.setText(barcodeData);
			processBarcode(barcodeData);
			barcodeText.setText(null);
		});
	}

	private void processLabelId(String data) {
		beginLoadLabel(data);
	}

	/**
	 * > Если отсканированный штрих-код является этикеткой, загрузите этикетку. Если это местоположение,
	 * загрузите местоположение. Если это SMC06, загрузите этикетку. Если это SMC02, покажите
	 * предупреждение. Если это Zapor, загрузите этикетку. Если это Коминмет, загрузите этикетку. Если это
	 * Трубосталь, загрузите этикетку. Если это Arcelor, загрузите этикетку. Если это SMC07, загрузите
	 * этикетку. Если ничего из перечисленного выше, показать предупреждение
	 *
	 * @param data отсканированный штрих-код
	 */
	private void processBarcode(String data) {
		ScanItem scanItem = new ScanItem(data);

		if (!scanItem.isCorrect()) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_identity_error, null);
		} else {

			if (scanItem.getType() == ScanItem.ScanItemType.LABELID) {
				beginLoadLabel(scanItem.getData(0));
			} else if (scanItem.getType() == ScanItem.ScanItemType.SMC06) {
				if (scanItem.getData(7).equalsIgnoreCase("ТВ")) {
					beginLoadLabelTheor(scanItem);
				} else {
					beginLoadLabel(scanItem.getData(0), scanItem);
				}
			} else if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONID) {
				beginLoadLocation(scanItem.getData(0));
			} else if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONCODE) {
				beginLoadLocationByCode(scanItem.getData(0));
			} else if (scanItem.getType() == ScanItem.ScanItemType.SMC02) {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.smc02_prompt_scan, null);
			} else if (scanItem.getType() == ScanItem.ScanItemType.ZAPOR) {
				beginLoadLabelZapor(scanItem);
			} else if (scanItem.getType() == ScanItem.ScanItemType.KOMINMET) {
				beginLoadLabelKominmet(scanItem);
			} else if (scanItem.getType() == ScanItem.ScanItemType.TRUBOSTAL) {
				beginLoadLabelTrubostal(scanItem);
			} else if (scanItem.getType() == ScanItem.ScanItemType.ARCELOR) {
				beginLoadLabelArcelor(scanItem);
			} else if (scanItem.getType() == ScanItem.ScanItemType.SMC07) {
				beginLoadLabelUnknown(scanItem);
			} else {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_identity_error, null);
			}
		}
	}

	private void beginLoadLabelTheor(ScanItem scanItem) {
		String labelId = scanItem.getData(0);
        /*String ozm = scanItem.getData(8);
        float length = Utils.parseFloat(scanItem.getData(3));
        float width = Utils.parseFloat(scanItem.getData(4));
        float thickness = Utils.parseFloat(scanItem.getData(5));
        int netto = Utils.parseInt(scanItem.getData(6));*/
		showInfoByLabelIdTheor(labelId);
	}

	private void beginLoadLabelUnknown(ScanItem scanItem) {
		JSONArray array = Utils.getJsonArray(scanItem.getData(2));
		if (array == null) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_error_scan_item, null);
		} else {
			JSONObject object = Utils.getJsonObject(array, 0);
			String labelId = Utils.getJsonStringIgnoreCase(object, "id");
			if (labelId.isEmpty()) {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_error_scan_item, null);
			} else {
				showInfoByLabelId(labelId);
			}
		}
	}

	private void beginLoadLabelKominmet(ScanItem scanItem) {
		showInfoByKominmet(scanItem);
	}

	private void beginLoadLabelZapor(ScanItem scanItem) {
		showInfoByZapor(scanItem);
	}

	private void beginLoadLabelTrubostal(ScanItem scanItem) {
		showInfoByTrubostal(scanItem);
	}

	private void beginLoadLabelArcelor(ScanItem scanItem) {
		showInfoByArcelor(scanItem);
	}

	private void beginLoadLocationByCode(String locationCode) {
		showInfoByLocationCode(locationCode);
	}

	private void beginLoadLocation(String locationId) {
		showInfoByLocationId(locationId);
	}

	private void beginLoadLabel(String labelId) {
		showInfoByLabelId(labelId);
	}

	private void beginLoadLabel(String labelId, ScanItem scanItem) {
		showInfoByLabelId(labelId, scanItem);
	}
}

