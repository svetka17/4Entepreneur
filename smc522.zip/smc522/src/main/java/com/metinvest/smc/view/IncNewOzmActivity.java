package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.metinvest.smc.R;
import com.metinvest.smc.inc.TTN;
import com.metinvest.smc.inc.TransportDoc;
import com.metinvest.smc.tools.Utils;

import butterknife.BindView;
import butterknife.BindViews;
import butterknife.ButterKnife;

public class IncNewOzmActivity extends MyActivity {

    @BindView(R.id.textName)
    EditText textName;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;
    @BindViews({R.id.textL, R.id.textW, R.id.textT})
    EditText[] textSize;

    private TransportDoc doc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inc_new_ozm);
        ButterKnife.bind(this);

        doc = TransportDoc.fromTransport(
                getIntent().getStringExtra("transportJson"),
                (TTN) getIntent().getSerializableExtra("ttn")
        );
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        beginAccept();
    }

    private void beginAccept() {
        if (isLoading()) return;

        String name = textName.getText().toString();
        if (name.isEmpty()) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.warning_empty_ozm, null);
            return;
        }

        int length = Utils.parseInt(textSize[0].getText().toString());
        int width = Utils.parseInt(textSize[1].getText().toString());
        int thickness = Utils.parseInt(textSize[2].getText().toString());

        Intent data = new Intent();
        data.putExtra("name", name);
        data.putExtra("length", length);
        data.putExtra("width", width);
        data.putExtra("thickness", thickness);
        setResult(RESULT_OK, data);
        finish();
    }

}
