package com.metinvest.smc.view;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.ShipmentDocument;
import com.metinvest.smc.db.ShipmentItem;
import com.metinvest.smc.db.ShipmentTransport;
import com.metinvest.smc.inc.SohFilter;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.LabelGeneratorCardSaveDpl;
import com.metinvest.smc.tools.LabelGeneratorCardSaveZpl;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemDocument;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class ShipCarActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener, AdapterItemDocument.Listener {

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.buttonRefresh)
    Button buttonRefresh;
    @BindView(R.id.viewContentData)
    View viewContentData;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    @BindView(R.id.viewButtons)
    View viewButtons;
    @BindView(R.id.buttonCombine)
    Button buttonCombine;
    @BindView(R.id.buttonData)
    Button buttonData;
    @BindView(R.id.buttonPrint)
    Button buttonPrint;

    private Date date, date2;
    private String sohSmcId;
    private SohFilter sohFilter;
    private String transportName;
    private long transportId;
    private FlexibleAdapter<AdapterItemDocument> adapter;
    //private ShipmentTransport transport;
    private ArrayList<String> documentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ship_car);
        ButterKnife.bind(this);

        date = (Date) getIntent().getSerializableExtra("date");
        date2 = (Date) getIntent().getSerializableExtra("date2");
        sohSmcId = getIntent().getStringExtra("sohSmcId");
        sohFilter = sohSmcId == null ? SohFilter.NotSoh() : SohFilter.SohInc(sohSmcId);
        if (config.isEo()) sohSmcId = null;
        transportName = getIntent().getStringExtra("transportName");
        transportId = getIntent().getLongExtra("transportId", 0);
        textContentTitle.setText(Utils.format("Наряди %s", transportName));

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        if (getIntent().hasExtra("documentList")) {
            documentList = getIntent().getStringArrayListExtra("documentList");
        }
        //frameButtonCombine.setVisibility(View.GONE);
    }

    @Override
    protected String getHelpContent() {
        return getString(R.string.ship_car_help);
    }

    @Override
    public boolean onItemClick(View view, int position) {
        AdapterItemDocument item = adapter.getItem(position);
        if (item != null) {
            if (config.isEo() && config.getEoLocationId() == 0)
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.text_location_eo_error1, String.valueOf(config.getEoLocationId()), String.valueOf(item.getDocument().getEoLocationId())  ), null);
            else if (config.isEo() && config.getEoLocationId() != item.getDocument().getEoLocationId())
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.text_location_eo_error, String.valueOf(item.getDocument().getEoLocationId()), item.getDocument().getEoLocationName(), String.valueOf(config.getEoLocationId()) ), null);
            else
                return openDocument(item.getDocument());
        }
        return false;
    }

    private boolean openDocument(ShipmentDocument document) {
        Intent intent = new Intent(this, ShipDetailActivity.class);
        intent.putExtra("date", date);
        intent.putExtra("date2", date2);
        intent.putExtra("dateVo", document.getDateVoDt());
        intent.putExtra("transportName", document.getTransportName());
        intent.putExtra("documentNumber", document.getDocNumber());
        if (sohSmcId != null)
            intent.putExtra("sohSmcId", sohSmcId);
        startActivityForResult(intent, REQUEST_DEFAULT);
        return true;
    }

    private boolean openDocuments(List<ShipmentDocument> documentList) {
        Intent intent = new Intent(this, ShipCardActivity.class);
        intent.putExtra("date", date);
        intent.putExtra("date2", date2);
        intent.putExtra("soh", false);
        intent.putExtra("dateVo", documentList.get(0).getDateVoDt());
        intent.putExtra("transportName", transportName);
        if (sohSmcId != null)
            intent.putExtra("sohSmcId", sohSmcId);

        ArrayList<String> documentNumbers = new ArrayList<>(documentList.size());
        for (ShipmentDocument document : documentList) {
            documentNumbers.add(document.getDocNumber());
        }

        intent.putStringArrayListExtra("documentNumbers", documentNumbers);
        startActivityForResult(intent, REQUEST_DEFAULT);
        return true;
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) buttonCombineClick();
        else if (number == 3) buttonDataClick();
        else if (number == 4) buttonRefreshClick();
        else if (number == 5) buttonPrintClick();
    }

    private void buttonPrintClick() {
        showToast("Виконую друк");
        if (isLoading() || !buttonPrint.isEnabled()) return;

        beginPrint();
    }

    private void beginPrint() {
        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);
        buttonPrint.setEnabled(false);

        Utils.runOnBackground(() -> {
            JsonResult result = null;
            List<ShipmentDocument> documentList = db.shipmentDocumentDao().getByTransportName(transportName);
            for (ShipmentDocument document : documentList) {
                result = app.loadShipmentOrderDetails(document.getDateVoDt(), document.getDocNumber(), sohFilter);
                if (result.isOk()) {
                    document.schipmentItems = db.shipmentItemDao().getByDocument(document.getDocNumber());
                    for (ShipmentItem shipmentItem : document.schipmentItems) {
                        shipmentItem.shipmentItemLoc = db.shipmentItemLocDao().getByItem(shipmentItem.getId());
                    }
                }
            }

            String data, title;
            if (isPrinterZebra()) {
                LabelGeneratorCardSaveZpl gen = new LabelGeneratorCardSaveZpl(documentList);
                data = gen.generateZpl();
                title = gen.generateTitle();
            } else {
                LabelGeneratorCardSaveDpl gen = new LabelGeneratorCardSaveDpl(documentList);
                data = gen.generateDpl();
                title = gen.generateTitle();
            }

            final Printer.PrintResult printResult = Printer.sendCommand(title, config.getPrinter(), data);
            JsonResult finalResult = result;
            runOnUiThread(() -> endPrint(finalResult, printResult));
        });

    }

    private void endPrint(JsonResult jsonResult, Printer.PrintResult printResult) {
        buttonPrint.setEnabled(true);
        viewButtons.setVisibility(View.VISIBLE);
        hideLoading();

        if (jsonResult == null)
            return;

        if (jsonResult.isOk()) {
            if (printResult.getStatus() == Printer.PrintResultStatus.OK) {
                showToast(R.string.text_print_result_succeeded);
                // app.sendFaPrint();
            } else {
                @StringRes final int message = app.getPrintResultMessage(printResult);
                showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> beginPrint());
            }
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(jsonResult), (dialog, which) -> beginPrint());
        }
    }

    private void buttonDataClick() {
        if (isLoading() || !buttonData.isEnabled() || adapter == null || adapter.getItemCount() == 0)
            return;

        Intent intent = new Intent(this, ShipDataActivity.class);
        intent.putExtra("date", date);
        intent.putExtra("date2", date2);
        intent.putExtra("transportId", transportId/*transport.getId()*/);

        startActivityForResult(intent, REQUEST_DEFAULT);
    }

    private void buttonCombineClick() {
        if (isLoading() || /*frameButtonCombine.getVisibility() != View.VISIBLE || */!buttonCombine.isEnabled())
            return;

        List<AdapterItemDocument> list = getCheckedItems();
        if (list.isEmpty()) return;

        List<ShipmentDocument> documentList = new ArrayList<>(list.size());
        for (AdapterItemDocument item : list) {
            documentList.add(item.getDocument());
        }
        openDocuments(documentList);
    }

    private void buttonRefreshClick() {
        if (isLoading()) return;

        beginLoad();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_DEFAULT && resultCode == RESULT_OK) {
            beginLoad();
        }

        if (requestCode == REQUEST_SEARCH && resultCode == RESULT_OK && data != null) {
            long id = data.getLongExtra("id", 0);
            boolean isTransport = data.getBooleanExtra("isTransport", false);

            if (!isTransport) {
                openDocument(db.shipmentDocumentDao().getById(id));
            }
        }
    }

    private void beginLoad() {
        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);
        buttonCombine.setEnabled(false);
        buttonData.setEnabled(false);

        saveCombined();

        Utils.runOnBackground(() -> {
            JsonResult result;
            if (config.isEo())
                result = app.loadShipmentOrdersEO(documentList);
            else
                result = app.loadShipmentOrders(date, date2, transportName, sohFilter);

            List<AdapterItemDocument> list = new ArrayList<>();

            if (result.isOk()) {
                //transport = db.shipmentTransportDao().getByName(transportName);
                //transport = db.shipmentTransportDao().getById(transportId);
                List<ShipmentDocument> documentList;
                if (config.isEo())
                    documentList = db.shipmentDocumentDao().getByTransportId(transportId);
                else
                    documentList = db.shipmentDocumentDao().getByTransportName(transportName);
                for (ShipmentDocument document : documentList) {
                    //List<ShipmentItem> items = db.shipmentItemDao().getByDocument(document.getDocNumber());
                    ShipmentTransport transport = db.shipmentTransportDao().getById(transportId);
                    list.add(new AdapterItemDocument(document, transport/*items*/, this));
                }

                if (!config.isEo())
                    Collections.sort(list, (o1, o2) -> {
                        if (o1.getDocument().getStatus() != o2.getDocument().getStatus() &&
                                (o1.getDocument().getStatus() == 1 || o2.getDocument().getStatus() == 1)) {
                            return Integer.compare(o1.getDocument().getStatus(), o2.getDocument().getStatus());
                        }
                        return o1.getDocument().getDocNumber().compareToIgnoreCase(o2.getDocument().getDocNumber());
                    });
            }
            runOnUiThread(() -> endLoad(result, list));
        });
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        super.onBackPressed();
    }

    private void endLoad(JsonResult result, List<AdapterItemDocument> list) {
        hideLoading();
        viewButtons.setVisibility(View.VISIBLE);

        viewContentData.setVisibility(!list.isEmpty() ? View.VISIBLE : View.GONE);
        textNotFound.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
        listView.setAdapter(null);

        if (result.isOk()) {
            buttonData.setEnabled(true);
            adapter = new FlexibleAdapter<>(list);
            adapter.addListener(this);
            listView.setAdapter(adapter);
            scrollView.post(() -> scrollView.scrollTo(0, 0));
            restoreCombined();
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
        }
    }

    private List<AdapterItemDocument> getCheckedItems() {
        List<AdapterItemDocument> list = new ArrayList<>();

        if (adapter != null) {
            List<AdapterItemDocument> items = adapter.getCurrentItems();
            for (AdapterItemDocument item : items) {
                if (item.isChecked()) list.add(item);
            }
        }

        Collections.sort(list, (o1, o2) -> o1.getDocument().getDocNumber().compareToIgnoreCase(o2.getDocument().getDocNumber()));

        return list;
    }

    @Override
    public void onItemCheck(AdapterItemDocument item, boolean checked) {
        refreshCombine();
    }

    private void refreshCombine() {
        int checkedCount = getCheckedItems().size();
        boolean hasChecked = checkedCount > 0;

        buttonCombine.setText(!hasChecked ? getString(R.string.button_combine_zero) : getString(R.string.button_combine, checkedCount));

        //frameButtonCombine.setVisibility(true ? View.VISIBLE : View.GONE);

        buttonCombine.setEnabled(checkedCount > 1);
    }

    private List<String> savedDocs;

    private void saveCombined() {

        List<AdapterItemDocument> list = getCheckedItems();

        savedDocs = new ArrayList<>();
        for (AdapterItemDocument item : list) {
            savedDocs.add(item.getDocument().getDocNumber());
        }
    }

    private void setChecked(String documentNumber, boolean checked) {
        if (adapter != null) {
            List<AdapterItemDocument> items = adapter.getCurrentItems();
            for (AdapterItemDocument item : items) {
                if (item.getDocument().getDocNumber().equalsIgnoreCase(documentNumber)) {
                    item.setChecked(checked);
                    adapter.updateItem(item);
                }
            }
        }
    }

    private void restoreCombined() {
        if (adapter != null && savedDocs != null && !savedDocs.isEmpty()) {
            for (String savedItem : savedDocs) {
                setChecked(savedItem, true);
            }
            refreshCombine();
        }
    }
}
