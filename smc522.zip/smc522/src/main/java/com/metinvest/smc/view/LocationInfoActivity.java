package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LocationInfoActivity extends MyActivity implements IScan {

    @BindView(R.id.location1)
    EditText location1;
    @BindView(R.id.location2)
    EditText location2;
    @BindView(R.id.location3)
    EditText location3;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;
    @BindView(R.id.buttonPrint)
    Button buttonPrint;
    @BindView(R.id.buttonList)
    Button buttonList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_info);
        ButterKnife.bind(this);
        location1.requestFocus();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) buttonAcceptClick();
        else if (number == 6) buttonListClick();
        else if (number == 7) buttonPrintClick();
    }

    private void buttonListClick() {
        if (isLoading() || !buttonList.isEnabled()) return;

        startActivityForResult(new Intent(this, LocationListActivity.class), REQUEST_LOCATION_SELECT);
    }

    private void buttonPrintClick() {
        if (isLoading() || !buttonPrint.isEnabled()) return;
        beginPrint();
    }

    private void beginPrint() {

        if (!buttonPrint.isEnabled()) return;

        buttonPrint.setEnabled(false);
        showLoading(R.string.text_printing_title);

        int[] loc = new int[]{
                Utils.parseInt(location1.getText().toString()),
                Utils.parseInt(location2.getText().toString()),
                Utils.parseInt(location3.getText().toString())
        };

        String locationCode = Utils.format("%s-%s-%s", loc[0], loc[1], loc[2]);

        Utils.runOnBackground(() -> {

            Network.NetworkResultValue<String> networkResultValue = net.getLocationIdWithCreate(locationCode);
            JsonResult jsonResult = networkResultValue.getResult();
            Printer.PrintResult printResult = null;

            if (networkResultValue.isOk()) {
                String data = app.generateDplLocation(networkResultValue.getValue(), locationCode);
                String name = Utils.format("<b>Локація</b><br>%s", locationCode);
                printResult = Printer.sendCommand(name, config.getPrinter(), data);
            }

            Printer.PrintResult finalPrintResult = printResult;
            runOnUiThread(() -> endPrint(jsonResult, finalPrintResult));
        });
    }

    private void endPrint(JsonResult jsonResult, Printer.PrintResult printResult) {
        buttonPrint.setEnabled(true);
        hideLoading();

        if (jsonResult.isOk()) {
            if (printResult.getStatus() == Printer.PrintResultStatus.OK) {
                //app.sendFaPrint();
                showToast(R.string.text_print_result_succeeded);
            } else {
                @StringRes final int message = app.getPrintResultMessage(printResult);
                showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> beginPrint());
            }
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(jsonResult), (dialog, which) -> beginPrint());
        }
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        String locationCode = Utils.format("%s-%s-%s",
                location1.getText().toString(),
                location2.getText().toString(),
                location3.getText().toString());

        if (app.isLocationCorrect(locationCode)) {
            //beginLoadLocationByCode(app.fixLocation(locationCode));
            showInfoByLocationCode(app.fixLocation(locationCode));
        } else {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_error_location_incorrect, (dialog, which) -> location1.requestFocus());
        }
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {
        ScanItem scanItem = new ScanItem(barcodeData);

        runOnUiThread(() -> {

            if (!scanItem.isCorrect()) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_identity_error, null);
                return;
            }

            if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONID) {
                beginLoadLocation(scanItem.getData(0));
            } else if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONCODE) {
                beginLoadLocationByCode(scanItem.getData(0));
            } else {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_identity_error, null);
            }
        });
    }

    private void beginLoadLocation(String locationId) {
        showLoading(R.string.text_please_wait);
        buttonAccept.setEnabled(false);

        Utils.runOnBackground(() -> {
			String locationCode = net.getLocationCode(locationId);

            String url = config.getUrlApi() + "getlocationinfo";
            url = net.addUrlParam(url, "location_code", locationCode);
            JsonResult result = net.downloadJson(url);

            runOnUiThread(() -> endLoadLocation(locationCode, result));
        });
    }

    private void beginLoadLocationByCode(String locationCode) {
        showLoading(R.string.text_please_wait);
        buttonAccept.setEnabled(false);

        Utils.runOnBackground(() -> {
            String url = config.getUrlApi() + "getlocationinfo";
            url = net.addUrlParam(url, "location_code", locationCode);
            JsonResult result = net.downloadJson(url);

            runOnUiThread(() -> endLoadLocation(locationCode, result));
        });
    }

    private void endLoadLocation(String locationCode, JsonResult result) {
        if (result.isOk()) {
            showInfoByLocationCode(locationCode);
        } else if (result.getStatus() == LoadResultStatus.ZERO) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.location_not_found, locationCode), (dialog, which) -> location1.requestFocus());
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> buttonAcceptClick());
        }

        hideLoading();
        buttonAccept.setEnabled(true);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_LOCATION_SELECT && resultCode == RESULT_OK && data != null) {
            String locationCode = data.getStringExtra("id");
            beginLoadLocationByCode(locationCode);
        }
    }
}
