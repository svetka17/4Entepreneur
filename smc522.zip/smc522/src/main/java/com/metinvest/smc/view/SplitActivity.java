package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.Utils;

import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SplitActivity extends MyActivity {

	@BindView(R.id.buttonAccept)
	Button buttonAccept;
	@BindView(R.id.textWeight)
	TextView textWeight;
	@BindView(R.id.textSplitWeight)
	EditText textSplitWeight;
	@BindView(R.id.buttonCrane)
	ImageButton buttonCrane;

	private String labelId;
	private int weight;
	private int splitWeight;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_split);
		ButterKnife.bind(this);

		labelId = getIntent().getStringExtra("labelId");
		weight = getIntent().getIntExtra("weight", 0);

		textWeight.setText(Utils.format("%d кг", weight));
		textSplitWeight.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				onSplitWeightChanged();
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		});
		onSplitWeightChanged();

		setActionDone(textSplitWeight, buttonAccept);

		buttonCrane.setOnClickListener(v -> loadCraneWeight());
		buttonCrane.setOnLongClickListener(v -> {
			loadCraneTara();
			return true;
		});
	}

	@Override
	protected void onCraneWeight(long craneId, int value) {
		textSplitWeight.setText(String.valueOf(value));
		onSplitWeightChanged();
	}

	private void onSplitWeightChanged() {
		splitWeight = Utils.parseInt(textSplitWeight.getText().toString());
		buttonAccept.setEnabled(splitWeight > 0 && splitWeight < weight);
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 5) {
            buttonAcceptClick();
        }
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        beginAccept();
    }

    private void beginAccept() {
        showLoading(R.string.text_please_wait);
        buttonAccept.setEnabled(true);

        String url = config.getUrlApi() + "clonelabel";
        url = net.addUrlParam(url, "label_id", labelId);
        url = net.addUrlParam(url, "Weight_nett", splitWeight);
        url = net.addUrlParam(url, "Weight_pack", 0);
        reqGet(url, this::endAccept);
    }

	private void endAccept(JsonResult result) {
		hideLoading();
		buttonAccept.setEnabled(!result.isOk());

		JSONObject json = Utils.getJsonObject(result.getJson(), "data");

		if (result.isOk() && json != null) {

			String newLabelId = Utils.getJsonStringIgnoreCase(json, "label_id");

			showDialog(R.drawable.ic_info_24dp, R.string.text_information, "Розміщуйте залишок в окремій стопці", (dialog, which) -> {
				//Toast.makeText(this, R.string.split_ok, Toast.LENGTH_SHORT).show();
				Intent data = new Intent();
				data.putExtra("labelId", labelId);
				data.putExtra("newLabelId", newLabelId);
				data.putExtra("weightSplit", splitWeight);
				setResult(RESULT_OK, data);
				finish();
			});

		} else if (result.getStatus() == LoadResultStatus.PLUS2) {
			showDialog(R.drawable.ic_error_24dp, R.string.text_error, "Заблоковано. позицію переведено в статус, що не дозволяє операцію!", null);
		} else if (result.getStatus() == LoadResultStatus.PLUS3) {
			showDialog(R.drawable.ic_error_24dp, R.string.text_error, "Вага нової етикетки більша за стару! Оновіть дані.", null);
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginAccept());
		}
    }
}
