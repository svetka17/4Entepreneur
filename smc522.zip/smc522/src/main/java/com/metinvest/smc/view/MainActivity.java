package com.metinvest.smc.view;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.metinvest.smc.App;
import com.metinvest.smc.Config;
import com.metinvest.smc.R;
import com.metinvest.smc.db.LabelBatch;
import com.metinvest.smc.db.OffShipLabel;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.LabelEditItem;
import com.metinvest.smc.tools.StoreItem;
import com.metinvest.smc.tools.Updater;
import com.metinvest.smc.tools.Utils;
import com.microsoft.appcenter.AppCenter;
import com.microsoft.appcenter.analytics.Analytics;
import com.microsoft.appcenter.crashes.Crashes;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends MyActivity implements Updater.UpdaterListener {

    @BindView(R.id.viewRoot)
    View viewRoot;

    private Updater updater;
    private boolean labelBatchLoaded = false;

    private List<JSONObject> craneList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        AppCenter.start(getApplication(), "9cbcf74f-9eec-41f8-9562-4eb511083f2f",
                Analytics.class, Crashes.class);
// signature hash для azure KeyHash:ndSUh5m7LdnyhpMhTY743sz0gNE=
/*		try {
			android.content.pm.PackageInfo info = getPackageManager().getPackageInfo(
					"com.metinvest.smc",//"com.sytecs.zst-mim",
					android.content.pm.PackageManager.GET_SIGNATURES);
			for (android.content.pm.Signature signature : info.signatures) {
				java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA");
				md.update(signature.toByteArray());
				android.util.Log.d("KeyHash", "KeyHash:" + android.util.Base64.encodeToString(md.digest(),
						android.util.Base64.DEFAULT));

			}
		} catch (android.content.pm.PackageManager.NameNotFoundException e) {
			android.util.Log.d("KeyHash", "KeyHash:" + e.toString());

		} catch (java.security.NoSuchAlgorithmException e) {
			android.util.Log.d("KeyHash", "KeyHash:" + e.toString());
		}
*/
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        checkMyPermission();

        updater = new Updater(
                this, this,
                //config.getUrlUpdater() + "/" + app.getPackageName() + ".txt",
                //config.getUrlUpdater() + "/" + app.getPackageName() + ".apk",
                config.getUrlUpdater() + app.getPackageName() + ".txt",//(BuildConfig.APPLICATION_ID.contains("test")?".test.txt":".txt"),
                config.getUrlUpdater() + app.getPackageName() + ".apk",//(BuildConfig.APPLICATION_ID.contains("test")?".test.apk":".apk"),
                app.getApkVersion()
        );
    }

    public void checkMyPermission() {

        String[] permissionListDenied = getDeniedPermissions(new String[]{
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.CHANGE_WIFI_STATE,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.CALL_PHONE
        });

        if (permissionListDenied.length > 0) {
            log("Asked for permissions: %d", permissionListDenied.length);
            ActivityCompat.requestPermissions(this, permissionListDenied, REQUEST_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION) {
            log("onRequestPermissionsResult");
            for (int i = 0; i < permissions.length; i++) {
                log("%s %s", permissions[i], grantResults[i] == PackageManager.PERMISSION_GRANTED ? "OK" : "FAIL");
            }
        }
    }
    private String[] getDeniedPermissions(String[] permissionList) {
        List<String> list = new ArrayList<>();

        for (String permission : permissionList) {
            if (checkSelfPermission(permission) == PackageManager.PERMISSION_DENIED)
                list.add(permission);
        }

        return list.toArray(new String[0]);
    }

    private void testProxy() {
        Utils.runOnBackground(() -> {
            String url = "https://smcqrcode.metinvestholding.com/api/ping";
            JsonResult result = net.requestProxy(url, false, null, null);
            if (result.isOk()) {
                log("PROXY RESULT: %s", result.getJson().toString());
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (checkUser()) {
            updater.beginCheck();
            ////
            if (config.getSmcId() != null && !config.getSmcId().isEmpty())
                Utils.runOnBackground(() -> {
                    String url = config.getUrlApi() + "getSprCranes";
                    url = net.addUrlParam(url, "smc_id", config.getSmcId());
                    JsonResult result = net.downloadJson(url);
                    craneList.clear();

                    if (result.isOk()) {
                        log("RES: %s", result.getJson().toString());

                        JSONArray jsonArray = Utils.getJsonArray(Utils.getJsonStringIgnoreCase(result.getJson(), "data"));
                        //String jsonArray = Utils.getJsonStringIgnoreCase(result.getJson(), "data");
                        for (int i = 0; jsonArray != null && i < jsonArray.length(); i++) {
                            craneList.add(Utils.getJsonObject(jsonArray, i));
                        }
                    }
                });
            if (config.isEo())
                Utils.runOnBackground(() -> {
                    String url = config.getUrlApiEO() + "RouteList/Location";
                    url = net.addUrlParam(url, "smcId", config.getSmcId());
                    url = net.addUrlParam(url, "stock", config.getStorage());
                    JsonResult result = net.downloadJson(url);
                    JSONObject content = Utils.getJsonObject(result.getJson(),"content");
                    if (content != null) {
                        config.setEoLocationId(Utils.getJsonIntIgnoreCase(content, "locationId"));
                        config.setEoLocationName(Utils.getJsonStringIgnoreCase(content, "locationName"));
                    } else {
                        //showLoading(getString(R.string.no_settings_oe, config.getSmcId(), config.getStorage()));
                        config.setEoLocationId(0);
                        config.setEoLocationName("");
                        log("no settings for: %s, storage: %s", config.getSmcId(), config.getStorage());
                    }

                });
            ////
            if (!labelBatchLoaded) {
                beginLabelBatch();
            }
        }
        refreshHeader();
        //updater.beginCheck();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        updater.dispose();
    }


    private boolean checkUser() {
        log("check userId: %s, token: %s", config.getConfigUserId(), config.getToken());
        if (config.isAuthMSAL()) {
            if (app.getConfUserId() != 0 && config.getExpiresOn() != null && config.getExpiresOn().getTime() > (new Date()).getTime()) {
                return true;
            } else {
                startActivityForResult(new Intent(this, MSALLoginActivity.class), REQUEST_LOGIN);
                //startActivityForResult(new Intent(this, MSALMultiLoginActivity.class), REQUEST_LOGIN);
                return false;
            }
        } else if (app.getConfUserId() == 0) {
            startActivityForResult(new Intent(this, LoginActivity.class), REQUEST_LOGIN);
            return false;
        } else {
            return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_LOGIN && resultCode == RESULT_OK) {
            //updater.setUpdateCheckUrl(config.getUrlUpdater() + "/com.metinvest.smc.txt");
            //updater.setUpdateDownloadUrl(config.getUrlUpdater() + "/com.metinvest.smc.apk");
            updater.setUpdateCheckUrl(config.getUrlUpdater() + app.getPackageName() + ".txt");
            updater.setUpdateDownloadUrl(config.getUrlUpdater() + app.getPackageName() + ".apk");
            if (db.offShipLabelDao().getCount() > 0) beginUploadOffline();
        } else if (requestCode == REQUEST_SELECT_SMC && resultCode == RESULT_OK) {
            refreshHeader();
        }
    }

    private void beginUploadOffline() {
        showLoading(R.string.text_sending);

        Utils.runOnBackground(() -> {

            List<String> itemList = db.offShipLabelDao().getAllLabels();
            int total = itemList.size();
            List<LabelEditItem> labelEditItems = new ArrayList<>(total);

            for (String labelId : itemList) {
                OffShipLabel item = db.offShipLabelDao().getByLabel(labelId);
                if (item != null) {
                    int nettoOrig = db.offShipLabelDao().getLabelNettoOrig(labelId);
                    int nettoShipped = db.offShipLabelDao().getTotalLabelShipped(labelId);
                    int nettoAfter = nettoOrig - nettoShipped;
                    labelEditItems.add(new LabelEditItem(labelId, App.getInstance().getSmcIdCurrent(), nettoAfter, item.getPack(), null, null, false));
                }
            }

            JsonResult result =
                    app.editLabelWeight(
                            labelEditItems,
                            Calendar.getInstance().getTime(),
                            app.getDeviceId()
                    );

            try {
                if (result.isOk()) db.offShipLabelDao().truncate();
            } catch (Exception ignored) {
            }

            runOnUiThread(() -> endUploadOffline(result));
        });
    }

    private void endUploadOffline(JsonResult result) {
        hideLoading();
        if (result.isOk()) {
            showToast(R.string.offline_data_send_success);
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, getString(R.string.error_offline_send), (dialog, which) -> beginUploadOffline(), (dialog, which) -> requestDeleteOfflineData());
        }
    }

    private void requestDeleteOfflineData() {
        showDialogConfirm(R.string.text_warning, R.string.confirm_offline_delete, (dialog, which) -> {
            try {
                db.offShipLabelDao().truncate();
            } catch (Exception ignored) {

            }
        });
    }

    @Override
    protected void onFunctionKey(int number) {
        boolean flag = false;

        if (isLoading()) return;

        if (craneList.size() > 0 && config.getCraneId() != 0) {
            for (int i = 0; i < craneList.size(); i++) {
                JSONObject jsonObject = craneList.get(i);
                long craneId = Utils.getJsonLongIgnoreCase(jsonObject, "id");
                if (craneId == config.getCraneId())
                    flag = true;
            }
        }

        if ((number == 2 || number == 3) && (flag == false || craneList.size() == 0 || config.getCraneId() == 0)) {
            showShack(R.string.text_prompt_select_crane);
            return;
        }

        if (number == 3 && config.isEo() && config.getEoLocationId() == 0 ) {
            showShack(getString(R.string.no_settings_oe, config.getSmcId(), config.getStorage()));
            return;
        }

        if (config.getStorage() == null || config.getStorage().isEmpty())
            showShack(R.string.text_error_storage_empty);
        switch (number) {
            case 2:
                startActivity(new Intent(this, IncActivity.class));
                break;
            case 3:
                if (config.isEo()) {
                    Intent intent = new Intent(this, ShipCarsActivity.class);
                    intent.putExtra("date", new Date());
                    intent.putExtra("date2", new Date());
                    intent.putExtra("sohSmcId", config.getSmcId());
                    if (config.getStorage().length() > 1)
                        intent.putExtra("lgort", config.getStorage());
                    startActivity(intent);
                    //startActivity(new Intent(this, ShipCarsActivity.class));
                } else
                    startActivity(new Intent(this, ShipActivity.class));
                break;
            case 4:
                startActivity(new Intent(this, BuyoutActivity.class));
                break;
            case 5:
                startActivity(new Intent(this, TempActivity.class));
                break;
            case 6:
                startActivity(new Intent(this, ManagerActivity.class));
                break;
            case 7:
                startActivity(new Intent(this, TransferLabelManyActivity.class));
                break;
            case 8:
                startActivity(new Intent(this, Main2Activity.class));
                break;
            case 9:
                startActivityForResult(new Intent(this, Settings2Activity.class), REQUEST_SELECT_SMC);
                break;
            case 0:
                showDialogConfirm(R.string.text_warning, R.string.text_logout_confirm, (dialog, which) -> {
                    labelBatchLoaded = false;
                    app.logoutUser();
                    if (config.isAuthMSAL()) {
                        //startActivity(new Intent(this, MSALLoginActivity.class));
                        startActivityForResult(new Intent(this, MSALLoginActivity.class), REQUEST_LOGIN);
                    } else {
                        checkUser();
                    }
                });
        }
    }

    @Override
    protected String getHelpContent() {
        return getString(R.string.select_operation_help);
    }

    @Override
    public void onBackPressed() {
        /*showDialogConfirm(R.string.text_warning, R.string.text_logout_confirm, (dialog, which) -> {
            app.logoutUser();
            checkUser();
        });*/
    }

    @Override
    public void onStateChanged(Updater.UpdaterState stateOld, Updater.UpdaterState stateNew) {
        log("State changed from %s to %s", stateOld, stateNew);
    }

    @Override
    public void onLog(String message) {
        log("Updater->%s", message);
    }

    @Override
    public void onEndCheck(boolean success, boolean needUpdate) {
        if (success) {
            if (needUpdate) {
                prepareUpdate();
            } else {
                showShack(R.string.your_app_version_is_last);
            }
        } else {
            showShack(R.string.text_check_update_error);
        }
    }

    @Override
    public void onEndDownload(boolean success) {
        log("onEndDownload(%s)", success ? "OK" : "FAIL");
        hideLoading();
        if (success) updater.beginUpdate();
    }

    private void prepareUpdate() {
        log("prepareUpdate()");

        showDialogConfirm(R.string.text_warning, R.string.text_updater_newversion, (dialog, which) -> startUpdate());
    }

    private void startUpdate() {
        showLoading(R.string.text_sending);

        Utils.runOnBackground(() -> {
            if (db.printedDao().getCountNew() > 0) {
                JsonResult result = net.uploadInbound();
                runOnUiThread(() -> endUpdate(result));
            } else {
                runOnUiThread(() -> endUpdate(new JsonResult(LoadResultStatus.OK)));
            }
        });
    }

    private void endUpdate(JsonResult result) {

        hideLoading();

        if (result.isOk()) {
            Toast.makeText(this, R.string.updating_new_version_prompt, Toast.LENGTH_LONG).show();
            showLoading(R.string.text_please_wait);
            updater.beginDownload();
        } else {
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> startUpdate());
        }
    }

    private void beginLabelBatch() {
        showLoading(R.string.text_batches_loading);

        Utils.runOnBackground(() -> {
            config.setStoreTransItems(new ArrayList<>());
            JsonResult result;
            Network.NetworkResultValue<List<StoreItem>> networkResultValue = net.loadStorageList(app.getSmcIdCurrent());
            result = networkResultValue.getResult();

            if (networkResultValue.isOk()) {
                List<StoreItem> storeItemList = networkResultValue.getValue();
                config.setStoreTransItems(Utils.getTransStoreItems(storeItemList));
                StoreItem storeItem = Utils.getSourceStoreItem(storeItemList);
                if (storeItem != null) {

                    if (!Utils.contains(storeItem.getStoreList(), config.getStorage())) {
                        config.setStorage(storeItem.getStoreList().isEmpty() ? Config.DEFAULT_STORAGE : storeItem.getStoreList().get(0));
                        config.saveConfig();
                    }

                    String url = config.getUrlApi() + "getlabelbatch";
                    url = net.addUrlParam(url, "smcid", app.getSmcIdCurrent());
                    result = net.downloadJson(url);

                    if (result.isOk()) {
                        JSONArray array = Utils.getJsonArray(result.getJson(), "data");
                        List<LabelBatch> list = new ArrayList<>();
                        for (int i = 0; array != null && i < array.length(); i++) {
                            JSONObject json = Utils.getJsonObject(array, i);
                            if (json != null) {
                                String labelId = Utils.getJsonString(json, "l");
                                String batch = Utils.getJsonString(json, "b");
                                if (labelId.length() > 0 && batch.length() > 0)
                                    list.add(new LabelBatch(0, labelId, batch));
                            }
                        }
                        db.labelBatchDao().truncate();
                        db.labelBatchDao().insertAll(list);
                        labelBatchLoaded = true;
                    }
                }
            }


            JsonResult finalResult = result;
            runOnUiThread(() -> endLabelBatch(finalResult));
        });
    }

    private void endLabelBatch(JsonResult result) {
        hideLoading();

        if (!result.isOk()) {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLabelBatch());
        }
    }

}
