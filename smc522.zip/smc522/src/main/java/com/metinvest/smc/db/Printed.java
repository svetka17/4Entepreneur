package com.metinvest.smc.db;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity
public class Printed {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private long onTheWayId;
    private int weightPack, weightNetto, weightTara;
    private String sapMattDescr, sapOzm;
    private long date;
    private boolean old;
    private String location;
    private boolean temporary;
    private long weighingId;
    private int weightTag;
    private boolean theor;
    private String plavka;

    public Printed() {
    }

    @Ignore
    public Printed(long id, long onTheWayId, int weightNetto, int weightPack, int weightTara, String sapMattDescr,
                   String sapOzm, long date, boolean old, String location, boolean temporary, long weighingId, int weightTag, boolean theor, String plavka) {
        this.id = id;
        this.onTheWayId = onTheWayId;
        this.weightPack = weightPack;
        this.weightNetto = weightNetto;
        this.weightTara = weightTara;
        this.sapMattDescr = sapMattDescr;
        this.sapOzm = sapOzm;
        this.date = date;
        this.old = old;
        this.location = location;
        this.temporary = temporary;
        this.weighingId = weighingId;
        this.weightTag = weightTag;
        this.theor = theor;
        this.plavka = plavka;
    }

    public String getPlavka() {
        return plavka;
    }

    public void setPlavka(String plavka) {
        this.plavka = plavka;
    }

    public boolean isTheor() {
        return theor;
    }

    public void setTheor(boolean theor) {
        this.theor = theor;
    }

    public int getWeightTag() {
        return weightTag;
    }

    public void setWeightTag(int weightTag) {
        this.weightTag = weightTag;
    }

    public long getWeighingId() {
        return weighingId;
    }

    public void setWeighingId(long weighingId) {
        this.weighingId = weighingId;
    }

    public boolean isTemporary() {
        return temporary;
    }

    public void setTemporary(boolean temporary) {
        this.temporary = temporary;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public boolean isOld() {
        return old;
    }

    public void setOld(boolean old) {
        this.old = old;
    }

    public int getWeightTara() {
        return weightTara;
    }

    public void setWeightTara(int weightTara) {
        this.weightTara = weightTara;
    }

    public String getSapMattDescr() {
        return sapMattDescr;
    }

    public void setSapMattDescr(String sapMattDescr) {
        this.sapMattDescr = sapMattDescr;
    }

    public String getSapOzm() {
        return sapOzm;
    }

    public void setSapOzm(String sapOzm) {
        this.sapOzm = sapOzm;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getOnTheWayId() {
        return onTheWayId;
    }

    public void setOnTheWayId(long onTheWayId) {
        this.onTheWayId = onTheWayId;
    }

    public int getWeightPack() {
        return weightPack;
    }

    public void setWeightPack(int weightPack) {
        this.weightPack = weightPack;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public int getWeightNetto() {
        return weightNetto;
    }

    public void setWeightNetto(int weightNetto) {
        this.weightNetto = weightNetto;
    }
}
