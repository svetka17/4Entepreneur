package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface RollDao {

    @Query("SELECT DISTINCT(markdown) FROM roll ORDER BY 1")
    List<String> getMarkdownList();

    @Query("SELECT * FROM roll WHERE batch = :batch ORDER BY dt DESC LIMIT 1")
    Roll getRollByBatchMax(String batch);

    @Query("SELECT DISTINCT(mera) FROM roll ORDER BY 1")
    List<String> getMeraList();

    @Query("SELECT DISTINCT(travl) FROM roll ORDER BY 1")
    List<String> getTravlList();

    @Query("SELECT * FROM roll ORDER BY id")
    List<Roll> getAll();

    @Query("SELECT * FROM roll WHERE nameId = :nameId ORDER BY id")
    List<Roll> getByName(long nameId);

    @Query("SELECT * " +
            "FROM roll " +
            "WHERE nameId = :nameId " +
            "AND (:markdown IS NULL OR :markdown = roll.markdown) " +
            "AND (:mera IS NULL OR :mera = roll.mera) " +
            "AND (:travl IS NULL OR :travl = roll.travl) " +
            "AND (:weight = -1 OR stock = :weight) AND actual = 1 ORDER BY id")
    List<Roll> getByNameAndWeight(long nameId, int weight, String markdown, String mera, String travl);

    @Query("SELECT batch " +
            "FROM roll " +
            "WHERE nameId = :nameId AND actual = 1 " +
            "AND (:markdown IS NULL OR :markdown = roll.markdown) " +
            "AND (:mera IS NULL OR :mera = roll.mera) " +
            "AND (:travl IS NULL OR :travl = roll.travl) " +
            "ORDER BY (CASE WHEN stock >= :weight THEN stock - :weight ELSE :weight - stock END), dt DESC LIMIT 1")
    String getBatchByNameMinDiff(long nameId, int weight, String markdown, String mera, String travl);

    @Query("SELECT batch " +
            "FROM roll " +
            "WHERE nameId = :nameId AND actual = 1 " +
            "AND (stock > 0) " +
            "AND (:markdown IS NULL OR :markdown = roll.markdown) " +
            "AND (:mera IS NULL OR :mera = roll.mera) " +
            "AND (:travl IS NULL OR :travl = roll.travl) " +
            "ORDER BY dt DESC LIMIT 1")
    String getBatchByDate(long nameId, String markdown, String mera, String travl);

    @Query("SELECT batch " +
            "FROM roll " +
            "WHERE nameId = :nameId AND actual = 1 " +
            "AND (:markdown IS NULL OR :markdown = roll.markdown) " +
            "AND (:mera IS NULL OR :mera = roll.mera) " +
            "AND (:travl IS NULL OR :travl = roll.travl) " +
            "ORDER BY dt LIMIT 1")
    String getBatchByDateLast(long nameId, String markdown, String mera, String travl);

    @Query("SELECT * FROM roll WHERE nameId = :nameId AND batch = :batch AND actual = 1 ORDER BY dt DESC LIMIT 1")
    Roll getByNameAndBatchLastDt(long nameId, String batch);

    @Query("SELECT count(1) FROM roll")
    long getCount();

    @Query("SELECT * FROM roll WHERE id = :id")
    Roll getById(long id);

    @Insert
    long insert(Roll roll);

    @Insert
    void insertAll(List<Roll> roll);

    @Update
    void update(Roll roll);

    @Delete
    void delete(Roll roll);

    @Query("DELETE FROM roll")
    void truncate();
}