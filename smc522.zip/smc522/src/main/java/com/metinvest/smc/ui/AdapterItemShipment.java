package com.metinvest.smc.ui;

import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.tools.Utils;

import org.json.JSONObject;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemShipment implements IFlexible<AdapterItemShipment.AdapterItemShipmentViewHolder> {

    private final JSONObject json;
    private final IItemAction action;
    private boolean selectable, enabled, hidden, draggable, swipeable;

    public interface IItemAction {
        void OnDeleteClick(int position);
    }

    public AdapterItemShipment(JSONObject json, IItemAction action) {
        this.json = json;
        this.action = action;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }

    @Override
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    @Override
    public boolean isHidden() {
        return this.hidden;
    }

    @Override
    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    @Override
    public int getSpanSize(int spanCount, int position) {
        return 1;
    }

    @Override
    public boolean shouldNotifyChange(IFlexible newItem) {
        return false;
    }

    @Override
    public boolean isSelectable() {
        return this.selectable;
    }

    @Override
    public void setSelectable(boolean selectable) {
        this.selectable = selectable;
    }

    @Override
    public String getBubbleText(int position) {
        return null;
    }

    @Override
    public boolean isDraggable() {
        return this.draggable;
    }

    @Override
    public void setDraggable(boolean draggable) {
        this.draggable = draggable;
    }

    @Override
    public boolean isSwipeable() {
        return this.swipeable;
    }

    @Override
    public void setSwipeable(boolean swipeable) {
        this.swipeable = swipeable;
    }

    @Override
    public int getItemViewType() {
        return 0;
    }

    @Override
    public AdapterItemShipmentViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new AdapterItemShipmentViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemShipmentViewHolder holder, int position, List<Object> payloads) {

        holder.textTitle.setText(Utils.getJsonStringIgnoreCase(json, "name"));

        StringBuilder sb = new StringBuilder();

        sb.append(Utils.format("Партія: %s<br>", Utils.getJsonStringIgnoreCase(json, "batch")));
        sb.append(Utils.format("Вага нетто: %s кг.<br>", Utils.getJsonStringIgnoreCase(json, "shipment_Weight")));
        sb.append(Utils.format("ОЗМ: %s<br>", Utils.getJsonStringIgnoreCase(json, "ozm")));
        sb.append(Utils.format("Розмір: %s",
                App.getInstance().sizeToString(
                        Utils.getJsonFloatIgnoreCase(json, "width"),
                        Utils.getJsonFloatIgnoreCase(json, "length"),
                        Utils.getJsonFloatIgnoreCase(json, "thickness")
                )
        ));

        holder.textContent.setText(App.getInstance().fromHtml(sb.toString()));

        holder.textTitle.setVisibility(View.VISIBLE);
        holder.buttonDelete.setVisibility(View.VISIBLE);
        holder.buttonDelete.setOnClickListener(v -> action.OnDeleteClick(position));
    }

    @Override
    public void unbindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemShipmentViewHolder holder, int position) {
        //empty
    }

    @Override
    public void onViewAttached(FlexibleAdapter<IFlexible> adapter, AdapterItemShipmentViewHolder holder, int position) {
        //empty
    }

    @Override
    public void onViewDetached(FlexibleAdapter<IFlexible> adapter, AdapterItemShipmentViewHolder holder, int position) {
        //empty
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_shipment_row;
    }

    /**
     * The ViewHolder used by this item.
     * Extending from FlexibleViewHolder is recommended especially when you will use
     * more advanced features.
     */
    public class AdapterItemShipmentViewHolder extends FlexibleViewHolder {

        private final View view;

        public TextView textTitle, textContent;
        public ImageButton buttonDelete;

        public AdapterItemShipmentViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.view = view;
            this.textTitle = view.findViewById(R.id.textTitle);
            this.textContent = view.findViewById(R.id.textContent);
            this.buttonDelete = view.findViewById(R.id.buttonDelete);
        }
    }
}
