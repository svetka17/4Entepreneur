package com.metinvest.smc.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Carrier;
import com.metinvest.smc.db.NameStore;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.db.Printed;
import com.metinvest.smc.db.Weighing;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterIn4;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class In4Activity extends MyActivity implements AdapterIn4.IAdapterIn4Listener {

    @BindView(R.id.textContent)
    TextView textContent;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;
    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.listView)
    RecyclerView listView;

    private int weightCrane, packCount;
    private Carrier carrier;
    private NameStore name;
    private ArrayList<Long> wayList;
    private ArrayList<Integer> weightList1, weightList2, weightList3;
    private ArrayList<Integer> weightListFinal;

    private boolean accepted, printed;
    private List<Printed> printedList;
    private long tempWayId;
    private String locationCode;
    private boolean isTheor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in4);
        ButterKnife.bind(this);

        long carrierId = getIntent().getLongExtra("carrierId", 0);
        long nameId = getIntent().getLongExtra("nameId", 0);
        isTheor = getIntent().getBooleanExtra("isTheor", false);
        weightCrane = getIntent().getIntExtra("weightCrane", 0);
        packCount = getIntent().getIntExtra("packCount", 0);
        locationCode = getIntent().getStringExtra("locationCode");
        wayList = (ArrayList<Long>) getIntent().getSerializableExtra("wayList");
        weightList1 = (ArrayList<Integer>) getIntent().getSerializableExtra("weightList1");
        weightList2 = (ArrayList<Integer>) getIntent().getSerializableExtra("weightList2");
        weightList3 = (ArrayList<Integer>) getIntent().getSerializableExtra("weightList3");
        carrier = db.carrierDao().getById(carrierId);
        name = db.nameStoreDao().getById(nameId);
        tempWayId = getIntent().getLongExtra("tempWayId", 0);

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        listView.setVisibility(View.GONE);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    private int getTotalBrutto() {
        int total = 0;
        for (int i = 0; i < packCount; i++)
            total += weightList1.get(i) + weightList2.get(i) + weightList3.get(i);
        return total;
    }

    private int getTotalPack() {
        int total = 0;
        for (int i = 0; i < packCount; i++)
            total += weightList2.get(i) + weightList3.get(i);
        return total;
    }

    private int getTotalNetto() {
        int total = 0;
        for (int i = 0; i < packCount; i++)
            total += weightList1.get(i);
        return total;
    }

    public int getWeightCrane() {
        return weightCrane;
    }

    private String contentShort;

    private void beginLoad() {
        showLoading(R.string.text_please_wait);
        buttonAccept.setEnabled(false);

        Utils.runOnBackground(() -> {

            weightListFinal = new ArrayList<>(packCount);

            int totalNetto = getTotalNetto();
            int weightToDivide = getWeightCrane() - getTotalBrutto();
            double weightExtra = 0;

            for (int i = 0; i < packCount; i++) {

                double weightToAdd = 0;

                if (weightToDivide != 0) {
                    double itemPercent = totalNetto == 0 ? 0 : (double) weightList1.get(i) * 100 / totalNetto;
                    weightToAdd = itemPercent * weightToDivide / 100.0f;
                }

                weightExtra += weightToAdd - (int) weightToAdd;
                weightListFinal.add(weightList1.get(i) + (int) weightToAdd);
            }

            weightExtra = Math.round(weightExtra);

            log("weightExtra: %.3f", weightExtra);

            if (Math.abs(weightExtra) > 0) {
                int i = 0;
                while (Math.abs(weightExtra) >= 1.0f) {
                    weightListFinal.set(i, weightListFinal.get(i) + (weightExtra > 0 ? 1 : -1));
                    weightExtra -= (weightExtra > 0 ? 1 : -1);
                    i = i == weightListFinal.size() - 1 ? 0 : i + 1;
                }
            }

            log("weightExtra: %.3f", weightExtra);

            StringBuilder sb = new StringBuilder();

            sb.append(Utils.format("<b>Транспорт:</b> %s<br>", carrier.getName()));
            sb.append(Utils.format("<b>Найменування:</b> %s<br>", name.getName()));
            sb.append(Utils.format("<b>Вага з крану:</b> %s кг.<br>", weightCrane));
            sb.append(Utils.format("<b>Локація:</b> %s<br>", app.fixLocation(locationCode)));
            sb.append(Utils.format("<b>Кількість позицій:</b> %s", packCount));

            contentShort = sb.toString();

            sb.append("<br><br>");

            for (int i = 0; i < packCount; i++) {

                Long wayId = wayList.get(i);
                OnTheWay way = wayId == 0 ? null : db.onTheWayDao().getById(wayId);

                sb.append(Utils.format("<b><font color=\"#34326D\">Позиція №%s</font></b><br>", i + 1));
                if (way != null) {
                    sb.append(Utils.format("<b>Партія:</b> %s<br>", way.getSapBatch()));
                    sb.append(Utils.format("<b>Склад:</b> %s<br>", way.getStorage()));
                } else {
                    sb.append("<b>Партія:</b> -<br>");
                }
                sb.append(Utils.format("<b>Вага з бірки:</b> %s кг.<br>", weightList1.get(i)));
                sb.append(Utils.format("<b>Вага упаковки:</b> %s кг.<br>", weightList2.get(i)));
                sb.append(Utils.format("<b>Тара:</b> %s кг.<br>", weightList3.get(i)));
                sb.append(Utils.format("<b>Призначена вага:</b> <font color=\"#34326D\"> %s кг.</font><br>", weightListFinal.get(i)));
                if (i + 1 != packCount) sb.append("<br>");
            }

            runOnUiThread(() -> endLoad(sb.toString()));
        });
    }

    private void endLoad(String content) {
        hideLoading();
        textContent.setText(app.fromHtml(content));
        scrollView.post(() -> scrollView.scrollTo(0, 0));
        buttonAccept.setEnabled(true);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            if (accepted)
                buttonPrintClick();
            else
                buttonAcceptClick();
        }
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        beginAccept();
    }

    private void beginAccept() {
        showLoading(R.string.text_please_wait);
        buttonAccept.setEnabled(false);

        String url = config.getUrlApi() + "getlabelid";
        url = net.addUrlParam(url, "count", String.valueOf(packCount));
        reqGet(url, this::endAccept);
    }

    private void endAccept(JsonResult result) {

        hideLoading();
        buttonAccept.setEnabled(true);

        if (result.isOk()) {
            JSONArray array = Utils.getJsonArray(result.getJson(), "data");

            List<Integer> idList = new ArrayList<>(packCount);
            for (int i = 0; i < packCount; i++) {
                try {
					idList.add(array.getInt(i));
				} catch (Exception e) {
					log(e, "idList.add(array.getInt(%s))", i);
					idList.add(0);
				}
            }

            if (array == null || array.length() != packCount) {
                showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, getString(R.string.text_upload_coming_list_error, "Помилка сервера"), (dialog, which) -> {
                    buttonAcceptClick();
                });
            } else {
                accepted = updateDb(idList);
                if (accepted) {
                    setResult(RESULT_OK);
                    buttonAccept.setText(packCount > 1 ? R.string.button_print_all : R.string.button_print);
                    buttonAccept.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_print_24dp, 0, 0, 0);
                    loadList();
                }
            }

        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, getString(R.string.text_upload_coming_list_error, result.getStatus().name()), (dialog, which) -> {
                buttonAcceptClick();
            });
        }
    }

    @Override
    public void onPrintClicked(AdapterIn4 item) {
        if (isLoading() || !accepted || !buttonAccept.isEnabled()) return;

        buttonAccept.setEnabled(false);
        showLoading(R.string.text_printing_title);

        List<Printed> listToPrint = new ArrayList<>();
        listToPrint.add(item.getPrinted());

        Utils.runOnBackground(() -> beginPrint(listToPrint));
    }

    private void loadList() {

        textContent.setText(app.fromHtml(contentShort));

        List<AdapterIn4> list = new ArrayList<>();
        for (int i = 0; i < printedList.size(); i++) {
            OnTheWay way = wayList.get(i) == 0 ? null : db.onTheWayDao().getById(wayList.get(i));
            list.add(new AdapterIn4(i, printedList.get(i), way, this));
        }

        FlexibleAdapter<AdapterIn4> adapter = new FlexibleAdapter<>(list);
        adapter.addListener(this);
        listView.setVisibility(View.VISIBLE);
        listView.setAdapter(adapter);
        scrollView.post(() -> scrollView.scrollTo(0, 0));
    }

    private boolean updateDb(List<Integer> idList) {

        printedList = new ArrayList<>(packCount);

        //Long weighingNumber = db.weighingDao().getMaxNumber();
        //weighingNumber = weighingNumber == null ? 1L : weighingNumber + 1;

        Integer weighingNumber = db.weighingDao().getMaxNumber();

        Weighing weighing = new Weighing(
                0,
                weighingNumber == null ? 1 : weighingNumber + 1,
                weightCrane,
                packCount
        );
        weighing.setId(db.weighingDao().insert(weighing));

        for (int i = 0; i < packCount; i++) {

            OnTheWay way = wayList.get(i) == 0 ? null : db.onTheWayDao().getById(wayList.get(i));

            if (way != null) {
                way.setWeightAccepted(way.getWeightAccepted() + weightListFinal.get(i));
                way.setPrinted(way.getSapWeightNett() <= way.getWeightAccepted());
                way.setDatePrinted(Calendar.getInstance().getTime().getTime());
                db.onTheWayDao().update(way);
            }

            Printed printedRow = new Printed(
                    idList.get(i),
                    tempWayId > 0 ? tempWayId : wayList.get(i),
                    weightListFinal.get(i),
                    weightList2.get(i),
                    weightList3.get(i),
                    name.getMatt(), name.getOzm(),
                    Calendar.getInstance().getTime().getTime(),
                    false, locationCode, tempWayId > 0, weighing.getId(),
                    weightList1.get(i),
                    isTheor, ""
            );
            db.printedDao().insert(printedRow);
            printedList.add(printedRow);
        }

        return true;
    }

    public void buttonPrintClick() {
        if (isLoading() || !accepted || !buttonAccept.isEnabled()) return;

        buttonAccept.setEnabled(false);
        showLoading(R.string.text_printing_title);

        Utils.runOnBackground(() -> beginPrint(printedList));
    }

    private void beginPrint(List<Printed> listToPrint) {
        StringBuilder data = new StringBuilder();

        for (Printed printedItem : listToPrint) {

            try {
                OnTheWay way = db.onTheWayDao().getById(printedItem.getOnTheWayId());
                NameStore nameStore = db.nameStoreDao().getById(way.getNameId());
                Carrier dbCarrier = db.carrierDao().getById(way.getCarrierId());
                data.append(app.generateDplLabel(
                        String.valueOf(printedItem.getId()), new Date(printedItem.getDate()), nameStore.getMatt(),
                        nameStore.getWidth(), nameStore.getLength(), nameStore.getThickness(),
                        printedItem.getWeightNetto(), printedItem.getWeightPack(), printedItem.getWeightTara(),
                        nameStore.getOzm(), printedItem.isTemporary() ? "TEMP" : way.getSapBatch(),
                        dbCarrier.getName(), 0,
                        printedItem.isTheor(), 0, printedItem.getLocation(), "",
                        printedItem.getPlavka(), "", null, "", "", null));
            } catch (Exception e) {
                log(e, "generateDplLabel()");
            }

        }

        StringBuilder dplName = new StringBuilder("<b>Зважування</b><br>");
        dplName.append(Utils.format("Вага з крану: %s кг.<br>", weightCrane));
        dplName.append(Utils.format("Кількість позицій: %s<br>", packCount));
        for (int i = 0; i < packCount; i++) {
            dplName.append(Utils.format("Позиція №%s: %s кг", i + 1, weightListFinal.get(i)));
            if (i + 1 < packCount) dplName.append("<br>");
        }

        final Printer.PrintResult result = Printer.sendCommand(dplName.toString(), config.getPrinter(), data.toString());

        runOnUiThread(() -> endPrint(result));
    }

    private void endPrint(Printer.PrintResult result) {

        buttonAccept.setEnabled(true);
        hideLoading();

        if (result.getStatus() == Printer.PrintResultStatus.OK) {
            printed = true;
            showToast(R.string.text_print_result_succeeded);
            //app.sendFaPrint();
        } else {
            @StringRes final int message = app.getPrintResultMessage(result);

            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> {
                dialog.dismiss();
                buttonPrintClick();
            });
        }

    }

    @Override
    public void onBackPressed() {
        if (accepted && !printed) {
            showDialogConfirm(R.string.text_warning, "Ви не роздрукували бірку. Ви дійсно бажаєте вийти?", (dialog, which) -> finish());
            return;
        }
        super.onBackPressed();
    }
}
