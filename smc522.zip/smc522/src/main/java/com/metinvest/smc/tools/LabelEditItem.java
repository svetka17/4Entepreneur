package com.metinvest.smc.tools;

public class LabelEditItem {
	private String labelId, batch, lowPricePercent;
	private String smcId;
	private int nettoNew, packNew;
	private boolean isRelease;

	public LabelEditItem(String labelId, String smcId, int nettoNew, int packNew, String batch, String lowPricePercent, boolean isRelease) {
		this.labelId = labelId;
		this.smcId = smcId;
		this.nettoNew = nettoNew;
		this.packNew = packNew;
		this.batch = batch;
		this.lowPricePercent = lowPricePercent;
		this.isRelease = isRelease;
	}

	public boolean isRelease() {
		return isRelease;
	}

	public void setRelease(boolean release) {
		isRelease = release;
	}

	public String getLabelId() {
		return labelId;
	}

	public int getNettoNew() {
		return nettoNew;
	}

    public int getPackNew() {
        return packNew;
    }

	public String getSmcId() {
		return smcId;
	}

	public void setSmcId(String smcId) {
		this.smcId = smcId;
	}

	public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public String getLowPricePercent() {
        return lowPricePercent;
    }

    public void setLowPricePercent(String lowPricePercent) {
        this.lowPricePercent = lowPricePercent;
    }
}
