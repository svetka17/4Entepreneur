package com.metinvest.smc.net;

public class StringResult extends NetworkResult<String> {
}
