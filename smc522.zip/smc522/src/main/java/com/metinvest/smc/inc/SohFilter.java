package com.metinvest.smc.inc;

import com.metinvest.smc.App;

import java.util.Objects;

public class SohFilter {
	private SohFilterType type;
	private String sohSmcId;

	private String sohStorage;

	public SohFilter(SohFilterType type, String sohSmcId) {
		this.type = type;
		this.sohSmcId = sohSmcId;
		this.sohStorage = null;
	}

	public SohFilter(SohFilterType type, String sohSmcId, String storage) {
		this.type = type;
		this.sohSmcId = sohSmcId;
		this.sohStorage = storage;
	}

	public SohFilterType getType() {
		return type;
	}

	public String getSohSmcId() {
		return sohSmcId;
	}

	public String getSohStorage() {
		return sohStorage;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		SohFilter sohFilter = (SohFilter) o;
		return type == sohFilter.type &&
				Objects.equals(sohSmcId, sohFilter.sohSmcId) &&
				Objects.equals(sohStorage, sohFilter.sohStorage);
	}

	@Override
	public int hashCode() {
		return Objects.hash(type, sohSmcId, sohStorage);
	}

	public static SohFilter All() {
		return new SohFilter(SohFilterType.ALL, null);
	}

	public static SohFilter NotSoh() {
		return new SohFilter(SohFilterType.NOT_SOH, null);
	}

	public static SohFilter SohInc(String sohSmcId) {
		return new SohFilter(SohFilterType.SOH_FALSE, sohSmcId, "0001");
	}

	public static SohFilter Eo(String sohSmcId, String storage) {
		return new SohFilter(SohFilterType.EO_TRUE, sohSmcId, storage);
	}

	public static SohFilter SohBuyOut() {
		return new SohFilter(SohFilterType.SOH_TRUE, App.getInstance().getSmcIdCurrent());
	}
}

