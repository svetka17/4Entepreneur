package com.metinvest.smc.db;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity
public class Inventory {

    @PrimaryKey(autoGenerate = true)
    private long id;

    private long date;
    private String locationCode;
    private long labelId;
    private String qr;
    private long dateScan;
    private long datePrint;
    private int netto;
    private int pack;
    private String batch, ozm, matt;
    private float width, length, thickness;

    public Inventory() {
    }

    @Ignore
    public Inventory(long id, long date, String locationCode, long labelId, String qr, long dateScan, long datePrint, int netto, int pack, String batch, String ozm, String matt, float width, float length, float thickness) {
        this.id = id;
        this.date = date;
        this.locationCode = locationCode;
        this.labelId = labelId;
        this.qr = qr;
        this.dateScan = dateScan;
        this.datePrint = datePrint;
        this.netto = netto;
        this.pack = pack;
        this.batch = batch;
        this.ozm = ozm;
        this.matt = matt;
        this.width = width;
        this.length = length;
        this.thickness = thickness;
    }


    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public String getOzm() {
        return ozm;
    }

    public void setOzm(String ozm) {
        this.ozm = ozm;
    }

    public String getMatt() {
        return matt;
    }

    public void setMatt(String matt) {
        this.matt = matt;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getLength() {
        return length;
    }

    public void setLength(float length) {
        this.length = length;
    }

    public float getThickness() {
        return thickness;
    }

    public void setThickness(float thickness) {
        this.thickness = thickness;
    }

    public long getDatePrint() {
        return datePrint;
    }

    public void setDatePrint(long datePrint) {
        this.datePrint = datePrint;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public long getLabelId() {
        return labelId;
    }

    public void setLabelId(long labelId) {
        this.labelId = labelId;
    }

    public String getQr() {
        return qr;
    }

    public void setQr(String qr) {
        this.qr = qr;
    }

    public long getDateScan() {
        return dateScan;
    }

    public void setDateScan(long dateScan) {
        this.dateScan = dateScan;
    }

    public int getNetto() {
        return netto;
    }

    public void setNetto(int netto) {
        this.netto = netto;
    }

    public int getPack() {
        return pack;
    }

    public void setPack(int pack) {
        this.pack = pack;
    }
}
