package com.metinvest.smc.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.metinvest.smc.tools.IValue;
import com.metinvest.smc.tools.Utils;

import java.util.List;

@Entity
public class ShipmentItem implements IValue {

    @Ignore
    public List<ShipmentItemLoc> shipmentItemLoc;

    @PrimaryKey(autoGenerate = true)
    private long id;
    private int lineId, sapWeightNett, sapWeightNettFact;
    private String smcId, documentNumber, positionId, vo, transportName, sapOzm, sapMattDescr, delFlag;
    private long dateVo, dateUpload;
    private float length, width, thickness;
    private String  discount;
    public ShipmentItem() {
    }

    @Ignore
    public ShipmentItem(long id, int lineId, int sapWeightNett, int sapWeightNettFact, String smcId, String documentNumber, String positionId, String vo, String transportName, String sapOzm, String sapMattDescr, String delFlag, long dateVo, long dateUpload,
                        float length, float width, float thickness, String discount) {
        this.id = id;
        this.lineId = lineId;
        this.sapWeightNett = sapWeightNett;
        this.sapWeightNettFact = sapWeightNettFact;
        this.smcId = smcId;
        this.documentNumber = documentNumber;
        this.positionId = positionId;
        this.vo = vo;
        this.transportName = transportName;
        this.sapOzm = sapOzm;
        this.sapMattDescr = sapMattDescr;
        this.delFlag = delFlag;
        this.dateVo = dateVo;
        this.dateUpload = dateUpload;
        this.length = length;
        this.width = width;
        this.thickness = thickness;
        this.discount = discount;
    }

    @Override
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getLineId() {
        return lineId;
    }

    public void setLineId(int lineId) {
        this.lineId = lineId;
    }

    public int getSapWeightNett() {
        return sapWeightNett;
    }

    public void setSapWeightNett(int sapWeightNett) {
        this.sapWeightNett = sapWeightNett;
    }

    public int getSapWeightNettFact() {
        return sapWeightNettFact;
    }

    public void setSapWeightNettFact(int sapWeightNettFact) {
        this.sapWeightNettFact = sapWeightNettFact;
    }

    public String getSmcId() {
        return smcId;
    }

    public void setSmcId(String smcId) {
        this.smcId = smcId;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public String getPositionId() {
        return positionId;
    }

    public void setPositionId(String positionId) {
        this.positionId = positionId;
    }

    public String getVo() {
        return vo;
    }

    public void setVo(String vo) {
        this.vo = vo;
    }

    public String getTransportName() {
        return transportName;
    }

    public void setTransportName(String transportName) {
        this.transportName = transportName;
    }

    public String getSapOzm() {
        return sapOzm;
    }

    public void setSapOzm(String sapOzm) {
        this.sapOzm = sapOzm;
    }

    public String getSapMattDescr() {
        return sapMattDescr;
    }

    public void setSapMattDescr(String sapMattDescr) {
        this.sapMattDescr = sapMattDescr;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public long getDateVo() {
        return dateVo;
    }

    public void setDateVo(long dateVo) {
        this.dateVo = dateVo;
    }

    public long getDateUpload() {
        return dateUpload;
    }

    public void setDateUpload(long dateUpload) {
        this.dateUpload = dateUpload;
    }

    public float getLength() {
        return length;
    }

    public void setLength(float length) {
        this.length = length;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getThickness() {
        return thickness;
    }

    public void setThickness(float thickness) {
        this.thickness = thickness;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    @Override
    public String getName() {
        return getSapMattDescr();
    }

    @NonNull
    @Override
    public String toString() {
        return Utils.format("[%d] %s", getId(), getName());
    }
}
