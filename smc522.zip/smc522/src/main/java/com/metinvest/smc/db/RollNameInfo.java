package com.metinvest.smc.db;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity
public class RollNameInfo {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private long rollNameId;
    private String markdown, mera, travl;

    public RollNameInfo() {
    }

    @Ignore
    public RollNameInfo(long id, long rollNameId, String markdown, String mera, String travl) {
        this.id = id;
        this.rollNameId = rollNameId;
        this.markdown = markdown;
        this.mera = mera;
        this.travl = travl;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getRollNameId() {
        return rollNameId;
    }

    public void setRollNameId(long rollNameId) {
        this.rollNameId = rollNameId;
    }

    public String getMarkdown() {
        return markdown;
    }

    public void setMarkdown(String markdown) {
        this.markdown = markdown;
    }

    public String getMera() {
        return mera;
    }

    public void setMera(String mera) {
        this.mera = mera;
    }

    public String getTravl() {
        return travl;
    }

    public void setTravl(String travl) {
        this.travl = travl;
    }
}
