package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface RollNameDao {
    @Query("SELECT * FROM rollname ORDER BY matt")
    List<RollName> getAll();

    @Query("SELECT * FROM rollname WHERE " +
            "id in (:rollNameIdList) " +
            "AND lower(matt) LIKE lower(:matt) " +
            "AND (:width = -1 OR :width = width) " +
            "AND (:length = -1 OR :length = length) " +
            "AND (:thickness = -1 OR :thickness = thickness) " +
            "ORDER BY matt")
    List<RollName> find(List<Long> rollNameIdList, String matt, float width, float length, float thickness);

    /*
    @Query("SELECT DISTINCT(rollNameId) FROM RollNameInfo WHERE " +
            "(:markdown is null OR :markdown = markdown) " +
            "AND (:mira is null OR :mira = mera) " +
            "AND (:travl is null OR :travl = travl) ")
     */
    @Query("SELECT rollname.* FROM rollname JOIN rollnameinfo ON rollnameinfo.rollNameId = rollname.id WHERE " +
            "    (:markdown is null OR :markdown = rollnameinfo.markdown) " +
            "AND (:mera is null OR :mera = rollnameinfo.mera) " +
            "AND (:travl is null OR :travl = rollnameinfo.travl) " +
            "AND lower(rollname.matt) LIKE lower(:matt) " +
            "AND (:width = -1 OR :width = rollname.width) " +
            "AND (:length = -1 OR :length = rollname.length) " +
            "AND (:thickness = -1 OR :thickness = rollname.thickness) " +
            "ORDER BY rollname.matt")
    List<RollName> find(String markdown, String mera, String travl, String matt, float width, float length, float thickness);

    @Query("SELECT * FROM rollname WHERE id = :id")
    RollName getById(long id);

    @Query("SELECT * FROM rollname WHERE id in (:idList)")
    List<RollName> getById(List<Long> idList);

    @Query("SELECT * FROM rollname WHERE matt = :matt AND ozm = :ozm AND width = :width AND length = :length AND thickness = :thickness")
    RollName getByFull(String matt, String ozm, float width, float length, float thickness);

    @Query("SELECT count(1) FROM rollname")
    long getCount();

    @Insert
    long insert(RollName rollName);

    @Insert
    void insertAll(List<RollName> rollNameList);

    @Update
    void update(RollName rollName);

    @Delete
    void delete(RollName rollname);

    @Query("DELETE FROM rollName")
    void truncate();
}