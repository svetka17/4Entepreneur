package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

import com.metinvest.smc.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PincodeActivity extends MyActivity {

    private String action;
    private String labelId;

    @BindView(R.id.textPincode)
    EditText textPincode;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pincode);
        ButterKnife.bind(this);

        action = getIntent().getStringExtra("action");
        labelId = getIntent().getStringExtra("labelId");

        textPincode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (isPincodeCorrect(s.toString())) buttonAcceptClick();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        textPincode.requestFocus();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    private boolean isPincodeCorrect(String pincode) {
        return pincode.equalsIgnoreCase("7525");
    }

    private void buttonAcceptClick() {
        String pincode = textPincode.getText().toString();

        if (pincode.length() == 0) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.warning_pincode_empty, (dialog, which) -> textPincode.requestFocus());
            return;
        }

        if (!isPincodeCorrect(pincode)) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.warning_pincode_error, (dialog, which) -> {
                textPincode.setText(null);
                textPincode.requestFocus();
            });
            return;
        }

        Intent intent = new Intent();
        intent.putExtra("action", action);
        intent.putExtra("labelId", labelId);
        setResult(RESULT_OK, intent);
        finish();
    }
}
