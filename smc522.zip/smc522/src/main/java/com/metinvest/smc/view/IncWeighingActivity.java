package com.metinvest.smc.view;

import static com.metinvest.smc.tools.Utils.parseInt;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanIntentResult;
import com.journeyapps.barcodescanner.ScanOptions;
import com.metinvest.smc.BuildConfig;
import com.metinvest.smc.R;
import com.metinvest.smc.inc.Order;
import com.metinvest.smc.inc.Ozm;
import com.metinvest.smc.inc.SohFilter;
import com.metinvest.smc.inc.TTN;
import com.metinvest.smc.inc.TransportDoc;
import com.metinvest.smc.inc.Weight;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.ScalesConfig;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.tools.Value;
import com.metinvest.smc.ui.AdapterItemPack;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.BindViews;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class IncWeighingActivity extends MyActivity implements IScan, AdapterItemPack.Listener {
	@BindView(R.id.textContentTitle)
	TextView textContentTitle;
	@BindView(R.id.spinnerName)
	Spinner spinnerName;
	@BindView(R.id.textNotFound)
	TextView textNotFound;
	@BindView(R.id.viewContentData)
	View viewContentData;
	@BindView(R.id.scrollView)
	NestedScrollView scrollView;

	@BindView(R.id.buttonToggle)
	Button buttonToggle;
	@BindView(R.id.textWeight)
	EditText textWeight;
	@BindView(R.id.textCount)
	EditText textCount;
	@BindViews({R.id.textLocation1, R.id.textLocation2, R.id.textLocation3})
	EditText[] textLocation;
	@BindView(R.id.listView)
	RecyclerView listView;
	@BindView(R.id.buttonAccept)
	Button buttonAccept;
	@BindView(R.id.buttonSearchOzm)
	ImageButton buttonSearchOzm;
	@BindView(R.id.buttonCrane)
	ImageButton buttonCrane;

	@BindView(R.id.buttonZeroCrane)
	ImageButton buttonZeroCrane;
	@BindView(R.id.buttonAdd)
	ImageButton buttonAdd;
	@BindView(R.id.checkVhpIgnore)
	CheckBox checkVhpIgnore;

	private final List<String> scannedLabels = new ArrayList<>();

	private Date date, dateFrom, dateTo;
	private String transportName;
	private TransportDoc transportDoc;
	private List<Order> orderList;
	private List<Ozm> ozmList, ozmListUser;

	private List<Order> currentOrderList;
	private boolean theor = false;
	private FlexibleAdapter<AdapterItemPack> adapter;

	private boolean firstLoad;
	private TTN ttn;
	private int packCount;
	private boolean isVhp;
	private String sohSmcId;
	private SohFilter sohFilter;
	private ActivityResultLauncher<Intent> scanLauncher;
	/*команда 1-тест(посылается в настройках), 2-взвешивание(кнопка с краном buttonCrane), 7-обнуление весов(кнопка sync buttonZeroCrane)*/
	private byte cmd = 2;

	private void scanBarcode() {
		Intent intent = new ScanContract().createIntent(
				this,
				new ScanOptions() //Builder()
						.setPrompt("Відскануйте штрихкод або QR-код")
						.setBeepEnabled(true)
						.setOrientationLocked(true)
						.setTorchEnabled(true)
						//.build()
		);
		scanLauncher.launch(intent);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_inc_weighing);
		ButterKnife.bind(this);

		sohSmcId = getIntent().getStringExtra("sohSmcId");
		sohFilter = sohSmcId == null ? SohFilter.NotSoh() : SohFilter.SohInc(sohSmcId);
		Boolean isVhpB = (Boolean) getIntent().getSerializableExtra("isVhp");
		isVhp = isVhpB != null && isVhpB;
		dateFrom = (Date) getIntent().getSerializableExtra("dateFrom");
		dateTo = (Date) getIntent().getSerializableExtra("dateTo");
		date = (Date) getIntent().getSerializableExtra("date");
		transportName = getIntent().getStringExtra("transportName");
		ttn = (TTN) getIntent().getSerializableExtra("ttn");

		if (BuildConfig.DEBUG)
		{
			scanLauncher = registerForActivityResult(
					new ActivityResultContracts.StartActivityForResult(),
					result -> {
						if (result != null) {
							ScanContract scanContract = new ScanContract();
							ScanIntentResult intentResult = scanContract.parseResult(result.getResultCode(), result.getData());
							if (intentResult != null) {
								String cameraBarcode = intentResult.getContents();
								onBarcodeEvent(cameraBarcode);
							}
						}
					});

			textContentTitle.setOnClickListener(v -> {
				scanBarcode();
			/*	onBarcodeEvent("Code Gal: 59134810220905\n" +
						"ID: 591348 1022 09 05\n" +
						"SIZE[mm]: 10x2000x6000\n" +
						"QUALITY: S275JR+AR\n" +
						"HEAT: Y917357\n" +
						"Surface app: EN10163-2: ClassA,Subclass1\n" +
						"Tol Thickness: EN10029 Class A\n" +
						"Min Thickness: 0.5000\n" +
						"Max Thickness: 0.9000\n" +
						"10076965");*/
				//onBarcodeEvent("{'qr_link':'http://77.222.152.25:17236/mdmz/hs/docs/pack/k0724519-1?yp=23 ','code':'Kominmet','pack':'k0724519-1/23','heats':'813098','party':'0','stand':'DIN EN 10219-1:2006, DIN EN 10219-2:2019','ms':'S235JRH','dim':'40х40х3х6000','qt':110,'ln':660,'wt':2.302,'date':'22.06.2023'}");
//onBarcodeEvent("http://metinvest.io/qr/&2100&0&108&1275139&/&864532652&001013369&106191&3&1700&1715&ГАРЯЧЕКАТАНИЙ_ЛИСТ__&8.0x1500x6000&S235JR+AR&2023_971000-0899_0&2023\n" +
//		"|120|&/");
				//onBarcodeEvent("HTTP://METINVEST.IO/QR/&4900&1&620&1094161&/&94352869&206260-4&1-204515&1156&2565&2570&Лист точеный&50x3x6.000&S235JRH&608385004166&2020&/");
				//onBarcodeEvent("Трубосталь&80х60х4&ГОСТ8639-82&Ст2пс&1211500-1&12000&08-19/21&www.trubostal.net&2000000000398&c9f28ad6-f5a6-11eb-a28f-0cc47ada5628");

				//onBarcodeEvent("SMC06|99957|1436|Труба|0.000000|159.000000|4.000000|2161|ФВ||0|0|TEMP|0|20200404131952|AН4768НР/АН5481ХР");
				//onBarcodeEvent("SMC07|1000|1|[{\"netto\":\"1000\",\"pack\":\"0\",\"tara\":\"0\",\"id\":\"126163\"}]|04.04.2020|test|1-0-0|12345|11.22.33.44.55|test ozm|2000.000000|100.000000|50.000000");


				//processZavod("5&1&2020&2583&2&&0", 50, 5);
				//onBarcodeEvent("{'code':'Kominmet','pack':'54275/19','heats':'519102-2','party':'0','stand':'ГОСТ 8639-82,13663-86','dim':'160х160х4х12000','qt':12,'ln':144,'wt':3.326,'date':'21.06.2019'}");

				//onBarcodeEvent("SMC07|700|1|[{\"netto\":\"700\",\"pack\":\"0\",\"tara\":\"0\",\"id\":\"0\"}]|31.03.2020|AA777BB|1-0-0|DOC|11.22.33.44.55|Material name|2000.000000|10.000000|5.000000");

			});
		}

		//checkVhp.setEnabled(false);
		checkVhpIgnore.setVisibility(isVhp ? View.VISIBLE : View.GONE);

        /*if (isVhp == null) {
            checkVhp.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    isVhp = isChecked;
                }
            });
        }*/

		LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
		DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
		dividerItemDecoration.setDrawable(getDrawable(R.drawable.divider_adapter));
		listView.setLayoutManager(layoutManager);
		listView.addItemDecoration(dividerItemDecoration);

		spinnerName.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				onOzmChange();
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {

			}
		});
		buttonToggle.setOnClickListener(v -> setTheor(!isTheor()));
		textCount.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				if (s.length() > 0) onPackCountChanged(parseInt(s.toString()));
				checkTextCount();
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		});

		TextWatcher checkWatcher = new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				checkButtonAccept();
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		};
		textWeight.addTextChangedListener(checkWatcher);
		textLocation[0].addTextChangedListener(checkWatcher);
		textLocation[2].addTextChangedListener(checkWatcher);
		ozmListUser = new ArrayList<>();

		buttonSearchOzm.setOnClickListener(v -> beginSearchOzm());
		buttonCrane.setVisibility(View.VISIBLE);
		buttonCrane.setEnabled(true);
		buttonCrane.setOnClickListener(v -> {
			cmd = 2;
			loadScalesWeight((byte) 2);
		});
		buttonCrane.setOnLongClickListener(v -> {
			cmd = 2;
			loadScalesWeight((byte)2);
			return true;
		});
		buttonZeroCrane.setVisibility(View.VISIBLE);
		buttonZeroCrane.setEnabled(true);
		buttonZeroCrane.setOnClickListener(v -> {
			cmd = 7;
			loadScalesWeight((byte) 7);
		});
		buttonZeroCrane.setOnLongClickListener(v -> {
			cmd = 7;
			loadScalesWeight((byte)7);
			return true;
		});

		buttonAdd.setOnClickListener(v -> beginAddLabelId());
	}

	private boolean isSoh() {
		return sohSmcId != null;
	}

	private void saveScannedLabelList() {
		List<Weight> weightList = getWeightList();
		for (Weight item : weightList) {
			if (item.getScanLabelId() != null && item.getScanLabelId().length() > 0) {
				log("Save scanned label #%s", item.getScanLabelId());
				addLabelScanned(item.getScanLabelId());
			}
		}
	}

	private void addLabelScanned(String labelId) {
		if (isLabelScannedAll(labelId)) return;
		scannedLabels.add(labelId);
	}

	private boolean isLabelScannedAll(String labelId) {
		for (String item : scannedLabels) {
			if (item.equalsIgnoreCase(labelId)) return true;
		}

		return false;
	}

	private boolean isLabelScanned(String labelId) {
		List<Weight> weightList = getWeightList();
		for (Weight item : weightList) {
			if (item.getScanLabelId() != null && item.getScanLabelId().equalsIgnoreCase(labelId))
				return true;
		}

		return false;
	}

	private void beginAddLabelId() {
		startActivityForResult(new Intent(this, InputLabelIdActivity.class), REQUEST_LABEL_ID_INPUT);
	}

	@Override
	public void onItemDeleteClicked(int index) {

		AdapterItemPack item = getItemByIndex(index);

		if (item != null) {
			log(Utils.format("%s %s", "onItemDeleteClicked", item.toString()));

			showDialogConfirm(R.string.text_confirm, R.string.delete_position_confirm, (dialog, which) -> {
				item.setW1(0);
				item.setW2(0);
				item.setW3(0);
				item.setLabelId("");
				item.setIdQr("");
				item.setSmcId(app.getSmcIdCurrent());
				item.setBatch("");
				item.setScanLabelId("");
				item.setNettoOnly(isTheor());
				adapter.updateItem(item);
				printItems();
				checkButtonAccept();
			});
		}
	}

	private void printItems() {
		log("printItems");
		if (adapter != null) {
			List<AdapterItemPack> list = adapter.getCurrentItems();
			for (int i = 0; i < list.size(); i++) {
				log("i=%d -> %s", i, list.get(i).toString());
			}
		}
	}

	private AdapterItemPack newItem;

	private void loadAdapter() {
		List<AdapterItemPack> itemList = new ArrayList<>();
		adapter = new FlexibleAdapter<>(itemList);
		listView.setAdapter(adapter);
		scrollView.post(() -> scrollView.scrollTo(0, 0));
	}

	private void onPackCountChanged(int value) {

		if (adapter != null) {

			int packCountOld = adapter.getCurrentItems().isEmpty() ? 0 : packCount;
			packCount = value;

			if (isTheor()) {

				if (packCount > 0) {
					String packNumTheor = packCount > 1 ? "1-" + packCount : "1";
					String title = Utils.format("<b>Пачка №:%s", packNumTheor);

					if (adapter.getCurrentItems().isEmpty()) {
						AdapterItemPack item = new AdapterItemPack(1, title, 0, 0, 0, this);
						item.setNettoOnly(isTheor());
						adapter.addItem(item);
					} else {
						AdapterItemPack item = adapter.getCurrentItems().get(0);
						item.setIdQr("");
						item.setLabelId("");
						item.setTitle(title);
						item.setIndex(1);
						item.setNettoOnly(isTheor());
						adapter.updateItem(item);
					}
					printItems();
				}

			} else {

				if (packCount > packCountOld) {
					for (int i = 0; i < (packCount - packCountOld); i++) {
						String title = Utils.format("<b>Пачка №:%d</b>", packCountOld + i + 1);
						adapter.addItem(new AdapterItemPack(
								packCountOld + i, title,
								newItem == null ? 0 : newItem.getW1(),
								newItem == null ? 0 : newItem.getW2(),
								newItem == null ? 0 : newItem.getW3(),
								newItem == null ? "" : newItem.getLabelId(),
								newItem == null ? "" : newItem.getIdQr(),
								newItem == null ? "" : newItem.getBatch(),
								newItem == null ? "" : newItem.getScanLabelId(),
								this
						));
						printItems();
						if (newItem != null) newItem = null;
					}
				} else {
					List<Integer> posList = new ArrayList<>();
					for (int i = packCount; i < adapter.getItemCount(); i++) {
						posList.add(i);
						log("REMOVE ITEM #%d", i);
					}
					adapter.removeItems(posList);
					printItems();
				}
			}
		}

		new Timer().schedule(
				new TimerTask() {
					@Override
					public void run() {
						try {
							checkTextCount();
							checkButtonAccept();
						} catch (Exception ignored) {

						}
					}
				}, 100
		);
	}

	private void beginSearchOzm() {
		Ozm ozm = getCurrentOzm();
		if (ozm != null) {
			showInfoByOzm(ozm.getName(), true, -1, -1, -1);
		}
	}

	private boolean isPackCountCorrect() {
		int packCountOrig = packCount;
		return packCountOrig > 0 && packCountOrig <= (isTheor() ? 250 : 25);
	}

	private boolean isWeightCorrect() {
		int weight = getWeightCraneBrutto();
		return isTheor() || weight > 0;
	}

	private boolean isLocationCorrect() {
		if (isSoh()) //Для СОХ проверяем ярус
			return parseInt(textLocation[0].getText().toString()) > 0 && parseInt(textLocation[2].getText().toString()) > 0;
		else
			return parseInt(textLocation[0].getText().toString()) > 0;
	}

	private boolean isWeightListCorrect() {
		List<Weight> weightList = getWeightList();
		if (weightList.isEmpty()) return false;
		for (Weight weight : weightList) {
			if (weight.getNetto() == 0) return false;
		}
		return true;
	}

	private void checkTextCount() {
		if (isPackCountCorrect()) {
			textCount.setBackgroundTintList(null);
		} else {
			textCount.setBackgroundTintList(ContextCompat.getColorStateList(this, R.color.tint_incorrect));
		}

		checkButtonAccept();
	}

	private void checkButtonAccept() {
		boolean correct = false;

		if (isPackCountCorrect() && isWeightCorrect() && isLocationCorrect() && isWeightListCorrect()) {
			correct = true;
		}

		buttonAccept.setEnabled(correct);
	}

	public boolean isTheor() {
		return theor;
	}

	public void setTheor(boolean theor) {
		this.theor = theor;
		textWeight.setEnabled(!isTheor());
		buttonToggle.setBackgroundTintList(ContextCompat.getColorStateList(this, isTheor() ? R.color.toggle_on : R.color.toggle_off));

		loadAdapter();
		setPackCount(packCount);
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);

		checkButtonAccept();
		loadAdapter();
		beginLoad();
		//showLoading(null);

		/*AlertDialog dialog = showDialog(R.drawable.ic_info_24dp, R.string.text_information, R.string.text_inc_info, (dialogInterface, i) -> {
			hideLoading();
			checkButtonAccept();
			loadAdapter();
			beginLoad();
		});
		dialog.setCancelable(false);
		dialog.setCanceledOnTouchOutside(false);*/
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 2) {
			beginLoad();
		} else if (number == 3) {
			spinnerName.requestFocus();
			spinnerName.performClick();
		} else if (number == 4) {
			openNewOzm();
		} else if (number == 5) {
			buttonAcceptClick();
		}
	}

	@Override
	public void onBackPressed() {
		saveCurrentOzm();
		Intent data = new Intent();
		data.putExtra("isVhp", isVhp);
		setResult(RESULT_OK, data);
		super.onBackPressed();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == REQUEST_LABEL_ID_INPUT) {
			if (resultCode == RESULT_OK && data != null) {
				String resultLabelId = data.getStringExtra("labelId");
				if (resultLabelId != null) {
					beginLoadLabel(resultLabelId);
				}
			}
		} else if (requestCode == REQUEST_DEFAULT) {
			if (resultCode == RESULT_OK) {
				saveScannedLabelList();
				//
				savePackTara();
				//isVhp = checkVhp.isChecked();
				//checkVhp.setEnabled(false);
				textWeight.setText(null);
				textWeight.requestFocus();
				loadAdapter();
				packCount = 1;
				setPackCount(packCount);
				beginLoad();
			} else if (resultCode == RESULT_NEED_REFRESH) {
				beginLoad();
			} else if (resultCode == RESULT_DELETED) {
				setResult(RESULT_DELETED);
				finish();
			}
		}

		if (requestCode == REQUEST_ADD && resultCode == RESULT_OK && data != null) {
			String name = data.getStringExtra("name");
			int length = data.getIntExtra("length", 0);
			int width = data.getIntExtra("width", 0);
			int thickness = data.getIntExtra("thickness", 0);

			addOzm(name, length, width, thickness);
		}
	}

	private Weight savedPackTara;

	private void savePackTara() {
		List<Weight> weights = getWeightList();
		if (weights.isEmpty()) return;

		savedPackTara = weights.get(0);
	}

	private void restorePackTara() {
		if (savedPackTara == null) return;
		try {
			AdapterItemPack item = adapter.getItem(0);
			if (item != null) {
				item.setW2(savedPackTara.getPack());
				item.setW3(savedPackTara.getTara());
				item.setLabelId("");
				item.setIdQr("");
				item.setNettoOnly(isTheor());
				adapter.updateItem(item);
			}
		} catch (Exception ignored) {

		}
		savedPackTara = null;
	}

	private void beginLoad() {
		if (isLoading()) return;

		showLoading(R.string.text_please_wait);
		viewContentData.setVisibility(View.GONE);
		textNotFound.setVisibility(View.GONE);

		this.transportDoc = null;
		this.orderList = null;
		this.ozmList = null;
		this.currentOrderList = null;

		Utils.runOnBackground(() -> {
			Network.NetworkResultValue<TransportDoc> result = app.loadIncTransportDoc(date, dateFrom, dateTo, transportName, ttn, sohFilter);

			List<Order> listDoc = new ArrayList<>();
			if (result.getResult().isOk() && result.getValue() != null) {
				Network.NetworkResultValue<List<Order>> resultDocuments = app.loadIncOrderList(date, result.getValue(), sohFilter);
				if (resultDocuments.getResult().isOk()) {
					listDoc = resultDocuments.getValue();
				} else {
					result.setResult(resultDocuments.getResult());
				}
			}

			List<Order> finalOrderList = listDoc;
			runOnUiThread(() -> endLoad(result.getResult(), result.getValue(), finalOrderList));
		});
	}

	private void endLoad(JsonResult result, TransportDoc transportDoc, List<Order> orderList) {

		boolean isContent = false;

		hideLoading();

		if (result.isOk()) {

			if (firstLoad) firstLoad = false;

			if (transportDoc != null && !orderList.isEmpty()) {
				isContent = true;
				this.transportDoc = transportDoc;
				this.orderList = orderList;
				loadOzmList();
				loadNameList();
				loadCurrentOzm();
				restorePackTara();
			} else {
				isContent = false;
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, transportDoc == null ? R.string.error_inc_transport_not_found : R.string.error_inc_transport_empty, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialogInterface, int i) {
						setResult(RESULT_CANCELED);
						finish();
					}
				});
			}
		} else {
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
		}

		viewContentData.setVisibility(isContent ? View.VISIBLE : View.GONE);
		textNotFound.setVisibility(!isContent ? View.VISIBLE : View.GONE);
		buttonAccept.setEnabled(isContent);
	}

	private void loadOzmList() {
		this.ozmList = Order.getOzmList(orderList);
		if (!firstLoad) ozmList.addAll(ozmListUser);
	}

	private void loadNameList() {

		List<Value> valueList = new ArrayList<>();
		for (int i = 0; i < ozmList.size(); i++) {
			Ozm ozm = ozmList.get(i);
			valueList.add(new Value(i, Utils.format(
					"%s%s %s",
					ozm.isManual() ? "*" : "",
					ozm.getName(),
					app.sizeToString(ozm.getWidth(), ozm.getThickness(), ozm.getLength())
			)));
		}

		Utils.fillData(spinnerName, new ArrayList<>(valueList));
	}

	private Ozm getCurrentOzm() {
		long id = spinnerName.getSelectedItemId();
		return ozmList == null ? null : ozmList.get((int) id);
	}

	private void onOzmChange() {

		currentOrderList = Order.getByOzm(orderList, getCurrentOzm());

		int totalCurrentPlan = Order.getTotalWeightPlan(currentOrderList);
		int totalCurrentFact = Order.getTotalWeightFact(currentOrderList);

		textContentTitle.setText(getString(R.string.text_in_from_to,
				totalCurrentFact / 1000.0f,
				totalCurrentPlan / 1000.0f));

		checkButtonAccept();
		saveCurrentOzm();
	}

	private void setPackCount(int value) {
		textCount.setText(String.valueOf(value));
	}

	private int getWeightCraneBrutto() {
		return parseInt(textWeight.getText().toString());
	}

	private void setWeightCraneBrutto(long value) {
		if (cmd == 7) {
			if ((byte) value == 1)
				textWeight.setText("0");
			else
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.error_zero_scales, String.valueOf(value)), null);
		} else
			textWeight.setText(String.valueOf(value));
		cmd = 2;
	}

	private String getLocationCode() {
		return isLocationCorrect() ? app.fixLocation(Utils.format("%s-%s-%s",
				textLocation[0].getText().toString(),
				textLocation[1].getText().toString(),
				textLocation[2].getText().toString()
		)) : "";
	}

	/**
	 * Берем все нулевые пачки
	 * Вычиляем разницу между весом с крана и суммой веса упаковов нулевых пачек
	 * Разницу пропорционально распределяем между пачками
	 */
	@Override
	public void onItemCalcClicked(int index) {

		AdapterItemPack item = getItemByIndex(index);

		if (item != null) {
			log("onItemCalcClicked #%s", item.getIndex());
			if (adapter == null) return;

			List<AdapterItemPack> itemsZero = getZeroPacks();
			if (itemsZero.isEmpty()) return;

			int bruttoCrane = getWeightCraneBrutto();
			int zeroCount = itemsZero.size();
			int packTaraTotal = getPackTaraTotal();
			int nettoBusy = getNettoTotal();
			//int nettoFree = bruttoCrane - packTaraTotal - nettoBusy;
			//CodeQL requirement
			int nettoFree = 0;
			if (packTaraTotal < Integer.MAX_VALUE && nettoBusy < Integer.MAX_VALUE)
				nettoFree = bruttoCrane - packTaraTotal - nettoBusy;
			log("crane: %d, zeroCount: %d, packTaraTotal: %d, busy: %d, free: %d", bruttoCrane, zeroCount, packTaraTotal, nettoBusy, nettoFree);

			if (nettoFree > 0) {
				//
				List<Integer> wFinal = new ArrayList<>(zeroCount);
				double weightExtra = 0.0f;

				for (int i = 0; i < zeroCount; i++) {
					double weightToAdd;
					weightToAdd = (double) nettoFree / zeroCount;
					weightExtra += weightToAdd - (int) weightToAdd;
					wFinal.add((int) weightToAdd);
				}

				if (Math.abs(weightExtra) > 0) {
					int i = 0;
					while (Math.abs(weightExtra) >= 1.0f) {
						wFinal.set(i, wFinal.get(i) + (weightExtra > 0 ? 1 : -1));
						weightExtra -= (weightExtra > 0 ? 1 : -1);
						i = i == wFinal.size() - 1 ? 0 : i + 1;
					}
				}

				for (int i = 0; i < itemsZero.size(); i++) {
					itemsZero.get(i).setW1(wFinal.get(i));
					itemsZero.get(i).setNettoOnly(isTheor());
					adapter.updateItem(itemsZero.get(i));
					printItems();
				}
				//
			}
		}
	}

	private AdapterItemPack getItemByIndex(int index) {
		if (adapter != null) {
			List<AdapterItemPack> items = adapter.getCurrentItems();
			for (AdapterItemPack item : items) {
				if (item.getIndex() == index) return item;
			}
		}
		return null;
	}

	private int getPackTaraTotal() {
		int res = 0;

		if (adapter != null) {
			List<AdapterItemPack> items = adapter.getCurrentItems();
			for (AdapterItemPack item : items) {
				res += item.getW2() + item.getW3();
			}
		}

		return res;
	}

	private int getNettoTotal() {
		int res = 0;

		if (adapter != null) {
			List<AdapterItemPack> items = adapter.getCurrentItems();
			for (AdapterItemPack item : items) {
				if (item.getW1() > 0) res += item.getW1();
			}
		}

		return res;
	}

	private List<AdapterItemPack> getZeroPacks() {
		List<AdapterItemPack> res = new ArrayList<>();

		if (adapter != null) {
			List<AdapterItemPack> items = adapter.getCurrentItems();
			for (AdapterItemPack item : items) {
				if (item.getW1() == 0) res.add(item);
			}
		}

		Collections.sort(res, (o1, o2) -> Integer.compare(o1.getIndex(), o2.getIndex()));

		return res;
	}

	private List<Weight> getWeightList() {

		List<Weight> list = new ArrayList<>();

		if (adapter != null && adapter.getItemCount() > 0) {

			if (isTheor()) {
				AdapterItemPack item = adapter.getItem(0);
				if (item != null) {
					for (int i = 0; i < packCount; i++)
						list.add(new Weight(item.getW1(), item.getW2(), item.getW3(), item.getLabelId(), item.getIdQr(), item.getBatch(), item.getScanLabelId(), item.getBarcode() == null ? "" : item.getBarcode()));
				}
			} else {
				for (int i = 0; i < packCount; i++) {
					AdapterItemPack item = adapter.getItem(i);
					if (item != null) {
						list.add(new Weight(item.getW1(), item.getW2(), item.getW3(), item.getLabelId(), item.getIdQr(), item.getBatch(), item.getScanLabelId(), item.getBarcode() == null ? "" : item.getBarcode()));
					}
				}
			}
		}

		return list;
	}

	private void beginAcceptManual() {
		List<Weight> weightList = getWeightList();

		int weightCraneBrutto;
		if (isTheor()) {
			weightCraneBrutto = weightList.get(0).getBrutto() * packCount;
		} else {
			weightCraneBrutto = getWeightCraneBrutto();
		}

		int v = 0;
		for (Weight weight : weightList) v += weight.getPack() + weight.getTara();
		//int weightCraneNetto = weightCraneBrutto - v;
		//CodeQL requirement
		int weightCraneNetto = 0;
		if (v < Integer.MAX_VALUE)
			weightCraneNetto = weightCraneBrutto - v;

		Intent intent = new Intent(this, IncResultActivity.class);
		intent.putExtra("transportJson", transportDoc.getTransport().getJson().toString());
		intent.putExtra("ttn", transportDoc.getTtn());
		intent.putExtra("ozm", (Serializable) getCurrentOzm());
		intent.putExtra("isTheor", isTheor());
		intent.putExtra("weightCraneBrutto", weightCraneBrutto);
		intent.putExtra("weightCraneNetto", weightCraneNetto);
		intent.putExtra("packCount", packCount);
		intent.putExtra("locationCode", getLocationCode());
		intent.putParcelableArrayListExtra("weightList", new ArrayList<>(weightList));
		intent.putExtra("isNew", getIntent().getBooleanExtra("isNew", false));
		intent.putExtra("sohSmcId", sohSmcId);
		startActivityForResult(intent, REQUEST_DEFAULT);
	}

	private void buttonAcceptClick() {
		beginAccept();
	}

	private int getAnotherSmcIdCount() {
		int c = 0;
		if (adapter != null) {
			List<AdapterItemPack> list = adapter.getCurrentItems();
			for (int i = 0; i < list.size(); i++) {
				if (list.get(i).getSmcId() != null && !list.get(i).getSmcId().equalsIgnoreCase(app.getSmcIdCurrent()))
					c++;
			}
		}

		return c;
	}

	private void beginAccept() {

		if (!checkLocationPermit(getLocationCode())) return;

		if (getCurrentOzm() != null && getCurrentOzm().isManual()) {
			beginAcceptManual();
			return;
		}

		if (isVhp && !checkVhpIgnore.isChecked()) {
			double p;
			if (packCount > 1) {
				double t = getAnotherSmcIdCount();
				double c = packCount;
				p = t * 100.0 / c;
			} else {
				//1
				p = getAnotherSmcIdCount() == 1 ? 100 : 0;
			}
			if (p < 50 && packCount != 1) {
				showDialog(R.drawable.ic_error_24dp, R.string.text_error, R.string.inc_vph_50_percent_alert, null);
				return;
			}
		}

		List<Weight> weightList = getWeightList();

		int weightCraneBrutto;
		if (isTheor()) {
			weightCraneBrutto = weightList.get(0).getBrutto() * packCount;
		} else {
			weightCraneBrutto = getWeightCraneBrutto();
		}

		int v = 0;
		for (Weight weight : weightList) v += weight.getPack() + weight.getTara();
		//int weightCraneNetto = weightCraneBrutto - v;
		//CodeQL requirement
		int weightCraneNetto = 0;
		if (v < Integer.MAX_VALUE)
			weightCraneNetto = weightCraneBrutto - v;

		ArrayList<String> currentOrderListJson = new ArrayList<>();

		if (config.isAutoBatch()) {
			//Режим авторазнесения, выбираем первую партию по текущему ОЗМ
			for (int i = 0; i < packCount; i++) {
				currentOrderListJson.add(currentOrderList.get(0).getJson().toString());
			}
		} else if (isTheor()) {
			for (Order order : currentOrderList) {
				if (order.getAvailableNetto() * packCount == weightCraneNetto)
					currentOrderListJson.add(order.getJson().toString());
			}

			if (currentOrderListJson.size() < packCount) {
				showDialog(R.drawable.ic_error_24dp, R.string.text_error, getString(R.string.inc_theor_batch_small, currentOrderListJson.size()), null);
				return;
			}

		} else {
			for (Order order : currentOrderList) {
				currentOrderListJson.add(order.getJson().toString());
			}
		}

		Intent intent = new Intent(this, config.isAutoBatch() || isTheor() ? IncResultActivity.class : IncBatchActivity.class);
		intent.putExtra("transportJson", transportDoc.getTransport().getJson().toString());
		intent.putExtra("ttn", transportDoc.getTtn());
		intent.putExtra("ozm", (Serializable) getCurrentOzm());
		intent.putExtra("isTheor", isTheor());
		intent.putExtra("weightCraneBrutto", weightCraneBrutto);
		intent.putExtra("weightCraneNetto", weightCraneNetto);
		intent.putExtra("packCount", packCount);
		intent.putExtra("locationCode", getLocationCode());
		intent.putParcelableArrayListExtra("weightList", new ArrayList<>(weightList));
		intent.putStringArrayListExtra("orderList", currentOrderListJson);
		intent.putExtra("isNew", getIntent().getBooleanExtra("isNew", false));
		intent.putExtra("sohSmcId", sohSmcId);
		startActivityForResult(intent, REQUEST_DEFAULT);
	}

	private boolean listenerEnabled = true;

	@Override
	public void onItemNettoTextChanged(int index) {
		if (!listenerEnabled) return;
		checkButtonAccept();
	}

	@Override
	public void onItemPackTextChanged(int index) {
		if (!listenerEnabled) return;

		if (index == 0) {
			log("need update pack/tara");
			fillPackTaraFromFirstItem();
		}
		checkButtonAccept();
		printItems();
	}

	private void fillPackTaraFromFirstItem() {
		if (adapter == null || adapter.getItemCount() < 2) return;

		AdapterItemPack itemFirst = adapter.getItem(0);
		if (itemFirst == null) return;

		listenerEnabled = false;

		for (int i = 1; i < adapter.getItemCount(); i++) {
			AdapterItemPack item = adapter.getItem(i);
			if (item == null) continue;
			item.setW2(itemFirst.getW2());
			item.setW3(itemFirst.getW3());

			//adapter item setEnabled false!!!
			//item.setNettoOnly(isTheor());

			//item.setListenerEnabled(false);
			adapter.updateItem(item);
			//item.setListenerEnabled(true);
		}

		handler.postDelayed(() -> listenerEnabled = true, 500);
	}

	@Override
	public void onBarcodeEvent(String barcodeData) {

		if (isLoading()) return;

		runOnUiThread(() -> {

			//processZavod("5&1&2020&2583&2&&0", 50, 5);
			//if (true) return;
			if (isTheor()) return;

			ScanItem scanItem = new ScanItem(barcodeData);
			if (!scanItem.isCorrect()) {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_label, null);
			} else if (scanItem.getType() == ScanItem.ScanItemType.SMC05 || scanItem.getType() == ScanItem.ScanItemType.SMC07) {
				String lid = getLabelIdFromUnknown(scanItem);
				if (lid == null)
					checkIsUnknown(scanItem);
				else
					beginLoadLabel(lid);
			} else if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONCODE) {
				String locationCode = scanItem.getData(0);
				setLocationCode(locationCode);
			} else if (scanItem.getType() == ScanItem.ScanItemType.KOMINMET) {
				beginLoadKominmet(scanItem);
			} else if (scanItem.getType() == ScanItem.ScanItemType.ZAPOR) {
				beginLoadZapor(scanItem);
			} else if (scanItem.getType() == ScanItem.ScanItemType.GALATI) {
				beginLoadGalati(scanItem);
			} else if (scanItem.getType() == ScanItem.ScanItemType.TRUBOSTAL) {
				beginLoadTrubostal(scanItem);
			} else if (scanItem.getType() == ScanItem.ScanItemType.ARCELOR) {
				beginLoadArcelor(scanItem);
			} else if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONID) {
				String locationId = scanItem.getData(0);
				beginLoadLocation(locationId);
			} else if (scanItem.getType() == ScanItem.ScanItemType.SMC06) {
				String labelId = scanItem.getData(0);
				beginLoadLabel(labelId);
			}

		});
	}

	private boolean checkVphZavod() {
		if (isVhp && !checkVhpIgnore.isChecked()) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_vph_no_zavod, null);
			return false;
		}

		return true;
	}

	private void beginLoadTrubostal(ScanItem scanItem) {
		if (!checkVphZavod()) return;
		try {
			int netto = 0;
			int pack = 0;
			String id = scanItem.getData(8);

			if (isIdQrExistLocal(id)) {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.inc_idqr_is_exist, null);
				return;
			}

			if (isIdQrExistDb(id)) {
				showWarningIdQrDbExist();
				return;
			}

			if (!addItem(netto, pack, "", id, null, null, null, scanItem.getLine())) {
				showWarningNotFreePos();
			}

		} catch (Exception ignored) {

		}
	}

	private void beginLoadArcelor(ScanItem scanItem) {
		if (!checkVphZavod()) return;
		try {
			int netto = 0;
			int pack = 0;
			String id = scanItem.getData(0);

			if (isIdQrExistLocal(id)) {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.inc_idqr_is_exist, null);
				return;
			}

			if (isIdQrExistDb(id)) {
				showWarningIdQrDbExist();
				return;
			}

			if (!addItem(netto, pack, "", id, null, null, null, scanItem.getLine())) {
				showWarningNotFreePos();
			}

		} catch (Exception ignored) {

		}
	}

	private void beginLoadKominmet(ScanItem scanItem) {
		if (!checkVphZavod()) return;
		try {
			//String name = scanItem.getData(12);
			int netto = (int) Math.round(Utils.parseDouble(scanItem.getData(9)) /**/ * 1000);
			int pack = 0;
			//String batchNum = scanItem.getData(3);
			String id = scanItem.getData(1);

			//String[] size = app.stringToSize(scanItem.getData(5));

			if (isIdQrExistLocal(id)) {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.inc_idqr_is_exist, null);
				return;
			}

			if (isIdQrExistDb(id)) {
				showWarningIdQrDbExist();
				return;
			}

			if (!addItem(netto, pack, "", id, null, null, null, scanItem.getLine())) {
				showWarningNotFreePos();
			}

		} catch (Exception ignored) {

		}
	}

	private void showWarningIdQrDbExist() {
		showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.inc_id_qr_in_db, null);
	}

	private void beginLoadZapor(ScanItem scanItem) {
		if (!checkVphZavod()) return;
		StringBuilder sb = new StringBuilder();
		try {

			String name = scanItem.getData(12);
			int netto = parseInt(scanItem.getData(10));
			int brutto = parseInt(scanItem.getData(11));
			int pack = brutto - netto;
			String batchNum = scanItem.getData(8);
			String id = Utils.format("%s&%s&%s&%s",
					scanItem.getData(1),
					scanItem.getData(2),
					scanItem.getData(3),
					scanItem.getData(4)
			);

			if (isIdQrExistLocal(id)) {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.inc_idqr_is_exist, null);
				return;
			}

			if (isIdQrExistDb(id)) {
				showWarningIdQrDbExist();
				return;
			}

			if (!addItem(netto, pack, "", id, null, null, null, scanItem.getLine())) {
				showWarningNotFreePos();
			}

		} catch (Exception ignored) {

		}
	}

	private void beginLoadGalati(ScanItem scanItem) {
		if (!checkVphZavod()) return;
		//StringBuilder sb = new StringBuilder();
		try {
			String [] data = new String[4];
			int netto = 0, thickness = 0, width = 0, length = 0, pack = 0;
			String idQr = "";
			String idGalati = "";

			for (int i = 0; i < scanItem.getData().length ; i++) {

				if (scanItem.getData(i).toLowerCase().contains("gal")) {
					String[] codeGal = scanItem.getData(i).split(" ");
					if (codeGal.length > 2) {
						idGalati = codeGal[2];
					}
				}

				if (scanItem.getData(i).toLowerCase().contains("id")) {
					String[] id = scanItem.getData(i).split(" ");
					if (id.length > 4) {
						data = new String[id.length - 1];
						System.arraycopy(id, 1, data, 0, id.length - 1);
					}
				}

				if (scanItem.getData(i).toLowerCase().contains("COIL/PACK")) {
					String[] coil = scanItem.getData(i).split(" ");
					if (coil.length > 4) {
						data = new String[2];
						data[0] = coil[3];
						data[1] = coil[5];
					}
				}

				if (scanItem.getData(i).toLowerCase().contains("size")) {
					String[] size = scanItem.getData(i).split(" ");
					if (size.length > 1 && size[1].split("x").length == 3) {
						thickness = parseInt(size[1].split("x")[0]);
						width = parseInt(size[1].split("x")[1]);
						length = parseInt(size[1].split("x")[2]);
					}
				}

				if (scanItem.getData(i).toLowerCase().contains("net")) {
					String[] nettoStr = scanItem.getData(i).split(" ");
					if (nettoStr.length > 2) {
						netto = parseInt(nettoStr[2]);
					}
				}
			}

			for (int i = 0; i < data.length ; i++) {
			if (i == data.length - 1)
				idQr = idQr + parseInt(data[i]);
			else
				idQr = idQr + parseInt(data[i]) + "/";
			}
			/*Utils.format("%s&%s&%s&%s",
					scanItem.getData(1),
					scanItem.getData(2),
					scanItem.getData(3),
					scanItem.getData(4)
			);*/

			if (isIdQrExistLocal(idQr)) {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.inc_idqr_is_exist, null);
				return;
			}

			if (isIdQrExistDb(idQr)) {
				showWarningIdQrDbExist();
				return;
			}

			if (!addItem(netto, pack, "", idQr, null, null, null, scanItem.getLine())) {
				showWarningNotFreePos();
			}

		} catch (Exception ignored) {

		}
	}

	private void showWarningNotFreePos() {
		showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.inc_not_free_pos, null);
	}

	private void beginLoadLabel(String labelId) {

		if (isLabelScanned(labelId) || isLabelScannedAll(labelId)) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.inc_id_label_in_db, null);
			return;
		}

		log("PROCESS LABEL #%s", labelId);

		showLoading(R.string.text_please_wait);

		Utils.runOnBackground(() -> {

			Label label = null;

			String url = config.getUrlApi() + "getlabelinfo";
			url = net.addUrlParam(url, "label_id", labelId);
			url = net.addUrlParam(url, "smc_id", "NULL");
			JsonResult result = net.downloadJson(url);

			if (result.isOk()) {
				//GET LABEL
				JSONObject json = Utils.getJsonObject(result.getJson(), "data");
				label = Label.fromJson(json, labelId);
				if (label != null) {
					//GET LOCATION CODE
					url = config.getUrlApi() + "getlocationcode";
					url = net.addUrlParam(url, "location_id", label.getLocationId());
					result = net.downloadJson(url);
					if (result.isOk()) {
						json = Utils.getJsonObject(result.getJson(), "data");
						String locationCode = Utils.getJsonStringIgnoreCase(json, "location_code");
						label.setLocationCode(locationCode);

						if (!label.getSmcId().equals(app.getSmcIdCurrent())) {
							//GET SHIPPED INFO
							url = config.getUrlApi() + "getshippedinfo";
							url = net.addUrlParam(url, "label_id", labelId);
							url = net.addUrlParam(url, "TTN_NUM", transportDoc.getTtn().getNum());

							result = net.downloadJson(url);

							if (result.isOk()) {
								result.setStatus(LoadResultStatus.ZERO);
								JSONArray jsonArray = Utils.getJsonArray(result.getJson(), "data");
								if (jsonArray != null) {
									if (jsonArray.length() > 0) {
										JSONObject jItem = Utils.getJsonObject(jsonArray, 0);
										if (jItem != null) {
											int mengeBirk = Utils.getJsonWeightKgIgnoreCase(jItem, "mengE_BIRK");
											label.setWeightNetto(mengeBirk);
											result.setStatus(LoadResultStatus.OK);
										}
									}
								}
							}
						}
					} else {
						label = null;
					}
				}
			}

			JsonResult finalResult = result;
			Label finalLabel = label;
			runOnUiThread(() -> endLoadLabel(finalResult, labelId, finalLabel));
		});

	}

	private void endLoadLabel(JsonResult result, String labelId, Label label) {
		hideLoading();

		if (result.isOk() && label != null) {
			addLabel(label);
		} else if (result.getStatus() == LoadResultStatus.ZERO) {
			if (label != null && !label.getSmcId().equals(app.getSmcIdCurrent())) {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.label_id_not_found_shipped, transportDoc.getTtn().getNum()), null);
			} else {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_id_not_found, null);
			}
		} else {
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoadLabel(labelId));
		}
	}

	private void addLabel(Label label) {

		if (label.isTemp()) {
			processUnknown(label);
			return;
		}

		if (label.getOzm().length() > 0) {

			if (findOzm(label.getOzm(), label.getWidth(), label.getLength(), label.getThickness()) == null) {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.error_ship_ozm_not_found, label.getOzm()), null);
				return;
			}

			for (int i = 0; i < ozmList.size(); i++) {
				if (ozmList.get(i).getOzm().equals(label.getOzm())) {
					spinnerName.setSelection(i);
					break;
				}
			}
		}

		//Мой SMC_ID
		if (label.getSmcId().equals(app.getSmcIdCurrent())) {
			if (!addItem(label.getWeightNetto(), label.getWeightPack(), label.getBatch().equalsIgnoreCase("TEMP") ? label.getId() : "", "", null, label.getBatch(), label.getId())) {
				showWarningNotFreePos();
			}
			//Чужой SMC_ID
		} else {
			if (!addItem(label.getWeightNetto(), label.getWeightPack(), "", label.getId(), label.getSmcId(), label.getBatch(), label.getId())) {
				showWarningNotFreePos();
			}
		}
	}

	private int getFreeItem() {
		List<AdapterItemPack> items = adapter.getCurrentItems();
		for (int i = 0; i < items.size(); i++) {
			if (items.get(i).isEmpty()) return items.get(i).getIndex();
		}
		return -1;
	}

	private boolean isIdQrExistDb(String idQr) {

		if (BuildConfig.DEBUG) {
			return false;
		}

		try {
			return db.idQrStoreDao().getByName(idQr) != null;
		} catch (Exception ignored) {
			return false;
		}
	}

	private boolean isIdQrExistLocal(String idQr) {
		List<AdapterItemPack> items = adapter.getCurrentItems();
		for (int i = 0; i < items.size(); i++) {
			if (items.get(i).getIdQr().equalsIgnoreCase(idQr)) return true;
		}
		return false;
	}

	private boolean addItem(int netto, int pack, String labelId, String idQr, String smcId, String batch, String scanLabelId) {
		return addItem(netto, pack, labelId, idQr, smcId, batch, scanLabelId, null);
	}

	private boolean addItem(int netto, int pack, String labelId, String idQr, String smcId, String batch, String scanLabelId, String barcode) {
		log("addItem(%d, %d, %s, %s, %s, %s)", netto, pack, labelId, idQr, batch, scanLabelId);

		if (packCount == 0) return false;

		int index = getFreeItem();
		if (index == -1) return false;

		AdapterItemPack item = getItemByIndex(index);
		if (item == null) return false;

		item.setW1(netto);
		item.setW2(pack);
		item.setW3(0);
		item.setLabelId(labelId);
		item.setIdQr(idQr);
		item.setSmcId(smcId == null ? app.getSmcIdCurrent() : smcId);
		item.setBatch(batch);
		item.setScanLabelId(scanLabelId);
		item.setBarcode(barcode);
		item.setNettoOnly(isTheor());
		adapter.updateItem(item);
		printItems();

		checkButtonAccept();

		return true;
	}

	@Override
	protected void onIsUnknown(ScanItem scanItem, boolean unknown, Label label) {
		if (unknown) {
			processUnknown(scanItem, scanItem.getType() == ScanItem.ScanItemType.SMC07, label);
		} else {
			showWarningNotUnknown(label.getId());
		}
	}

	private void showWarningNotUnknown(String labelId) {
		showDialogConfirm(R.string.text_warning, R.string.unknown_is_constant, (dialog, which) -> beginPrint(labelId));
	}

	private void processUnknown(Label label) {
		if (label != null && label.getOzm().length() > 0) {
			Ozm ozm = findOzm(label.getOzm(), label.getWidth(), label.getLength(), label.getThickness());
			if (ozm != null) {
				for (int i = 0; i < ozmList.size(); i++) {
					if (ozmList.get(i).getOzm().equals(label.getOzm())) {
						spinnerName.setSelection(i);
						break;
					}
				}
			}
		}

		ArrayList<Weight> weightListTemp = new ArrayList<>();
		int totalNetto = 0;
		int weightCraneBrutto = 0;

		Weight w = new Weight(
				label.getWeightNetto(),
				label.getWeightPack(), 0, label.getId(),
				"", "", "", ""
		);
		weightListTemp.add(w);
		totalNetto += w.getNetto();
		weightCraneBrutto += label.getWeightNetto() + label.getWeightPack();

		if (totalNetto > 0) {
			boolean res = true;

			for (Weight weight : weightListTemp) {
				res = addItem(weight.getNetto(), weight.getPack(), weight.getId().equalsIgnoreCase("0") ? "" : weight.getId(), "", null, null, null);
				if (!res) break;
			}

			if (res) {
				setWeightCraneBrutto(weightCraneBrutto);
				if (app.isLocationCorrect(label.getLocationCode()))
					setLocationCode(label.getLocationCode());
			} else {
				showWarningNotFreePos();
			}
		} else {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_netto_zero, null);
		}
	}

	private void processUnknown(ScanItem scanItem, boolean isNew, Label label) {
		String locationCode = scanItem.getData(5);
		int weightCraneBrutto = parseInt(scanItem.getData(0));
		int newPackCount = parseInt(scanItem.getData(1));

		JSONArray array = Utils.getJsonArray(scanItem.getData(2));
		if (array == null) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_error_scan_item, null);
		} else {

			if (label != null && label.getOzm().length() > 0) {
				Ozm ozm = findOzm(label.getOzm(), label.getWidth(), label.getLength(), label.getThickness());
				if (ozm == null) {
					//showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.error_ship_ozm_not_found, label.getOzm()), null);
					//return;
				} else {
					for (int i = 0; i < ozmList.size(); i++) {
						if (ozmList.get(i).getOzm().equals(label.getOzm())) {
							spinnerName.setSelection(i);
							break;
						}
					}
				}
			}

			//loadAdapter();
			//packCount = 0;

			ArrayList<Weight> weightListTemp = new ArrayList<>();
			int totalNetto = 0;

			for (int i = 0; i < newPackCount; i++) {
				JSONObject object = Utils.getJsonObject(array, i);
				Weight w = new Weight(
						label != null ? label.getWeightNetto() : Utils.getJsonIntIgnoreCase(object, "netto"),
						Utils.getJsonIntIgnoreCase(object, "pack"),
						Utils.getJsonIntIgnoreCase(object, "tara"),
						Utils.getJsonStringIgnoreCase(object, "id"),
						"", "", "", ""
				);
				weightListTemp.add(w);
				totalNetto += w.getNetto();

				if (!isNew && i == 0) {
					weightCraneBrutto += weightListTemp.get(0).getPack() + weightListTemp.get(0).getTara();
				}
			}

			if (totalNetto > 0) {
				boolean res = true;

				for (Weight weight : weightListTemp) {
					res = addItem(weight.getNetto(), weight.getPack(), weight.getId().equalsIgnoreCase("0") ? "" : weight.getId(), "", null, null, null);
					if (!res) break;
				}

				if (res) {
					setWeightCraneBrutto(weightCraneBrutto);
					if (app.isLocationCorrect(locationCode)) setLocationCode(locationCode);
				} else {
					showWarningNotFreePos();
				}
			} else {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_netto_zero, null);
			}
		}
	}

	private Order findByIdQr(String idQr) {

		if (currentOrderList == null) return null;

		for (Order order : currentOrderList) {
			if (order.getIdQr().equalsIgnoreCase(idQr)) {
				return order;
			}
		}

		return null;
	}

	private Ozm findOzm(String sapOzm, float width, float length, float thickness) {
		for (Ozm ozm : ozmList) {
			if (ozm.getOzm().equalsIgnoreCase(sapOzm)) return ozm;
		}
		return null;
	}

	private void beginLoadLocation(String locationId) {
		showLoading(R.string.text_please_wait);

		Utils.runOnBackground(() -> {
			String locationCode = net.getLocationCode(locationId);

			runOnUiThread(() -> {
				if (locationCode == null) {
					showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_location_label, null);
				} else {
					setLocationCode(locationCode);
				}
			});

		});
	}

	private void setLocationCode(String locationCode) {
		if (app.isLocationCorrect(locationCode)) {
			String[] arr = app.fixLocation(locationCode).split("-");
			for (int i = 0; i < 3; i++)
				textLocation[i].setText(arr[i]);
		} else {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_error_location_incorrect, null);
		}
	}

	private void openNewOzm() {
		Intent intent = new Intent(this, IncNewOzmActivity.class);
		intent.putExtra("transportJson", transportDoc.getTransport().getJson().toString());
		intent.putExtra("ttn", transportDoc.getTtn());
		intent.putExtra("isNew", getIntent().getBooleanExtra("isNew", false));
		startActivityForResult(intent, REQUEST_ADD);
	}

	private void addOzm(String name, int length, int width, int thickness) {
		log("addOzm(\"%s\", %d, %d, %d)", name, length, width, thickness);
		Ozm ozm = new Ozm("", name, width, length, thickness);
		ozm.setManual(true);
		ozmList.add(ozm);
		ozmListUser.add(ozm);
		loadNameList();

		for (int i = 0; i < ozmList.size(); i++) {
			if (ozmList.get(i).getName().equalsIgnoreCase(ozm.getName())) {
				spinnerName.setSelection(i);
				break;
			}
		}
	}

	@Override
	protected void onCraneWeight(long craneId, int value) {
		setWeightCraneBrutto(value);
	}

	@Override
	protected void onScalesWeight(ScalesConfig scales, long value) {
		setWeightCraneBrutto(value);
	}

	private void saveCurrentOzm() {
		Ozm ozm = getCurrentOzm();

		config.setCurrentOzm(ozm);
		config.saveConfig();
		log("save ozm %s", ozm == null ? "null" : ozm.toString());
	}

	private void loadCurrentOzm() {

		if (ozmList == null || ozmList.isEmpty()) return;

		Ozm ozm = config.getCurrentOzm();
		log("load ozm %s", ozm == null ? "null" : ozm.toString());

		if (ozm == null) return;

		for (int i = 0; i < ozmList.size(); i++) {
			if (ozmList.get(i).equals(ozm)) {
				spinnerName.setSelection(i);
				break;
			}
		}
	}

	private void beginPrint(String labelId) {

		showLoading(R.string.text_printing_title);

		Utils.runOnBackground(() -> {
			Utils.NetworkPrintResult result = Utils.printLabel(labelId);
			runOnUiThread(() -> endPrint(result, labelId));
		});
	}

	private void endPrint(Utils.NetworkPrintResult result, String labelId) {

		hideLoading();

		if (result.getNetworkResult().isOk()) {

			if (result.getPrintResult().getStatus() == Printer.PrintResultStatus.OK) {
				showDialog(R.drawable.ic_info_24dp, R.string.text_information, R.string.text_print_result_succeeded, null).setCanceledOnTouchOutside(false);
				//app.sendFaPrint();
			} else {
				final int message = app.getPrintResultMessage(result.getPrintResult());
				showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> beginPrint(labelId));
			}

		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result.getNetworkResult()), (dialog, which) -> beginPrint(labelId));
		}

	}
}
