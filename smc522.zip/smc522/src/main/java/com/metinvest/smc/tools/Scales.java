package com.metinvest.smc.tools;

import static com.metinvest.smc.tools.Utils.parsePasswordScales;

import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.nfc.NdefRecord;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.metinvest.smc.App;
import com.metinvest.smc.db.Db;
import com.metinvest.smc.db.Dpl;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Calendar;
import java.util.UUID;

public class Scales {

    private static final String className = "Scales";
    public static final char[] weightCommand = {0x02};
    public static final char[] testCommand = {0x01};
    public static final char[] zeroCommand = {0x07};
	/*public static ScalesResult sendCommand(ScalesConfig scales, @NonNull String data) {
		return sendCommand(scales, data, false);
	}

	public static ScalesResult sendCommand(ScalesConfig scales, @NonNull String data, boolean checkStatus) {
		if (scales.getName() != null) addHistory(scales.getName(), data);

		for (int i = 0; i < data.length(); i += 4000) {
			String line = data.substring(i, Math.min(i + 4000, data.length()));
			App.getInstance().log(className, "\n" + line);
		}

		return sendCommand(scales, data.getBytes(StandardCharsets.UTF_8), checkStatus);
	}*/

    public static void addHistory(String name, String data) {
        Db db = App.getInstance().getDb();
        if (db != null && data != null) {

            Dpl last = db.dplDao().getLast();
            if (last != null && last.getData() != null && last.getData().equals(data)) return;

            try {
                long date = Calendar.getInstance().getTime().getTime();
                Dpl dpl = new Dpl(0, date, name, data);
                db.dplDao().insert(dpl);
                App.getInstance().log(className, "addHistory(%s)", name);
            } catch (Exception e) {
                App.getInstance().log(className, e, "db.dplDao().insert()");
            } finally {
                try {
                    db.dplDao().deleteOld();
                } catch (Exception e) {
                    App.getInstance().log(className, e, "db.dplDao().deleteOld()");
                }
            }
        }
    }

    public static ScalesResult sendCommand(ScalesConfig scales, byte cmd, boolean checkStatus) {

        //Utils.sleep(1000);

        /*if (checkStatus) {
            ScalesResult result = sendCommand(scales, new char[]{0x01} *//*(char) 0 + "1"*//*, false);

            App.getInstance().log(className, "Scales status: %s", result.getDataString(data.length).length() > 0 ? result.getData() : "null");

            if (result.getStatus() != ScalesResultStatus.OK) {
                return result;
            }
        }*/

        if (scales == null || scales.getMac().length() == 0) {
            return new ScalesResult(ScalesResultStatus.ERROR_NO_SCALES);
        }

        if (scales == null || scales.getName().length() < 4) {
            return new ScalesResult(ScalesResultStatus.ERROR_PASSWORD);
        }

        if (!App.getInstance().bluetoothOn()) {
            return new ScalesResult(ScalesResultStatus.ERROR_BLUETOOTH_OFF);
        }

        if (App.getInstance().getBluetoothAdapter() == null) {
            return new ScalesResult(ScalesResultStatus.ERROR_BLUETOOTH_ADAPTER_NULL);
        }

        BluetoothDevice device;
        char[] data;
        if (checkStatus == true) {
            data = testCommand;
        } else {
            if (cmd == (byte) 7)
                data = zeroCommand;
            else
                data = weightCommand;
        }

        try {
            device = App.getInstance().getBluetoothAdapter().getRemoteDevice(scales.getMac());
        } catch (Exception e) {
            App.getInstance().log(className, e, "getRemoteDevice(%s)", scales.getMac());
            return new ScalesResult(ScalesResultStatus.ERROR_BLUETOOTH_MAC_INVALID);
        }

        UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
        final BluetoothSocket socket;

        try {
            //socket = device.createRfcommSocketToServiceRecord(uuid);
            if (ActivityCompat.checkSelfPermission(App.getInstance().getActivity(), Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                //return TODO;
            }
            socket = device.createInsecureRfcommSocketToServiceRecord(uuid);
        } catch (Exception e) {
            App.getInstance().log(className, e, "createInsecureRfcommSocketToServiceRecord(%s)", uuid);
            return new ScalesResult(ScalesResultStatus.ERROR_BLUETOOTH_CONNECTION_ERROR);
        }

        if (!socket.isConnected()) {

            try {
                socket.connect();
            } catch (Exception ignored) {
                Utils.sleep(1000);
                try {
                    socket.connect();
                } catch (Exception e) {
                    App.getInstance().log(className, e, "socket.connect()");
                    return new ScalesResult(ScalesResultStatus.ERROR_SOCKET_CONNECT);
                }
            }

            long t = System.currentTimeMillis();

            while (!socket.isConnected() && System.currentTimeMillis() - t < 3000) {
                Utils.sleep(10);
            }

            if (!socket.isConnected())
                return new ScalesResult(ScalesResultStatus.ERROR_SOCKET_CONNECT);
        }

        OutputStream out;

        try {
            out = socket.getOutputStream();
        } catch (Exception e) {
            App.getInstance().log(className, e, "socket.getOutputStream()");
            return new ScalesResult(ScalesResultStatus.ERROR_SOCKET_STREAM);
        }

        InputStream in = null;

        try {
            in = socket.getInputStream();
        } catch (Exception ignored) {
        }

        String resultMessage = "";

        try {
            //out.write(data);
            out.write(String.valueOf(data).getBytes());

            if (in != null) {

                Utils.sleep(3000);

                try {
                    int n = in.available();

                    if (n > 0) {
                        boolean cond = true;
                        while (cond) {
                            //byte[] buffer = new byte[n];
                            byte[] buffer = new byte[1024];
                            int bytes = in.read(buffer);
                            // If no byte is available because the stream is at
                            // the end of the file, the value -1 is returned;
                            if (bytes == -1) {
                                break;
                            }
                            resultMessage = new String(buffer, 0, bytes);
                            if (resultMessage.contains("password")) {
                                out.write(parsePasswordScales(String.valueOf(scales.getName())).getBytes());
                            } else if (resultMessage.contains("successful")) {
                                if (cmd == (byte) 7){
                                    for (int i = 0; i < zeroCommand.length; i++) {
                                        out.write(String.valueOf(zeroCommand[i]).getBytes());
                                    }
                                } else {
                                    for (int i = 0; i < weightCommand.length; i++) {
                                        out.write(String.valueOf(weightCommand[i]).getBytes());
                                    }
                                }
                                Thread.sleep(3000); // если быстро читать ответ возвращается например [2, 1, 116, 104, 101, 110, 116, 105, 99, 97, 116, ...
                            } else if (resultMessage.length() > 9) {
                                cond = false;
                                return new ScalesResult(ScalesResultStatus.OK, buffer);
                                //App.getInstance().log(App.getInstance(), resultMessage);
                            } else {
                                cond = false;
                                return new ScalesResult(ScalesResultStatus.ERROR_DATA_EMPTY, buffer);
                            }
                        }
                    }
                } catch (Exception ignored) {
                }
            }
        } catch (Exception e) {
            App.getInstance().log(className, e, "socket.write()");
            return new ScalesResult(ScalesResultStatus.ERROR_SOCKET_WRITE);
        } finally {
            try {
                socket.close();
            } catch (Exception ignored) {

            }
        }
        return null; //new ScalesResult(ScalesResultStatus.OK, resultMessage);
    }

    public enum ScalesResultStatus {
        ERROR_NO_SCALES,
        ERROR_BLUETOOTH_OFF,
        ERROR_BLUETOOTH_ADAPTER_NULL,
        ERROR_BLUETOOTH_MAC_INVALID,
        ERROR_BLUETOOTH_CONNECTION_ERROR,
        ERROR_SOCKET_CONNECT,
        ERROR_SOCKET_STREAM,
        ERROR_SOCKET_WRITE,
        ERROR_DATA_EMPTY,
        ERROR_PASSWORD,
        OK
    }

    public static class ScalesResult {
        private ScalesResultStatus status;
        private byte[] data;
        private DataSetResult scalesResult;

        public ScalesResult(ScalesResultStatus status, byte[] data) {
            this.status = status;
            this.data = data;
        }

        public ScalesResult(ScalesResultStatus status) {
            this.status = status;
            //this.data = new byte[1024];
        }

        public ScalesResultStatus getStatus() {
            return status;
        }

        public byte[] getData() {
            return data;
        }

        public String getDataString(int bytes) {
            return new String(data, 0, bytes);
        }

        public DataSetResult getScalesResult() {
            scalesResult = new DataSetResult();
            if (data != null && data.length > 0) {
                Boolean signPlas = null;
                byte[] weight, temperature, accum;
                int pos = -1;
                //int pos = 0;
                for (int i = 0; i < data.length; i++) {
                    if (data[i] == (byte) weightCommand[0]) {
                        pos = i;
                        break;
                    }
                    if (data[i] == (byte) testCommand[0]) {
                        pos = i;
                        break;
                    }
                    if (data[i] == (byte) zeroCommand[0]) {
                        pos = i;
                        break;
                    }
                }
                signPlas = true;
                if (pos == -1 || pos + 10 > data.length) {

                    //scalesResult.status = "pos="+pos+" len="+data.length+" data="+data.toString();
                    scalesResult.status = "pos="+pos+" len="+data.length+" data="+getDataString(1024);

                } else /*{
                    if (data[pos + 1] == 0x01) signPlas = true;
                    else if (data[pos + 1] == 0x00) signPlas = false;
                    else scalesResult.status = "sign undefined";
                }*/
                if (scalesResult.status == "") {
                    weight = Arrays.copyOfRange(data, pos + 2, pos + 6);
                    temperature = Arrays.copyOfRange(data, pos + 6, pos + 8);
                    accum = Arrays.copyOfRange(data, pos + 8, pos + 10);

                    ByteBuffer buffer = ByteBuffer.allocate(Integer.BYTES);

                    buffer.put(weight);
                    buffer.rewind();
                    int value = buffer.getInt();
                    int reverse = Integer.reverseBytes(value);

                    scalesResult.weight = (signPlas ? reverse : -1 * reverse);

                    buffer.clear();
                    buffer.put(temperature);
                    buffer.rewind();
                    value = buffer.getInt();
                    reverse = Integer.reverseBytes(value);
                    scalesResult.temperature = (short) reverse;

                    buffer.clear();
                    buffer.put(accum);
                    buffer.rewind();
                    value = buffer.getInt();
                    reverse = Integer.reverseBytes(value);
                    scalesResult.accum = (short) reverse;

                    scalesResult.status = "weight = " + scalesResult.weight + " temp = " + scalesResult.temperature + " accum = " + scalesResult.accum + " pos= " + pos;
                }
            } else {
                scalesResult.status = "data = null";
            }
            return scalesResult;
        }

        @NonNull
        @Override
        public String toString() {
            return Utils.format("[%s] %s", getStatus(), getData());
        }

        public class DataSetResult {
            long weight;
            short temperature;
            short accum;
            String status;

            public DataSetResult() {
                this.weight = 0;
                this.temperature = 0;
                this.accum = 0;
                this.status = "";
            }

            public long getWeight() {
                return weight;
            }

            public short getTemperature() {
                return temperature;
            }

            public short getAccum() {
                return accum;
            }

            public String getStatus() {
                return status;
            }
        }
    }

    public static ScalesConfig detectScales(NFC nfc) {

        String scalesMac = null, scalesName = null;

        for (NdefRecord record : nfc.getRecords()) {

            Uri uri = record.toUri();
            if (uri != null && uri.getHost() != null && uri.getHost().toLowerCase().contains("vis-rkm")) {
                scalesMac = uri.getQueryParameter("mBL");
                if (scalesMac == null) {
                    scalesMac = uri.getQueryParameter("mB");
                }
                scalesName = uri.getQueryParameter("name");
                if (scalesMac != null && scalesName != null) {
                    return new ScalesConfig(scalesName, scalesMac.toUpperCase());
                } else {
                    return null;
                }
            }

            String type = record.toMimeType() == null ? "" : record.toMimeType();

            if (type.equals("application/vnd.bluetooth.ep.oob")) {
                byte[] payload = record.getPayload();
                if (payload != null && payload.length >= 6) {
                    payload = Utils.reverse(new byte[]{payload[2], payload[3], payload[4], payload[5], payload[6], payload[7]});
                    scalesMac = Utils.formatMacAddress(payload);
                }
            }

            if (type.equals("text/plain")) {
                try {
                    byte[] payload = record.getPayload();
                    if (payload != null && payload.length > 1) {
                        String textEncoding = ((payload[0] & 0200) == 0) ? "UTF-8" : "UTF-16";
                        int languageCodeLength = payload[0] & 0077;
                        String languageCode = new String(payload, 1, languageCodeLength, StandardCharsets.US_ASCII);

                        payload = Arrays.copyOfRange(payload, languageCodeLength + 1, payload.length - languageCodeLength - 1);

                        String text =
                                new String(payload, languageCodeLength + 1,
                                        payload.length - languageCodeLength - 1, textEncoding).trim();

                        if (text.length() > 0) {

                            if (text.charAt(0) == 'w') {

                                String[] s = text.split(String.valueOf((char) 65533));
                                int i = s[0].trim().lastIndexOf('\u0000');

                                scalesName = s[0].trim().substring(i + 1);
                            }

                        }
                    }
                } catch (Exception ignored) {

                }
            }

        }

        if (scalesName != null && scalesMac != null && scalesName.length() > 0 && scalesMac.length() > 0)
            return new ScalesConfig(scalesName, scalesMac);
        else
            return null;
    }
}
