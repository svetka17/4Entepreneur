package com.metinvest.smc.scanner;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import com.metinvest.smc.App;
import com.metinvest.smc.tools.Utils;

import java.util.ArrayList;
import java.util.Set;

public class BarcodeZebra {

/*
    <string name="activity_intent_filter_action">com.sytecs.barcode.ACTION</string>
    <string name="activity_action_from_service">com.zebra.datacapture1.service.ACTION</string>
    <string name="datawedge_intent_key_source">com.symbol.datawedge.source</string>
    <string name="datawedge_intent_key_label_type">com.symbol.datawedge.label_type</string>
    <string name="datawedge_intent_key_data">com.symbol.datawedge.data_string</string>
    <string name="datawedge_intent_key_source_legacy">com.motorolasolutions.emdk.datawedge.source</string>
    <string name="datawedge_intent_key_label_type_legacy">com.motorolasolutions.emdk.datawedge.label_type</string>
    <string name="datawedge_intent_key_data_legacy">com.motorolasolutions.emdk.datawedge.data_string</string>
 */

	private static final String ACTIVITY_INTENT_FILTER_ACTION = "com.metinvest.barcode.ACTION";
	private static final String ACTIVITY_ACTION_FROM_SERVICE = "com.zebra.datacapture1.service.ACTION";
	private static final String DATAWEDGE_INTENT_KEY_SOURCE = "com.symbol.datawedge.source";
	private static final String DATAWEDGE_INTENT_KEY_LABEL_TYPE = "com.symbol.datawedge.label_type";
	private static final String DATAWEDGE_INTENT_KEY_DATA = "com.symbol.datawedge.data_string";
	private static final String DATAWEDGE_INTENT_KEY_SOURCE_LEGACY = "com.motorolasolutions.emdk.datawedge.source";
	private static final String DATAWEDGE_INTENT_KEY_LABEL_TYPE_LEGACY = "com.motorolasolutions.emdk.datawedge.label_type";
	private static final String DATAWEDGE_INTENT_KEY_DATA_LEGACY = "com.motorolasolutions.emdk.datawedge.data_string";


	private static final String ACTION_RESULT_NOTIFICATION = "com.symbol.datawedge.api.NOTIFICATION_ACTION";
	private static final String ACTION_RESULT = "com.symbol.datawedge.api.RESULT_ACTION";
	private static final String ACTION_DATA_WEDGE = "com.symbol.datawedge.api.ACTION";
	private static final String EXTRA_PROFILE_NAME = App.getInstance().getPackageName();
	private static final String EXTRA_SET_CONFIG = "com.symbol.datawedge.api.SET_CONFIG";
	private static final String EXTRA_CREATE_PROFILE = "com.symbol.datawedge.api.CREATE_PROFILE";

	private final App app;

	private final IntentFilter filterScan;

	private final BroadcastReceiver scanReceiver;

	public BarcodeZebra(App app) {
		this.app = app;

		this.app.log(this, "()");

		filterScan = new IntentFilter();
		filterScan.addCategory(Intent.CATEGORY_DEFAULT);
		filterScan.addAction(ACTIVITY_INTENT_FILTER_ACTION);

		filterScan.addAction(ACTIVITY_ACTION_FROM_SERVICE);
		filterScan.addAction(ACTION_RESULT_NOTIFICATION);   // for notification result
		filterScan.addAction(ACTION_RESULT);                // for error code result

		scanReceiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {

				String action = intent.getAction();
				if (action == null) return;

				if (action.equalsIgnoreCase(ACTION_RESULT)) {
					//app.log(this, "onDataWedgeReceive %s", intent.toString());

					String command = intent.getStringExtra("COMMAND");
					String commandIdentifier = intent.getStringExtra("COMMAND_IDENTIFIER");
					String result = intent.getStringExtra("RESULT");

					Bundle bundle;
					StringBuilder sb = new StringBuilder();
					if (intent.hasExtra("RESULT_INFO")) {
						bundle = intent.getBundleExtra("RESULT_INFO");
						if (bundle != null) {
							Set<String> keys = bundle.keySet();
							for (String key : keys) {
								sb.append(Utils.format("%s: %s; ", key, bundle.getString(key)));
							}
						}
					}

					//String text = "Command: " + command + ", " + "Result: " + result + ", " + "Result Info: " + sb.toString() + ", " + "CID:" + commandIdentifier;
					//app.log(this, text);

				}

				if (action.equalsIgnoreCase(ACTIVITY_INTENT_FILTER_ACTION)) {

					//app.log(this, "onScanReceive %s", intent.toString());

					//  Received a barcode scan
					try {
						displayScanResult(intent);
					} catch (Exception e) {
						//  Catch if the UI does not exist when we receive the broadcast... this is not designed to be a production app
					}
				}

			}
		};
	}

	public void setTriggerState(Activity activity, boolean enable) {
		if (enable) {
			// define action and data strings
			String softScanTrigger = "com.symbol.datawedge.api.ACTION";
			String extraData = "com.symbol.datawedge.api.SOFT_SCAN_TRIGGER";

			// create the intent
			Intent i = new Intent();

			// set the action to perform
			i.setAction(softScanTrigger);

			// add additional info
			i.putExtra(extraData, "START_SCANNING");

			// send the intent to DataWedge
			activity.sendBroadcast(i);
		} else {
			// define action and data strings
			String softScanTrigger = "com.symbol.datawedge.api.ACTION";
			String extraData = "com.symbol.datawedge.api.SOFT_SCAN_TRIGGER";

			// create the intent
			Intent i = new Intent();

			// set the action to perform
			i.setAction(softScanTrigger);

			// add additional info
			i.putExtra(extraData, "STOP_SCANNING");

			// send the intent to DataWedge
			activity.sendBroadcast(i);
		}
	}

	private void createProfile() {
		//this.app.log(this, "createProfile()");

		//CREATE PROFILE
		sendDataWedgeIntentWithExtra(ACTION_DATA_WEDGE, EXTRA_CREATE_PROFILE, EXTRA_PROFILE_NAME);

		// Configure created profile to apply to this app
		Bundle profileConfig = new Bundle();
		profileConfig.putString("PROFILE_NAME", EXTRA_PROFILE_NAME);
		profileConfig.putString("PROFILE_ENABLED", "true");
		profileConfig.putString("CONFIG_MODE", "OVERWRITE");

		// Configure barcode input plugin
		Bundle barcodeConfig = new Bundle();
		barcodeConfig.putString("PLUGIN_NAME", "BARCODE");
		barcodeConfig.putString("RESET_CONFIG", "true"); //  This is the default
		Bundle barcodeProps = new Bundle();
		barcodeConfig.putBundle("PARAM_LIST", barcodeProps);
		profileConfig.putBundle("PLUGIN_CONFIG", barcodeConfig);

		// Associate profile with this app
		Bundle appConfig = new Bundle();
		appConfig.putString("PACKAGE_NAME", app.getPackageName());
		appConfig.putStringArray("ACTIVITY_LIST", new String[]{"*"});
		profileConfig.putParcelableArray("APP_LIST", new Bundle[]{appConfig});
		profileConfig.remove("PLUGIN_CONFIG");

		Bundle bundleKSOutConfig = new Bundle();
		bundleKSOutConfig.putString("PLUGIN_NAME", "KEYSTROKE");
		bundleKSOutConfig.putString("RESET_CONFIG", "false");
		Bundle bundleKSParams = new Bundle();
		bundleKSParams.putString("keystroke_output_enabled", "false");
		bundleKSOutConfig.putBundle("PARAM_LIST", bundleKSParams);

		// Configure intent output for captured data to be sent to this app
		Bundle intentConfig = new Bundle();
		intentConfig.putString("PLUGIN_NAME", "INTENT");
		intentConfig.putString("RESET_CONFIG", "true");
		Bundle intentProps = new Bundle();

		intentProps.putString("intent_output_enabled", "true");
		intentProps.putString("intent_action", ACTIVITY_INTENT_FILTER_ACTION);
		intentProps.putString("intent_delivery", "2");

		// Add each bundle to the profile configuration
		ArrayList<Bundle> bundlePluginConfig = new ArrayList<>();
		bundlePluginConfig.add(barcodeConfig);
		bundlePluginConfig.add(intentConfig);
		bundlePluginConfig.add(bundleKSOutConfig);

		intentConfig.putBundle("PARAM_LIST", intentProps);
		profileConfig.putParcelableArrayList("PLUGIN_CONFIG", bundlePluginConfig);
		sendDataWedgeIntentWithExtra(ACTION_DATA_WEDGE, EXTRA_SET_CONFIG, profileConfig);
	}

	private void displayScanResult(Intent intent) {

		String decodedSource = intent.getStringExtra(DATAWEDGE_INTENT_KEY_SOURCE);
		String decodedData = intent.getStringExtra(DATAWEDGE_INTENT_KEY_DATA);
		String decodedLabelType = intent.getStringExtra(DATAWEDGE_INTENT_KEY_LABEL_TYPE);

		if (null == decodedSource) {
			decodedSource = intent.getStringExtra(DATAWEDGE_INTENT_KEY_SOURCE_LEGACY);
			decodedData = intent.getStringExtra(DATAWEDGE_INTENT_KEY_DATA_LEGACY);
			decodedLabelType = intent.getStringExtra(DATAWEDGE_INTENT_KEY_LABEL_TYPE_LEGACY);
		}

		app.onBarcodeEvent(decodedData);
        /*if (app.getCurrentActivity() != null) {
            String finalBarcodeData = decodedData;
            app.getCurrentActivity().runOnUiThread(() -> app.getCurrentActivity().onBarcodeEvent(finalBarcodeData));
        }*/

	}

	public void onResume() {
		try {
			app.registerReceiver(scanReceiver, filterScan);

			createProfile();
		} catch (Exception ignored) {

		}
	}

	public void onPause() {
		app.unregisterReceiver(scanReceiver);
	}

	public void onDestroy() {
		app.log(this, "onDestroy()");
	}

	private void sendDataWedgeIntentWithExtra(String action, String extraKey, Bundle extras) {
		Intent dwIntent = new Intent();
		dwIntent.setAction(action);
		dwIntent.putExtra(extraKey, extras);
		dwIntent.putExtra("SEND_RESULT", "true");
		app.sendBroadcast(dwIntent);
	}

	private void sendDataWedgeIntentWithExtra(String action, String extraKey, String extraValue) {
		Intent dwIntent = new Intent();
		dwIntent.setAction(action);
		dwIntent.putExtra(extraKey, extraValue);
		dwIntent.putExtra("SEND_RESULT", "true");
		app.sendBroadcast(dwIntent);
	}
}