package com.metinvest.smc.ui;

import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.db.Dpl;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemDpl implements IFlexible<AdapterItemDpl.AdapterItemShipmentViewHolder> {

    private final Dpl dpl;
    private final IItemAction action;
    private boolean selectable, enabled, hidden, draggable, swipeable;

    public interface IItemAction {
        void OnPrintClick(Dpl dpl);
    }

    public AdapterItemDpl(Dpl dpl, IItemAction action) {
        this.dpl = dpl;
        this.action = action;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }

    @Override
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    @Override
    public boolean isHidden() {
        return this.hidden;
    }

    @Override
    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    @Override
    public int getSpanSize(int spanCount, int position) {
        return 1;
    }

    @Override
    public boolean shouldNotifyChange(IFlexible newItem) {
        return false;
    }

    @Override
    public boolean isSelectable() {
        return this.selectable;
    }

    @Override
    public void setSelectable(boolean selectable) {
        this.selectable = selectable;
    }

    @Override
    public String getBubbleText(int position) {
        return null;
    }

    @Override
    public boolean isDraggable() {
        return this.draggable;
    }

    @Override
    public void setDraggable(boolean draggable) {
        this.draggable = draggable;
    }

    @Override
    public boolean isSwipeable() {
        return this.swipeable;
    }

    @Override
    public void setSwipeable(boolean swipeable) {
        this.swipeable = swipeable;
    }

    @Override
    public int getItemViewType() {
        return 0;
    }

    @Override
    public AdapterItemShipmentViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new AdapterItemShipmentViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemShipmentViewHolder holder, int position, List<Object> payloads) {
        holder.textContent.setText(App.getInstance().fromHtml(dpl.getName()));
        holder.buttonPrint.setVisibility(View.VISIBLE);
        holder.buttonPrint.setOnClickListener(v -> action.OnPrintClick(dpl));
    }

    @Override
    public void unbindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemShipmentViewHolder holder, int position) {
        //empty
    }

    @Override
    public void onViewAttached(FlexibleAdapter<IFlexible> adapter, AdapterItemShipmentViewHolder holder, int position) {
        //empty
    }

    @Override
    public void onViewDetached(FlexibleAdapter<IFlexible> adapter, AdapterItemShipmentViewHolder holder, int position) {
        //empty
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_history_row;
    }

    /**
     * The ViewHolder used by this item.
     * Extending from FlexibleViewHolder is recommended especially when you will use
     * more advanced features.
     */
    public class AdapterItemShipmentViewHolder extends FlexibleViewHolder {

        private final View view;

        public TextView textContent;
        public ImageButton buttonPrint;

        public AdapterItemShipmentViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.view = view;
            this.textContent = view.findViewById(R.id.textContent);
            this.buttonPrint = view.findViewById(R.id.buttonPrint);
        }
    }
}
