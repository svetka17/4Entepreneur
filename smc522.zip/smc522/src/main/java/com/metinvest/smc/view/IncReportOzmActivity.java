package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.inc.SohFilter;
import com.metinvest.smc.inc.TTN;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.JsonUploadTask;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractExpandableItem;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.ExpandableViewHolder;
import eu.davidea.viewholders.FlexibleViewHolder;

public class IncReportOzmActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.viewButtons)
    View viewButtons;
    @BindView(R.id.viewContentData)
    View viewContentData;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;

    private Date dateFrom, dateTo, date;
    private String transportName;
    private FlexibleAdapter<IFlexible> adapter;
    private TTN ttn;
    private String status;
    private String sohSmcId;
    private SohFilter sohFilter;

    private boolean close;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inc_report_ozm);
        ButterKnife.bind(this);

        sohSmcId = getIntent().getStringExtra("sohSmcId");
        sohFilter = sohSmcId == null ? SohFilter.NotSoh() : SohFilter.SohInc(sohSmcId);
        dateFrom = (Date) getIntent().getSerializableExtra("dateFrom");
        dateTo = (Date) getIntent().getSerializableExtra("dateTo");
        date = (Date) getIntent().getSerializableExtra("date");
        transportName = getIntent().getStringExtra("transportName");
        ttn = (TTN) getIntent().getSerializableExtra("ttn");
        status = getIntent().getStringExtra("status");

        close = getIntent().getBooleanExtra("close", false);
        viewButtons.setVisibility(close ? View.VISIBLE : View.GONE);
        buttonAccept.setVisibility(close ? View.VISIBLE : View.GONE);
        buttonAccept.setEnabled(false);

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5 && buttonAccept.isEnabled() && close) {
            setResult(RESULT_OK);
            finish();
        }
    }

    private void beginLoad() {
        if (isLoading()) return;

        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);
        buttonAccept.setEnabled(false);

        Utils.runOnBackground(() -> {

            String url = config.getUrlApi() + "getinboundozmreport";
            url = net.addUrlParam(url, "TTN_DATE", app.getDateFormat().format(date));
            url = net.addUrlParam(url, "TTN_CARRIER_ID", transportName);
            url = net.addUrlParam(url, "TTN_NUM", ttn.getNum());
            //url = net.addUrlParam(url, "TTN_ID", ttn.getId());
            if (sohFilter.getSohSmcId() != null)
                url = net.addUrlParam(url, "smc_id", sohFilter.getSohSmcId());

            JsonResult result = net.downloadJson(url);

            if (result.isOk()) {

                List<IFlexible> list = new ArrayList<>();

                JSONArray array = Utils.getJsonArray(result.getJson(), "data");
                if (array != null) {
                    int groupCount = array.length();
                    for (int i = 0; i < groupCount; i++) {
                        JSONObject jsonGroup = Utils.getJsonObject(array, i);

                        if (jsonGroup != null) {

                            String name = Utils.getJsonStringIgnoreCase(jsonGroup, "saP_MATT_DESCR");
                            String ozm = Utils.getJsonStringIgnoreCase(jsonGroup, "saP_OZM");
                            float width = Utils.getJsonFloatIgnoreCase(jsonGroup, "width");
                            float length = Utils.getJsonFloatIgnoreCase(jsonGroup, "length");
                            float thickness = Utils.getJsonFloatIgnoreCase(jsonGroup, "thickness");
                            int plan = Utils.getJsonWeightKgIgnoreCase(jsonGroup, "plaN_Nett");
                            int fact = Utils.getJsonWeightKgIgnoreCase(jsonGroup, "facT_Nett");
                            JSONArray arrayLabels = Utils.getJsonArray(jsonGroup, "labels");

                            AdapterGroup group = new AdapterGroup(
                                    name, ozm,
                                    width, length, thickness,
                                    plan, fact
                            );

                            if (arrayLabels != null) {
                                int labelCount = arrayLabels.length();
                                for (int j = 0; j < labelCount; j++) {
                                    JSONObject jsonLabel = Utils.getJsonObject(arrayLabels, j);
                                    if (jsonLabel != null) {
                                        String labelId = Utils.getJsonStringIgnoreCase(jsonLabel, "labelId");
                                        String batch = Utils.getJsonStringIgnoreCase(jsonLabel, "batch");
                                        int labelNetto = Utils.getJsonWeightKgIgnoreCase(jsonLabel, "mengE_FACT");
                                        if (labelNetto > 0) {
                                            Adapter label = new Adapter(labelId, batch, labelNetto, isReadOnly());
                                            group.addSubItem(label);
                                        }
                                    }
                                }
                            }

                            list.add(group);
                        }
                    }
                }

                adapter = new FlexibleAdapter<>(list);
                adapter.addListener(this);

            }

            runOnUiThread(() -> endLoad(result));
        });
    }

    private boolean isReadOnly() {
        return !(status.equalsIgnoreCase("") || status.equalsIgnoreCase("0") || status.equalsIgnoreCase("97"));
    }

    private void endLoad(JsonResult result) {

        hideLoading();
        viewButtons.setVisibility(result.isOk() && close ? View.VISIBLE : View.GONE);
        viewContentData.setVisibility(result.isOk() ? View.VISIBLE : View.GONE);
        buttonAccept.setEnabled(result.isOk() && close);

        if (result.isOk()) {
            textNotFound.setVisibility(adapter.getItemCount() == 0 ? View.VISIBLE : View.GONE);
            listView.setAdapter(adapter);
            scrollView.post(() -> scrollView.scrollTo(0, 0));
        } else {
            textNotFound.setVisibility(View.VISIBLE);
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
        }
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_CANCELED);
        super.onBackPressed();
    }

    private void OnEditClick(Adapter item) {
        log("Edit %s", item.getLabelId());
        beginEdit(item.getLabelId());
    }

    private void OnDeleteClick(Adapter item) {
        log("Delete %s", item.getLabelId());
        beginDelete(item.getLabelId());
    }

    private void beginDelete(String labelId) {
        showLoading(R.string.text_please_wait);

        String url = config.getUrlApi() + "editsapinboundlabel";
        url = net.addUrlParam(url, "LabelId", labelId);
        url = net.addUrlParam(url, "NettWeight", "0");
        url = net.addUrlParam(url, "PackWeight", "0");
        if (sohFilter.getSohSmcId() != null)
            url = net.addUrlParam(url, "smc_id", sohFilter.getSohSmcId());
        net.uploadJson(new JsonUploadTask.JsonUploadTaskParam(url, ""), result -> endDelete(result, labelId));
    }

    private void endDelete(JsonResult result, String labelId) {
        hideLoading();

        if (result.isOk()) {
            Toast.makeText(this, R.string.successful_deleted, Toast.LENGTH_SHORT).show();
            beginLoad();
        } else if (result.getStatus() == LoadResultStatus.PLUS2) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.set_label_weight_error_plus2, null);
        } else {
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginDelete(labelId));
        }
    }

    private void beginEdit(String labelId) {
		Intent intent = new Intent(this, IncLabelEditActivity.class);
		intent.putExtra("labelId", labelId);
		intent.putExtra("date", date);
		intent.putExtra("dateFrom", dateFrom);
		intent.putExtra("dateTo", dateTo);
		intent.putExtra("transportName", transportName);
		intent.putExtra("ttn", ttn);
        intent.putExtra("status", status);
        intent.putExtra("sohSmcId", sohSmcId);
        startActivityForResult(intent, REQUEST_ACTION);
	}

    private void OnPrintClick(Adapter item) {
        log("Print %s", item.getLabelId());
        beginPrint(item.getLabelId());
    }

    private void beginPrint(String labelId) {

        showLoading(R.string.text_printing_title);

        Utils.runOnBackground(() -> {
            String smcId = sohFilter.getSohSmcId();
            Utils.NetworkPrintResult result = Utils.printLabel(labelId, smcId);
            runOnUiThread(() -> endPrint(result, labelId));
        });
    }

    private void endPrint(Utils.NetworkPrintResult result, String labelId) {

        hideLoading();

        if (result.getNetworkResult().isOk()) {

            if (result.getPrintResult().getStatus() == Printer.PrintResultStatus.OK) {
                showToast(R.string.text_print_result_succeeded);
				//app.sendFaPrint();
                //AlertDialog dialog = showDialog(R.drawable.ic_info_24dp, R.string.text_information, R.string.text_print_result_succeeded, null);
                //if (dialog != null) dialog.setCanceledOnTouchOutside(false);
            } else {
                final int message = app.getPrintResultMessage(result.getPrintResult());
                showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> beginPrint(labelId));
            }

        } else {
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result.getNetworkResult()), (dialog, which) -> beginPrint(labelId));
        }

    }

    @Override
    public boolean onItemClick(View view, int position) {
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_ACTION && resultCode == RESULT_OK && data != null) {
            String labelId = data.getStringExtra("labelId");
            int netto = data.getIntExtra("netto", 0);
            int pack = data.getIntExtra("pack", 0);
            log("labelId %s, netto:%s, pack:%s", labelId, netto, pack);
            beginLoad();
        }
    }

    public class Adapter extends AbstractFlexibleItem<Adapter.ViewHolder> {

        private final String labelId;
        private final String batch;
        private final int netto;
        private final String content;
        private final boolean readOnly;

        Adapter(String labelId, String batch, int netto, boolean readOnly) {
            this.labelId = labelId;
            this.batch = batch;
            this.netto = netto;
            this.readOnly = readOnly;

            StringBuilder sb = new StringBuilder();
            sb.append(Utils.format("<b>LabelID: %s</b><br>", labelId));
            sb.append(Utils.format("Партія: %s<br>", Utils.onNullOrEmpty(batch, "АВТО")));
            sb.append(Utils.format("Вага НЕТТО, тн: %.3f", netto / 1000.0f));
            this.content = sb.toString();
        }

        public boolean isReadOnly() {
            return readOnly;
        }

        public String getLabelId() {
            return labelId;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof Adapter && ((Adapter) o).getLabelId().equalsIgnoreCase(getLabelId());
        }

        @Override
        public int hashCode() {
            return getLabelId().hashCode();
        }

        @Override
        public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
            return new ViewHolder(view, adapter);
        }

        @Override
        public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {
            holder.textContent.setText(App.getInstance().fromHtml(content));
            View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
            holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
            refreshBackground(holder, holder.itemView.isFocused());

            holder.buttonEdit.setVisibility(isReadOnly() ? View.GONE : View.VISIBLE);
            holder.buttonDelete.setVisibility(isReadOnly() ? View.GONE : View.VISIBLE);

            holder.buttonPrint.setOnClickListener(v -> OnPrintClick(Adapter.this));
            holder.buttonEdit.setOnClickListener(v -> OnEditClick(Adapter.this));
            holder.buttonDelete.setOnClickListener(v -> OnDeleteClick(Adapter.this));
        }

        private void refreshBackground(ViewHolder holder, boolean hasFocus) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_adapter_light));
        }

        @Override
        public int getLayoutRes() {
            return R.layout.adapter_inc_report;
        }

        class ViewHolder extends FlexibleViewHolder {

            @BindView(R.id.textContent)
            TextView textContent;
            @BindView(R.id.buttonPrint)
            ImageButton buttonPrint;
            @BindView(R.id.buttonEdit)
            ImageButton buttonEdit;
            @BindView(R.id.buttonDelete)
            ImageButton buttonDelete;

            ViewHolder(View view, FlexibleAdapter adapter) {
                super(view, adapter);
                ButterKnife.bind(this, view);
            }
        }
    }

    public class AdapterGroup extends AbstractExpandableItem<AdapterGroup.ViewHolder, Adapter> {

        private final String name;
        private final String ozm;
        private final float width;
        private final float length;
        private final float thickness;
        private final int plan;
        private final int fact;
        private final String content;

        AdapterGroup(String name, String ozm, float width, float length, float thickness, int plan, int fact) {
			this.name = name;
			this.ozm = ozm;
			this.width = width;
			this.length = length;
			this.thickness = thickness;
			this.plan = plan;
			this.fact = fact;

			StringBuilder sb = new StringBuilder();
			sb.append(Utils.format("<b>%s</b><br>", Html.escapeHtml(name)));
			//sb.append(Utils.format("<b>%s</b><br>", name));
			if (app.sizeToString(width, length, thickness).trim().length() > 0)
				sb.append(Utils.format("%s<br>", app.sizeToString(width, length, thickness)));
			sb.append(Utils.format("ОЗМ: %s<br>", ozm));
			sb.append(Utils.format("План, тн: %.3f<br>", plan / 1000.0f));
			sb.append(Utils.format("Факт, тн: %s %s", Utils.factToString(fact), Utils.getTotalWeightPercentString(plan, fact)));
			this.content = sb.toString();
		}

        public String getName() {
            return name;
        }

        public String getOzm() {
            return ozm;
        }

        public float getWidth() {
            return width;
        }

        public float getLength() {
            return length;
        }

        public float getThickness() {
            return thickness;
        }

        public int getPlan() {
            return plan;
        }

        public int getFact() {
            return fact;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof AdapterGroup && (((AdapterGroup) o).getName().equals(getName()));
        }

        @Override
        public int hashCode() {
            return getName().hashCode();
        }

        @Override
        public int getLayoutRes() {
            return R.layout.adapter_inc_report_group;
        }

        @Override
        public ViewHolder createViewHolder(View view, FlexibleAdapter adapter) {
            return new ViewHolder(view, adapter);
        }

        @Override
        public void bindViewHolder(FlexibleAdapter adapter, ViewHolder holder, int position, List payloads) {
            holder.textTitle.setText(app.fromHtml(content));
            View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
            holder.itemView.setOnFocusChangeListener(onFocusChangeListener);

            refreshBackground(holder, holder.itemView.isFocused());
            View.OnClickListener headerListener = v -> {
                holder.toggleExpansion();
                refreshExpand(holder);
            };

            holder.itemView.setOnClickListener(headerListener);
            holder.imageExpand.setVisibility(hasSubItems() ? View.VISIBLE : View.INVISIBLE);
            holder.imageExpand.setOnClickListener(headerListener);
            holder.textTitle.setOnClickListener(headerListener);

            refreshExpand(holder);
        }

        private void refreshExpand(ViewHolder holder) {
            holder.imageExpand.setImageDrawable(ContextCompat.getDrawable(holder.itemView.getContext(),
                    isExpanded() ? R.drawable.ic_keyboard_arrow_down_black_24dp : R.drawable.ic_keyboard_arrow_right_black_24dp));
        }

        private float getTotalWeightPercent() {
            return plan == 0 ? 0 : fact * 100.0f / plan;
        }

        private void refreshBackground(ViewHolder holder, boolean hasFocus) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_adapter_light));
        }

        class ViewHolder extends ExpandableViewHolder {

            @BindView(R.id.textTitle)
            TextView textTitle;
            @BindView(R.id.imageExpand)
            ImageView imageExpand;

            ViewHolder(View view, FlexibleAdapter adapter) {
                super(view, adapter);
                ButterKnife.bind(this, view);
            }

            @Override
            public void toggleExpansion() {
                super.toggleExpansion();
            }
        }
    }

}
