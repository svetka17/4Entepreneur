package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.inc.SohFilter;
import com.metinvest.smc.inc.TTN;
import com.metinvest.smc.inc.Transport;
import com.metinvest.smc.inc.TransportDoc;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.Utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class BuyoutListActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

	@BindView(R.id.textContentTitle)
	TextView textContentTitle;
	@BindView(R.id.listView)
	RecyclerView listView;
	@BindView(R.id.viewContentData)
	View viewContentData;
	@BindView(R.id.textNotFound)
	TextView textNotFound;
	@BindView(R.id.viewButtons)
	View viewButtons;
	@BindView(R.id.textFilter)
	EditText textFilter;
	@BindView(R.id.buttonFilterClear)
	ImageButton buttonFilterClear;

	private Date dateFrom, dateTo;
	private FlexibleAdapter<Adapter> adapter;
	private List<Adapter> listItems;
	private SohFilter sohFilter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_buyout_list);
		ButterKnife.bind(this);

		sohFilter = SohFilter.SohBuyOut();
		dateFrom = (Date) getIntent().getSerializableExtra("dateFrom");
		dateTo = (Date) getIntent().getSerializableExtra("dateTo");

		listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
		textFilter.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				applyFilter();
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		});
	}

	private void applyFilter() {
		String filterText = textFilter.getText().toString().toLowerCase();
		if (adapter == null) return;

		List<Adapter> list = new ArrayList<>();

		for (Adapter item : listItems) {
			if (filterText.length() == 0
					|| item.getTransportDoc().getTtn().getNum().toLowerCase().contains(filterText)
					|| item.getTransport().getName().toLowerCase().contains(filterText)
			) {
				list.add(item);
			}
		}

		setAdapter(list);
		textNotFound.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
	}

	private void buttonFilterClick() {
		listView.post(() -> listView.requestFocus());
		applyFilter();
	}

	private void buttonFilterClearClick() {
		hideKeyboard();
		textFilter.setText(null);
		buttonFilterClick();
	}

	@Override
	protected String getHelpContent() {
		return getString(R.string.buyout_list_help);
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		beginLoad();
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 2) buttonRefreshClick();
		else if (number == 3) buttonFilterClearClick();
	}

	private void buttonRefreshClick() {
		if (isLoading()) return;
		beginLoad();
	}

	@Override
	public boolean onItemClick(View view, int position) {
		Adapter item = adapter.getItem(position);
		if (item == null) return false;
		openTtn(item);
		return true;
	}

	private void openTtn(Adapter item) {
		/*if (!item.isActive()) {
			Toast.makeText(this, "Завдання вже завершено!", Toast.LENGTH_SHORT).show();
			return;
		}*/

		Intent intent = new Intent(this, BuyoutTtnActivity.class);
		intent.putExtra("ttn", item.getTransportDoc().getTtn());
		intent.putExtra("transportName", item.getTransport().getName());
		intent.putExtra("date", item.getTransport().getDate());
		startActivityForResult(intent, REQUEST_DEFAULT);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == REQUEST_DEFAULT) {
			if (resultCode == RESULT_OK ) {
				beginLoad();
			}
		}
	}

	private void beginLoad() {

		if (isLoading()) return;

		showLoading(R.string.text_please_wait);
		viewButtons.setVisibility(View.GONE);

		setAdapter(null);

		Utils.runOnBackground(() -> {
			Network.NetworkResultValue<List<Transport>> result = app.loadIncTransportList(dateFrom, dateTo, null, sohFilter);
			listItems = new ArrayList<>();

			if (result.getResult().isOk()) {
				for (Transport transport : result.getValue()) {
					List<TTN> ttnList = transport.getTtnList();
					for (TTN ttn : ttnList) {
						TransportDoc transportDoc = TransportDoc.fromTransport(transport, ttn);
						if (transportDoc == null) continue;
						listItems.add(new Adapter(transport, transportDoc));
					}
				}

				/* TODO Collections.sort(listItems, (o1, o2) -> {
					int res = Boolean.compare(o2.isActive(), o1.isActive());
					if (res == 0) {
						res = o1.getTtn().getNum().compareTo(o2.getTtn().getNum());
					}
					return res;
				});*/
			}

			runOnUiThread(() -> endLoad(result.getResult(), listItems));
		});
	}

	private void endLoad(JsonResult result, List<Adapter> listItems) {
		hideLoading();
		viewButtons.setVisibility(View.VISIBLE);

		setAdapter(listItems);
		viewContentData.setVisibility(result.isOk() && !listItems.isEmpty() ? View.VISIBLE : View.GONE);
		textNotFound.setVisibility(!result.isOk() || listItems.isEmpty() ? View.VISIBLE : View.GONE);

		if (result.isOk() && !listItems.isEmpty()) {
			buttonFilterClick();
		}

		if (!result.isOk()) {
			if (result.getStatus() == LoadResultStatus.TIMEOUT) {
				showDialog(R.drawable.ic_error_24dp, R.string.text_error, R.string.inc_timeout_transport_list, (dialog, which) -> onBackPressed());
			} else {
				showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
			}
		}

	}

	private void setAdapter(List<Adapter> list) {
		if (list == null) {
			adapter = null;
		} else {
			adapter = new FlexibleAdapter<>(list);
			adapter.addListener(this);
		}
		listView.setAdapter(adapter);
	}

	public static class Adapter extends AbstractFlexibleItem<Adapter.TransportViewHolder> {

		private final Transport transport;
		private final TransportDoc transportDoc;

		@ColorInt
		private int backgroundColor;

		public Adapter(Transport transport, TransportDoc transportDoc) {
			this.transport = transport;
			this.transportDoc = transportDoc;
			this.backgroundColor = -1;
		}

		public Transport getTransport() {
			return transport;
		}

		public TransportDoc getTransportDoc() {
			return transportDoc;
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof Adapter && ((Adapter) o).getTransportDoc().getTtn().equals(getTransportDoc().getTtn());
		}

		@Override
		public int hashCode() {
			return transportDoc.getTtn().getNum().hashCode();
		}

		@Override
		public int getLayoutRes() {
			return R.layout.adapter_buyout_item;
		}

		@Override
		public TransportViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
			return new TransportViewHolder(view, adapter);
		}

		@Override
		public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, TransportViewHolder holder, int position, List<Object> payloads) {
			String title = Utils.format("<b>%s</b>", transport.getName());

			holder.textTitle.setText(App.getInstance().fromHtml(title));

			StringBuilder sb = new StringBuilder();
			sb.append(Utils.format("ТТН: %s<br>", transportDoc.getTtn().getNum()));
			sb.append(Utils.format("План, тн: %.3f<br>", transportDoc.getTotalWeightPlan() / 1000.0f));
			sb.append(Utils.format("Факт, тн: %s<br>", Utils.factToString(transportDoc.getTotalWeightFact())));
			sb.append(Utils.getBuyoutStatusDescr(transportDoc.getStatus()));

			holder.textContent.setText(App.getInstance().fromHtml(sb.toString()));

			holder.imageView.setImageResource(Utils.getBuyoutStatusDrawable(transportDoc.getStatus()));

			View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
			holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
			refreshBackground(holder, holder.itemView.isFocused());
		}

		private void refreshBackground(TransportViewHolder holder, boolean hasFocus) {
			if (backgroundColor == -1) {
				holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_adapter_light));
			} else {
				holder.itemView.setBackgroundColor(backgroundColor);
			}
		}

		static class TransportViewHolder extends FlexibleViewHolder {

			@BindView(R.id.textTitle)
			TextView textTitle;
			@BindView(R.id.textContent)
			TextView textContent;
			@BindView(R.id.imageView)
			ImageView imageView;

			TransportViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
				super(view, adapter);
				ButterKnife.bind(this, view);
			}
		}
	}
}
