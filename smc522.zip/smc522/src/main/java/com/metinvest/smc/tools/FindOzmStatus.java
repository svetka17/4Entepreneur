package com.metinvest.smc.tools;

public enum FindOzmStatus {
    OK, NOT_FOUNT, ERROR_SIZE, ERROR_LENGTH, ERROR_DISCOUNT
}
