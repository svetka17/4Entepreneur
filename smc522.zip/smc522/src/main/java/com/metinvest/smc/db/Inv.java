package com.metinvest.smc.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.metinvest.smc.App;
import com.metinvest.smc.tools.Utils;

import java.util.Date;

@Entity
public class Inv {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private String category;
    private int percent;
    private String smcId, storage, storageName, ozm, name, batch, baseEi;
    private int stock;
    private float thickness, width, length;
    private String markdown, group, dateVozn, category2, travl, classUzk;
    private String s1, s2, s3, s4, s5, s6;
    private String codeUkt, manufacturer;
    private long dt;

    public Inv() {
    }

    @Ignore
    public Inv(long id, String category, int percent, String smcId, String storage, String storageName, String ozm, String name, String batch, String baseEi, int stock, float thickness, float width, float length, String markdown, String group, String dateVozn, String category2, String travl, String classUzk, String s1, String s2, String s3, String s4, String s5, String s6, String codeUkt, String manufacturer) {
        this.id = id;
        this.category = category;
        this.percent = percent;
        this.smcId = smcId;
        this.storage = storage;
        this.storageName = storageName;
        this.ozm = ozm;
        this.name = name;
        this.batch = batch;
        this.baseEi = baseEi;
        this.stock = stock;
        this.thickness = thickness;
        this.width = width;
        this.length = length;
        this.markdown = markdown;
        this.group = group;
        this.dateVozn = dateVozn;
        this.category2 = category2;
        this.travl = travl;
        this.classUzk = classUzk;
        this.s1 = s1;
        this.s2 = s2;
        this.s3 = s3;
        this.s4 = s4;
        this.s5 = s5;
        this.s6 = s6;
        this.codeUkt = codeUkt;
        this.manufacturer = manufacturer;
        Date date = App.getInstance().parseDate(App.getInstance().getDateFormat(), this.dateVozn);
        this.dt = date == null ? 0 : date.getTime();
    }

    public long getDt() {
        return dt;
    }

    public void setDt(long dt) {
        this.dt = dt;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getPercent() {
        return percent;
    }

    public void setPercent(int percent) {
        this.percent = percent;
    }

    public String getSmcId() {
        return smcId;
    }

    public void setSmcId(String smcId) {
        this.smcId = smcId;
    }

    public String getStorage() {
        return storage;
    }

    public void setStorage(String storage) {
        this.storage = storage;
    }

    public String getStorageName() {
        return storageName;
    }

    public void setStorageName(String storageName) {
        this.storageName = storageName;
    }

    public String getOzm() {
        return ozm;
    }

    public void setOzm(String ozm) {
        this.ozm = ozm;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public String getBaseEi() {
        return baseEi;
    }

    public void setBaseEi(String baseEi) {
        this.baseEi = baseEi;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public float getThickness() {
        return thickness;
    }

    public void setThickness(float thickness) {
        this.thickness = thickness;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getLength() {
        return length;
    }

    public void setLength(float length) {
        this.length = length;
    }

    public String getMarkdown() {
        return markdown;
    }

    public void setMarkdown(String markdown) {
        this.markdown = markdown;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getDateVozn() {
        return dateVozn;
    }

    public void setDateVozn(String dateVozn) {
        this.dateVozn = dateVozn;
    }

    public String getCategory2() {
        return category2;
    }

    public void setCategory2(String category2) {
        this.category2 = category2;
    }

    public String getTravl() {
        return travl;
    }

    public void setTravl(String travl) {
        this.travl = travl;
    }

    public String getClassUzk() {
        return classUzk;
    }

    public void setClassUzk(String classUzk) {
        this.classUzk = classUzk;
    }

    public String getS1() {
        return s1;
    }

    public void setS1(String s1) {
        this.s1 = s1;
    }

    public String getS2() {
        return s2;
    }

    public void setS2(String s2) {
        this.s2 = s2;
    }

    public String getS3() {
        return s3;
    }

    public void setS3(String s3) {
        this.s3 = s3;
    }

    public String getS4() {
        return s4;
    }

    public void setS4(String s4) {
        this.s4 = s4;
    }

    public String getS5() {
        return s5;
    }

    public void setS5(String s5) {
        this.s5 = s5;
    }

    public String getS6() {
        return s6;
    }

    public void setS6(String s6) {
        this.s6 = s6;
    }

    public String getCodeUkt() {
        return codeUkt;
    }

    public void setCodeUkt(String codeUkt) {
        this.codeUkt = codeUkt;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    @NonNull
    @Override
    public String toString() {
        return Utils.format("[%d] %s %d", getId(), getBatch(), getStock());
    }
}
