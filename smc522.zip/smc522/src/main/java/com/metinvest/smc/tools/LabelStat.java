package com.metinvest.smc.tools;

import androidx.annotation.NonNull;

public class LabelStat {
	private boolean isManual;
	private String appView;

	public LabelStat(boolean isManual, String appView) {
		this.isManual = isManual;
		this.appView = appView;
	}

	public boolean isManual() {
		return isManual;
	}

	public String getAppView() {
		return appView;
	}

	@NonNull
	@Override
	public String toString() {
		return Utils.format("[%s] %s", appView, isManual);
	}
}
