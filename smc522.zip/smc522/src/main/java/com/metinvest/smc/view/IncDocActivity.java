package com.metinvest.smc.view;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;

import com.metinvest.smc.R;
import com.metinvest.smc.inc.SohFilter;
import com.metinvest.smc.inc.SohFilterType;
import com.metinvest.smc.inc.TTN;
import com.metinvest.smc.inc.TransportDoc;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.DplGeneratorInc;
import com.metinvest.smc.tools.DplGeneratorZebraInc;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

@SuppressLint("NonConstantResourceId")
public class IncDocActivity extends MyActivity {

	@BindView(R.id.textContentTitle)
	TextView textContentTitle;
	@BindView(R.id.viewButtons)
	View viewButtons;
	@BindView(R.id.viewContentData)
	View viewContentData;
	@BindView(R.id.textNotFound)
	TextView textNotFound;
	@BindView(R.id.textContent)
	TextView textContent;
	@BindView(R.id.imageView)
	ImageView imageView;
	@BindView(R.id.buttonWeighing)
	Button buttonWeighing;
	@BindView(R.id.buttonPrint)
	Button buttonPrint;
	@BindView(R.id.buttonSendSap)
	Button buttonSendSap;
	@BindView(R.id.buttonRelease)
	Button buttonRelease;
	@BindView(R.id.viewButtonWeighting)
	View viewButtonWeighting;
	@BindView(R.id.viewButtonSendSap)
	View viewButtonSendSap;
	@BindView(R.id.viewButtonPrint)
	View viewButtonPrint;
	@BindView(R.id.viewButtonReportBatch)
	View viewButtonReportBatch;
	@BindView(R.id.viewButtonRelease)
	View viewButtonRelease;

	private Date dateFrom, dateTo, date;
	private String transportName;
	private TTN ttn;
	private TransportDoc doc;
	private String sohSmcId;
	private SohFilter sohFilter;

	private boolean storageFlag = true;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_inc_doc);
		ButterKnife.bind(this);

		sohSmcId = getIntent().getStringExtra("sohSmcId");
		sohFilter = sohSmcId == null ? SohFilter.NotSoh() : SohFilter.SohInc(sohSmcId);
		dateFrom = (Date) getIntent().getSerializableExtra("dateFrom");
		dateTo = (Date) getIntent().getSerializableExtra("dateTo");
		date = (Date) getIntent().getSerializableExtra("date");
		transportName = getIntent().getStringExtra("transportName");
		ttn = (TTN) getIntent().getSerializableExtra("ttn");

		textContentTitle.setText(transportName);
		//viewButtonReportBatch.setVisibility(config.isAutoBatch() ? View.GONE : View.VISIBLE);
		//viewButtonReportBatch.setVisibility(View.VISIBLE);
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		beginLoad();
	}

	@Override
	protected void onFunctionKey(int number) {
		if (isLoading()) return;

		if (number == 2 && buttonWeighing.isEnabled()) openWeighing();
		else if (number == 3) openReportBatch();
		else if (number == 4) openReportOzm();
		else if (number == 5) buttonSendSapClick();
		else if (number == 6) beginPrint();
		else if (number == 7) buttonReleaseClick();
	}

	private void buttonReleaseClick() {
		Intent intent = new Intent(this, LabelReleaseActivity.class);
		intent.putExtra("transport", transportName);
		intent.putExtra("ttnNum", doc.getTtn().getNum());
		intent.putExtra("ttnDate", doc.getTransport().getDate());
		intent.putExtra("status", doc.getStatus());
		intent.putExtra("statusString", doc.getStatusString());
		startActivityForResult(intent, REQUEST_ACTION);
	}

	private void buttonSendSapClick() {

		if (canReturnSoh()) {
			returnFromSap();
			return;
		}

		Intent intent = new Intent(this, IncReportOzmActivity.class);
		intent.putExtra("isVhp", doc.isVhp());
		intent.putExtra("status", doc.getStatus());
		intent.putExtra("date", date);
		intent.putExtra("transportName", transportName);
		intent.putExtra("ttn", ttn);
		intent.putExtra("isNew", getIntent().getBooleanExtra("isNew", false));
		intent.putExtra("close", true);
		intent.putExtra("sohSmcId", sohSmcId);
		startActivityForResult(intent, REQUEST_INC_CLOSE);
	}

	private void returnFromSap() {
		showDialogConfirm(R.string.text_warning, getString(R.string.return_soh_confirm), (dialog, which) ->
				beginStatusChange(97, doc.isVhp()));
	}

	private void openReportOzm() {
		if (isLoading() || viewButtons.getVisibility() != View.VISIBLE) return;
		Intent intent = new Intent(this, IncReportOzmActivity.class);
		intent.putExtra("isVhp", doc.isVhp());
		intent.putExtra("status", doc.getStatus());
		intent.putExtra("date", date);
		intent.putExtra("dateFrom", dateFrom);
		intent.putExtra("dateTo", dateTo);
		intent.putExtra("transportName", transportName);
		intent.putExtra("ttn", ttn);
		intent.putExtra("isNew", getIntent().getBooleanExtra("isNew", false));
		intent.putExtra("sohSmcId", sohSmcId);
		startActivityForResult(intent, REQUEST_DEFAULT);
	}

	private void openReportBatch() {
		if (isLoading() || viewButtons.getVisibility() != View.VISIBLE) return;
		Intent intent = new Intent(this, IncReportBatchActivity.class);
		intent.putExtra("isVhp", doc.isVhp());
		intent.putExtra("status", doc.getStatus());
		intent.putExtra("date", date);
		intent.putExtra("dateFrom", dateFrom);
		intent.putExtra("dateTo", dateTo);
		intent.putExtra("transportName", transportName);
		intent.putExtra("ttn", ttn);
		intent.putExtra("isNew", getIntent().getBooleanExtra("isNew", false));
		intent.putExtra("sohSmcId", sohSmcId);
		startActivityForResult(intent, REQUEST_DEFAULT);
	}

	private void openWeighing() {
		if (isLoading() || viewButtons.getVisibility() != View.VISIBLE || !buttonWeighing.isEnabled())
			return;

		Intent intent = new Intent(this, IncWeighingActivity.class);
		intent.putExtra("isVhp", doc.isVhp());
		intent.putExtra("dateFrom", dateFrom);
		intent.putExtra("dateTo", dateTo);
		intent.putExtra("date", date);
		intent.putExtra("transportName", transportName);
		intent.putExtra("ttn", ttn);
		intent.putExtra("isNew", getIntent().getBooleanExtra("isNew", false));
		intent.putExtra("sohSmcId", sohSmcId);
		startActivityForResult(intent, REQUEST_DEFAULT);
	}

	private void beginLoad() {
		if (isLoading()) return;

		showLoading(R.string.text_please_wait);
		viewButtons.setVisibility(View.GONE);

		Utils.runOnBackground(() -> {
			Network.NetworkResultValue<TransportDoc> result = app.loadIncTransportDoc(date, dateFrom, dateTo, transportName, ttn, sohFilter);
			runOnUiThread(() -> endLoad(result.getResult(), result.getValue()));
		});
	}

	private void endLoad(JsonResult result, TransportDoc transport) {

		boolean isContent = transport != null;

		hideLoading();
		this.doc = transport;
		viewButtons.setVisibility(isContent ? View.VISIBLE : View.GONE);
		viewContentData.setVisibility(isContent ? View.VISIBLE : View.GONE);
		textNotFound.setVisibility(!isContent ? View.VISIBLE : View.GONE);

		if (transport != null) {
			showContent();
		} else {
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
		}
	}

	private boolean canWeight() {
		if (doc == null) return false;
		String status = doc.getStatus();
		return Utils.equalsIgnoreCaseIn(status, "", "0", "97", "8");
	}

	private boolean canSendSap() {
		if (doc == null) return false;
		String status = doc.getStatus();
		return Utils.equalsIgnoreCaseIn(status, "0", "97", "99", "8") && !doc.isProcessing();
	}

	private boolean canPrint() {
		if (doc == null) return false;
		String status = doc.getStatus();
		return !Utils.equalsIgnoreCaseIn(status, "", "0", "99");
	}

	private boolean canReturnSoh() {
		if (doc == null) return false;
		return doc.getStatus().equalsIgnoreCase("7") && sohFilter.getType() == SohFilterType.SOH_FALSE;
	}

	private boolean canRelease() {
		if (doc == null) return false;
		//return doc.getStatus().equalsIgnoreCase("7") && sohFilter.getType() == SohFilterType.SOH_FALSE;
		//return doc.getStatus().equalsIgnoreCase("0") || doc.getStatus().equalsIgnoreCase("97");
		//return doc.getStatus().equalsIgnoreCase("1");
		return Utils.equalsIgnoreCaseIn(doc.getStatus(), "1", "2", "3", "4", "5");
	}

	private void refreshButtons() {
		viewButtonWeighting.setVisibility(canWeight() ? View.VISIBLE : View.GONE);
		buttonWeighing.setEnabled(canWeight());

		viewButtonSendSap.setVisibility(canSendSap() || canReturnSoh() ? View.VISIBLE : View.GONE);
		buttonSendSap.setEnabled(canSendSap() || canReturnSoh());
		buttonSendSap.setText(canReturnSoh() ? R.string.button_return_form_sap : R.string.button_send_sap);

		viewButtonPrint.setVisibility(canPrint() ? View.VISIBLE : View.GONE);
		buttonPrint.setEnabled(canPrint());

		viewButtonRelease.setVisibility(canRelease() ? View.VISIBLE : View.GONE);
		buttonRelease.setEnabled(canRelease());
	}

	private void showContent() {
		StringBuilder sb = new StringBuilder();
		sb.append(Utils.format("План, тн: %.3f<br>", doc.getTotalWeightPlan() / 1000.0f));
		sb.append(Utils.format("Факт, тн: %s %s<br>", Utils.factToString(doc.getTotalWeightFact()), doc.getTotalWeightPercentString()));
		if (doc.getTotalWeightFactTemp() > 0) {
			sb.append(Utils.format("<font color=\"red\">з них тимчасових, тн: %.3f</font><br>", doc.getTotalWeightFactTemp() / 1000.0f));
		}
		sb.append(Utils.format("ТТН: %s %s<br>", doc.getTtn().getNum(), app.getDateFormat().format(doc.getTransport().getDate())));

		if (doc.isProcessing()) {
			sb.append(Utils.format("%s (AUTO_BATCH)", doc.getStatusString()));
		} else {
			sb.append(Utils.format("%s", doc.getStatusString()));
		}

		if (doc.isVhp()) sb.append("<br>ВХП");

		sb.append(Utils.format("<br>Склад: %s", config.getStorage()==null?doc.getStorage():config.getStorage()));

		textContent.setText(app.fromHtml(sb.toString()));
		imageView.setImageResource(Utils.getStatusDrawable(doc.getStatus()));
		refreshButtons();

		if (storageFlag) {
			storageFlag = false;
			//showDialog(R.drawable.ic_info_24dp, R.string.text_warning, Utils.format("Виконуйте розвантаження на склад \"%s\"!", doc.getStorage()), null);
		}
	}

	@Override
	public void onBackPressed() {
		Intent data = new Intent();
		data.putExtra("transportName", transportName);
		data.putExtra("ttn", ttn);
		data.putExtra("date", date);
		setResult(RESULT_OK, data);
		super.onBackPressed();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == REQUEST_DEFAULT) {
			if (resultCode == RESULT_OK) {
				beginLoad();
			} else if (resultCode == RESULT_DELETED) {
				setResult(RESULT_DELETED);
				finish();
			}
		} else if (requestCode == REQUEST_INC_CLOSE && resultCode == RESULT_OK) {
			prepareForStatusChange(99, doc.isVhp());
		}
	}

	private void beginStatusChange(int statusId, boolean isVhp) {
		log("beginStatusChange %s", statusId);

		showLoading(R.string.text_please_wait);
		viewButtons.setVisibility(View.GONE);

		Utils.runOnBackground(() -> {
			JsonResult result = reqSetStatus(statusId);
			runOnUiThread(() -> endStatusChange(statusId, isVhp, result));
		});
	}

	private JsonResult reqSetStatus(int statusId) {
		String url = config.getUrlApi() + "setinboundstatus";
		url = net.addUrlParam(url, "TTN_DATE", app.getDateFormat().format(date));
		url = net.addUrlParam(url, "TTN_CARRIER_ID", doc.getTransport().getName());
		url = net.addUrlParam(url, "TTN_NUM", doc.getTtn().getNum());
		url = net.addUrlParam(url, "STATUS", statusId);
		url = net.addUrlParam(url, "is_auto",  config.partyAUTO() ? "true" : "false");
		url = net.addUrlParam(url, "is_sap", "true");
		if (sohFilter.getSohSmcId() != null)
			url = net.addUrlParam(url, "smc_id", sohFilter.getSohSmcId());
		return net.downloadJson(url);
	}

	private void endStatusChange(int statusId, boolean isVhp, JsonResult result) {
		hideLoading();
		viewButtons.setVisibility(View.VISIBLE);

		if (result.isOk()) {
			/*if (statusId == 99) {
				showToast("Відправлено менеджеру!");
			} else*/
			if (statusId == 1 || statusId == 99) {
				showToast("Відправлено в SAP!");
			} else if (statusId == 97) {
				showToast("Повернуто на доопрацювання!");
			}
			//setResult(RESULT_DELETED);
			//finish();
			Utils.sleep(20000);
			beginLoad();
		} else if (result.getStatus() == LoadResultStatus.S004) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.set_inc_status_s004, null);
		} else {
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginStatusChange(statusId, isVhp));
		}
	}

	private void beginPrint() {
		beginPrint(-1, doc.isVhp());
	}

	private void beginPrint(int statusId, boolean isVhp) {
		if (isLoading() || viewButtons.getVisibility() != View.VISIBLE || !buttonPrint.isEnabled())
			return;

		showLoading(R.string.text_printing_title);
		buttonPrint.setEnabled(false);
		viewButtons.setVisibility(View.GONE);

		Utils.runOnBackground(() -> {

			JsonResult jsonResult;
			Printer.PrintResult printResult = null;

			String url = config.getUrlApi() + "getinboundozmreport";
			url = net.addUrlParam(url, "TTN_DATE", app.getDateFormat().format(date));
			url = net.addUrlParam(url, "TTN_CARRIER_ID", transportName);
			url = net.addUrlParam(url, "TTN_NUM", ttn.getNum());
			//url = net.addUrlParam(url, "TTN_ID", ttn.getId());
			if (sohFilter.getSohSmcId() != null)
				url = net.addUrlParam(url, "smc_id", sohFilter.getSohSmcId());

			jsonResult = net.downloadJson(url);

			if (jsonResult.isOk()) {
				JSONArray array = Utils.getJsonArray(jsonResult.getJson(), "data");
				if (array != null) {

					String title, dpl;
					if (isPrinterZebra()) {
						DplGeneratorZebraInc gen = new DplGeneratorZebraInc(doc, array);
						title = gen.generateTitle();
						dpl = gen.generateDpl();
					} else {
						DplGeneratorInc gen = new DplGeneratorInc(doc, array);
						title = gen.generateTitle();
						dpl = gen.generateDpl();
					}
					printResult = Printer.sendCommand(title, config.getPrinter(), dpl);
				}
			}

			Printer.PrintResult finalPrintResult = printResult;
			runOnUiThread(() -> endPrint(jsonResult, finalPrintResult, statusId, isVhp));

		});
	}

	private void endPrint(JsonResult jsonResult, Printer.PrintResult printResult, int statusId, boolean isVhp) {

		viewButtons.setVisibility(View.VISIBLE);
		buttonPrint.setEnabled(true);
		hideLoading();

		Runnable r = () -> {
			if (statusId != -1) beginStatusChange(statusId, isVhp);
		};

		if (jsonResult.isOk()) {
			if (printResult.getStatus() == Printer.PrintResultStatus.OK) {
				showToast(R.string.text_print_result_succeeded);
				//app.sendFaPrint();
				r.run();
			} else {
				@StringRes final int message = app.getPrintResultMessage(printResult);
				showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> beginPrint(statusId, isVhp), (dialog, which) -> r.run());
			}
		} else {
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(jsonResult), (dialog, which) -> beginPrint(statusId, isVhp), (dialog, which) -> r.run());
		}

	}

	private void prepareForStatusChange(int statusId, boolean isVhp) {
		showLoading(R.string.text_please_wait);
		viewButtons.setVisibility(View.GONE);

		Utils.runOnBackground(() -> {
			String url = config.getUrlApi() + (config.isAutoBatch() ? "getinboundozmreport" : "getinboundbatchreport2");
			url = net.addUrlParam(url, "TTN_DATE", app.getDateFormat().format(date));
			url = net.addUrlParam(url, "TTN_CARRIER_ID", transportName);
			url = net.addUrlParam(url, "TTN_NUM", ttn.getNum());

			JsonResult result = net.downloadJson(url);

			runOnUiThread(() -> endPrepareForStatusChange(result, statusId, isVhp));
		});
	}

	private void endPrepareForStatusChange(JsonResult result, int statusId, boolean isVhp) {

		viewButtons.setVisibility(View.VISIBLE);
		hideLoading();

		if (result.isOk()) {

			boolean isAuto = config.isAutoBatch();
			List<String> listOzmOrBatch = new ArrayList<>();

			JSONArray array = Utils.getJsonArray(result.getJson(), "data");
			int totalPlan = 0;
			int totalFact = 0;
			if (array != null) {
				int groupCount = array.length();
				for (int i = 0; i < groupCount; i++) {
					JSONObject jsonGroup = Utils.getJsonObject(array, i);

					if (jsonGroup != null) {

						String ozmOrBatch = isAuto ? Utils.getJsonStringIgnoreCase(jsonGroup, "saP_OZM") : Utils.getJsonStringIgnoreCase(jsonGroup, "saP_BATCH");
						int plan = Utils.getJsonWeightKgIgnoreCase(jsonGroup, "plaN_Nett");
						int fact = Utils.getJsonWeightKgIgnoreCase(jsonGroup, "facT_Nett");
						totalPlan += plan;
						totalFact += fact;

						if (isVhp) {
							if (plan - fact >= 40 || fact - plan >= 40) {
								listOzmOrBatch.add(ozmOrBatch);
							}
						} else {
							float p;

							float v = plan == 0 ? 0 : fact * 100.0f / plan;
							p = 100.0f - v;

							if (p >= 0.5 || p <= -0.5) {
								listOzmOrBatch.add(ozmOrBatch);
							}
						}
					}
				}
			}

			if (!listOzmOrBatch.isEmpty() || (isVhp && (totalPlan - totalFact >= 40 || totalFact - totalPlan >= 40))) {
				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < listOzmOrBatch.size(); i++) {
					sb.append(listOzmOrBatch.get(i));
					if (i + 1 < listOzmOrBatch.size()) sb.append(",");
				}

				if (doc.isVhp()) {
					showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(isAuto ? R.string.inc_tolerans_error_ozm : R.string.inc_tolerans_error_batch, sb.toString()), null);
				} else {
					showDialogConfirm(R.string.text_warning, getString(isAuto ? R.string.inc_tolerans_warning_ozm : R.string.inc_tolerans_warning_batch, sb.toString()), (dialog, which) -> beginStatusChange(statusId, isVhp));
				}
			} else {
				beginStatusChange(statusId, isVhp);
			}

		} else {
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> prepareForStatusChange(statusId, isVhp));
		}
	}

}
