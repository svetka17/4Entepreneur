package com.metinvest.smc.tools;

import com.metinvest.smc.App;
import com.metinvest.smc.BuildConfig;
import com.metinvest.smc.db.ShipmentDocument;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class DplGeneratorShip {

	private final App app;
	private final ShipmentDocument document;
	private final Date date;
	private final int totalBrutto;

	private int printedY;
	private StringBuilder printedData;
	private int printedPage, printedPageCount;
	private String printedTtnDate;

	private final int maxY = 1460;

	private List<Group> groupList;

	private class Group {
		public String name, ozm;
		public float width, length, thickness;
		public int plan, fact;
		private List<Batch> batchList;

		private void addItem(Batch batch) {
			batchList.add(batch);
		}

		private void sortItems() {
			//Collections.sort(batchList, (o1, o2) -> Integer.compare(o1.weighingId, o2.weighingId));
		}

		private Batch getBatch(int index) {
			return batchList.get(index);
		}

		private int getItemCount() {
			return batchList.size();
		}

		public Group(String name, String ozm, float width, float length, float thickness, int plan, int fact) {
			this.name = name;
			this.ozm = ozm;
			this.width = width;
			this.length = length;
			this.thickness = thickness;
			this.plan = plan;
			this.fact = fact;
			this.batchList = new ArrayList<>();
		}
	}

	private class Batch {
		private String status;
		public String batch;
		public int fact;
		public List<Item> itemList;
		public List<String> carrierList;
		public List<String> printedList;

		public Batch(String batch, int fact, String status) {
			this.batch = batch;
			this.fact = fact;
			this.status = status;
			this.itemList = new ArrayList<>();
			this.carrierList = new ArrayList<>();
			this.printedList = new ArrayList<>();
		}
	}

	private static class Item {
		public int lineId;
		public String labelId;
		public int nett, pack;
		public String ttnCarrierId, datePrinted;

		public Item(int lineId, String labelId, int nett, int pack, String ttnCarrierId, String datePrinted) {
			this.lineId = lineId;
			this.labelId = labelId;
			this.nett = nett;
			this.pack = pack;
			this.ttnCarrierId = ttnCarrierId;
			this.datePrinted = datePrinted;
		}
	}

	public DplGeneratorShip(ShipmentDocument document, Date date, int totalBrutto, JSONArray ozmArray) {
		this.app = App.getInstance();
		this.document = document;
		this.date = date;
		this.totalBrutto = totalBrutto;
		this.groupList = new ArrayList<>();

		int groupCount = ozmArray == null ? 0 : ozmArray.length();
		for (int i = 0; i < groupCount; i++) {
			JSONObject jsonGroup = Utils.getJsonObject(ozmArray, i);

			if (jsonGroup != null) {

				String name = Utils.getJsonStringIgnoreCase(jsonGroup, "saP_MATT_DESCR");
				String ozm = Utils.getJsonStringIgnoreCase(jsonGroup, "saP_OZM");
				float width = Utils.getJsonFloatIgnoreCase(jsonGroup, "width");
				float length = Utils.getJsonFloatIgnoreCase(jsonGroup, "length");
				float thickness = Utils.getJsonFloatIgnoreCase(jsonGroup, "thickness");
				int plan = Utils.getJsonWeightKgIgnoreCase(jsonGroup, "plaN_Weight");
				int fact = Utils.getJsonWeightKgIgnoreCase(jsonGroup, "facT_Weight");
				JSONArray arrayBatches = Utils.getJsonArray(jsonGroup, "ozmBatches");

				Group group = new Group(
						name, ozm,
						width, length, thickness,
						plan, fact
				);

				if (arrayBatches != null) {
					int batchCount = arrayBatches.length();
					for (int j = 0; j < batchCount; j++) {
						JSONObject jsonBatch = Utils.getJsonObject(arrayBatches, j);

						if (jsonBatch != null) {
							String sapBatch = Utils.getJsonStringIgnoreCase(jsonBatch, "saP_Batch");

							int factNetto = Utils.getJsonWeightKgIgnoreCase(jsonBatch, "facT_Weight");
							String status = Utils.getJsonStringIgnoreCase(jsonBatch, "saP_FACT_STATUS_OUT");
							if (factNetto > 0) {
								Batch batch = new Batch(sapBatch, factNetto, status);

								//List<String> carrierList = new ArrayList<>();
								//List<String> printedList = new ArrayList<>();

								JSONArray arrayLabels = Utils.getJsonArray(jsonBatch, "lidsByBatch");
								if (arrayLabels != null && arrayLabels.length() > 0) {
									int labelCount = arrayLabels.length();
									for (int z = 0; z < labelCount; z++) {
										JSONObject jsonLabel = Utils.getJsonObject(arrayLabels, z);
										int labelLineId = Utils.getJsonIntIgnoreCase(jsonLabel, "line_id");
										String labelId = Utils.getJsonStringIgnoreCase(jsonLabel, "id_qr");
										int labelNett = Utils.getJsonWeightKg(jsonLabel, "saP_WEIGHT_NETT");
										int labelPack = Utils.getJsonWeightKg(jsonLabel, "saP_WEIGHT_PACK");
										String ttnCarrierId = Utils.getJsonStringIgnoreCase(jsonLabel, "ttN_CARRIER_ID");
										String datePrinted = Utils.getJsonStringIgnoreCase(jsonLabel, "datE_PRINTED");
										if (datePrinted.length() > 10)
											datePrinted = datePrinted.substring(0, 10);

										int ind = findLabel(batch.itemList, labelId);

										if (ind != -1) {
											batch.itemList.get(ind).nett += labelNett;
											batch.itemList.get(ind).pack += labelPack;
										} else {
											Item item = new Item(labelLineId, labelId, labelNett, labelPack, ttnCarrierId, datePrinted);
											batch.itemList.add(item);
										}

										//
										int ind2 = findString(batch.carrierList, ttnCarrierId);
										if (ind2 == -1) {
											batch.carrierList.add(ttnCarrierId);
											batch.printedList.add(datePrinted);
										} else {
											String foundDt = batch.printedList.get(ind2);
											if (!foundDt.equalsIgnoreCase(datePrinted)) {
												batch.carrierList.add(ttnCarrierId);
												batch.printedList.add(datePrinted);
											}
										}
									}
								}

								group.addItem(batch);
							}
						}
					}

				}

				group.sortItems();
				groupList.add(group);
			}
		}
	}

	private int findString(List<String> list, String value) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).equalsIgnoreCase(value)) return i;
		}
		return -1;
	}

	private int findLabel(List<Item> list, String labelId) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).labelId.equalsIgnoreCase(labelId)) return i;
		}
		return -1;
	}

	public String generateTitle() {
		return Utils.format("<b>Відвантаження</b><br>Номер наряду: %s<br>Номер машини: %s",
				document.getDocNumber(), document.getTransportName());
	}

	public String generateDpl() {

		long t1 = Calendar.getInstance().getTime().getTime();

		printedData = new StringBuilder();
		printedY = 0;
		printedPage = 0;
		printedPageCount = 0;

		printedTtnDate = app.getDateFormat().format(date);

		processItems();

		long t2 = Calendar.getInstance().getTime().getTime();

		app.log(this, "TIME FOR GENERATE DPL: %d ms", t2 - t1);

		return printedData.toString();
	}

	private void processItems() {

		//DPL
		printedData.append("\u0002m\n\u0002L\nD11\nPC\nySU8\n");

		//HEADER
		addHeader();

		int totalWeightFact = 0;

		//CONTENT
		for (int g = 0; g < groupList.size(); g++) {

			Group group = groupList.get(g);

			totalWeightFact += group.fact;

			addOzm(group);

			for (int i = 0; i < group.getItemCount(); i++) {
				Batch groupBatch = group.getBatch(i);

				printedData.append(Utils.format(
						"3911S53%04d0915P010P009Партія: %s %.3f тн%n",
						printedY,
						groupBatch.batch, groupBatch.fact / 1000.0f
				));
				addY(40);

				for (int j = 0; j < groupBatch.itemList.size(); j++) {
					printedData.append(Utils.format(
							"3911S53%04d0915P010P009        LabelId:%s %.3f тн%n",
							printedY,
							groupBatch.itemList.get(j).labelId, groupBatch.itemList.get(j).nett / 1000.0f
					));
					addY(40);
				}

				for (int j = 0; j < groupBatch.carrierList.size(); j++) {
					printedData.append(Utils.format(
							"3911S53%04d0915P010P009        ТС:%s %s%n",
							printedY,
							groupBatch.carrierList.get(j), groupBatch.printedList.get(j)
					));
					addY(40);
				}
			}

			int r = group.fact - group.plan;

			String ozmFooter = Utils.format(
					"Сума НЕТТО план/факт: %.3f/%.3f тн (%s кг)",
					group.plan / 1000.0f, group.fact / 1000.0f, (r > 0 ? "+" : "") + r
			);
			printedData.append(Utils.format(
					"3911S53%04d0980P010P009%s%n",
					printedY, ozmFooter));
			addY(15);
			addLine();
			addY(40);
		}

		//USER
		if (printedY > maxY - 40 * 4) {
			addNewPage();
		}

		printedY = maxY - 40 * 2;

		printedData.append(Utils.format("3911S53%04d0980P010P009%s%n", printedY,
				Utils.format("Оператор: %s (%s)", app.getConfig().getUserName(), app.getDateTimeFormat().format(Calendar.getInstance().getTime()))
		));
		addY(40);

		printedData.append(Utils.format("3911S53%04d0980P010P009%s%n", printedY,
				Utils.format("Сумма НЕТТО/БРУТТО по ТС: %.3f/%.3f тн",
						totalWeightFact / 1000.0f,
						totalBrutto / 1000.0f
				)
		));
		addY(40);

		printedData.append("Q0001\n E\n");

		Utils.replaceAll(printedData, "{{PAGE_COUNT}}", String.valueOf(printedPageCount));
	}

	private void addNewPage() {
		printedData.append("Q0001 \n E \n");
		if (BuildConfig.DEBUG) {
			printedData.append("\u0002m\n\u0002L\nD11\nPC\nySU8\n");
		} else {
			printedData.append("\u0002m\n\u0002L\nD11\nPA\nySU8\n");
		}

		printedY = 0;
		addHeader();
	}

	private void addOzm(Group group) {
		String nameLine = group.name.substring(0, Math.min(group.name.length(), 45));
		String ozmLine = group.ozm.substring(0, Math.min(group.ozm.length(), 45));
		String sizeLine = app.sizeToString(group.length, group.width, group.thickness);

		printedData.append(Utils.format("3911S51%04d0980P010P011%s%n", printedY, nameLine));
		addY(40);

		if (sizeLine.length() > 0) {
			printedData.append(Utils.format("3911S53%04d0980P010P009%s%s%n", printedY, sizeLine, ozmLine.length() > 0 ? ", ОЗМ:" + ozmLine : ""));
			addY(40);
		}

        /*if (ozmLine.length() > 0) {
            ozmLine = "озм: " + ozmLine;
            printedData.append(Utils.format("3911S53%04d0980P010P009%s%n", printedY, ozmLine));
            addY(40);
        }*/
	}

	private void addHeader() {

		printedPage++;
		printedPageCount++;

		addY(5);
		addLine();

		printedData.append(Utils.format(
				//"1X1100000050010l10000006\n" +
				"3911S5300500980P010P010Наряд на відгрузку № %s\n" +
						"3911S5300900980P010P010Транспорт №: %s %s\n" +
						"3911S5300500250P010P010Лист %d з {{PAGE_COUNT}}\n",
				//      "1X1100001050010l10000006\n",
				document.getDocNumber(),
				document.getTransportName(), printedTtnDate,
				printedPage
				)
		);

		addY(140);
	}

	private void addY(int value) {
		printedY += value;

		if (value > 0 && printedY > maxY) {
			addNewPage();
		}
	}

	private void addLine() {
		//printedData.append(Utils.format("1X11000%04d0010l10000006%n", printedY));
	}

}
