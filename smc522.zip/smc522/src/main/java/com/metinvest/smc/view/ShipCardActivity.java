package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanIntentResult;
import com.journeyapps.barcodescanner.ScanOptions;
import com.metinvest.smc.BuildConfig;
import com.metinvest.smc.R;
import com.metinvest.smc.db.ShipmentDocument;
import com.metinvest.smc.db.ShipmentItem;
import com.metinvest.smc.db.ShipmentItemLoc;
import com.metinvest.smc.inc.SohFilter;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.FindOzmStatus;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.LabelStat;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemCard;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class ShipCardActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener, IScan, AdapterItemCard.AdapterItemCardListener {

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.buttonRefresh)
    ImageButton buttonRefresh;
    @BindView(R.id.viewContentData)
    View viewContentData;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    @BindView(R.id.imageStatus)
    ImageView imageStatus;
    @BindView(R.id.viewButtons)
    View viewButtons;
    @BindView(R.id.textLabelId)
    EditText textLabelId;
    @BindView(R.id.buttonAddLabel)
    ImageButton buttonAddLabel;

    @BindView(R.id.viewTotal)
    View viewTotal;
    @BindView(R.id.textTotal)
    TextView textTotal;

    private Date date, date2, dateVo;
    private boolean soh;
    private boolean edit;
    private boolean escAdd = false;
    private boolean escClose = false;
    private String sohSmcId;
    private SohFilter sohFilter;
    private String documentNumber;
    private ArrayList<String> documentNumbers;
    private String transportName;

    private String whoEo;

    private FlexibleAdapter<AdapterItemCard> adapter;
    private ShipmentDocument document;
    //private List<ShipmentItem> itemList;
    private int totalFact = 0;
    private boolean isCombined() {
        return documentNumbers != null && !documentNumbers.isEmpty();
    }
    private ActivityResultLauncher<Intent> scanLauncher;

    private void scanBarcode() {
        Intent intent = new ScanContract().createIntent(
                this,
                new ScanOptions() //Builder()
                        .setPrompt("Відскануйте штрихкод або QR-код")
                        .setBeepEnabled(true)
                        .setOrientationLocked(true)
                        .setTorchEnabled(true)
                //.build()
        );
        scanLauncher.launch(intent);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ship_card);
        ButterKnife.bind(this);
        date = (Date) getIntent().getSerializableExtra("date");
        soh = (Boolean) getIntent().getSerializableExtra("soh");
        date2 = (Date) getIntent().getSerializableExtra("date2");
        dateVo = (Date) getIntent().getSerializableExtra("dateVo");
        sohSmcId = getIntent().getStringExtra("sohSmcId");
        sohFilter = sohSmcId == null ? SohFilter.NotSoh() : SohFilter.SohInc(sohSmcId);
        if (getIntent().hasExtra("whoEo")) {
            whoEo = getIntent().getStringExtra("whoEo");
        }
        if (getIntent().hasExtra("edit")) {
            edit = (Boolean) getIntent().getSerializableExtra("edit");
        } else {
            edit = true;
        }
        if (getIntent().hasExtra("documentNumbers")) {
            documentNumbers = getIntent().getStringArrayListExtra("documentNumbers");
            documentNumber = documentNumbers.get(0);
        } else {
            documentNumber = getIntent().getStringExtra("documentNumber");
        }
        transportName = getIntent().getStringExtra("transportName");

        //textContentTitle.setText(Utils.format("Наряд %s", documentNumber));
        if (soh) {
            edit = true;
            textContentTitle.setText("Погрузка на СОХ");
        } else {
            if (edit)
                textContentTitle.setText("Погрузка");
            else
                textContentTitle.setText("Погрузка (ПЕРЕГЛЯД)");
        }

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

        viewTotal.setVisibility(View.GONE);

        setActionDone(textLabelId, buttonAddLabel);

        if (BuildConfig.DEBUG) {
            scanLauncher = registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result != null) {
                            ScanContract scanContract = new ScanContract();
                            ScanIntentResult intentResult = scanContract.parseResult(result.getResultCode(), result.getData());
                            if (intentResult != null) {
                                String cameraBarcode = intentResult.getContents();
                                onBarcodeEvent(cameraBarcode);
                            }
                        }
                    });
            textContentTitle.setOnClickListener(v -> {
                scanBarcode();
                //onBarcodeEvent("{'qr_link':'http://77.222.152.25:17236/mdmz/hs/docs/pack/k0724519-1?yp=23 ','code':'Kominmet','pack':'k0724519-1/23','heats':'813098','party':'0','stand':'DIN EN 10219-1:2006, DIN EN 10219-2:2019','ms':'S235JRH','dim':'40х40х3х6000','qt':110,'ln':660,'wt':2.302,'date':'22.06.2023'}");
                //onBarcodeEvent("http://metinvest.io/qr/&2100&0&108&1275139&/&864532652&001013369&106191&3&1700&1715&ГАРЯЧЕКАТАНИЙ_ЛИСТ__&8.0x1500x6000&S235JR+AR&2023_971000-0899_0&2023|120|&/");
                //onBarcodeEvent("{'code':'Kominmet','pack':'l07512055/22','heats':'212230','party':'0','stand':'ДСТУ 8943:2019','ms':'3ПС','dim':'219х8х12000','qt':10,'ln':120,'wt':4.957,'date':'24.08.2022'}");
                //onBarcodeEvent("http://metinvest.io/qr/&2100&0&106&1165724&/&246355328&0131306-9&11033&2в&4050&4110&ХОЛОДНОКАТАНИЙ_ЛИСТ__&0.7x1000x2100&08КП&2023_991000-0307_0&2023|126|&/");
                //onBarcodeEvent("HTTP://METINVEST.IO/QR/&4900&1&620&1094161&/&94352869&206260-4&1-204515&1156&2565&2570&Лист точеный&50x3x6.000&S235JRH&608385004166&2020&/");
                //onBarcodeEvent("Трубосталь&80х60х4&ГОСТ8639-82&Ст2пс&1211500-1&12000&08-19/21&www.trubostal.net&2000000000398&c9f28ad6-f5a6-11eb-a28f-0cc47ada5628");

                //onBarcodeEvent("SMC06|99957|1436|Труба|0.000000|159.000000|4.000000|2161|ФВ||0|0|TEMP|0|20200404131952|AН4768НР/АН5481ХР");
                //onBarcodeEvent("SMC07|1000|1|[{\"netto\":\"1000\",\"pack\":\"0\",\"tara\":\"0\",\"id\":\"126163\"}]|04.04.2020|test|1-0-0|12345|11.22.33.44.55|test ozm|2000.000000|100.000000|50.000000");


                //processZavod("5&1&2020&2583&2&&0", 50, 5);
                /*if (!addItem(500, 10, "", "5&1&2020&2583&2&&0")) {
                    showWarningNotFreePos();
                }*/
                /*Label l = new Label();
                l.setId("3494");
                onIsUnknown(null, false, l);*/

                //beginLoadLabel("1406", "154219");
                //beginLoadLabel("1434", "2607");
            });
        }
    }

    private void refreshNumber() {
        imageStatus.setVisibility(document == null ? View.GONE : View.VISIBLE);
        if (document != null) {
            imageStatus.setImageResource(Utils.shipStatusToImage(document.getStatus()));
        }
    }

    @Override
    protected String getHelpContent() {
        return "Скануйте бірки товарних позицій.\n\n" +
                "Введіть LabelId в разі якщо бірка не сканується.";
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    /*private void checkEO() {
        Utils.runOnBackground(() -> {
            JsonResult result = app.putStatusEO(document.getDocNumber(), 1, document.getTurnId());

            if (!result.isOk()) {
                edit = false;
                String message = Utils.getJsonStringIgnoreCase(result.getJson(), "message");
                if (whoEo != null && whoEo.length() > 0)
                    textContentTitle.setText("Погрузку блоковано "+whoEo+")");
                else
                    textContentTitle.setText("Погрузка (БЛОКОВАНО)");
                runOnUiThread(() -> blockAdd(message));
            }
        });
    }

    private void blockAdd(String error) {
        if (error != null && !error.isEmpty()) {
            if (whoEo != null && whoEo.length() > 0)
                showDialog(R.drawable.ic_error_24dp, R.string.text_error, "БЛОКОВАНО " + whoEo, null);
            else
                showDialog(R.drawable.ic_error_24dp, R.string.text_error, error, null);
            return;
        }
    }*/

    @Override
    public boolean onItemClick(View view, int position) {
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_LOCATION_SELECT) {
            if (resultCode == RESULT_OK && data != null) {
                String locationCode = data.getStringExtra("locationCode");
                log("Select location: %s", locationCode);

                long id = data.getLongExtra("id", -1);
                if (id > -1) {
                    ShipmentItem item = db.shipmentItemDao().getById(id);
                    if (item != null) {
                        showInfoByLocationCode(locationCode, item.getSapOzm(), item.getLength(), item.getWidth(), item.getThickness(), null,
                                config.isEo()?document.getEoSmcId():
                                        (sohFilter.getSohSmcId() != null ? sohFilter.getSohStorage() : config.getStorage())
                                //sohFilter.getSohSmcId() != null?sohFilter.getSohStorage():config.getStorage()
                        );
                        return;
                    }
                }

                showInfoByLocationCode(locationCode);
            }
        }

        if (requestCode == REQUEST_DEFAULT) {
            if (resultCode == RESULT_OK) {
                escAdd = true;
                escClose = false;
                beginLoad();
                textLabelId.setText(null);
            }
            if (resultCode == REQUEST_CLOSE_NARAD){
                escClose = true;
                onBackPressed();
            }
        }
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) buttonRefreshClick();
        else if (number == 3) buttonAddLabelClick();
    }

    private void buttonRefreshClick() {
        if (isLoading()) return;

        beginLoad();
    }

    private void beginLoad() {
        showLoading(R.string.text_please_wait);
        refreshNumber();
        viewButtons.setVisibility(View.GONE);
        viewTotal.setVisibility(View.GONE);

        //test
        adapter = null;
        listView.setAdapter(null);

        Utils.runOnBackground(() -> {
            String message409 = "";
            document = null;
            JsonResult result;
            if (config.isEo()) {
                result = new JsonResult(); //app.loadShipmentOrdersEO();
                result.setStatus(LoadResultStatus.OK);
            } else
                result = app.loadShipmentOrders(date, date2, transportName, sohFilter);

            List<AdapterItemCard> list = new ArrayList<>();

            if (result.isOk()) {

                document = db.shipmentDocumentDao().getByName(documentNumber, transportName);
if (document == null) return;

                if (config.isEo()) {
                    if (document.getFirstDate() != 0)
                        dateVo = new Date(document.getFirstDate());
                    sohFilter = SohFilter.Eo(document.getEoSmcId(), document.getEoStorage());
                }
                if (isCombined()) {
                    result = app.loadShipmentOrderDetails(dateVo == null ? date : dateVo, documentNumbers, sohFilter);
                } else {
                    result = app.loadShipmentOrderDetails(dateVo == null ? date : dateVo, documentNumber, sohFilter);
                }

                if (result.isOk()) {

                    if (isCombined()) {
                        list = loadCombinedItems();
                    } else {
                        List<ShipmentItem> itemList = db.shipmentItemDao().getByDocument(documentNumber);

                        for (ShipmentItem shipmentItem : itemList) {
                            List<ShipmentItemLoc> locList = db.shipmentItemLocDao().getByItem(shipmentItem.getId());
                            //тредование подсвечивать локацию цветом, если в ней есть деленные бирки
                            //для передачи признака наличия деленных бирок, если divLabel == 1, то в этой локации есть деленые бирки
                            for (ShipmentItemLoc loc : locList) {
                                //loc.setDivLabel("0");
                                /*String url = config.getUrlApi() + "getlocationinfoByOzm";
                                url = net.addUrlParam(url, "smc_id", config.getSmcId());
                                url = net.addUrlParam(url, "location_code", loc.getLocation());
                                url = net.addUrlParam(url, "ozm", shipmentItem.getSapOzm());
                                url = net.addUrlParam(url, "length", shipmentItem.getLength());
                                url = net.addUrlParam(url, "width", shipmentItem.getWidth());
                                url = net.addUrlParam(url, "thickness", shipmentItem.getThickness());
                                url = net.addUrlParam(url, "store", config.getStorage());
                                JsonResult resultLoc = net.downloadJson(url);
                                if (resultLoc.isOk()) {
                                    //JSONObject jsonData = Utils.getJsonObject(resultLoc.getJson(), "data");
                                    loc.setDivLabel(Utils.getJsonStringIgnoreCase(resultLoc.getData(), "result"));
                                }*/
                                    String url = config.getUrlApi() + "getlocationinfo";
                                    url = net.addUrlParam(url, "location_code", loc.getLocation());
                                if (sohFilter.getSohSmcId() != null) {
                                    url = net.addUrlParam(url, "smc_id", sohFilter.getSohSmcId());
                                    url = net.addUrlParam(url, "lgort", sohFilter.getSohStorage());
                                } else if (config.getStorage().length() > 1) {
                                    if (config.isEo()) {
                                        url = net.addUrlParam(url, "smc_id", document.getEoSmcId());
                                        url = net.addUrlParam(url, "store", document.getEoStorage());
                                    } else
                                        url = net.addUrlParam(url, "store", config.getStorage());
                                }
                                    JsonResult resultLoc = net.downloadJson(url);

                                if (resultLoc.isOk()) {
                                    JSONObject jsonData = Utils.getJsonObject(resultLoc.getJson(), "data");
                                    JSONArray array = Utils.getJsonArray(jsonData, "labels");
                                    if (array != null) {
                                        for (int i = 0; i < array.length(); i++) {
                                            JSONObject item = Utils.getJsonObject(array, i);
                                            if (item != null) {
                                                String ozm = Utils.getJsonStringIgnoreCase(item, "saP_Ozm");
                                                if (shipmentItem.getSapOzm().equalsIgnoreCase(ozm)) {
                                                    int netto = Utils.getJsonIntIgnoreCase(item, "netT_Weight");
                                                    int start = Utils.getJsonIntIgnoreCase(item, "start_Weight");
                                                    if (netto > 0 && start > netto) {
                                                        float width = Utils.getJsonFloatIgnoreCase(item, "width");
                                                        float length = Utils.getJsonFloatIgnoreCase(item, "length");
                                                        float thickness = Utils.getJsonFloatIgnoreCase(item, "thickness");
                                                        if ((shipmentItem.getLength() == length) &&
                                                                (shipmentItem.getWidth() == width) &&
                                                                (shipmentItem.getThickness() == thickness)) {
                                                            loc.setDivLabel("1");
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                }
                                list.add(new AdapterItemCard(shipmentItem, locList, this));
                            //}
                        }
                    }
                    if (edit && config.isEo() && !escAdd) {
                        JsonResult resultPut = app.putStatusEO(document.getDocNumber(), 1, document.getTurnId());

                        if (!resultPut.isOk()) {
                            edit = false;
                            message409 = Utils.getJsonStringIgnoreCase(resultPut.getJson(), "message");
                            if (whoEo != null && whoEo.length() > 0)
                                textContentTitle.setText("БЛОКОВАНО "+whoEo);
                            else
                                textContentTitle.setText("Погрузка (БЛОКОВАНО)");
                            //runOnUiThread(() -> blockAdd(message));
                            //result = resultPut;
                        }
                    }
                    escAdd = false;
                }

                Collections.sort(list, (o1, o2) -> Utils.compareLocations(o2.getLargerLocation(), o1.getLargerLocation()));
            }

            JsonResult finalResult = result;
            List<AdapterItemCard> finalList = list;
            String message = message409;
            runOnUiThread(() -> endLoad(finalResult, finalList, message));
        });
    }

    private void endLoad(JsonResult result, List<AdapterItemCard> list, String message) {
        hideLoading();
        viewButtons.setVisibility(result.isOk() ? View.VISIBLE : View.GONE);
        viewContentData.setVisibility(result.isOk() && !list.isEmpty() ? View.VISIBLE : View.GONE);
        textNotFound.setVisibility(!result.isOk() || list.isEmpty() ? View.VISIBLE : View.GONE);
        refreshNumber();

        if (result.isOk()) {
            adapter = new FlexibleAdapter<>(list);
            adapter.addListener(this);
            listView.setAdapter(adapter);
            scrollView.post(() -> scrollView.scrollTo(0, 0));
            calcTotal();
            viewTotal.setVisibility(View.VISIBLE);
            if (message != null && message != "")
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, message, null);
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
        }
    }

    private void calcTotal() {

        int totalNett = 0;
        totalFact = 0;

        if (adapter != null) {
            List<AdapterItemCard> itemList = adapter.getCurrentItems();
            for (AdapterItemCard itemCard : itemList) {
                totalNett += itemCard.getSapWeightNettAll();
                totalFact += itemCard.getSapWeightNettFactAll();
            }
        }

        textTotal.setText(Utils.format(
                "%.3f / %.3f / %.3f",
                totalNett / 1000.0f,
                totalFact / 1000.0f,
                (totalNett - totalFact < 0 ? 0 : ((totalNett - totalFact) / 1000.0f))
        ));
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {
        if (isLoading()) return;
        if (edit)
            runOnUiThread(() -> {

                ScanItem scanItem = new ScanItem(barcodeData);
                if (!scanItem.isCorrect()) {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_label, null);
                    return;
                }

                if ((scanItem.getType() == ScanItem.ScanItemType.LABELID || scanItem.getType() == ScanItem.ScanItemType.SMC06)) {
                    beginLoadLabel(scanItem.getData(0), false, true);
                } else if (scanItem.getType() == ScanItem.ScanItemType.SMC07) {
                    checkIsUnknown(scanItem);
                } else {
                    beginLoadLabelQR(barcodeData);
                }
            });
    }

    @Override
    protected void onIsUnknown(ScanItem scanItem, boolean unknown, Label label) {
        if (unknown) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_ship_label_temp, null);
        } else {
            beginLoadLabel(label.getId(), false, false);
        }
    }

    private void beginLoadLabel(String labelId, boolean isManual, boolean flagScan) {
        //buttonWeighing.setEnabled(statusEO == 2 || statusEO == 0)
        if (document.getStatus() >= 1 && !config.isEo()) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.cant_edit_closed_ship, null);
            return;
        }

        showLoading(R.string.text_please_wait);
        buttonAddLabel.setEnabled(false);
        textLabelId.setEnabled(false);

        Utils.runOnBackground(() -> {
            LabelStat labelStat = isManual ? new LabelStat(true, "shipping") : null;
            JsonResult result;
            if (config.isEo())
                result = net.loadLabelInfo(document.getEoSmcId(), labelId, labelStat);
            else {
                result = net.loadLabelInfo(labelId, labelStat);
            }

            runOnUiThread(() -> endLoadLabel(labelId, isManual, result, false, false, flagScan));
        });

    }

    private void beginLoadLabelQR(String qrCode) {

        if (document.getStatus() >= 1 && !config.isEo()) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.cant_edit_closed_ship, null);
            return;
        }

        showLoading(R.string.text_please_wait);
        buttonAddLabel.setEnabled(false);
        textLabelId.setEnabled(false);

        Utils.runOnBackground(() -> {
            if (qrCode == null || qrCode.isEmpty()) {
                return;
            }
            //Utils.runOnBackground(() -> {

            String url = config.getUrlApi() + "getLabelIdQRId";
            url = net.addUrlParam(url, "qr_code", Base64.getEncoder().encodeToString(qrCode.getBytes()));
            JsonResult result = net.downloadJson(url);

            if (result.isOk()) {
                String labelId = Utils.getJsonStringIgnoreCase(result.getJson(), "data");
                if (labelId != null && !labelId.isEmpty()) {
                    textLabelId.setText(labelId);
                    String urlLabel = config.getUrlApi() + "getlabelinfo";
                    urlLabel = net.addUrlParam(urlLabel, "label_id", labelId);
                    urlLabel = net.addUrlParam(urlLabel, "smc_id", "NULL");
                    JsonResult resultLabel = net.downloadJson(urlLabel);
                    if (resultLabel.isOk()) {
                        //GET LABEL
                        JSONObject json = Utils.getJsonObject(resultLabel.getJson(), "data");
                        Label label = Label.fromJson(json, labelId);
                        if (label != null) {
                            hideLoading();
                            runOnUiThread(() -> endLoadLabel(labelId, false, resultLabel, false, false, true));
                        } else {
                            runOnUiThread(() -> {
                                hideLoading();
                                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.qr_not_found, null);
                                return;
                            });
                        }
                    }
                } else {
                    //label.setId(labelId);
                    runOnUiThread(() -> {
                        hideLoading();
                        showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.qr_not_found, null);
                        return;
                    });
                }
            } else {
                runOnUiThread(() -> {
                    hideLoading();
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_error, qrCode, null);
                    return;
                });
            }
            //});
        });

    }

    private boolean checkLabelStatus(String status) {
        return status.equalsIgnoreCase("7");
                /*status.equalsIgnoreCase("1") ||
                        status.equalsIgnoreCase("2") ||
                        status.equalsIgnoreCase("3") ||
                        status.equalsIgnoreCase("4") ||
                        status.equalsIgnoreCase("5") ||
                        status.equalsIgnoreCase("6") ||
                        status.equalsIgnoreCase("7") ||
                        status.equalsIgnoreCase("8") ||
                        status.equalsIgnoreCase("9") ||
                status.equalsIgnoreCase("90") ||
                status.equalsIgnoreCase("91");*/
    }

    private void endLoadLabel(String labelId, boolean isManual, JsonResult result, boolean ignoreWarning, boolean ignoreLength, boolean flagScan) {
        hideLoading();
        buttonAddLabel.setEnabled(true);
        textLabelId.setEnabled(true);

        JSONObject json = Utils.getJsonObject(result.getJson(), "data");

        if (result.isOk() && json != null) {

            Label label = Label.fromJson(json);

			/*float width = Utils.getJsonFloatIgnoreCase(json, "width");
			float length = Utils.getJsonFloatIgnoreCase(json, "length");
			float thickness = Utils.getJsonFloatIgnoreCase(json, "thickness");
			String ozm = Utils.getJsonStringIgnoreCase(json, "ozm").replace("null", "");
			boolean theor = Utils.getJsonStringIgnoreCase(json, "teoR_Weight").equalsIgnoreCase("true");
			int nett = (int) Utils.getJsonFloatIgnoreCase(json, "netT_Weight");
			String status = Utils.getJsonStringIgnoreCase(json, "statuS_OUT");
			String batch = Utils.jsonExist(json, "saP_Batch") ? Utils.getJsonStringIgnoreCase(json, "saP_Batch") : Utils.getJsonStringIgnoreCase(json, "batch");
			boolean release = Utils.getJsonStringIgnoreCase(json, "release").equalsIgnoreCase("true");*/

            if (label.isTemp()) {
                showDialog(R.drawable.ic_error_24dp, R.string.text_error, R.string.error_ship_label_temp, null);
                return;
            }

            if (!label.isRelease()) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_label_not_released, null);
                return;
            }

            if (!config.isEo() && !((sohFilter.getSohSmcId() != null)?sohFilter.getSohStorage():config.getStorage()).equalsIgnoreCase(label.getStorage())) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.label_wrong_storage, label.getStorage()), null);
                return;
            }
            //type label.discount is string
            float labelDiscount;
            try {
                labelDiscount = Utils.parseDiscount(label.getLowPricePercent());
            } catch (Exception e) {
                labelDiscount = 0;
            }

            FindOzmResult findResult = findItemByOzm(label.getOzm(), label.getWidth(), label.getLength(), label.getThickness(), labelDiscount, ignoreLength);

            if (findResult.status == FindOzmStatus.OK) {

                if (label.getWeightNetto() <= 0) {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.ship_label_netto_zero, null);
                    return;
                }

                /*if (!ignoreWarning && !checkLabelStatus(status)) {
                    showDialogConfirm(R.string.text_warning, getString(R.string.ship_confirm_label_status_warning, batch), (dialog, which) -> endLoadLabel(labelId, result, true, ignoreLength));
                    return;
                }*/

                Intent intent = new Intent(this, ShipAddActivity.class);
                intent.putExtra("date", date);
                intent.putExtra("dateVo", dateVo);
                intent.putExtra("soh", soh);
                if (sohFilter.getSohSmcId() != null)
                    intent.putExtra("smcIdSoh", sohFilter.getSohSmcId());
                intent.putExtra("itemId", findResult.itemCard.getShipmentItem().getId());
                intent.putExtra("labelId", labelId);
                intent.putExtra("flagScan", flagScan);
                intent.putExtra("isTheorWeight", label.isTheor());

                ArrayList<Long> longList = new ArrayList<>();
                List<ShipmentItem> anotherList = findResult.itemCard.getAnotherShipmentItems();
                for (ShipmentItem shipmentItem : anotherList) {
                    longList.add(shipmentItem.getId());
                }
                intent.putExtra("anotherList", longList);

                startActivityForResult(intent, REQUEST_DEFAULT);
            } else if (findResult.status == FindOzmStatus.ERROR_LENGTH) {
                showDialogConfirm(R.string.text_warning, R.string.ship_ozm_size_length_not_found, (dialog, which) -> endLoadLabel(labelId, isManual, result, ignoreWarning, true, flagScan));
            } else if (findResult.status == FindOzmStatus.ERROR_SIZE) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning,
                        Utils.format("<i>Наряд %s</i><br>%s", documentNumber, getString(R.string.ship_ozm_size_not_found)), null);
            } else if (findResult.status == FindOzmStatus.ERROR_DISCOUNT) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning,
                        Utils.format("<i>Наряд %s</i><br>%s<br>%s%s%s", documentNumber, getString(R.string.ship_ozm_discount_not_found), "Уцінка по бірці ", labelDiscount, ", має бути інша"), null);
                return;

            } else {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, Utils.format("<i>Наряд %s</i><br>%s", documentNumber, getString(R.string.ship_ozm_not_found)), null);
            }

        } else if (result.getStatus() == LoadResultStatus.ZERO) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_identity_error, null);
        } else if (result.getStatus() == LoadResultStatus.S007) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_s007, null);
        } else {
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoadLabel(labelId, isManual, flagScan));
        }
    }

    static class FindOzmResult {
        public AdapterItemCard itemCard;
        public FindOzmStatus status;

        public FindOzmResult(AdapterItemCard itemCard, FindOzmStatus status) {
            this.itemCard = itemCard;
            this.status = status;
        }
    }

    private FindOzmResult findItemByOzm(String ozm, float width, float length, float thickness, float discount, boolean ignoreLength) {

        if (adapter == null) return new FindOzmResult(null, FindOzmStatus.NOT_FOUNT);
        List<AdapterItemCard> itemList = adapter.getCurrentItems();

        FindOzmResult result = new FindOzmResult(null, FindOzmStatus.NOT_FOUNT);

        for (int i = 0; i < itemList.size(); i++) {

            AdapterItemCard item = itemList.get(i);

            if (!item.getShipmentItem().getDelFlag().equalsIgnoreCase("1") && item.getShipmentItem().getSapOzm().equalsIgnoreCase(ozm)) {
                if (item.getShipmentItem().getWidth() == width && item.getShipmentItem().getThickness() == thickness) {
                    if (item.getShipmentItem().getLength() == length || ignoreLength) {
                        if (Utils.parseDiscount(item.getShipmentItem().getDiscount()) == discount)
                            return new FindOzmResult(item, FindOzmStatus.OK);
                        else result = new FindOzmResult(item, FindOzmStatus.ERROR_DISCOUNT);
                    } else {
                        result = new FindOzmResult(item, FindOzmStatus.ERROR_LENGTH);
                    }
                } else {
                    if (result.status != FindOzmStatus.ERROR_LENGTH && result.status != FindOzmStatus.ERROR_DISCOUNT)
                        result = new FindOzmResult(item, FindOzmStatus.ERROR_SIZE);
                }
            }
        }

        return result;
    }

    public void buttonAddLabelClick() {

        if (isLoading() || !buttonAddLabel.isEnabled()) return;

        String labelId = textLabelId.getText().toString();

        if (labelId.length() == 0) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.warning_labelid_empty, null);
            textLabelId.requestFocus();
            return;
        }
        if (edit)
            beginLoadLabel(labelId, true, false);
    }

    @Override
    public void onBackPressed() {
        if (config.isEo())
            Utils.runOnBackground(() -> {
                if (edit) {
                    JsonResult resultPut = app.putStatusEO(document.getDocNumber(), escClose ? 3 : 2, document.getTurnId());
                    if (!resultPut.isOk()) {
                        String message = Utils.getJsonStringIgnoreCase(resultPut.getJson(), "message");
                        if (message != null && !message.isEmpty())
                            runOnUiThread(() -> showDialog(R.drawable.ic_error_24dp, R.string.text_error, message, null));
                        else
                            runOnUiThread(() -> showDialog(R.drawable.ic_error_24dp, R.string.text_error, "Помилка виконання putStatusEO", null));
                    } else {
                        Intent intent = new Intent();
                        if (escClose) {
                            intent.putExtra("action", "close");
                            JsonResult result = app.loadShipmentFact(dateVo == null ? date : dateVo, documentNumber, transportName);
                            if (result.isOk()) {
                                document = db.shipmentDocumentDao().getByName(documentNumber, transportName);
                                totalFact = document.getFact();
                            }
                        }
                        intent.putExtra("fact", totalFact);
                        setResult(RESULT_OK, intent);
                        super.onBackPressed();
                    }
                } else {
                    Intent intent = new Intent();
                    setResult(RESULT_OK, intent);
                    super.onBackPressed();
                }
            });
        else {
            Intent intent = new Intent();
            setResult(RESULT_OK, intent);
            super.onBackPressed();
        }
    }

    @Override
    public void onViewClick(AdapterItemCard item) {
        List<ShipmentItemLoc> locList = item.getLocList();
        if (locList != null && !locList.isEmpty()) {

            if (locList.size() == 1) {

                showInfoByLocationCode(
                        locList.get(0).getLocation(),
                        item.getShipmentItem().getSapOzm(),
                        item.getShipmentItem().getLength(),
                        item.getShipmentItem().getWidth(),
                        item.getShipmentItem().getThickness(),
                        null,
                        config.isEo()?document.getEoSmcId():
                                (sohFilter.getSohSmcId() != null ? sohFilter.getSohStorage() : config.getStorage())
                );

            } else {

                Intent intent = new Intent(this, LocListActivity.class);

                ArrayList<String> locationList = new ArrayList<>();
                ArrayList<String> divList = new ArrayList<>();
                ArrayList<Integer> weightList = new ArrayList<>();
                for (int i = 0; i < locList.size(); i++) {
                    locationList.add(locList.get(i).getLocation());
                    divList.add(locList.get(i).getDivLabel());
                    weightList.add(locList.get(i).getSumWeight());
                }

                intent.putStringArrayListExtra("locationList", locationList);
                intent.putStringArrayListExtra("sapBatchList", divList);
                intent.putIntegerArrayListExtra("weightList", weightList);
                intent.putExtra("id", item.getShipmentItem().getId());

                startActivityForResult(intent, REQUEST_LOCATION_SELECT);
            }
        }
    }

    private int findIn(List<AdapterItemCard> list, ShipmentItem shipmentItem) {

        for (int i = 0; i < list.size(); i++) {

            AdapterItemCard itemCard = list.get(i);
            if (itemCard.getShipmentItem().getSapOzm().equalsIgnoreCase(shipmentItem.getSapOzm())
                    &&
                    itemCard.getShipmentItem().getWidth() == shipmentItem.getWidth() &&
                    itemCard.getShipmentItem().getLength() == shipmentItem.getLength() &&
                    itemCard.getShipmentItem().getThickness() == shipmentItem.getThickness()
            ) {
                return i;
            }

        }

        return -1;
    }

    private int findIn(List<ShipmentItemLoc> list, ShipmentItemLoc itemLoc) {

        for (int i = 0; i < list.size(); i++) {

            ShipmentItemLoc itemCard = list.get(i);
            if (itemCard.getLocation().equalsIgnoreCase(itemLoc.getLocation())) {
                return i;
            }

        }

        return -1;
    }

    private List<AdapterItemCard> loadCombinedItems() {

        List<AdapterItemCard> list = new ArrayList<>();

        for (String docId : documentNumbers) {

            List<ShipmentItem> shipmentItems = db.shipmentItemDao().getByDocument(docId);
            for (ShipmentItem shipmentItem : shipmentItems) {

                List<ShipmentItemLoc> locListNew = db.shipmentItemLocDao().getByItem(shipmentItem.getId());

                int index = findIn(list, shipmentItem);
                if (index == -1) {
                    list.add(new AdapterItemCard(shipmentItem, locListNew, this));
                } else {

                    AdapterItemCard itemCard = list.get(index);
                    itemCard.addAnotherShipmentItem(shipmentItem);

                    /*List<ShipmentItemLoc> locList = itemCard.getLocList();

                    for (ShipmentItemLoc locNew : locListNew) {
                        int indexLoc = findIn(locList, locNew);
                        if (indexLoc == -1) {
                            locList.add(locNew);
                        } else {
                            locList.get(indexLoc).setSumWeight(locList.get(indexLoc).getSumWeight() + locNew.getSumWeight());
                        }
                    }

                    itemCard.setLocList(locList);*/

                }

            }

        }

        return list;
    }
}
