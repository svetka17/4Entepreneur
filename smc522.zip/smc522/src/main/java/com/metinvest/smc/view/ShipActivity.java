package com.metinvest.smc.view;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.metinvest.smc.BuildConfig;
import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ShipActivity extends MyActivity {

    @BindView(R.id.buttonDate)
    Button buttonDate;
    @BindView(R.id.textYesterday)
    TextView textYesterday;
    @BindView(R.id.checkPeriod)
    CheckBox checkPeriod;

    private Date date;
    private Thread thread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ship);
        ButterKnife.bind(this);
        date = Calendar.getInstance().getTime();

        if (BuildConfig.DEBUG) {
            Calendar calendar = Calendar.getInstance();
            calendar.set(2019, 8 - 1, 19);
            //date = calendar.getTime();
        }

        refreshButtons();
        textYesterday.setVisibility(View.GONE);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        //beginLoadStat();
    }

    /*private void beginLoadStat() {

        killThread();

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, -1);
        Date yesterday = calendar.getTime();

        log("beginLoadStat %s", app.getDateFormat().format(yesterday));
        textYesterday.setVisibility(View.GONE);

        thread = Utils.runOnBackground(() -> {

            if (thread != null) {
                log("start thread #%d", thread.getId());

                NetworkResult result = app.loadShipmentOrders(yesterday, null);
                long total = 0;

                if (result.isOk()) {
                    total = db.shipmentTransportDao().getCountGreen();
                }

                long finalTotal = total;
                runOnUiThread(() -> endLoadStat(result, finalTotal));
            }

        });
    }*/

    private void killThread() {
        Utils.killThread(thread);
    }

    private void endLoadStat(JsonResult result, long total) {
        if (thread != null) {
            log("stop thread #%d", thread.getId());
            thread = null;
            textYesterday.setText(getString(R.string.ship_yesterday, total));
            textYesterday.setVisibility(total > 0 ? View.VISIBLE : View.GONE);
        }
    }

    private void refreshButtons() {
        buttonDate.setText(app.getDateFormat().format(date));
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) buttonDateClick();
        else if (number == 4) buttonSohClick();
        else if (number == 5) buttonAcceptClick(null);
    }

    private void buttonSohClick() {
        if (getSubSmcCount() == 0) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, "Немає складів СОХ!", null);
            return;
        }

        Intent intent = new Intent(this, SubSmcSelectActivity.class);
        startActivityForResult(intent, REQUEST_ACTION);
    }
    private int getSubSmcCount() {
        return getSubSmcList().size();
    }

    private List<String> getSubSmcList() {
        List<String> res = new ArrayList<>();
        JSONArray jsonArray = Utils.getJsonArray(config.getSmcListJson());
        for (int i = 0; jsonArray != null && i < jsonArray.length(); i++) {
            JSONObject jsonObject = Utils.getJsonObject(jsonArray, i);
            int parent = Utils.getJsonIntIgnoreCase(jsonObject, "parent");
            String smcId = Utils.getJsonStringIgnoreCase(jsonObject, "smcid");
            if (parent > 0) res.add(smcId);
        }
        return res;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ACTION && resultCode == RESULT_OK && data != null) {
            String smcId = data.getStringExtra("smc_id");
            log("COX SMC_ID: %s", smcId);
            buttonAcceptClick(smcId);
        }
    }

    private void buttonDateClick() {
        Calendar calendar = Utils.toCalendar(date);

        DatePickerDialog dialog = new DatePickerDialog(this,
                (view1, year, month, dayOfMonth) -> {
                    Calendar calendar1 = Calendar.getInstance();
                    calendar1.set(year, month, dayOfMonth);
                    date = calendar1.getTime();
                    refreshButtons();
                    //beginLoadStat();
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DATE));
        dialog.show();
    }

    private void buttonAcceptClick(String sohSmcId) {
        /*Intent intent = new Intent(this, IncTransportListActivity.class);
        intent.putExtra("dateFrom", dateFrom);
        intent.putExtra("dateTo", dateTo);
        intent.putExtra("isNew", getIntent().getBooleanExtra("isNew", false));
        intent.putExtra("sohSmcId", sohSmcId);
        intent.putExtra("isManager", true);
        startActivity(intent);*/
        killThread();
        boolean usePeriod = checkPeriod.isChecked();
        Utils.runOnBackground(() -> {
            Utils.sleep(100);
            runOnUiThread(() -> {
                Intent intent = new Intent(this, ShipCarsActivity.class);
                Date date1 = date;
                Date date2 = date;

                if (usePeriod) {
                    date1 = Utils.addDays(date1, -3);
                    date2 = Utils.addDays(date2, +2);
                }

                intent.putExtra("date", date1);
                intent.putExtra("date2", date2);
                intent.putExtra("sohSmcId", sohSmcId);
                if (config.getStorage().length() > 1)
                    intent.putExtra("lgort", config.getStorage());
                startActivity(intent);
            });
        });
    }
}
