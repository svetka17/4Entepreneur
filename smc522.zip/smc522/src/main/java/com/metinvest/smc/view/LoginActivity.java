package com.metinvest.smc.view;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.metinvest.smc.BuildConfig;
import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Utils;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LoginActivity extends MyActivity implements IScan {

	@BindView(R.id.buttonEnter)
	Button buttonEnter;
	@BindView(R.id.textUser)
	EditText textUser;
	@BindView(R.id.textPassword)
	EditText textPassword;
	@BindView(R.id.textAppVersion)
	TextView textVersion;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		ButterKnife.bind(this);

		textVersion.setText(getString(R.string.text_app_version, app.getApkVersionName()));
		textUser.setText(config.getUserName());

		checkMyPermission();

		if (BuildConfig.DEBUG) {
			textUser.setText("V.Vasil.Kravchenko");
			textPassword.setText("Workpass!-123");
			//textUser.setText("evgeniy.chertoprudov");
			//textPassword.setText("Pass716word");
		}

		if (textUser.getText().length() > 0)
			textPassword.requestFocus();
		else
			textUser.requestFocus();

		setActionDone(textPassword, buttonEnter);
	}

	@Override
	public void onBarcodeEvent(String barcodeData) {
		runOnUiThread(() -> {
			if (textUser.isFocused()) textUser.setText(barcodeData);
			else if (textPassword.isFocused()) textPassword.setText(barcodeData);
		});
	}

	private String[] getDeniedPermissions(String[] permissionList) {
		List<String> list = new ArrayList<>();

		for (String permission : permissionList) {
			if (checkSelfPermission(permission) == PackageManager.PERMISSION_DENIED)
				list.add(permission);
		}

		return list.toArray(new String[0]);
	}

	public void checkMyPermission() {

		String[] permissionListDenied = getDeniedPermissions(new String[]{
				Manifest.permission.READ_EXTERNAL_STORAGE,
				Manifest.permission.WRITE_EXTERNAL_STORAGE,
				Manifest.permission.ACCESS_FINE_LOCATION,
				Manifest.permission.ACCESS_COARSE_LOCATION,
				Manifest.permission.CHANGE_WIFI_STATE,
				Manifest.permission.READ_PHONE_STATE,
				Manifest.permission.CALL_PHONE
		});

		if (permissionListDenied.length > 0) {
			log("Asked for permissions: %d", permissionListDenied.length);
			ActivityCompat.requestPermissions(this, permissionListDenied, REQUEST_PERMISSION);
		}
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == REQUEST_PERMISSION) {
			log("onRequestPermissionsResult");
			for (int i = 0; i < permissions.length; i++) {
				log("%s %s", permissions[i], grantResults[i] == PackageManager.PERMISSION_GRANTED ? "OK" : "FAIL");
			}
		}
	}

	public void buttonEnterClick() {
		beginAuth();
	}

	@Override
	protected void onButtonCancelClick() {
		log("onButtonCancelClick");
	}

	private void beginAuth() {

		if (isLoading()) return;

		if (config.getSmcId().isEmpty()) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.smc_id_empty, (dialog, which) -> openSettings(true));
			return;
		}

		if (textUser.getText().toString().trim().length() == 0) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_login_pass_empty, null);
			textUser.requestFocus();
			return;
		} else if (textPassword.getText().toString().trim().length() == 0) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_login_pass_empty, null);
			textPassword.requestFocus();
			return;
		}

		buttonEnter.setEnabled(false);
		showLoading(R.string.text_auth_connecting, false);

		Utils.runOnBackground(() -> {
			String url = config.getUrlApi() + "authorize";
			url = net.addUrlParam(url, "user", textUser.getText().toString());
			url = net.addUrlParam(url, "password", textPassword.getText().toString());
			url = net.addUrlParam(url, "smcid", config.getSmcId());
			JsonResult result = net.downloadJson(url);
			runOnUiThread(() -> endAuth(result));
		});
	}

	//Логін або пароль невірний
	//Ви залогінились більше ніж 3 дні тому. Необхідно вийти і зайти в систему знов

	private void endAuth(JsonResult result) {
		buttonEnter.setEnabled(true);
		hideLoading();

		JSONObject jsonData = Utils.getJsonObject(result.getJson(), "data");
		if (result.getStatus() == LoadResultStatus.OK && jsonData != null) {
			app.authUser(jsonData, textUser.getText().toString());
			setResult(RESULT_OK);
			finish();
		} else if (result.getStatus() == LoadResultStatus.S000) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.s000_login), (dialog, which) -> textPassword.requestFocus());
		} else if (result.getStatus() == LoadResultStatus.S005) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.s005_login), (dialog, which) -> textPassword.requestFocus());
		} else {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, app.getNetworkErrorMessage(result), null);
		}
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 2) textUser.requestFocus();
		else if (number == 3) textPassword.requestFocus();
		else if (number == 4) buttonEnterClick();
		else if (number == 5) buttonSettingsClick();
		else if (number == 6) buttonOfflineClick();
	}

	private void buttonOfflineClick() {
		if (config.getSmcId().isEmpty()) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.smc_id_empty, (dialog, which) -> openSettings(true));
			return;
		}

		startActivity(new Intent(this, OfflineActivity.class));
	}

	private void buttonSettingsClick() {
		if (isLoading()) return;

		openSettings();
	}

	private void openSettings() {
		openSettings(false);
	}

	private void openSettings(boolean focusSmcId) {
		Intent intent = new Intent(this, SettingsActivity.class);
		intent.putExtra("focusSmcId", focusSmcId);
		startActivity(intent);
	}

	@Override
	public void onBackPressed() {
		//block back button
	}

	@Override
	protected String getHelpContent() {
		return "Введіть логін та пароль користвача.\n\n" +
				"Перехід між полями використовуйте TAB\n\n" +
				"F4 - авторизуватися\n\n" +
				"F5 - меню налаштування входу";
	}
}
