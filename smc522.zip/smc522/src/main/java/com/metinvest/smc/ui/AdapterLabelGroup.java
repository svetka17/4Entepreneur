package com.metinvest.smc.ui;

import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractExpandableItem;
import eu.davidea.viewholders.ExpandableViewHolder;

public class AdapterLabelGroup extends AbstractExpandableItem<AdapterLabelGroup.ViewHolder, AdapterLabel> {

    private final String name, ozm;
    private final float width, length, thickness;
    private boolean isTheor;
    private int theorCount;
    private int totalNetto;
    private int totalFact = 0;

    public AdapterLabelGroup(String name, float width, float length, float thickness, String ozm) {
        this.name = name;
        this.width = width;
        this.length = length;
        this.thickness = thickness;
        this.ozm = ozm;
		this.totalNetto = -1;
		this.isTheor = false;
		this.theorCount = 0;
	}

	public void setTheor(int count) {
		isTheor = true;
		theorCount = count;
	}

    public boolean isTheor() {
        return isTheor;
    }

    public int getTheorCount() {
		return theorCount;
	}

	public int getTotalFact() {
		return totalFact;
	}

	public void setTotalFact(int totalFact) {
		this.totalFact = totalFact;
	}

	public int getTotalNetto() {
        return totalNetto;
    }

    public void setTotalNetto(int totalNetto) {
        this.totalNetto = totalNetto;
    }

    public String getName() {
        return name;
    }

    public String getOzm() {
        return ozm;
    }

    public float getWidth() {
        return width;
    }

    public float getLength() {
        return length;
    }

    public float getThickness() {
        return thickness;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterLabelGroup && (
                ((AdapterLabelGroup) o).getName().equalsIgnoreCase(getName())
                        && ((AdapterLabelGroup) o).getWidth() == getWidth()
                        && ((AdapterLabelGroup) o).getLength() == getLength()
                        && ((AdapterLabelGroup) o).getThickness() == getThickness()
        );
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_label_group;
    }

    @Override
    public ViewHolder createViewHolder(View view, FlexibleAdapter adapter) {
        return new ViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter adapter, ViewHolder holder, int position, List payloads) {

        refreshHeader(holder);

        View.OnClickListener headerListener = v -> {
            holder.toggleExpansion();
            refreshHeader(holder);
        };

        holder.itemView.setOnClickListener(headerListener);
        holder.imageExpand.setVisibility(hasSubItems() ? View.VISIBLE : View.INVISIBLE);
        holder.imageExpand.setOnClickListener(headerListener);
        holder.textTitle.setOnClickListener(headerListener);
    }

    private void refreshHeader(ViewHolder holder) {

        StringBuilder sb = new StringBuilder();
        sb.append(Utils.format("<b>%s</b>", Html.escapeHtml(getName())));
        String size = App.getInstance().sizeToString(
                getWidth(), getLength(), getThickness()
        );
        if (size.trim().length() > 0) sb.append(Utils.format("<br>%s", size));
        sb.append(Utils.format("<br>ОЗМ: %s", getOzm().length() > 0 ? getOzm() : "<i><font color=\"#303030\">-</font></i>"));
        if (totalNetto != -1) {
            if (totalFact == 0) {
                sb.append(Utils.format( "<br>Вага НЕТТО, тн: %.3f", totalNetto / 1000.0f));
            } else {
                sb.append(Utils.format( "<br>НЕТТО план, тн: %.3f", totalNetto / 1000.0f));
                sb.append(Utils.format( "<br>НЕТТО факт, тн: %.3f", totalFact / 1000.0f));
            }
        }

        if (isTheor) {
            sb.append(Utils.format("<br>Кількість: %d", theorCount));
        }

        holder.textTitle.setText(App.getInstance().fromHtml(sb.toString()));

        holder.imageExpand.setImageDrawable(ContextCompat.getDrawable(holder.itemView.getContext(),
                isExpanded() ? R.drawable.ic_keyboard_arrow_down_black_24dp : R.drawable.ic_keyboard_arrow_right_black_24dp));
    }

    static class ViewHolder extends ExpandableViewHolder {

        @BindView(R.id.imageExpand)
        ImageView imageExpand;
        @BindView(R.id.textTitle)
        TextView textTitle;

        ViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            ButterKnife.bind(this, view);
        }

        @Override
        public void toggleExpansion() {
            super.toggleExpansion();
        }
    }
}