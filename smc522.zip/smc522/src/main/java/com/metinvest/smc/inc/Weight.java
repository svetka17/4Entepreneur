package com.metinvest.smc.inc;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import com.metinvest.smc.tools.Utils;

public class Weight implements Parcelable {

    public static final Creator<Weight> CREATOR = new Creator<Weight>() {
        @Override
        public Weight createFromParcel(Parcel source) {
            return new Weight(source);
        }

        @Override
        public Weight[] newArray(int size) {
            return new Weight[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(netto);
        dest.writeInt(pack);
        dest.writeInt(tara);
        dest.writeString(id);
        dest.writeString(idQr);
        dest.writeString(batch);
        dest.writeString(scanLabelId);
        dest.writeString(barcode);
    }

    private int netto, pack, tara;
    private String id, idQr;
    private String batch, scanLabelId;
    private String barcode;

    protected Weight(Parcel in) {
        netto = in.readInt();
        pack = in.readInt();
        tara = in.readInt();
        id = in.readString();
        idQr = in.readString();
        batch = in.readString();
        scanLabelId = in.readString();
        barcode = in.readString();
    }

    public Weight(int netto, int pack, int tara) {
        this(netto, pack, tara, "", "", "", "", "");
    }

    public Weight(int netto, int pack, int tara, String labelId, String idQr, String batch, String scanLabelId, String barcode) {
        this.netto = netto;
        this.pack = pack;
        this.tara = tara;
        this.id = labelId;
        this.idQr = idQr;
        this.batch = batch;
        this.scanLabelId = scanLabelId;
        this.barcode = barcode;
    }

    public String getScanLabelId() {
        return scanLabelId;
    }

    public void setScanLabelId(String scanLabelId) {
        this.scanLabelId = scanLabelId;
    }

    public int getNetto() {
        return netto;
    }

    public int getBrutto() {
        return netto + pack + tara;
    }

    public void setNetto(int netto) {
        this.netto = netto;
    }

    public int getPack() {
        return pack;
    }

    public void setPack(int pack) {
        this.pack = pack;
    }

    public int getTara() {
        return tara;
    }

    public void setTara(int tara) {
        this.tara = tara;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdQr() {
        return idQr;
    }

    public void setIdQr(String idQr) {
        this.idQr = idQr;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    @NonNull
    @Override
    public String toString() {
        return Utils.format("%s%s%s%s%d/%d/%d кг%s",
                id != null && id.isEmpty() ? "" : Utils.format("[labelId %s] ", id),
                idQr != null && idQr.isEmpty() ? "" : Utils.format("[IdQr %s] ", idQr),
                batch != null && batch.isEmpty() ? "" : Utils.format("[batch %s] ", batch),
                scanLabelId != null && scanLabelId.isEmpty() ? "" : Utils.format("[scanLID %s] ", scanLabelId),
                pack, tara, netto,
                barcode != null && barcode.isEmpty() ? "" : " (+barcode)");
    }
}
