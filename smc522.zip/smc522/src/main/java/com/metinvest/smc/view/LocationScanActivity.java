package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LocationScanActivity extends MyActivity implements IScan {

    @BindView(R.id.textContent)
    TextView textContent;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;
    private String locationCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_scan);
        ButterKnife.bind(this);
        setLocation(null);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        } else if (number == 4) {
            buttonLocationSelectClick();
        }
    }

    private void buttonLocationSelectClick() {
        if (isLoading()) return;

        Intent intent = new Intent(this, LocationSelectActivity.class);
        startActivityForResult(intent, REQUEST_LOCATION_SELECT);
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        Intent intent = new Intent();
        intent.putExtra("locationCode", locationCode);
        setResult(RESULT_OK, intent);
        finish();
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {
        if (isLoading()) return;

        runOnUiThread(() -> {

            setLocation(null);
            ScanItem scanItem = new ScanItem(barcodeData);

            if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONID) {

                if (scanItem.isCorrect()) {
                    beginLoadLocationById(scanItem.getData(0));
                } else {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.location_identity_error, null);
                }
            }

            if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONCODE) {

                if (scanItem.isCorrect()) {
                    setLocation(scanItem.getData(0));
                } else {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.location_identity_error, null);
                }
            }

        });
    }

    private void beginLoadLocationById(String newLocationId) {
        if (isLoading()) return;

        showLoading(R.string.text_please_wait);
        Utils.runOnBackground(() -> {
            String newLocationCode = net.getLocationCode(newLocationId);
            runOnUiThread(() -> {
                hideLoading();
                setLocation(newLocationCode);
            });
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_LOCATION_SELECT && resultCode == RESULT_OK && data != null) {
            setLocation(data.getStringExtra("locationCode"));
            buttonAcceptClick();
        }

    }

    private void setLocation(String newLocationCode) {
        locationCode = newLocationCode;

        String data;

        if (locationCode == null) {
            data = getString(R.string.text_location_scan_prompt_f4);
        } else {
            data = Utils.format("Локація: %s", locationCode);
        }

        textContent.setText(data);
        buttonAccept.setEnabled(locationCode != null);
    }
}
