package com.metinvest.smc.tools;

public enum PrinterType {
	UNKNOWN(0),
	HONEYWELL(1),
	ZEBRA(2);

	private final int value;

	PrinterType(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}
}