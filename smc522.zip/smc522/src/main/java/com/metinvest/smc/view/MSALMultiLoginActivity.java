package com.metinvest.smc.view;

import static com.metinvest.smc.tools.Utils.parseEmail;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Utils;
import com.microsoft.identity.client.AuthenticationCallback;
import com.microsoft.identity.client.IAccount;
import com.microsoft.identity.client.IAuthenticationResult;
import com.microsoft.identity.client.IMultipleAccountPublicClientApplication;
import com.microsoft.identity.client.IPublicClientApplication;
import com.microsoft.identity.client.PublicClientApplication;
import com.microsoft.identity.client.SilentAuthenticationCallback;
import com.microsoft.identity.client.exception.MsalClientException;
import com.microsoft.identity.client.exception.MsalException;
import com.microsoft.identity.client.exception.MsalServiceException;
import com.microsoft.identity.client.exception.MsalUiRequiredException;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MSALMultiLoginActivity extends MyActivity implements IScan {

	private IMultipleAccountPublicClientApplication mMultipleAccountApp;
	private List<IAccount> accountList;

	@BindView(R.id.buttonEnter)
	Button buttonEnter;
	//@BindView(R.id.textUser)
	//EditText textUser;
	//@BindView(R.id.textPassword)
	//EditText textPassword;
	@BindView(R.id.textAppVersion)
	TextView textVersion;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login_msal);
		ButterKnife.bind(this);

		textVersion.setText(getString(R.string.text_app_version, app.getApkVersionName()));

		checkMyPermission();

		// Creates a PublicClientApplication object with res/raw/auth_config_single_account.json
		PublicClientApplication.createMultipleAccountPublicClientApplication(this,
				R.raw.auth_config_multiple_account,
				new IPublicClientApplication.IMultipleAccountApplicationCreatedListener() {
					@Override
					public void onCreated(IMultipleAccountPublicClientApplication application) {
						mMultipleAccountApp = application;
						loadAccounts();
					}

					@Override
					public void onError(MsalException exception) {
						log("Error: " + exception.toString());
					}
				});
	}

	private void loadAccounts() {
		if (mMultipleAccountApp == null) {
			return;
		}

		mMultipleAccountApp.getAccounts(new IPublicClientApplication.LoadAccountsCallback() {
			@Override
			public void onTaskCompleted(final List<IAccount> result) {
				// You can use the account data to update your UI or your app database.
				accountList = result;
				//updateUI(accountList);
			}

			@Override
			public void onError(MsalException exception) {
				log("Error: " + exception.toString());
				showDialog(R.drawable.ic_warning_24dp,  R.string.text_warning, exception.toString(), null);
			}
		});
	}

	@Override
	public void onBarcodeEvent(String barcodeData) {
	}

	private String[] getDeniedPermissions(String[] permissionList) {
		List<String> list = new ArrayList<>();

		for (String permission : permissionList) {
			if (checkSelfPermission(permission) == PackageManager.PERMISSION_DENIED)
				list.add(permission);
		}

		return list.toArray(new String[0]);
	}

	public void checkMyPermission() {

		String[] permissionListDenied = getDeniedPermissions(new String[]{
				Manifest.permission.READ_EXTERNAL_STORAGE,
				Manifest.permission.WRITE_EXTERNAL_STORAGE,
				Manifest.permission.ACCESS_FINE_LOCATION,
				Manifest.permission.ACCESS_COARSE_LOCATION,
				Manifest.permission.CHANGE_WIFI_STATE,
				Manifest.permission.READ_PHONE_STATE,
				Manifest.permission.CALL_PHONE
		});

		if (permissionListDenied.length > 0) {
			log("Asked for permissions: %d", permissionListDenied.length);
			ActivityCompat.requestPermissions(this, permissionListDenied, REQUEST_PERMISSION);
		}
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == REQUEST_PERMISSION) {
			log("onRequestPermissionsResult");
			for (int i = 0; i < permissions.length; i++) {
				log("%s %s", permissions[i], grantResults[i] == PackageManager.PERMISSION_GRANTED ? "OK" : "FAIL");
			}
		}
	}

	public void buttonEnterClick() {
		beginAuth();
	}

	@Override
	protected void onButtonCancelClick() {
		log("onButtonCancelClick");
	}

	private void beginAuth() {

		if (isLoading()) return;

		if (config.getSmcId().isEmpty()) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.smc_id_empty, (dialog, which) -> openSettings(true));
			return;
		}

		buttonEnter.setEnabled(false);
		showLoading(R.string.text_auth_connecting, false);

		if (mMultipleAccountApp == null) {
			return;
		}
		//final IAccount selectedAccount = accountList.get(accountListSpinner.getSelectedItemPosition());
		if (accountList != null && accountList.size() != 0){
			mMultipleAccountApp.acquireTokenSilentAsync(config.MSAL_SCOPES, accountList.get(0),
					mMultipleAccountApp.getConfiguration().getAuthorities().get(0).getAuthorityURL().toString(), getAuthSilentCallback());
		}
		else {
			loadAccounts();
			//if (accountList != null)
				/*mMultipleAccountApp.signOut(new ISingleAccountPublicClientApplication.SignOutCallback() {
										  @Override
										  public void onSignOut() {
											  accountList = null;
										  }

										  @Override
										  public void onError(@NonNull MsalException exception) {
											  log("signout fail");
											  showDialog(R.drawable.ic_warning_24dp,  R.string.text_warning, "MsalException"+exception.toString(), null);
											  endAuth();
										  }
			});*/

			//mSingleAccountApp.signIn(this, null, config.MSAL_SCOPES, getAuthInteractiveCallback());
			mMultipleAccountApp.acquireToken(this, config.MSAL_SCOPES, getAuthInteractiveCallback());
		}
			//((TenantProfile)((MultiTenantAccount) mAccount).getTenantProfiles().values().toArray()[0]).mRawIdToken
			//mAccount = (IMultiTenantAccount)mSingleAccountApp.getCurrentAccount();

	}
	/**
	 * Callback used in for silent acquireToken calls.
	 */
	private SilentAuthenticationCallback getAuthSilentCallback() {
		return new SilentAuthenticationCallback() {

			@Override
			public void onSuccess(IAuthenticationResult authenticationResult) {
				log("Successfully authenticated silently ");
				/* Successfully got a token, use it to call a protected resource - MSGraph */
				//callGraphAPI(authenticationResult);
				//log("Response: " + response.toString());
				//accountList = authenticationResult.getAccount();
				config.setExpiresOn(authenticationResult.getExpiresOn());
				config.setToken(authenticationResult.getAccessToken());
				DecodedJWT jwt = JWT.decode(authenticationResult.getAccessToken());
				//String userName = jwt.getClaims().get("name").toString();
				String userEmail = jwt.getClaims().get("email").toString();
				config.setUserName(parseEmail(userEmail));
				Utils.runOnBackground(() -> {
					String url = config.getUrlApi() + "getUserData";
					//url = net.addUrlParam(url, "version", textUser.getText().toString());
					//url = net.addUrlParam(url, "requestid", textPassword.getText().toString());
					//url = net.addUrlParam(url, "device", textPassword.getText().toString());
					url = net.addUrlParam(url, "smcid", config.getSmcId());
					JsonResult result = net.downloadJson(url);
					runOnUiThread(() -> endAuth(result));
				});
				//config.setUserName(authenticationResult);
				//config.setUserId(162);
				//config.saveConfig();
				//mAccount = authenticationResult.getAccount();
				//config.setToken(authenticationResult.getAccessToken());
			}

			@Override
			public void onError(MsalException exception) {
				/* Failed to acquireToken */
				log("Authentication failed: " + exception.toString());
				if (exception instanceof MsalClientException) {
					/* Exception inside MSAL, more info inside MsalError.java */
					showDialog(R.drawable.ic_warning_24dp,  R.string.text_warning, "MsalClientException"+exception.toString(), null);
				} else if (exception instanceof MsalServiceException) {
					/* Exception when communicating with the STS, likely config issue */
					showDialog(R.drawable.ic_warning_24dp,  R.string.text_warning, "MsalServiceException"+exception.toString(), null);
				} else if (exception instanceof MsalUiRequiredException) {
					/* Tokens expired or no session, retry with interactive */
					showDialog(R.drawable.ic_warning_24dp,  R.string.text_warning, "MsalUiRequiredException"+exception.toString(), null);
				} else {
					showDialog(R.drawable.ic_warning_24dp,  R.string.text_warning, exception.toString(), null);
				}
				endAuth();
			}
		};
	}

	/**
	 * Callback used for interactive request.
	 * If succeeds we use the access token to call the Microsoft Graph.
	 * Does not check cache.
	 */
	private AuthenticationCallback getAuthInteractiveCallback() {
		return new AuthenticationCallback() {

			@Override
			public void onSuccess(IAuthenticationResult authenticationResult) {
				/* Successfully got a token, use it to call a protected resource - MSGraph */
				log("Successfully authenticated");
				//Log.d(TAG, "ID Token: " + authenticationResult.getAccount().getClaims().get("id_token"));

				/* Update account */
				//mAccount = authenticationResult.getAccount();
				config.setExpiresOn(authenticationResult.getExpiresOn());
				config.setToken(authenticationResult.getAccessToken());
				DecodedJWT jwt = JWT.decode(authenticationResult.getAccessToken());
				//String userName = jwt.getClaims().get("name").toString();
				String userEmail = jwt.getClaims().get("email").toString();
				config.setUserName(parseEmail(userEmail));
				Utils.runOnBackground(() -> {
					String url = config.getUrlApi() + "getUserData";
					//url = net.addUrlParam(url, "version", textUser.getText().toString());
					//url = net.addUrlParam(url, "requestid", textPassword.getText().toString());
					//url = net.addUrlParam(url, "device", textPassword.getText().toString());
					url = net.addUrlParam(url, "smcid", config.getSmcId());
					JsonResult result = net.downloadJson(url);
					runOnUiThread(() -> endAuth(result));
				});

			}

			@Override
			public void onError(MsalException exception) {
				/* Failed to acquireToken */
				log("Authentication failed: " + exception.toString());
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, exception.toString(), null);
				if (exception instanceof MsalClientException) {
					/* Exception inside MSAL, more info inside MsalError.java */
					showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, "MsalClientException"+exception.toString(), null);
				} else if (exception instanceof MsalServiceException) {
					/* Exception when communicating with the STS, likely config issue */
					showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, "MsalServiceException"+exception.toString(), null);
				}
				endAuth();
			}

			@Override
			public void onCancel() {
				/* User canceled the authentication */
				log("User cancelled login.");
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, "User canceled the authentication", null);
			}
		};
	}

	private void endAuth() {
		buttonEnter.setEnabled(true);
		hideLoading();

		//app.authUser(jsonData, textUser.getText().toString());
		//this.user = json;
		//JSONArray smcList = Utils.getJsonArray(json, "smc_info");
		//String smcListJson = smcList != null ? smcList.toString() : "";
		//config.setSmcListJson(smcListJson);
		//config.setUserName(/*userName*/);
		//config.setUserId(162/*Utils.getJsonInt(user, "user_id")*/);
		//config.setToken(Utils.getJsonString(user, "token"));
		//config.saveConfig();
/*		try {
			db.idQrStoreDao().truncate();
		} catch (Exception ignored) {
		}

		if (config.getToken() != null) {
			setResult(RESULT_OK);
			finish();
		}
			else {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, "Помилка!", null);
			}*/

		/*JSONObject jsonData = Utils.getJsonObject(result.getJson(), "data");
		if (result.getStatus() == LoadResultStatus.OK && jsonData != null) {
			app.authUser(jsonData, config.getUserName());
			setResult(RESULT_OK);
			finish();
			//} else if (result.getStatus() == LoadResultStatus.S000) {
			//	showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.s000_login), (dialog, which) -> textPassword.requestFocus());
			//} else if (result.getStatus() == LoadResultStatus.S005) {
			//	showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.s005_login), (dialog, which) -> textPassword.requestFocus());
		} else {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, app.getNetworkErrorMessage(result), null);
		}*/
	}

	private void endAuth(JsonResult result) {
		buttonEnter.setEnabled(true);
		hideLoading();

		JSONObject jsonData = Utils.getJsonObject(result.getJson(), "data");
		if (result.getStatus() == LoadResultStatus.OK && jsonData != null) {
			app.authUser(jsonData, config.getUserName());
			setResult(RESULT_OK);
			finish();
		//} else if (result.getStatus() == LoadResultStatus.S000) {
		//	showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.s000_login), (dialog, which) -> textPassword.requestFocus());
		//} else if (result.getStatus() == LoadResultStatus.S005) {
		//	showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.s005_login), (dialog, which) -> textPassword.requestFocus());
		} else {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, app.getNetworkErrorMessage(result), null);
		}
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 4) buttonEnterClick();
		else if (number == 5) buttonSettingsClick();
		else if (number == 6) buttonOfflineClick();
	}

	private void buttonOfflineClick() {
		if (config.getSmcId().isEmpty()) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.smc_id_empty, (dialog, which) -> openSettings(true));
			return;
		}

		startActivity(new Intent(this, OfflineActivity.class));
	}

	private void buttonSettingsClick() {
		if (isLoading()) return;

		openSettings();
	}

	private void openSettings() {
		openSettings(false);
	}

	private void openSettings(boolean focusSmcId) {
		Intent intent = new Intent(this, SettingsActivity.class);
		intent.putExtra("focusSmcId", focusSmcId);
		startActivity(intent);
	}

	@Override
	public void onBackPressed() {
		//block back button
	}

	@Override
	protected String getHelpContent() {
		return "Введіть логін та пароль користвача.\n\n" +
				"Перехід між полями використовуйте TAB\n\n" +
				"F4 - авторизуватися\n\n" +
				"F5 - меню налаштування входу";
	}

	@Override
	public void onResume() {
		super.onResume();
		/**
		 * The account may have been removed from the device (if broker is in use).
		 *
		 * In shared device mode, the account might be signed in/out by other apps while this app is not in focus.
		 * Therefore, we want to update the account state by invoking loadAccount() here.
		 */
		loadAccounts();
	}
}
