package com.metinvest.smc.inc;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.Serializable;
import java.util.List;

public class Ozm implements Serializable, Parcelable {

    public static final Creator<Ozm> CREATOR = new Creator<Ozm>() {
        @Override
        public Ozm createFromParcel(Parcel source) {
            return new Ozm(source);
        }

        @Override
        public Ozm[] newArray(int size) {
            return new Ozm[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(ozm);
        dest.writeString(name);
        dest.writeFloat(width);
        dest.writeFloat(length);
        dest.writeFloat(thickness);
        dest.writeByte((byte) (manual ? 1 : 0));
    }

    protected Ozm(Parcel in) {
        ozm = in.readString();
        name = in.readString();
        width = in.readFloat();
        length = in.readFloat();
        thickness = in.readFloat();
        manual = in.readByte() == 1;
    }

    private String ozm, name;
    private float width, length, thickness;
    private boolean manual;

    public Ozm() {
    }

    public Ozm(String ozm, String name, float width, float length, float thickness) {
        this.manual = false;
        this.ozm = ozm;
        this.name = name;
        this.width = width;
        this.length = length;
        this.thickness = thickness;
    }

    public boolean isManual() {
        return manual;
    }

    public void setManual(boolean manual) {
        this.manual = manual;
    }

    @Override
    public boolean equals(@Nullable Object obj) {

        if (obj instanceof Ozm) {
            Ozm ozmObj = (Ozm) obj;
            return ozmObj.isManual() == isManual()
                    && ozmObj.getOzm().equalsIgnoreCase(getOzm())
                    && ozmObj.getWidth() == getWidth()
                    && ozmObj.getLength() == getLength()
                    && ozmObj.getThickness() == getThickness();
        }

        return false;
    }

    public String getOzm() {
        return ozm;
    }

    public void setOzm(String ozm) {
        this.ozm = ozm;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getLength() {
        return length;
    }

    public void setLength(float length) {
        this.length = length;
    }

    public float getThickness() {
        return thickness;
    }

    public void setThickness(float thickness) {
        this.thickness = thickness;
    }

    @NonNull
    @Override
    public String toString() {
        return name;
    }

    public static Ozm findOzm(List<Ozm> ozmList, Ozm ozm) {

        for (Ozm ozm1 : ozmList) {
            if (ozm1.equals(ozm)) return ozm1;
        }

        return null;
    }
}
