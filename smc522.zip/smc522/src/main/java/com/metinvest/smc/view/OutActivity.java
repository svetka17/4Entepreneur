package com.metinvest.smc.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Carrier;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.db.Printed;
import com.metinvest.smc.db.Weighing;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.DplGeneratorTransport;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterOut;
import com.metinvest.smc.ui.AdapterOutGroup;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.IFlexible;

public class OutActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

    @BindView(R.id.textContent)
    TextView textContent;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    private FlexibleAdapter<IFlexible> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_out);
        ButterKnife.bind(this);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
        listView.setLayoutManager(layoutManager);
        listView.addItemDecoration(dividerItemDecoration);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    private void beginLoad() {
        showLoading(R.string.text_please_wait);
        buttonAccept.setEnabled(false);

        Utils.runOnBackground(() -> {

            List<Printed> printedList = db.printedDao().getAllNew();

            List<IFlexible> list = new ArrayList<>();

            Weighing weighing = null;
            AdapterOutGroup outGroup = null;

            for (int i = 0; i < printedList.size(); i++) {

                Printed printed = printedList.get(i);

                if (weighing == null || weighing.getId() != printed.getWeighingId()) {

                    weighing = db.weighingDao().getById(printed.getWeighingId());
                    outGroup = new AdapterOutGroup(weighing);
                    list.add(outGroup);
                }

                outGroup.addSubItem(new AdapterOut(printed, db.onTheWayDao().getById(printed.getOnTheWayId())));

                /*Long wayId = printedList.get(i).getOnTheWayId();
                OnTheWay way = db.onTheWayDao().getById(wayId);
                sb.append(Utils.format("<b><font color=\"#34326D\">Позиція №%s</font></b><br>", i + 1));
                sb.append(Utils.format("<b>Призначена вага:</b> <font color=\"#34326D\">%s кг.</font><br>", printed.getWeightNetto()));
                sb.append(Utils.format("<b>Упаковка/тара:</b> %s/%s кг.<br>", printed.getWeightPack(), printed.getWeightTara()));
                sb.append(Utils.format("<b>Партія:</b> %s<br>", printed.isTemporary() ? "-" : way.getSapBatch()));
                sb.append(Utils.format("<b>Локація:</b> %s<br>", app.fixLocation(printed.getTitle())));
                if (i + 1 < printedList.size()) sb.append("<br>");*/
            }

            runOnUiThread(() -> endLoad(list));
        });
    }

    private void endLoad(List<IFlexible> list) {

        adapter = new FlexibleAdapter<>(list);
        adapter.addListener(this);
        listView.setAdapter(adapter);
        adapter.expandAll();

        hideLoading();
        buttonAccept.setEnabled(true);

        scrollView.post(() -> scrollView.scrollTo(0, 0));
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        showLoading(R.string.text_please_wait);
        buttonAccept.setEnabled(false);

        Utils.runOnBackground(() -> {

            //Получаем выгружаемые вагоны
            List<Printed> printedList = db.printedDao().getAllNew();

            List<Carrier> carrierList = new ArrayList<>();

            for (int i = 0; i < printedList.size(); i++) {
                Printed printed = printedList.get(i);
                OnTheWay way = db.onTheWayDao().getById(printed.getOnTheWayId());
                Carrier carrier = db.carrierDao().getById(way.getCarrierId());

                if (findCarrier(carrierList, carrier) == -1)
                    carrierList.add(carrier);
            }

            for (Carrier carrier : carrierList) {
                DplGeneratorTransport gen = new DplGeneratorTransport(carrier.getId());
                String name = gen.generateTitle();
                String dpl = gen.generateDpl();
                Printer.addHistory(name, dpl);
            }

			JsonResult result = net.uploadInbound();

            runOnUiThread(() -> endUpload(result));

        });
    }

    private int findCarrier(List<Carrier> list, Carrier carrier) {
        try {
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i).getId() == carrier.getId()) return i;
            }
        } catch (Exception ignored) {
        }
        return -1;
    }

	private void endUpload(JsonResult result) {
		hideLoading();
		buttonAccept.setEnabled(true);

		if (result.isOk()) {
			showToast(R.string.successful_sended);
			setResult(RESULT_OK);
			finish();
		} else {
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> buttonAcceptClick());
		}
    }

    @Override
    public boolean onItemClick(View view, int position) {
        return false;
    }
}
