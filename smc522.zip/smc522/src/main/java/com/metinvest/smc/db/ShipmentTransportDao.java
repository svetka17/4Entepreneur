package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ShipmentTransportDao {
    @Query("SELECT * FROM ShipmentTransport ORDER BY name")
    List<ShipmentTransport> getAll();

    @Query("SELECT * FROM ShipmentTransport WHERE id = :id")
    ShipmentTransport getById(long id);

    @Query("SELECT * FROM ShipmentTransport WHERE lower(name) = lower(:name)")
    ShipmentTransport getByName(String name);

    @Query("SELECT * FROM ShipmentTransport WHERE lower(name) LIKE lower(:name)")
    List<ShipmentTransport> getByNameLike(String name);

    @Query("SELECT COUNT(1) FROM ShipmentTransport WHERE status <> 1 AND status <> 0")
    long getCountGreen();

    @Insert
    long insert(ShipmentTransport shipmentTransport);

    @Insert
    void insertAll(List<ShipmentTransport> shipmentTransport);

    @Update
    void update(ShipmentTransport shipmentTransport);

    @Delete
    void delete(ShipmentTransport shipmentTransport);

    @Query("DELETE FROM ShipmentTransport")
    void truncate();
}