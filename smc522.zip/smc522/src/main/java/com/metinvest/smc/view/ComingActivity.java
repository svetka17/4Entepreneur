package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ComingActivity extends MyActivity {

    private static final int COMING_LIST_LOAD_REQUEST = 1;
    private static final int COMING_LIST_UPLOAD_REQUEST = 2;

    @BindView(R.id.buttonListLoad)
    TextView buttonListLoad;
    @BindView(R.id.buttonWeighing)
    TextView buttonWeighing;
    @BindView(R.id.buttonListView)
    TextView buttonListView;
    @BindView(R.id.buttonSend)
    TextView buttonSend;
    private boolean canSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coming);
        ButterKnife.bind(this);

        /*Integer updateAvailability = app.getInApp().getLastUpdateAvailability();
        String str = "null";
        if (updateAvailability == UpdateAvailability.UNKNOWN) str = "UNKNOWN";
        else if (updateAvailability == UpdateAvailability.UPDATE_NOT_AVAILABLE) str = "UPDATE_NOT_AVAILABLE";
        else if (updateAvailability == UpdateAvailability.UPDATE_AVAILABLE) str = "UPDATE_AVAILABLE";
        else if (updateAvailability == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) str = "DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS";

        showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, Utils.format(app.getLocale(),"UpdateAvailability: %s", str), null);
    */
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshButtons();
    }

    @Override
    protected void onFunctionKey(int number) {
        switch (number) {
            case 2:
                openListLoad();
                break;
            case 3:
                openWeighing();
                break;
            case 5:
                openTemp();
                break;
            case 7:
                openListView();
                break;
            case 8:
                openOut();
                break;
        }
    }

    @Override
    protected String getHelpContent() {
        return "Післи виконання приходу продукції\n" +
                "ви маєте переглянути звіт і відправити\n" +
                "дані на сервер для обробки.";
    }

    private void openListView() {
        if (buttonListView.isEnabled())
            startActivity(new Intent(this, ComingListActivity.class));
    }

    private void openTemp() {
        startActivity(new Intent(this, UnknownActivity.class));
    }

    private void openOut() {
        if (buttonSend.isEnabled())
            startActivityForResult(new Intent(this, OutActivity.class), COMING_LIST_UPLOAD_REQUEST);
    }

    private void openListLoad() {
        startActivityForResult(new Intent(this, ComingListLoadActivity.class), COMING_LIST_LOAD_REQUEST);
    }

    private void openWeighing() {
        if (buttonWeighing.isEnabled())
            startActivity(new Intent(this, InActivity.class));
    }

    private void refreshButtons() {

        canSend = db.printedDao().getCountNew() > 0;

        buttonWeighing.setEnabled(config.isComingListLoaded());
        buttonListView.setEnabled(config.isComingListLoaded());
        buttonSend.setEnabled(canSend);
        buttonSend.setCompoundDrawablesWithIntrinsicBounds(canSend ? R.drawable.ic_warning_24dp : 0, 0, 0, 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == COMING_LIST_LOAD_REQUEST) {
            if (resultCode == RESULT_OK) {
                //openListView();
                refreshButtons();
                openWeighing();
            }
        }
        if (requestCode == COMING_LIST_UPLOAD_REQUEST && resultCode == RESULT_OK) {
            refreshButtons();
        }
    }

    @Override
    public void onBackPressed() {
        if (canSend) {
            showDialogConfirm(getString(R.string.text_warning),
                    "Ви не відправили дані. Дійсно вийти?",
                    (dialog, which) -> finish(), (dialog, which) -> openOut());
        } else {
            super.onBackPressed();
        }
    }
}
