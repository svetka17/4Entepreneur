package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

import com.metinvest.smc.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class InputLabelIdActivity extends MyActivity {

    @BindView(R.id.textLabelId)
    EditText textLabelId;
    @BindView(R.id.buttonAdd)
    Button buttonAdd;

    private String CurrentLabelId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_label_id);
        ButterKnife.bind(this);

        textLabelId.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                CurrentLabelId = s.toString();
                OnLabelIdChanged();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void OnLabelIdChanged() {
        CheckButtonAdd();
    }

    private void CheckButtonAdd() {
        buttonAdd.setEnabled(CurrentLabelId != null && CurrentLabelId.length() > 0);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) buttonAddClick();
    }

    private void buttonAddClick() {
        if (isLoading() || !buttonAdd.isEnabled()) return;

        beginAdd();
    }

    private void beginAdd() {
        Intent data = new Intent();
        data.putExtra("labelId", CurrentLabelId);
        setResult(RESULT_OK, data);
        finish();
    }
}

