package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface NameStoreDao {
    @Query("SELECT * FROM namestore ORDER BY matt")
    List<NameStore> getAll();

    @Query("SELECT * FROM namestore WHERE id = :id")
    NameStore getById(long id);

    @Query("SELECT * FROM namestore WHERE id in (:idList)")
    List<NameStore> getById(List<Long> idList);

    @Query("SELECT * FROM namestore WHERE matt = :matt AND ozm = :ozm AND width = :width AND length = :length AND thickness = :thickness")
    NameStore getByFull(String matt, String ozm, float width, float length, float thickness);

    @Insert
    long insert(NameStore namestore);

    @Insert
    void insertAll(List<NameStore> namestore);

    @Update
    void update(NameStore namestore);

    @Delete
    void delete(NameStore namestore);

    @Query("DELETE FROM namestore")
    void truncate();
}