package com.metinvest.smc.view;

import static com.metinvest.smc.tools.Utils.parseEmail;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.db.ShipmentDocument;
import com.metinvest.smc.db.ShipmentItem;
import com.metinvest.smc.inc.SohFilter;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.DplGeneratorShip;
import com.metinvest.smc.tools.DplGeneratorZebraShip;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.ShipReasonData;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ShipDetailActivity extends MyActivity {

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.viewContentData)
    View viewContentData;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    @BindView(R.id.textContent)
    TextView textContent;
    @BindView(R.id.textDriver)
    TextView textDriver;
    @BindView(R.id.imageStatus)
    ImageView imageStatus;
    @BindView(R.id.viewButtons)
    View viewButtons;
    @BindView(R.id.buttonStatus)
    Button buttonStatus;
    @BindView(R.id.buttonPrint)
    Button buttonPrint;
    @BindView(R.id.buttonWeighing)
    Button buttonWeighing;
    @BindView(R.id.frSOH)
    FrameLayout frSoh;
    @BindView(R.id.buttonCall)
    ImageButton buttonCall;
    @BindView(R.id.viewDriver)
    View viewDriver;
    @BindView(R.id.buttonTara)
    ImageButton buttonTara;

    private Date date, date2;
    private String sohSmcId;
    private SohFilter sohFilter;
    private String documentNumber;
    private String transportName;

    private ShipmentDocument document;
    private List<ShipmentItem> documentItems;

    private String driverPhone, driverFio;
    private int statusEO;
    private String whoEo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ship_detail);
        ButterKnife.bind(this);

        date = (Date) getIntent().getSerializableExtra("date");
        date2 = (Date) getIntent().getSerializableExtra("date2");
        sohSmcId = getIntent().getStringExtra("sohSmcId");
        sohFilter = sohSmcId == null ? SohFilter.NotSoh() : SohFilter.SohInc(sohSmcId);
        if (sohFilter.getSohSmcId() != null)
            frSoh.setVisibility(View.GONE);
        documentNumber = getIntent().getStringExtra("documentNumber");
        transportName = getIntent().getStringExtra("transportName");

        textContentTitle.setText(Utils.format("Наряд %s", documentNumber));

        buttonCall.setOnClickListener(v -> makeCall(driverPhone, driverFio));
        buttonTara.setOnClickListener(v -> loadCraneTara());
        buttonTara.setVisibility(isCraneAvailable() ? View.VISIBLE : View.GONE);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_DEFAULT && resultCode == RESULT_OK) {
            String action = null;
            int fact = 0;
            if (data != null) {
                action = data.getStringExtra("action");
                fact = data.getIntExtra("fact",0);
                if (document != null) {
                    document.setFact(fact);
                    db.shipmentDocumentDao().update(document);
                }
            }
            if (config.isEo() && action != null && action.equalsIgnoreCase("close")) {
                statusEO = 3;
                beginPrepareClose();
            }
            else
                beginLoad();
        }

        if (requestCode == REQUEST_ACTION && resultCode == RESULT_OK && data != null) {
            String action = data.getStringExtra("action");
            if (action != null) {
                if (action.equalsIgnoreCase("close")) beginPrepareClose();
                else if (action.equalsIgnoreCase("part")) beginPart();
                else if (action.equalsIgnoreCase("open")) beginOpen();
            }
        }

        if (requestCode == REQUEST_VIEW && resultCode == RESULT_OK && data != null) {
            int id = data.getIntExtra("id", -1);
            String reason = data.getStringExtra("reason");
            beginSetReason(id, reason);
        }
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) buttonRefreshClick();
        else if (number == 3) {
            /*if (config.isEo()) {
                Utils.runOnBackground(() -> {
                    JsonResult result = app.putStatusEO(document.getDocNumber(), 1, document.getTurnId());
                    if (result.isOk()) {
                        statusEO = 1;
                        runOnUiThread(() -> buttonWeighingClick(false, null));
                    } else {
                        String message = Utils.getJsonStringIgnoreCase(result.getJson(), "message");
                        //showToast(message);
                        runOnUiThread(() -> buttonWeighingClick(false, message));
                        //showDialog(R.drawable.ic_error_24dp, R.string.text_error, message, null);
                        //return;
                    }
                });
            } else */
                buttonWeighingClick(false, null);
        } else if (number == 4) buttonReportClick();
        else if (number == 5) {
            buttonStatusClick();
        } else if (number == 6) buttonPrintClick();
        else if (number == 8) {
            /*if (config.isEo()) {
                Utils.runOnBackground(() -> {
                    JsonResult result = app.putStatusEO(document.getDocNumber(), 1, document.getTurnId());
                    if (result.isOk()) {
                        statusEO = 1;
                        runOnUiThread(() -> buttonWeighingClick(true, null));
                    } else {
                        String message = Utils.getJsonStringIgnoreCase(result.getJson(), "message");
                        runOnUiThread(() -> buttonWeighingClick(true, message));
                    }
                });
            } else */
                buttonWeighingClick(true, null);
        }
    }

    private void buttonPrintClick() {
        if (isLoading() || !buttonPrint.isEnabled()) return;

        if (!config.isEo() && !(document.getStatus() == 1 || document.isDeleted())) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.ship_first_close_document, null);
            return;
        } else if (config.isEo() && statusEO != 3 ) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.ship_first_close_document, null);
            return;
        }

        beginPrint();
    }

    public void beginPrint() {

        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);
        buttonPrint.setEnabled(false);

        Utils.runOnBackground(() -> {

            String url = config.getUrlApi() + "getsapshippedozm";
            if (sohSmcId != null && sohSmcId != "")
                url = net.addUrlParam(url, "smc_id", sohSmcId);
            if (config.isEo()){
                url = net.addUrlParam(url, "date_vo", app.getDateFormat().format(document.getFirstDate() == 0 ? date : new Date(document.getFirstDate())));
                url = net.addUrlParam(url, "car", document.getTransportNameSap());
            } else {
            url = net.addUrlParam(url, "date_vo", app.getDateFormat().format(document.getDateVoDt() == null ? date : document.getDateVoDt()));
            url = net.addUrlParam(url, "car", transportName);
            }
            url = net.addUrlParam(url, "id_doc", documentNumber);

            JsonResult jsonResult = net.downloadJson(url);

            JSONObject jsonObject = Utils.getJsonObject(jsonResult.getJson(), "data");

            if (jsonResult.isOk() && jsonObject != null) {

                runOnUiThread(() -> showLoading(R.string.text_printing_title));

                JSONArray ozmArray = Utils.getJsonArray(jsonObject, "ozms");

                int totalBrutto = Utils.getJsonWeightKgIgnoreCase(jsonObject, "bruT_Weight");

                String data, title;

                if (isPrinterZebra()) {
                    DplGeneratorZebraShip gen = new DplGeneratorZebraShip(document, date, totalBrutto, ozmArray);
                    data = gen.generateDpl();
                    title = gen.generateTitle();
                } else {
                    DplGeneratorShip gen = new DplGeneratorShip(document, date, totalBrutto, ozmArray);
                    data = gen.generateDpl();
                    title = gen.generateTitle();
                }

                final Printer.PrintResult printResult = Printer.sendCommand(title, config.getPrinter(), data);

                runOnUiThread(() -> endPrint(jsonResult, printResult));

            } else {
                runOnUiThread(() -> endPrint(jsonResult, null));
            }

        });

    }

    private void endPrint(JsonResult jsonResult, Printer.PrintResult printResult) {
        buttonPrint.setEnabled(true);
        viewButtons.setVisibility(View.VISIBLE);
        hideLoading();

        if (jsonResult.isOk()) {

            if (printResult.getStatus() == Printer.PrintResultStatus.OK) {
                showToast(R.string.text_print_result_succeeded);
                //app.sendFaPrint();
            } else {
                @StringRes final int message = app.getPrintResultMessage(printResult);
                showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> beginPrint());
            }

        } else {

            //showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, getString(R.string.request_error, networkResult.getDescription()), (dialog, which) -> beginPrint());
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(jsonResult), (dialog, which) -> beginPrint());
        }
    }

    private void buttonWeighingClick(boolean soh, String error) {
        if (isLoading() || !buttonWeighing.isEnabled()) return;
        if (error != null && !error.isEmpty()) {
            showDialog(R.drawable.ic_error_24dp, R.string.text_error, error, null);
            return;
        }
        if (document.isDeleted()) {
            showDialog(R.drawable.ic_error_24dp, R.string.text_error, "Наряд видалено!", null);
            return;
        }

        if (config.isEo()) {
            showDialogConfirm(R.string.text_confirm, getString(R.string.ship_eo_start),
                    getString(R.string.ship_eo_edit),
                    getString(R.string.ship_eo_view),
                    (dialog, which) -> {Intent intent = new Intent(this, ShipCardActivity.class);
                        intent.putExtra("edit", true);
                        intent.putExtra("date", date);
                        intent.putExtra("date2", date2);
                        intent.putExtra("dateVo", document.getDateVoDt());
                        intent.putExtra("sohSmcId", sohSmcId);
                        intent.putExtra("transportName", document.getTransportName());
                        intent.putExtra("documentNumber", document.getDocNumber());
                        intent.putExtra("soh", soh);
                        if (whoEo != null && whoEo.length() > 0)
                            intent.putExtra("whoEo", whoEo);
                        startActivityForResult(intent, REQUEST_DEFAULT);},
                    (dialog, which) -> {Intent intent = new Intent(this, ShipCardActivity.class);
                        intent.putExtra("edit", false);
                        intent.putExtra("date", date);
                        intent.putExtra("date2", date2);
                        intent.putExtra("dateVo", document.getDateVoDt());
                        intent.putExtra("sohSmcId", sohSmcId);
                        intent.putExtra("transportName", document.getTransportName());
                        intent.putExtra("documentNumber", document.getDocNumber());
                        intent.putExtra("soh", soh);
                        startActivityForResult(intent, REQUEST_DEFAULT);});
        } else {
            Intent intent = new Intent(this, ShipCardActivity.class);
            intent.putExtra("edit", true);
            intent.putExtra("date", date);
            intent.putExtra("date2", date2);
            intent.putExtra("dateVo", document.getDateVoDt());
            intent.putExtra("sohSmcId", sohSmcId);
            intent.putExtra("transportName", document.getTransportName());
            intent.putExtra("documentNumber", document.getDocNumber());
            intent.putExtra("soh", soh);
            startActivityForResult(intent, REQUEST_DEFAULT);
        }
    }

    private void buttonReportClick() {
        if (isLoading() || viewButtons.getVisibility() != View.VISIBLE) return;

        Intent intent = new Intent(this, ShipBatchActivity.class);
        intent.putExtra("date", date);
        intent.putExtra("date2", date2);
        if (config.isEo())
            intent.putExtra("sohSmcId", document.getEoSmcId());
        else
            intent.putExtra("sohSmcId", sohSmcId);
        intent.putExtra("documentNumber", documentNumber);
        if (config.isEo()) {
            intent.putExtra("dateVo", new Date(document.getFirstDate()));
            intent.putExtra("transportName", document.getTransportNameSap());
        } else {
            intent.putExtra("dateVo", document.getDateVoDt());
            intent.putExtra("transportName", transportName);
        }
        startActivityForResult(intent, REQUEST_DEFAULT);
    }

    private void buttonRefreshClick() {
        if (isLoading()) return;

        beginLoad();
    }

    private void beginLoad() {
        showLoading(R.string.text_please_wait);

        imageStatus.setVisibility(View.GONE);
        viewButtons.setVisibility(View.GONE);
        buttonWeighing.setEnabled(false);

        Utils.runOnBackground(() -> {

            document = null;

            JsonResult result = new JsonResult();
            //result.setStatus(LoadResultStatus.OK);
            if (!config.isEo())
                result = app.loadShipmentOrders(date, date2, transportName, sohFilter);
            else
                result = app.getStatusEO(documentNumber);

            if (result.isOk()) {
                document = db.shipmentDocumentDao().getByName(documentNumber, transportName);
            }

            JsonResult finalResult = result;
            runOnUiThread(() -> endLoad(finalResult));
        });
    }

    private void endLoad(JsonResult result) {
        hideLoading();

        viewButtons.setVisibility(result.isOk() && document != null ? View.VISIBLE : View.GONE);
        viewContentData.setVisibility(result.isOk() && document != null ? View.VISIBLE : View.GONE);
        textNotFound.setVisibility(!result.isOk() || document == null ? View.VISIBLE : View.GONE);

        if (result.isOk()) {
            if (document != null) {

                driverFio = document.getDriverName();
                driverPhone = document.getDriverCellPhone();
				/*if (BuildConfig.DEBUG) {
					if (driverFio == null || driverFio.isEmpty()) driverFio = "Іванов А.С.";
					if (driverPhone == null || driverPhone.isEmpty()) driverPhone = "+380979911222";
				}*/

                if (config.isEo()) {
                    JSONObject content = Utils.getJsonObject(result.getJson(), "content");
                    if (content != null) {
                        statusEO = Utils.getJsonInt(content, "idDocStatusCode");
                        if (statusEO == 1)
                            whoEo = parseEmail(Utils.getJsonString(content, "ownerName"));
                    }
                }
                showContent();
            }
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
        }

    }

    private void showContent() {

        StringBuilder sb = new StringBuilder();
        sb.append(Utils.format("<b>%s</b>", document.getTransportName()));

        if (document.isDeleted()) {
            sb.append("<br>ВП видалено");
        }

        sb.append(Utils.format("<br>План, тн: %.3f", document.getPlan() / 1000.f));
        sb.append(Utils.format("<br>Факт, тн: %s", Utils.factToString(document.getFact())));
        if (app.getConfig().isEo()) {
            sb.append(Utils.format("<br>%s", Utils.shipStatusToStringEO(document.getStatus())));
            imageStatus.setImageResource(R.drawable.ic_ship_black);
            switch (statusEO) {
                case 0:
                    imageStatus.setImageResource(R.drawable.ic_ship_green);
                    break;
                case 1:
                    imageStatus.setImageResource(R.drawable.ic_ship_black);
                    break;
                case 2:
                    imageStatus.setImageResource(R.drawable.ic_ship_yellow);
                    break;
                case 3:
                    imageStatus.setImageResource(R.drawable.ic_ship_red);
                    break;
            }
        } else {
            String planTimeStr = App.getInstance().longToTimeString(document.getPlanTime());
            if (planTimeStr.length() > 0) {
                sb.append(Utils.format("<br>Заброньований час: %s", planTimeStr));
            }

            String timeStr = "";

            if (document.getStatus() == 0) {
                timeStr = Utils.format("%s..", App.getInstance().longToTimeString(document.getFirstDate()));
            } else if (document.getStatus() >= 1) {
                timeStr = Utils.format("%s - %s", App.getInstance().longToTimeString(document.getFirstDate()), App.getInstance().longToTimeString(document.getLastDate()));
            } else {
                //sb.append("Очікується");
            }

            if (!document.isDeleted())
                sb.append(Utils.format("<br>%s %s", Utils.shipStatusToString(document.getStatus()), timeStr));
            imageStatus.setImageResource(document.isDeleted() ? R.drawable.ic_ship_black : Utils.shipStatusToImageShip(document.getStatus()));
        }
        imageStatus.setVisibility(View.VISIBLE);
        textContent.setText(app.fromHtml(sb.toString()));

        if (driverFio != null && !driverFio.isEmpty()) {

            sb = new StringBuilder();
            sb.append(Utils.format("Водій: %s", driverFio));
            if (driverPhone != null && driverPhone.length() > 0) {
                sb.append(Utils.format("<br>Телефон: %s", driverPhone));
            }

            buttonCall.setEnabled(driverPhone != null && driverPhone.length() > 0);

            textDriver.setText(app.fromHtml(sb.toString()));
            viewDriver.setVisibility(View.VISIBLE);
        } else {
            viewDriver.setVisibility(View.GONE);
        }
        if (config.isEo()) {
            buttonStatus.setEnabled(true);
            //buttonWeighing.setEnabled(statusEO == 2 || statusEO == 0);
            buttonWeighing.setEnabled(true);
            //if (statusEO == 1)
            //    buttonWeighing.setText("БЛОКОВАНО " + whoEo);
            //else
                buttonWeighing.setText("ПОГРУЗКА");
        } else {
            buttonStatus.setEnabled(document.getStatus() <= 1);
            buttonWeighing.setEnabled(document.getStatus() < 1 /*|| BuildConfig.DEBUG*/);
        }
        //buttonWeighing.setEnabled(document.getStatus() < 1 || config.isEo() /*|| BuildConfig.DEBUG*/);
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        super.onBackPressed();
    }

    private void buttonStatusClick() {
        if (isLoading() || !buttonStatus.isEnabled()) return;
        Intent intent = new Intent(this, ShipStatusActivity.class);
        if (config.isEo()) {
            //intent.putExtra("isEO", statusEO == 1);
            if (statusEO == 0) {
                intent.putExtra("isClose", true);
            } else {
                intent.putExtra("isClose", statusEO == 2);
            }
            intent.putExtra("isClosePart", statusEO == 1);
        } else
            intent.putExtra("isClose", document.getStatus() < 1);
        startActivityForResult(intent, REQUEST_ACTION);
    }

    private void beginSetReason(int id, String reason) {
        log("set reason: %d, %s", id, reason);

        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);
        buttonStatus.setEnabled(false);

        Utils.runOnBackground(() -> {

            String url = config.getUrlApi() + "addreasons";
            url = net.addUrlParam(url, "Feedback_id", id);

            String data = Utils.format("[\"%s\"]", reason);

            JsonResult result = net.uploadJson(url, data);

            runOnUiThread(() -> endSetReason(id, reason, result));
        });
    }

    private void endSetReason(int id, String reason, JsonResult result) {
        hideLoading();
        viewButtons.setVisibility(View.VISIBLE);
        buttonStatus.setEnabled(true);

        if (result.isOk()) {
            Toast.makeText(this, R.string.ship_closed, Toast.LENGTH_SHORT).show();
            beginLoad();
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginSetReason(id, reason));
        }
    }

    private void beginPart() {
        if (statusEO != 1) return;
        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);
        buttonStatus.setEnabled(false);
        Utils.runOnBackground(() -> {
            JsonResult result = app.putStatusEO(document.getDocNumber(), 2, document.getTurnId());
            runOnUiThread(() -> endPart(result));
        });
    }

    private void endPart(JsonResult result) {
        hideLoading();
        viewButtons.setVisibility(View.VISIBLE);
        buttonStatus.setEnabled(true);
        if (result.isOk()) {
            statusEO = 2;
            beginLoad();
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginPart());
        }

    }

    private void beginOpen() {
        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);
        buttonStatus.setEnabled(false);

        String url = config.getUrlApi() + "openshipment";
        if (sohSmcId != null && sohSmcId != "")
            url = net.addUrlParam(url, "smc_id", sohSmcId);
        if (config.isEo()) {
            Date dateVO = new Date(document.getFirstDate());
            url = net.addUrlParam(url, "date_vo", app.getDateFormat().format(dateVO == null ? date : dateVO));
        } else
            url = net.addUrlParam(url, "date_vo", app.getDateFormat().format(document.getDateVoDt() == null ? date : document.getDateVoDt()));
        url = net.addUrlParam(url, "id_doc", documentNumber);

        reqGet(url, this::endOpen);
    }

    private void beginPrepareClose() {
        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);
        buttonStatus.setEnabled(false);

        Utils.runOnBackground(() -> {
            JsonResult result;
            if (config.isEo()) {
                Date dateVO = new Date(document.getFirstDate());
                result = app.loadShipmentOrderDetails(dateVO == null ? date : dateVO, documentNumber, sohFilter);
            } else
                result = app.loadShipmentOrderDetails(document.getDateVoDt() == null ? date : document.getDateVoDt(), documentNumber, sohFilter);
            documentItems = result.isOk() ? db.shipmentItemDao().getByDocument(documentNumber) : null;

            runOnUiThread(() -> endPrepareClose(result));
        });
    }

    private void endPrepareClose(JsonResult result) {
        hideLoading();
        viewButtons.setVisibility(View.VISIBLE);
        buttonStatus.setEnabled(true);

        if (result.isOk()) {
            /*if (config.isEo() && statusEO == 2){
                Utils.runOnBackground(() -> {
                        app.putStatusEO(document.getDocNumber(), 3, document.getTurnId());
                });
                beginClose();
            } else*/
                beginClose();
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginPrepareClose());
        }

    }

    private void beginClose() {
        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);
        buttonStatus.setEnabled(false);

        Utils.runOnBackground(() -> {

            String url = config.getUrlApi() + "finishshipment";
            if (sohSmcId != null && sohSmcId != "")
                url = net.addUrlParam(url, "smc_id", sohSmcId);
            if (config.isEo()) {
                Date dateVO = new Date(document.getFirstDate());
                url = net.addUrlParam(url, "date_vo", app.getDateFormat().format(dateVO == null ? date : dateVO));
            } else
                url = net.addUrlParam(url, "date_vo", app.getDateFormat().format(document.getDateVoDt() == null ? date : document.getDateVoDt()));

            url = net.addUrlParam(url, "id_doc", documentNumber);
            JsonResult result = net.downloadJson(url);

            runOnUiThread(() -> endClose(result));
        });
    }

    private void endOpen(JsonResult result) {
        if (result.isOk()) {
            if (config.isEo()) {
                Utils.runOnBackground(() -> {
                    JsonResult resultEO = app.putStatusEO(document.getDocNumber(), 1, document.getTurnId());
                    if (resultEO.isOk()) {
                        statusEO = 1;
                        //Utils.runOnBackground(() -> {
                        JsonResult resultEO2 = app.putStatusEO(document.getDocNumber(), 2, document.getTurnId());
                        if (resultEO2.isOk()) {
                            runOnUiThread(() -> {
                                hideLoading();
                                viewButtons.setVisibility(View.VISIBLE);
                                buttonStatus.setEnabled(true);
                                statusEO = 2;
                                beginLoad();
                            });
                        }
                    } else {
                        runOnUiThread(() -> {
                            hideLoading();
                            viewButtons.setVisibility(View.VISIBLE);
                            buttonStatus.setEnabled(true);
                            String message = Utils.getJsonStringIgnoreCase(resultEO.getJson(), "message");
                            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                            beginLoad();
                        });
                    }
                });

            } else {
                hideLoading();
                viewButtons.setVisibility(View.VISIBLE);
                buttonStatus.setEnabled(true);
                Toast.makeText(this, R.string.ship_open, Toast.LENGTH_SHORT).show();
                beginLoad();
            }
        } else {
            hideLoading();
            viewButtons.setVisibility(View.VISIBLE);
            buttonStatus.setEnabled(true);
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
        }
    }

    private int calcPlanTime() {
        if (documentItems == null) return 0;

        int totalPlanTime = 0;

        for (ShipmentItem order : documentItems) {
            int fact = order.getSapWeightNettFact();
            int minutes = 0;
            if (fact < 8000) minutes = 7;
            else if (fact < 16000) minutes = 14;
            else minutes = 21;

            log("PLAN TIME: %d min for %d kg", minutes, fact);

            totalPlanTime += minutes;
        }

        log("TOTAL PLAN TIME: %d min", totalPlanTime);

        return totalPlanTime;
    }

    private void endClose(JsonResult result) {


        if (result.isOk()) {
            if (config.isEo() && statusEO != 3) {
                Utils.runOnBackground(() -> {
                    JsonResult resultEO = app.putStatusEO(document.getDocNumber(), 3, document.getTurnId());
                    if (resultEO.isOk()) {
                        statusEO = 3;
                        runOnUiThread(() -> {
                            hideLoading();
                            viewButtons.setVisibility(View.VISIBLE);
                            buttonStatus.setEnabled(true);
                            ShipReasonData reasonData = ShipReasonData.fromJson(Utils.getJsonObject(result.getJson(), "data"));
                            postEndClose(reasonData);
                        });
                    } else {
                        showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(resultEO), (dialog, which) -> beginClose());
                    }
                });
            } else {
                hideLoading();
                viewButtons.setVisibility(View.VISIBLE);
                buttonStatus.setEnabled(true);
                ShipReasonData reasonData = ShipReasonData.fromJson(Utils.getJsonObject(result.getJson(), "data"));
                postEndClose(reasonData);
            }

        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginClose());
        }
    }

    private void postEndClose(ShipReasonData reasonData) {
        int planTime = calcPlanTime();
        int factTime = reasonData == null ? -1 : reasonData.getFact();

        if (factTime != -1) {
            log("TOTAL FACT TIME: %d min", factTime);
        }

        if (factTime == -1 || factTime <= planTime) {
            hideLoading();
            viewButtons.setVisibility(View.VISIBLE);
            buttonStatus.setEnabled(true);
            Toast.makeText(this, R.string.ship_closed, Toast.LENGTH_SHORT).show();
            beginLoad();
        } else {
            //log("Set reason request: id=%d", reasonData.getId());
            Intent intent = new Intent(this, ShipReasonActivity.class);
            intent.putExtra("transportName", transportName);
            intent.putExtra("reasonData", reasonData);
            intent.putExtra("planTime", planTime);
            startActivityForResult(intent, REQUEST_VIEW);
        }
    }

}
