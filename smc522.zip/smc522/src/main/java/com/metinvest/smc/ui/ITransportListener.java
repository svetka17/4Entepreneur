package com.metinvest.smc.ui;

import java.util.Date;

public interface ITransportListener {
	void onTransportClicked(String ttnCarrierId, Date ttnDate, String ttnNum);
}
