package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface RollNameInfoDao {
    @Query("SELECT * FROM RollNameInfo WHERE id = :id")
    RollNameInfo getById(long id);

    @Query("SELECT * FROM RollNameInfo WHERE " +
            " (:rollNameId = rollNameId)" +
            "AND (:markdown = markdown) " +
            "AND (:mera = mera) " +
            "AND (:travl = travl) ")
    RollNameInfo getByFull(long rollNameId, String markdown, String mera, String travl);

    @Query("SELECT DISTINCT(rollNameId) FROM RollNameInfo WHERE " +
            "(:markdown is null OR :markdown = markdown) " +
            "AND (:mera is null OR :mera = mera) " +
            "AND (:travl is null OR :travl = travl) ")
    List<Long> findNameId(String markdown, String mera, String travl);

    @Query("SELECT * FROM RollNameInfo WHERE id in (:idList)")
    List<RollNameInfo> getById(List<Long> idList);

    @Query("SELECT * FROM RollNameInfo WHERE rollNameId = :nameId")
    List<RollNameInfo> getByNameId(long nameId);

    @Query("SELECT * FROM RollNameInfo")
    List<RollNameInfo> getAll();

    @Query("SELECT count(1) FROM RollNameInfo")
    long getCount();

    @Insert
    long insert(RollNameInfo rollNameInfo);

    @Insert
    void insertAll(List<RollNameInfo> rollNameInfoList);

    @Update
    void update(RollNameInfo rollNameInfo);

    @Delete
    void delete(RollNameInfo rollNameInfo);

    @Query("DELETE FROM RollNameInfo")
    void truncate();
}