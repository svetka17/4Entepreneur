package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.NameStore;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.db.Printed;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemPrinted;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class WayActivity extends MyActivity implements AdapterItemPrinted.IAdapterItemPrintedListener {

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.listView)
    RecyclerView listView;

    private FlexibleAdapter<AdapterItemPrinted> adapter;
    private OnTheWay way;
    private NameStore name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_way);
        ButterKnife.bind(this);

        long wayId = getIntent().getLongExtra("wayId", 0);
        way = db.onTheWayDao().getById(wayId);
        name = db.nameStoreDao().getById(way.getNameId());

        textContentTitle.setText(name.getName());

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
        listView.setLayoutManager(layoutManager);
        listView.addItemDecoration(dividerItemDecoration);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoadData();
    }

    private void beginLoadData() {

        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            List<Printed> list = db.printedDao().getByOnTheWayId(way.getId());

            List<AdapterItemPrinted> items = new ArrayList<>(list.size());
            for (int i = 0; i < list.size(); i++) {
                items.add(new AdapterItemPrinted(list.get(i), this));
            }

            adapter = new FlexibleAdapter<>(items);

            endLoadData();
        });
    }

    private void endLoadData() {
        hideLoading();

        runOnUiThread(() -> {
            listView.setAdapter(adapter);
            scrollView.post(() -> scrollView.scrollTo(0, 0));
        });
    }

    @Override
    public void onEditClicked(int position) {
        AdapterItemPrinted item = adapter.getItem(position);
        if (item != null) {
            Intent intent = new Intent(this, PrintedEditActivity.class);
            intent.putExtra("id", item.getPrinted().getId());
            startActivityForResult(intent, REQUEST_DEFAULT);
        }
    }

    @Override
    public void onDeleteClicked(int position) {
        showDialogConfirm(R.string.text_confirm, R.string.delete_position_confirm, (dialog, which) -> {
            AdapterItemPrinted item = adapter.getItem(position);
            if (item != null) {

                //OnTheWay way = db.onTheWayDao().getById(item.getPrinted().getOnTheWayId());
                way.setWeightAccepted(way.getWeightAccepted() - item.getPrinted().getWeightNetto());
                db.onTheWayDao().update(way);

                db.printedDao().delete(item.getPrinted());
                beginLoadData();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_DEFAULT && resultCode == RESULT_OK) {
            beginLoadData();
        }
    }
}
