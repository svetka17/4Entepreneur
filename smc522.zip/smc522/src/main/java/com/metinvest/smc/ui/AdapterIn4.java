package com.metinvest.smc.ui;

import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.db.Printed;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterIn4 extends AbstractFlexibleItem<AdapterIn4.ViewHolder> {

    private final int index;
    private final Printed printed;
    private final OnTheWay way;
    private final IAdapterIn4Listener listener;

    public interface IAdapterIn4Listener {
        void onPrintClicked(AdapterIn4 item);
    }

    public AdapterIn4(int index, Printed printed, OnTheWay way, IAdapterIn4Listener listener) {
        this.index = index;
        this.printed = printed;
        this.way = way;
        this.listener = listener;
    }

    public Printed getPrinted() {
        return printed;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterIn4 && ((AdapterIn4) o).getPrinted().getId() == getPrinted().getId();
    }

    @Override
    public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new ViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {

        holder.textTitle.setText(App.getInstance().fromHtml(Utils.format("<b><font color=\"#34326D\">Позиція №%d</font></b>", index + 1)));

        StringBuilder sb = new StringBuilder();

        sb.append(Utils.format("<b>LabelId:</b> %d<br>", printed.getId()));
        if (way != null) {
            sb.append(Utils.format("<b>Партія:</b> %s<br>", way.getSapBatch()));
			sb.append(Utils.format("<b>Склад:</b> %s<br>", way.getStorage()));
        } else {
			sb.append("<b>Партія:</b> - <br>");
        }
        sb.append(Utils.format("<b>Вага нетто:</b> %s кг.<br>", printed.getWeightNetto()));
        sb.append(Utils.format("<b>Вага упаковки:</b> %s кг.<br>", printed.getWeightPack()));
        sb.append(Utils.format("<b>Тара:</b> %s кг.", printed.getWeightTara()));

        holder.buttonPrint.setOnClickListener(v -> {
            if (listener != null) listener.onPrintClicked(this);
        });

        holder.textContent.setText(App.getInstance().fromHtml(sb.toString()));
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_in4_row;
    }

    public class ViewHolder extends FlexibleViewHolder {

        public TextView textTitle, textContent;
        public ImageButton buttonPrint;

        public ViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.textTitle = view.findViewById(R.id.textTitle);
            this.textContent = view.findViewById(R.id.textContent);
            this.buttonPrint = view.findViewById(R.id.buttonPrint);
        }
    }
}
