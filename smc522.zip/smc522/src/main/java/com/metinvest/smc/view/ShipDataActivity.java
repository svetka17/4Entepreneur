package com.metinvest.smc.view;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.ShipmentDocument;
import com.metinvest.smc.db.ShipmentTransport;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.JsonUploadTask;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterShipData;

import java.util.ArrayList;
import java.util.List;

import br.com.sapereaude.maskedEditText.MaskedEditText;
import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class ShipDataActivity extends MyActivity {

	@BindView(R.id.scrollView)
	NestedScrollView scrollView;
	@BindView(R.id.listView)
	RecyclerView listView;
	@BindView(R.id.buttonAccept)
	Button buttonAccept;
	@BindView(R.id.textFio)
	EditText textFio;
	@BindView(R.id.textPhone)
	MaskedEditText textPhone;

	private FlexibleAdapter<AdapterShipData> adapter;
	private List<ShipmentDocument> documentList;
	private ShipmentTransport transport;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ship_data);
		ButterKnife.bind(this);
		listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

		long transportId = getIntent().getLongExtra("transportId", 0);
		if (transportId == 0) finish();

		transport = db.shipmentTransportDao().getById(transportId);
		documentList = db.shipmentDocumentDao().getByTransportId(transportId);

		TextWatcher textWatcher = new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				checkTextFields();
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		};
		textFio.addTextChangedListener(textWatcher);
		textPhone.addTextChangedListener(textWatcher);
		checkTextFields();
	}

	private void checkTextFields() {
		setCorrectTint(textFio, !textFio.getText().toString().isEmpty());
		setCorrectTint(textPhone, textPhone.getRawText().length() == 10);
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		beginLoad();
	}

	private void beginLoad() {

		showLoading(R.string.text_please_wait);

		Utils.runOnBackground(() -> {

			List<AdapterShipData> list = new ArrayList<>(documentList.size());

			for (ShipmentDocument document : documentList) {
				list.add(new AdapterShipData(document));
			}

			adapter = new FlexibleAdapter<>(list);

			runOnUiThread(this::endLoad);

		});

	}

	private void endLoad() {
		hideLoading();

		listView.setAdapter(adapter);
		listView.requestFocus();
		scrollView.post(() -> scrollView.scrollTo(0, 0));
		textFio.post(() -> textFio.requestFocus());

		setData();
	}

	private void setData() {
		if (!documentList.isEmpty()) {
			ShipmentDocument docZero = documentList.get(0);
			textFio.setText(docZero.getDriverName());

			String phone = docZero.getDriverCellPhone();
			if (docZero.getDriverCellPhone().startsWith("+38")) {
				phone = phone.substring(3);
			}

			textPhone.setText(phone);

			if (adapter != null && documentList.size() == adapter.getItemCount()) {
				List<AdapterShipData> listAdapter = adapter.getCurrentItems();
				for (int i = 0; i < documentList.size(); i++) {
					listAdapter.get(i).setValue(documentList.get(i).getSapPoNum());
					adapter.updateItem(listAdapter.get(i));
				}
			}
		}
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 5) beginAccept();
	}

	private void beginAccept() {
		if (isLoading() || !buttonAccept.isEnabled()) return;

		String fio = textFio.getText().toString().trim();
		String phone = textPhone.getRawText();

		if (fio.length() == 0) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.warning_fio_empty, (dialog, which) -> textFio.post(() -> textFio.requestFocus()));
			return;
		}

		if (phone.length() == 0) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.warning_phone_empty, (dialog, which) -> textPhone.post(() -> textPhone.requestFocus()));
			return;
		}

		phone = "+38" + phone;

		for (int i = 0; i < documentList.size(); i++) {
			AdapterShipData item = adapter.getItem(i);
			if (item != null) {
				if (item.getValue() == null || item.getValue().length() != 10) {
					showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.text_error_ship_data_numbers, item.getDocument().getDocNumber()), (dialog, which) -> listView.post(() -> listView.requestFocus()));
					return;
				}
			}
		}

		showLoading(R.string.text_please_wait);
		buttonAccept.setEnabled(false);

		String finalPhone = phone;
		Utils.runOnBackground(() -> {

			String json;

			String url = config.getUrlApi() + "addschedulerdetails";
			url = net.addUrlParam(url, "user_login", app.getConfUserId());

			StringBuilder sb = new StringBuilder();
			sb.append("[");

			for (int i = 0; i < documentList.size(); i++) {

				AdapterShipData item = adapter.getItem(i);

				if (item != null) {

					sb.append(Utils.format("{%n%s%n%s%n%s%n%s%n%s%n%s%n}"
							, Utils.format("\"SMC_ID\":\"%s\",", app.getSmcIdCurrent())
							, Utils.format("\"PO_DRIVER_NAME\":\"%s\",", fio)
							, Utils.format("\"PO_DRIVER_CELLPHONE\":\"%s\",", finalPhone)
							, Utils.format("\"SAP_PO_NUM\":\"%s\",", item.getValue())
							, Utils.format("\"iD_DOC\":\"%s\",", documentList.get(i).getDocNumber())
							, Utils.format("\"TTN_CARRIER_ID\":\"%s\"", transport.getName())

					));

					if (i + 1 < documentList.size()) sb.append(",");
				}

			}

			sb.append("]");

			json = sb.toString();

			net.uploadJson(new JsonUploadTask.JsonUploadTaskParam(url, json), this::endAccept);

		});
	}

	private void endAccept(JsonResult result) {

		hideLoading();
		buttonAccept.setEnabled(!result.isOk());

		if (result.isOk()) {
			showToast(R.string.successful_accepted);
			setResult(RESULT_OK);
			finish();
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginAccept());
		}
	}
}
