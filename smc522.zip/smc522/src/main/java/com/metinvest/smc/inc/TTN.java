package com.metinvest.smc.inc;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.metinvest.smc.tools.Utils;

import java.io.Serializable;

public class TTN implements Serializable {
	private String /*id, */num;
	private Boolean soh;

	public TTN(/*String id, */String num, Boolean soh) {
		//this.id = id;
		this.num = num;
		this.soh = soh;
	}

	/*public String getId() {
		return id;
	}*/

	public String getNum() {
		return num;
	}

	public Boolean getSoh() {
		return soh;
	}

	@NonNull
	@Override
	public String toString() {
		//return Utils.format("[%s %s] %s", id, num, soh);
		return Utils.format("[%s] %s", num, soh);
	}

	@Override
	public boolean equals(@Nullable Object obj) {
		//return obj instanceof TTN && ((TTN) obj).getId().equalsIgnoreCase(getId()) && ((TTN) obj).getNum().equalsIgnoreCase(getNum());
		return obj instanceof TTN && ((TTN) obj).getNum().equalsIgnoreCase(getNum());
	}

    @Override
    public int hashCode() {
		//return getId() == null ? getNum().hashCode() : Objects.hash(getId(), getNum());
		return getNum().hashCode();
	}
}
