package com.metinvest.smc.view;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.Utils;

import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LabelReleaseActivity extends MyActivity {

	@BindView(R.id.textContent)
	TextView textContent;
	@BindView(R.id.button1)
	Button button1;
	@BindView(R.id.button2)
	Button button2;

	private String transportName;
	private String ttnNum;
	private Date ttnDate;
	private String status;
	private String statusString;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_label_release);
		ButterKnife.bind(this);

		/*
				intent.putExtra("transport", transportName);
		intent.putExtra("ttnNum", doc.getTtn().getNum());
		intent.putExtra("status", doc.getStatusString());
		 */
		transportName = getIntent().getStringExtra("transport");
		ttnNum = getIntent().getStringExtra("ttnNum");
		ttnDate = (Date) getIntent().getSerializableExtra("ttnDate");
		status = getIntent().getStringExtra("status");
		statusString = getIntent().getStringExtra("statusString");

		textContent.setText(app.fromHtml(Utils.format("<b>%s</b><br>ТТН: %s %s<br>%s",
				transportName,
				ttnNum, app.getDateFormat().format(ttnDate),
				statusString)));
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 4) {
			beginRelease(true);
		} else if (number == 5) {
			beginRelease(false);
		}
	}

	private void beginRelease(boolean release) {
		if (isLoading()) return;
		showLoading(R.string.text_please_wait);

		Utils.runOnBackground(() -> {
			String url = config.getUrlApi() + "release";

			url = net.addUrlParam(url, "TTN_NUM", ttnNum);
			url = net.addUrlParam(url, "TTN_CARRIER_ID", transportName);
			url = net.addUrlParam(url, "TTN_DATE", app.getDateFormat().format(ttnDate));
			url = net.addUrlParam(url, "value", release ? "true" : "false");

			JsonResult result = net.uploadJson(url, "");

			runOnUiThread(() -> endRelease(result, release));
		});
	}

	private void endRelease(JsonResult result, boolean release) {
		hideLoading();

		if (result.isOk()) {
			int labelCount = Utils.getJsonIntIgnoreCase(result.getJson(), "data");
			Toast.makeText(this, getString(R.string.successful_released, labelCount), Toast.LENGTH_SHORT).show();
			setResult(RESULT_OK);
			finish();
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginRelease(release));
		}
	}
}

