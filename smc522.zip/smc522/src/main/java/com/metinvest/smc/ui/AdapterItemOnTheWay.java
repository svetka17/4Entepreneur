package com.metinvest.smc.ui;

import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.db.NameStore;
import com.metinvest.smc.db.OnTheWay;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemOnTheWay extends AbstractFlexibleItem<AdapterItemOnTheWay.AdapterItemOnTheWayViewHolder> {

    private final IAdapterItemOnTheWayListener listener;

    public interface IAdapterItemOnTheWayListener {
        void onViewClicked(int position);
    }

    private OnTheWay onTheWay;
    private NameStore nameStore;

    public AdapterItemOnTheWay(OnTheWay onTheWay, IAdapterItemOnTheWayListener listener) {
        this.listener = listener;
        this.onTheWay = onTheWay;
        this.nameStore = App.getInstance().getDb().nameStoreDao().getById(onTheWay.getNameId());
    }

    public OnTheWay getOnTheWay() {
        return onTheWay;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterItemOnTheWay && ((AdapterItemOnTheWay) o).getOnTheWay().getId() == getOnTheWay().getId();
    }

    @Override
    public AdapterItemOnTheWayViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new AdapterItemOnTheWayViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemOnTheWayViewHolder holder, int position, List<Object> payloads) {

        holder.textTitle.setText(nameStore.getMatt());

        StringBuilder sb = new StringBuilder();

        sb.append("Партія: ");
        sb.append(onTheWay.getSapBatch());
        sb.append("<br>");
        sb.append("Розмір: ");
        sb.append(nameStore.getSize());
        sb.append("<br>");
        sb.append("ОЗМ: ");
        sb.append(nameStore.getOzm());
        sb.append("<br>");
        sb.append("Склад: ");
        sb.append(onTheWay.getStorage());
        sb.append("<br>");
        sb.append("Очікувана вага: ");
        sb.append(onTheWay.getSapWeightNett());
        sb.append(" кг.");
        if (onTheWay.getWeightAccepted() > 0) {
            sb.append("<br>");
            sb.append("Прийнято: ");
            sb.append(onTheWay.getWeightAccepted());
            sb.append(" кг.");
        }

        holder.textContent.setText(App.getInstance().fromHtml(sb.toString()));

        if (onTheWay.getWeightAccepted() > 0) {
            holder.buttonView.setVisibility(View.VISIBLE);
            holder.buttonView.setOnClickListener(v -> {
                if (listener != null) listener.onViewClicked(position);
            });
        } else {
            holder.buttonView.setVisibility(View.GONE);
        }
    }

    @Override
    public void unbindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemOnTheWayViewHolder holder, int position) {

    }

    @Override
    public void onViewAttached(FlexibleAdapter<IFlexible> adapter, AdapterItemOnTheWayViewHolder holder, int position) {

    }

    @Override
    public void onViewDetached(FlexibleAdapter<IFlexible> adapter, AdapterItemOnTheWayViewHolder holder, int position) {

    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_ontheway_row;
    }

    /**
     * The ViewHolder used by this item.
     * Extending from FlexibleViewHolder is recommended especially when you will use
     * more advanced features.
     */
    public class AdapterItemOnTheWayViewHolder extends FlexibleViewHolder {

        private final View view;

        public TextView textTitle, textContent;
        public ImageButton buttonView;

        public AdapterItemOnTheWayViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.view = view;
            this.textTitle = view.findViewById(R.id.textTitle);
            this.textContent = view.findViewById(R.id.textContent);
            this.buttonView = view.findViewById(R.id.buttonView);
        }
    }
}
