package com.metinvest.smc.db;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity
public class OffShipLabel {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private String smcId;
    private String labelId;
    private long dt;
    private int nettoBefore, nettoAfter;
    private int pack;
    private String qrData;

    public OffShipLabel() {
    }

    @Ignore
    public OffShipLabel(long id, String qrData, String smcId, String labelId, long dt, int nettoBefore, int nettoAfter, int pack) {
        this.id = id;
        this.qrData = qrData;
        this.smcId = smcId;
        this.labelId = labelId;
        this.dt = dt;
        this.nettoBefore = nettoBefore;
        this.nettoAfter = nettoAfter;
        this.pack = pack;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getQrData() {
        return qrData;
    }

    public void setQrData(String qrData) {
        this.qrData = qrData;
    }

    public String getSmcId() {
        return smcId;
    }

    public void setSmcId(String smcId) {
        this.smcId = smcId;
    }

    public String getLabelId() {
        return labelId;
    }

    public void setLabelId(String labelId) {
        this.labelId = labelId;
    }

    public long getDt() {
        return dt;
    }

    public void setDt(long dt) {
        this.dt = dt;
    }

    public int getNettoBefore() {
        return nettoBefore;
    }

    public void setNettoBefore(int nettoBefore) {
        this.nettoBefore = nettoBefore;
    }

    public int getNettoAfter() {
        return nettoAfter;
    }

    public void setNettoAfter(int nettoAfter) {
        this.nettoAfter = nettoAfter;
    }

    public int getPack() {
        return pack;
    }

    public void setPack(int pack) {
        this.pack = pack;
    }
}
