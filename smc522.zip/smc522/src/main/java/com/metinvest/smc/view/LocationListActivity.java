package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterSimple;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class LocationListActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    @BindView(R.id.viewButtons)
    View viewButtons;
    @BindView(R.id.textFilter)
    EditText textFilter;
    @BindView(R.id.buttonFilterClear)
    ImageButton buttonFilterClear;

    private FlexibleAdapter<AdapterSimple> adapter;
    private List<AdapterSimple> adapterList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_list);
        ButterKnife.bind(this);

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

        textFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                doFilter();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) {
            beginLoad();
        } else if (number == 3) {
            buttonFilterClearClick();
        }
    }

    private void buttonFilterClearClick() {
        hideKeyboard();
        textFilter.setText(null);
        buttonFilterClick();
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        beginLoad();
    }

    private void beginLoad() {
        if (isLoading()) return;

        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);

        adapter = null;
        listView.setAdapter(null);

        Utils.runOnBackground(() -> {
            List<AdapterSimple> list = new ArrayList<>();

			String url = config.getUrlApi() + "getlocationlist";
			JsonResult result = net.downloadJson(url);

            if (result.isOk()) {
                JSONArray array = Utils.getJsonArray(result.getJson(), "data");

                for (int i = 0; array != null && i < array.length(); i++) {
                    String name = Utils.getJsonString(array, i);
                    AdapterSimple item = new AdapterSimple(name, name, null);
                    list.add(item);
                }
            }

            runOnUiThread(() -> endLoad(result, list));
        });
    }

	private void endLoad(JsonResult result, List<AdapterSimple> list) {
		hideLoading();

		textNotFound.setVisibility(result.isOk() && !list.isEmpty() ? View.GONE : View.VISIBLE);
		viewButtons.setVisibility(View.VISIBLE);

		if (result.isOk()) {
			this.adapterList = list;
			setAdapter(adapterList);
			buttonFilterClick();
		} else {
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
        }
    }

    private void buttonFilterClick() {
        doFilter();
        listView.post(() -> listView.requestFocus());
        scrollView.post(() -> scrollView.scrollTo(0, 0));
    }

    private void setAdapter(List<AdapterSimple> list) {
        adapter = new FlexibleAdapter<>(list);
        adapter.addListener(this);
        listView.setAdapter(adapter);
    }

    private void doFilter() {
        String filterText = textFilter.getText().toString();
        if (adapter == null) return;

        List<AdapterSimple> list = new ArrayList<>();

        for (AdapterSimple item : adapterList) {
            if (item.getTitle().toLowerCase().contains(filterText.toLowerCase())) {
                list.add(item);
            }
        }

        setAdapter(list);
        textNotFound.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public boolean onItemClick(View view, int position) {
        AdapterSimple item = adapter.getItem(position);
        if (item != null) {
            Intent data = new Intent();
            data.putExtra("id", item.getId());
            setResult(RESULT_OK, data);
            finish();
        }
        return false;
    }
}
