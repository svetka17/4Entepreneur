package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.inc.SohFilter;
import com.metinvest.smc.inc.TTN;
import com.metinvest.smc.inc.TransportDoc;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.Utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class IncStatusActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

    @BindView(R.id.viewButtons)
    View viewButtons;
    @BindView(R.id.viewContentData)
    View viewContentData;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;

    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
	@BindView(R.id.listView)
	RecyclerView listView;

	private Date date, dateFrom, dateTo;
	private String transportName;
	private TransportDoc doc;
	private FlexibleAdapter<Adapter> adapter;
	private TTN ttn;
	private String status;
	private boolean isManager;
	private String sohSmcId;
	private SohFilter sohFilter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_inc_status);
		ButterKnife.bind(this);

		sohSmcId = getIntent().getStringExtra("sohSmcId");
		sohFilter = sohSmcId == null ? SohFilter.NotSoh() : SohFilter.SohInc(sohSmcId);
		dateFrom = (Date) getIntent().getSerializableExtra("dateFrom");
		dateTo = (Date) getIntent().getSerializableExtra("dateTo");
		date = (Date) getIntent().getSerializableExtra("date");
		transportName = getIntent().getStringExtra("transportName");
		ttn = (TTN) getIntent().getSerializableExtra("ttn");
		status = getIntent().getStringExtra("status");
		isManager = getIntent().getBooleanExtra("isManager", false);

		listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
	}

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) beginAccept();
        else if (number == 6) beginLoad();
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    private static class AV {
        public String id, title;
        boolean enabled;

        AV(String id, String title, boolean enabled) {
            this.id = id;
            this.title = title;
            this.enabled = enabled;
        }
    }

    private String getStatusTitle(String id) {
        if (id.equalsIgnoreCase("99")) return "Завершити розгрузку";
        if (id.equalsIgnoreCase("97")) return "Відхилити (майстер помилився)";
        if (id.equalsIgnoreCase("1")) return "Відправити в SAP";
        return "";
    }

    private void beginLoad() {
        if (isLoading()) return;

        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);

        Utils.runOnBackground(() -> {
            Network.NetworkResultValue<TransportDoc> result = app.loadIncTransportDoc(date, dateFrom, dateTo, transportName, ttn, sohFilter);

            if (result.getResult().isOk()) {

				List<AV> avs = new ArrayList<>();
                /*if (isManager) {
                    avs.add(new AV("1", getStatusTitle("1"), status.equalsIgnoreCase("99") || status.equalsIgnoreCase("8")));
                    avs.add(new AV("97", getStatusTitle("97"), status.equalsIgnoreCase("99") || status.equalsIgnoreCase("8")));
                } else {
                    avs.add(new AV("99", getStatusTitle("99"), status.equalsIgnoreCase("") || status.equalsIgnoreCase("0") || status.equalsIgnoreCase("97")));
                }*/
				avs.add(new AV("99", getStatusTitle("1"),
						status.equalsIgnoreCase("") ||
								status.equalsIgnoreCase("0") ||
								status.equalsIgnoreCase("97") ||
								status.equalsIgnoreCase("99") ||
								status.equalsIgnoreCase("8")
				));

				List<Adapter> list = new ArrayList<>();
				for (AV av : avs) {
					list.add(new Adapter(av.id, av.title, null, status.equalsIgnoreCase(av.id), av.enabled));
				}

				adapter = new FlexibleAdapter<>(list);
				adapter.addListener(this);
			}

            runOnUiThread(() -> endLoad(result.getResult(), result.getValue()));
        });
    }

    private void endLoad(JsonResult result, TransportDoc doc) {

        boolean isContent = doc != null;

        hideLoading();
        this.doc = doc;
        viewButtons.setVisibility(isContent ? View.VISIBLE : View.GONE);
        viewContentData.setVisibility(isContent ? View.VISIBLE : View.GONE);
        textNotFound.setVisibility(!isContent ? View.VISIBLE : View.GONE);

        if (doc != null) {
            showContent();
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
        }
    }

    private Adapter getCheckedItem() {
        if (adapter != null) {
            List<Adapter> list = adapter.getCurrentItems();
            for (Adapter item : list) {
                if (item.isEnabled() && item.isChecked()) return item;
            }
        }
        return null;
    }

    private void showContent() {
        listView.setAdapter(adapter);
        scrollView.post(() -> scrollView.scrollTo(0, 0));
        refreshButtonAccept();
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_CANCELED);
        super.onBackPressed();
    }

    @Override
    public boolean onItemClick(View view, int position) {
        Adapter item = adapter.getItem(position);
        if (item != null) {

            Adapter itemChecked = getCheckedItem();
            if (itemChecked != null && !itemChecked.equals(item)) {
                itemChecked.setChecked(false);
                adapter.updateItem(itemChecked);
            }

            item.setChecked(!item.isChecked());
            adapter.notifyItemChanged(position);
            refreshButtonAccept();
            return true;
        }
        return false;
    }

    private void refreshButtonAccept() {
        buttonAccept.setEnabled(getCheckedItem() != null);
    }

    private void beginAccept() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        Adapter item = getCheckedItem();
        if (item == null) return;

        accept(item);
    }

    private void accept(Adapter item) {
        Intent data = new Intent();
        data.putExtra("id", Utils.parseInt(item.getId()));
        data.putExtra("name", item.getTitle());
        data.putExtra("isVhp", false);
        setResult(RESULT_OK, data);
        finish();
    }

    public class Adapter extends AbstractFlexibleItem<Adapter.ViewHolder> {

        private final String id;
        private final String title, content;
        private boolean checked, enabled;

        public Adapter(String id, String title, String content, boolean checked, boolean enabled) {
            this.id = id;
            this.title = title;
            this.content = content;
            this.checked = checked;
            this.enabled = enabled;
        }

        @Override
        public boolean isEnabled() {
            return enabled;
        }

        @Override
        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof Adapter && ((Adapter) o).getTitle().equalsIgnoreCase(getTitle());
        }

        @Override
        public int hashCode() {
            return getTitle().hashCode();
        }

        public String getId() {
            return id;
        }

        public String getTitle() {
            return title;
        }

        public String getContent() {
            return content;
        }

        public boolean isChecked() {
            return checked;
        }

        public void setChecked(boolean checked) {
            this.checked = checked;
        }

        @Override
        public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
            return new ViewHolder(view, adapter);
        }

        @Override
        public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {
            String data = Utils.format("%s", getTitle());
            holder.textTitle.setText(App.getInstance().fromHtml(data));

            if (isEnabled()) {
                holder.imageCheck.setImageResource(isChecked() ? R.drawable.ic_checkbox_check : R.drawable.ic_checkbox_uncheck);
            } else {
                holder.imageCheck.setImageResource(isChecked() ? R.drawable.ic_checkbox_check_disabled : R.drawable.ic_checkbox_uncheck_disabled);
            }

            holder.textTitle.setTextColor(getColor(isEnabled() ? R.color.tint_black : R.color.tint_disabled));

            View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
            holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
            refreshBackground(holder, holder.itemView.isFocused());
        }

        private void refreshBackground(ViewHolder holder, boolean hasFocus) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_background));
        }

        @Override
        public int getLayoutRes() {
            return R.layout.adapter_inc_status;
        }

        public class ViewHolder extends FlexibleViewHolder {
            @BindView(R.id.imageCheck)
            ImageView imageCheck;
            @BindView(R.id.textTitle)
            TextView textTitle;

            public ViewHolder(View view, FlexibleAdapter adapter) {
                super(view, adapter);
                ButterKnife.bind(this, view);
            }
        }
    }

}
