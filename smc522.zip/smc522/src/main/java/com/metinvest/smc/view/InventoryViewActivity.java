package com.metinvest.smc.view;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemInventory;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class InventoryViewActivity extends MyActivity {

    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;

    private Date date;
    private String locationId;
    private FlexibleAdapter<AdapterItemInventory> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_view);
        ButterKnife.bind(this);

        date = new Date(getIntent().getLongExtra("date", 0));
        locationId = getIntent().getStringExtra("location_id");

        log("location_id: %s", locationId);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
        listView.setLayoutManager(layoutManager);
        listView.addItemDecoration(dividerItemDecoration);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    private void beginLoad() {
        showLoading(R.string.text_please_wait);

        String url = config.getUrlApi() + "invbydatelistofnonfound";
        url = net.addUrlParam(url, "location_id", locationId);
        url = net.addUrlParam(url, "date", app.getDateFormat().format(date));

        reqGet(url, this::endLoad);
    }

	private void endLoad(JsonResult result) {

		runOnUiThread(this::hideLoading);

		if (result.isOk()) {
			JSONObject json = Utils.getJsonObject(result.getJson(), "data");

			JSONArray labels = Utils.getJsonArray(json, "labels");

			List<AdapterItemInventory> items = new ArrayList<>();
			for (int i = 0; i < (labels == null ? 0 : labels.length()); i++) {
                items.add(new AdapterItemInventory(Utils.getJsonObject(labels, i)));
            }
            showList(items);

        } else {
            runOnUiThread(() -> {
                showList(null);
                showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_list_loading, (dialog, which) -> beginLoad());
            });
        }
    }

    private void showList(List<AdapterItemInventory> items) {
        adapter = new FlexibleAdapter<>(items);
        listView.setAdapter(adapter);
        scrollView.post(() -> scrollView.scrollTo(0, 0));
        textNotFound.setVisibility(adapter.getItemCount() > 0 ? View.GONE : View.VISIBLE);
    }
}
