package com.metinvest.smc.tools;

import com.metinvest.smc.App;
import com.metinvest.smc.db.ShipmentDocument;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class DplGeneratorZebraShip {

	private final App app;
	private final ShipmentDocument document;
	private final Date date;
	private final int totalBrutto;

	private int printedY;
	private StringBuilder printedData;
	private int printedPage, printedPageCount;
	private String printedTtnDate;

	private final int lineHeight = 30;
	private final int maxY = 1000;

	private final List<Group> groupList;

	private static class Group {
		public String name, ozm;
		public float width, length, thickness;
		public int plan, fact;
		private final List<Batch> batchList;

		private void addItem(Batch batch) {
			batchList.add(batch);
		}

		private void sortItems() {
			//Collections.sort(batchList, (o1, o2) -> Integer.compare(o1.weighingId, o2.weighingId));
		}

		private Batch getBatch(int index) {
			return batchList.get(index);
		}

		private int getItemCount() {
			return batchList.size();
		}

		public Group(String name, String ozm, float width, float length, float thickness, int plan, int fact) {
			this.name = name;
			this.ozm = ozm;
			this.width = width;
			this.length = length;
			this.thickness = thickness;
			this.plan = plan;
			this.fact = fact;
			this.batchList = new ArrayList<>();
		}
	}

	private static class Batch {
		private final String status;
		public final String batch;
		public final int fact;
		public final List<Item> itemList;
		public final List<String> carrierList;
		public final List<String> printedList;

		public Batch(String batch, int fact, String status) {
			this.batch = batch;
			this.fact = fact;
			this.status = status;
			this.itemList = new ArrayList<>();
			this.carrierList = new ArrayList<>();
			this.printedList = new ArrayList<>();
		}
	}

	private static class Item {
		public final int lineId;
		public final String labelId;
		public int nett, pack;
		public final String ttnCarrierId, datePrinted;

		public Item(int lineId, String labelId, int nett, int pack, String ttnCarrierId, String datePrinted) {
			this.lineId = lineId;
			this.labelId = labelId;
			this.nett = nett;
			this.pack = pack;
			this.ttnCarrierId = ttnCarrierId;
			this.datePrinted = datePrinted;
		}
	}

	public DplGeneratorZebraShip(ShipmentDocument document, Date date, int totalBrutto, JSONArray ozmArray) {
		this.app = App.getInstance();
		this.document = document;
		this.date = date;
		this.totalBrutto = totalBrutto;
		this.groupList = new ArrayList<>();

		int groupCount = ozmArray == null ? 0 : ozmArray.length();
		for (int i = 0; i < groupCount; i++) {
			JSONObject jsonGroup = Utils.getJsonObject(ozmArray, i);

			if (jsonGroup != null) {

				String name = Utils.getJsonStringIgnoreCase(jsonGroup, "saP_MATT_DESCR");
				String ozm = Utils.getJsonStringIgnoreCase(jsonGroup, "saP_OZM");
				float width = Utils.getJsonFloatIgnoreCase(jsonGroup, "width");
				float length = Utils.getJsonFloatIgnoreCase(jsonGroup, "length");
				float thickness = Utils.getJsonFloatIgnoreCase(jsonGroup, "thickness");
				int plan = Utils.getJsonWeightKgIgnoreCase(jsonGroup, "plaN_Weight");
				int fact = Utils.getJsonWeightKgIgnoreCase(jsonGroup, "facT_Weight");
				JSONArray arrayBatches = Utils.getJsonArray(jsonGroup, "ozmBatches");

				Group group = new Group(
						name, ozm,
						width, length, thickness,
						plan, fact
				);

				if (arrayBatches != null) {
					int batchCount = arrayBatches.length();
					for (int j = 0; j < batchCount; j++) {
						JSONObject jsonBatch = Utils.getJsonObject(arrayBatches, j);

						if (jsonBatch != null) {
							String sapBatch = Utils.getJsonStringIgnoreCase(jsonBatch, "saP_Batch");

							int factNetto = Utils.getJsonWeightKgIgnoreCase(jsonBatch, "facT_Weight");
							String status = Utils.getJsonStringIgnoreCase(jsonBatch, "saP_FACT_STATUS_OUT");
							if (factNetto > 0) {
								Batch batch = new Batch(sapBatch, factNetto, status);

								//List<String> carrierList = new ArrayList<>();
								//List<String> printedList = new ArrayList<>();

								JSONArray arrayLabels = Utils.getJsonArray(jsonBatch, "lidsByBatch");
								if (arrayLabels != null && arrayLabels.length() > 0) {
									int labelCount = arrayLabels.length();
									for (int z = 0; z < labelCount; z++) {
										JSONObject jsonLabel = Utils.getJsonObject(arrayLabels, z);
										int labelLineId = Utils.getJsonIntIgnoreCase(jsonLabel, "line_id");
										String labelId = Utils.getJsonStringIgnoreCase(jsonLabel, "id_qr");
										int labelNett = Utils.getJsonWeightKg(jsonLabel, "saP_WEIGHT_NETT");
										int labelPack = Utils.getJsonWeightKg(jsonLabel, "saP_WEIGHT_PACK");
										String ttnCarrierId = Utils.getJsonStringIgnoreCase(jsonLabel, "ttN_CARRIER_ID");
										String datePrinted = Utils.getJsonStringIgnoreCase(jsonLabel, "datE_PRINTED");
										if (datePrinted.length() > 10)
											datePrinted = datePrinted.substring(0, 10);

										int ind = findLabel(batch.itemList, labelId);

										if (ind != -1) {
											batch.itemList.get(ind).nett += labelNett;
											batch.itemList.get(ind).pack += labelPack;
										} else {
											Item item = new Item(labelLineId, labelId, labelNett, labelPack, ttnCarrierId, datePrinted);
											batch.itemList.add(item);
										}

										//
										int ind2 = findString(batch.carrierList, ttnCarrierId);
										if (ind2 == -1) {
											batch.carrierList.add(ttnCarrierId);
											batch.printedList.add(datePrinted);
										} else {
											String foundDt = batch.printedList.get(ind2);
											if (!foundDt.equalsIgnoreCase(datePrinted)) {
												batch.carrierList.add(ttnCarrierId);
												batch.printedList.add(datePrinted);
											}
										}
									}
								}

								group.addItem(batch);
							}
						}
					}

				}

				group.sortItems();
				groupList.add(group);
			}
		}
	}

	private int findString(List<String> list, String value) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).equalsIgnoreCase(value)) return i;
		}
		return -1;
	}

	private int findLabel(List<Item> list, String labelId) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).labelId.equalsIgnoreCase(labelId)) return i;
		}
		return -1;
	}

	public String generateTitle() {
		return Utils.format("<b>Відвантаження</b><br>Номер наряду: %s<br>Номер машини: %s",
				document.getDocNumber(), document.getTransportName());
	}

	public String generateDpl() {

		long t1 = Calendar.getInstance().getTime().getTime();

		printedData = new StringBuilder();
		printedY = 0;
		printedPage = 0;
		printedPageCount = 0;

		printedTtnDate = app.getDateFormat().format(date);

		processItems();

		long t2 = Calendar.getInstance().getTime().getTime();

		app.log(this, "TIME FOR GENERATE DPL: %d ms", t2 - t1);

		return printedData.toString();
	}

	private void processItems() {

		//DPL
		addNewPage(true);

		int totalWeightFact = 0;

		//CONTENT
		for (int g = 0; g < groupList.size(); g++) {

			Group group = groupList.get(g);

			totalWeightFact += group.fact;

			addOzm(group);

			for (int i = 0; i < group.getItemCount(); i++) {
				Batch groupBatch = group.getBatch(i);

				printLine(20, Utils.format("Партія: %s %.3f тн", groupBatch.batch, groupBatch.fact / 1000.0f));
				addY(lineHeight);

				for (int j = 0; j < groupBatch.itemList.size(); j++) {
					printLine(20, Utils.format(
							"        LabelId:%s %.3f тн",
							groupBatch.itemList.get(j).labelId, groupBatch.itemList.get(j).nett / 1000.0f
					));
					addY(lineHeight);
				}

				for (int j = 0; j < groupBatch.carrierList.size(); j++) {
					printLine(20, Utils.format(
							"        ТС:%s %s",
							groupBatch.carrierList.get(j), groupBatch.printedList.get(j)
					));
					addY(lineHeight);
				}
			}

			int r = group.fact - group.plan;

			String ozmFooter = Utils.format(
					"Сума НЕТТО план/факт: %.3f/%.3f тн (%s кг)",
					group.plan / 1000.0f, group.fact / 1000.0f, (r > 0 ? "+" : "") + r
			);
			printLine(20, ozmFooter);
			addY(lineHeight);
			addY(lineHeight);
		}

		//USER
		if (printedY > maxY - lineHeight * 4) {
			addNewPage(false);
		} else {
			printedY = maxY - lineHeight * 4;
		}

		printLine(20, Utils.format("Оператор: %s (%s)", app.getConfig().getUserName(), app.getDateTimeFormat().format(Calendar.getInstance().getTime())));
		addY(lineHeight);

		printLine(20,
				Utils.format("Сумма НЕТТО/БРУТТО по ТС: %.3f/%.3f тн",
						totalWeightFact / 1000.0f,
						totalBrutto / 1000.0f
				)
		);
		addY(lineHeight);

		printedData.append("\n^XZ\n");

		Utils.replaceAll(printedData, "{{PAGE_COUNT}}", String.valueOf(printedPageCount));
	}

	private void addNewPage(boolean printHeader) {
		printedPage++;
		printedPageCount++;

		if (printedPage > 1) printedData.append("\n^XZ\n");

		//printedData.append("\n\n^XA\n\n^CI28\n^A0N,50,50,E:TT0003M_.FNT\n^LH25,30\n^POI\n^PQ1,0,0,N\n\n~JS50\n^MD20\n^PR1,1,1\n^MNM,40\n^LL1050\n^PW900\n");
		if (app.getConfig().getPrinterPaperType() == 1) { //Етикетка
			printedData.append("\n\n^XA\n\n^CI28\n^A0N,50,50,E:TT0003M_.FNT\n^POI\n^MD20\n^PR2,2,2\n^PQ1,0,0,N\n\n^LH25,30\n^LL1050\n^PW900\n");
		} else if (app.getConfig().getPrinterPaperType() == 2) { //Бірка
			printedData.append("\n\n^XA\n\n^CI28\n^A0N,50,50,E:TT0003M_.FNT\n^POI\n^MD20\n^PR2,2,2\n^PQ1,0,0,N\n\n^LH25,0\n^LL1199\n^PW800\n");
		}
		printedY = 0;

		addHeader(printHeader);
	}

	private void addOzm(Group group) {
		String nameLine = group.name.substring(0, Math.min(group.name.length(), 45));
		String ozmLine = group.ozm.substring(0, Math.min(group.ozm.length(), 45));
		String sizeLine = app.sizeToString(group.length, group.width, group.thickness);

		printLine(20, nameLine);
		addY(lineHeight);

		if (sizeLine.length() > 0) {
			printLine(20, Utils.format("%s%s", sizeLine, ozmLine.length() > 0 ? ", ОЗМ:" + ozmLine : ""));
			addY(lineHeight);
		}
	}

	private void addHeader(boolean withTitle) {

		addY(lineHeight);

		printLine(20, Utils.format("Наряд на відгрузку №: %s", document.getDocNumber()));
		printLine(630, Utils.format("Лист %d з {{PAGE_COUNT}}", printedPage));
		addY(lineHeight);
		printLine(20, Utils.format("ТТН: %s %s ", document.getTransportName(), printedTtnDate));

		addY(50);
		addY(lineHeight);
	}

	private void addY(int value) {
		printedY += value;

		if (value > 0 && printedY > maxY) {
			addNewPage(true);
		}
	}

	private void printLine(int x, String text) {
		printedData.append(Utils.format("^FO%d,%d^A0N,27,25^FD%s^FS\n", x, printedY, text));
	}
}