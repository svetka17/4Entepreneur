package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import com.metinvest.smc.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ShipStatusActivity extends MyActivity {

    @BindView(R.id.viewContentData)
    View viewContentData;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;
    @BindView(R.id.checkbox)
    CheckBox checkbox;

    @BindView(R.id.checkboxPart)
    CheckBox checkboxPart;
    @BindView(R.id.textWarning)
    TextView textWarning;

    boolean isClose = false;
    boolean isClosePart = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ship_status);
        ButterKnife.bind(this);

        isClose = getIntent().getBooleanExtra("isClose", true);
        //isClosePart = getIntent().getBooleanExtra("isClosePart", false);
        textWarning.setVisibility(isClose ? View.VISIBLE : View.GONE);

        buttonAccept.setEnabled(false);
        checkbox.setText(isClose ? R.string.ship_status_action_close : R.string.ship_status_action_open);
        checkbox.setOnCheckedChangeListener((buttonView, isChecked) -> buttonAccept.setEnabled(isChecked));
        if (config.isEo())
        {
            /*if (isClose)
                checkbox.setVisibility(View.VISIBLE);
            else
                checkbox.setVisibility(View.GONE);*/
            isClosePart = getIntent().getBooleanExtra("isClosePart", false);
            if (isClosePart) {
                checkbox.setVisibility(View.GONE);
                checkboxPart.setVisibility(View.VISIBLE);
                checkboxPart.setText("Розблокувати наряд");
                checkboxPart.setOnCheckedChangeListener((buttonView, isChecked) -> buttonAccept.setEnabled(isChecked));
            } else
                checkboxPart.setVisibility(View.GONE);

            //buttonAccept.setEnabled(true);
            //
            /*checkboxPart.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (checkbox.isChecked() && checkboxPart.isChecked()) checkbox.setChecked(false);
                buttonAccept.setEnabled(isChecked);
            });*/
            //if (!isClose || isClosePart)

            //else
                //checkboxPart.setVisibility(View.VISIBLE);
        }
        else
            checkboxPart.setVisibility(View.GONE);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            /*if (config.isEo() && checkbox.isChecked() && checkboxPart.isChecked())
                checkbox.setChecked(false);
            else*/
                beginAccept();
        }
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_CANCELED);
        super.onBackPressed();
    }

    private void beginAccept() {
        if (isLoading() || !buttonAccept.isEnabled()) return;
        Intent data = new Intent();
        if (config.isEo() /*&& checkboxPart.isChecked()*/) {
            if (checkbox.isChecked())
                data.putExtra("action", isClose ? "close" : "open");
                //data.putExtra("action", "close");
            if (checkboxPart.isChecked())
                data.putExtra("action", "part");
        } else
            data.putExtra("action", isClose ? "close" : "open");
        setResult(RESULT_OK, data);
        finish();
    }
}
