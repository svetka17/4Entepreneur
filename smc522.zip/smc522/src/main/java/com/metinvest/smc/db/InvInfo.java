package com.metinvest.smc.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.metinvest.smc.App;
import com.metinvest.smc.tools.Utils;

import java.util.Date;

@Entity
public class InvInfo {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private long invDate, invCount;

    public InvInfo() {
    }

    @Ignore
    public InvInfo(long id, long invDate, long invCount) {
        this.id = id;
        this.invDate = invDate;
        this.invCount = invCount;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getInvDate() {
        return invDate;
    }

    public void setInvDate(long invDate) {
        this.invDate = invDate;
    }

    public long getInvCount() {
        return invCount;
    }

    public void setInvCount(long invCount) {
        this.invCount = invCount;
    }

    @NonNull
    @Override
    public String toString() {
        return Utils.format("[%s] %s", App.getInstance().getDateTimeFormat().format(new Date(getInvDate())), getInvCount());
    }
}
