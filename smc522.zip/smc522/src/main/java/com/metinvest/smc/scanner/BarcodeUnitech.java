package com.metinvest.smc.scanner;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

import com.metinvest.smc.App;

public class BarcodeUnitech {

	private final App app;
	private final IntentFilter filterScan;
	private final BroadcastReceiver scanReceiver;

	private static final String ACTIVITY_INTENT_FILTER_ACTION = "android.intent.ACTION_DECODE_DATA";

	public BarcodeUnitech(App app) {
		this.app = app;

		this.app.log(this, "()");

		filterScan = new IntentFilter();
		filterScan.addCategory(Intent.CATEGORY_DEFAULT);
		filterScan.addAction(ACTIVITY_INTENT_FILTER_ACTION);

		scanReceiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {

				String action = intent.getAction();
				if (action == null) return;

				app.log(this, "receive action: %s", action);

				if (action.equalsIgnoreCase(ACTIVITY_INTENT_FILTER_ACTION)) {
					String decodedData = intent.getStringExtra("barcode_string");
					if (decodedData != null) app.onBarcodeEvent(decodedData);
				}
			}
		};
	}

	public void onResume() {
		try {
			app.registerReceiver(scanReceiver, filterScan);
		} catch (Exception ignored) {

		}
	}

	public void onPause() {
		app.unregisterReceiver(scanReceiver);
	}

	public void onDestroy() {
		app.log(this, "onDestroy()");
	}
}