package com.metinvest.smc.tools;

import com.metinvest.smc.App;
import com.metinvest.smc.inc.Transport;
import com.metinvest.smc.inc.TransportDoc;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

public class DplGeneratorZebraInc {

	private final App app;
	private final Transport transport;
	private final TransportDoc doc;

	private int printedY;
	private StringBuilder printedData;
	private int printedPage, printedPageCount;
	private String printedCarrier, printedTtnNum, printedTtnDate;

	private final int lineHeight = 30;
	private final int maxY = 1000;// 1440;

	private final List<Group> groupList;

	private static class Group {
		public String name, ozm;
		public float width, length, thickness;
		public int plan, fact;
		private final List<Item> itemList;

		private void addItem(Item item) {
			itemList.add(item);
		}

		private void sortItems() {
			Collections.sort(itemList, (o1, o2) -> Integer.compare(o1.weighingId, o2.weighingId));
		}

		private Item getItem(int index) {
			return itemList.get(index);
		}

		private int getItemCount() {
			return itemList.size();
		}

		public Group(String name, String ozm, float width, float length, float thickness, int plan, int fact) {
			this.name = name;
			this.ozm = ozm;
			this.width = width;
			this.length = length;
			this.thickness = thickness;
			this.plan = plan;
			this.fact = fact;
			this.itemList = new ArrayList<>();
		}
	}

	private static class Item {
		public String labelId, batch;
		public int birk, fact, pack, tara;
		public int weighingId;

		public Item(String labelId, String batch, int birk, int fact, int pack, int tara, int weighingId) {
			this.labelId = labelId;
			this.batch = batch;
			this.birk = birk;
			this.fact = fact;
			this.pack = pack;
			this.tara = tara;
			this.weighingId = weighingId;
		}
	}

	public DplGeneratorZebraInc(TransportDoc doc, JSONArray array) {
		this.app = App.getInstance();
		this.transport = doc.getTransport();
		this.doc = doc;
		this.groupList = new ArrayList<>();

		int groupCount = array.length();
		for (int i = 0; i < groupCount; i++) {
			JSONObject jsonGroup = Utils.getJsonObject(array, i);

			if (jsonGroup != null) {

				String name = Utils.getJsonStringIgnoreCase(jsonGroup, "saP_MATT_DESCR");
				String ozm = Utils.getJsonStringIgnoreCase(jsonGroup, "saP_OZM");
				float width = Utils.getJsonFloatIgnoreCase(jsonGroup, "width");
				float length = Utils.getJsonFloatIgnoreCase(jsonGroup, "length");
				float thickness = Utils.getJsonFloatIgnoreCase(jsonGroup, "thickness");
				int plan = Utils.getJsonWeightKgIgnoreCase(jsonGroup, "plaN_Nett");
				int fact = Utils.getJsonWeightKgIgnoreCase(jsonGroup, "facT_Nett");
				JSONArray arrayLabels = Utils.getJsonArray(jsonGroup, "labels");

				Group group = new Group(
						name, ozm,
						width, length, thickness,
						plan, fact
				);

				if (arrayLabels != null) {
					int labelCount = arrayLabels.length();
					for (int j = 0; j < labelCount; j++) {
						JSONObject jsonLabel = Utils.getJsonObject(arrayLabels, j);
						if (jsonLabel != null) {
							String labelId = Utils.getJsonStringIgnoreCase(jsonLabel, "labelId");
							String batch = Utils.getJsonStringIgnoreCase(jsonLabel, "batch");
							int labelBirk = Utils.getJsonWeightKgIgnoreCase(jsonLabel, "mengE_BIRK");
							int labelFact = Utils.getJsonWeightKgIgnoreCase(jsonLabel, "mengE_FACT");
							int labelPack = Utils.getJsonWeightKgIgnoreCase(jsonLabel, "mengE_PACK");
							int labelTara = Utils.getJsonWeightKgIgnoreCase(jsonLabel, "mengE_TARA");
							int labelWid = Utils.getJsonIntIgnoreCase(jsonLabel, "iD_Wheigning");
							if (labelFact > 0) {
								Item label = new Item(labelId, batch, labelBirk, labelFact, labelPack, labelTara, labelWid);
								group.addItem(label);
							}
						}
					}

				}

				group.sortItems();
				groupList.add(group);
			}
		}
	}

	public String generateTitle() {
		return "<b>Звіт по транспорту</b><br>" + transport.getName();
	}

	public String generateDpl() {

		long t1 = Calendar.getInstance().getTime().getTime();

		printedData = new StringBuilder();
		printedY = 0;
		printedPage = 0;
		printedPageCount = 0;

		printedCarrier = transport.getName();
		printedTtnNum = doc.getTtn().getNum();
		printedTtnDate = app.getDateFormat().format(transport.getDate());

		processItems();

		long t2 = Calendar.getInstance().getTime().getTime();

		app.log(this, "TIME FOR GENERATE DPL: %d ms", t2 - t1);

		return printedData.toString();
	}

	private void processItems() {

		//DPL
		addNewPage(true);

		int totalWeightPlan = 0;
		int totalWeightFact = 0;
		int totalItemCount = 0;
		int totalWeighingCount = 0;
		int totalBruttoFact = 0;
		int totalR = 0;

		//CONTENT
		for (int g = 0; g < groupList.size(); g++) {

			Group group = groupList.get(g);

			totalWeightPlan += group.plan;
			totalWeightFact += group.fact;

			addOzm(group);

			for (int i = 0; i < group.getItemCount(); i++) {
				Item item = group.getItem(i);

				boolean printWeighing = i == 0 || group.getItem(i - 1).weighingId != item.weighingId;
				if (printWeighing) {
					totalWeighingCount++;
				}

				printedData.append(Utils.format("^FO20,%d^A0N,27,25^FD%s^FS\n" +  //Порядковый номер
								"^FO60,%d^A0N,27,25^FD%s^FS\n" + //вес брутто
								"^FO200,%d^A0N,27,25^FD%s^FS\n" + //номер партии
								"^FO390,%d^A0N,27,25^FD%s^FS\n" + //БІРКА БРУТ. /УПАК. /НЕТ.
								"^FO690,%d^A0N,27,25^FD%s^FS\n", //Ф.НЕТ.
						printedY, printWeighing ? Utils.format("%02d", item.weighingId) : "",
						printedY, printWeighing ? Utils.format("%.3f тн", getTotalBirkW(group, item.weighingId) / 1000.0f) : "",
						printedY, item.batch,
						printedY, Utils.format("%.3f / %.3f / %.3f",
								(item.birk + item.pack + item.tara) / 1000.0f,
								(item.pack + item.tara) / 1000.0f,
								(item.birk) / 1000.0f
						),
						printedY, Utils.format("%.3f", item.fact / 1000.0f
						)));

				addY(lineHeight);

				totalItemCount++;
				totalBruttoFact += item.fact + item.pack + item.tara;
			}

			int r = group.fact - group.plan;
			totalR += r;

			String ozmFooter = Utils.format(
					"Сума НЕТТО по ОЗМ план/факт: %.3f/%.3f тн (%s кг)",
					group.plan / 1000.0f, group.fact / 1000.0f, (r > 0 ? "+" : "") + String.valueOf(r)
			);
			printLine(20, ozmFooter);
			addY(7);
			addY(lineHeight);
		}

		//USER
		if (printedY > maxY - lineHeight * 4) {
			addNewPage(false);
		} else {
			printedY = maxY - lineHeight * 4;
		}

		printLine(20, Utils.format("Всього підйомів %d, пачок %d", totalWeighingCount, totalItemCount));
		addY(lineHeight);

		printLine(20, Utils.format("Оператор: %s (%s)", app.getConfig().getUserName(), app.getDateTimeFormat().format(Calendar.getInstance().getTime())));
		addY(lineHeight);

		printLine(20, Utils.format("Разом по ТС НЕТТО план/факт: %.3f/%.3f (%s кг)",
				totalWeightPlan / 1000.0f,
				totalWeightFact / 1000.0f,
				(totalR > 0 ? "+" : "") + totalR
				)
		);
		addY(lineHeight);

		printLine(20, Utils.format("Сумма БРУТТО факт по ТС: %.3f тн", totalBruttoFact / 1000.0f));

		printedData.append("\n^XZ\n");

		Utils.replaceAll(printedData, "{{PAGE_COUNT}}", String.valueOf(printedPageCount));
	}

	private void printLine(int x, String text) {
		printedData.append(Utils.format("^FO%d,%d^A0N,27,25^FD%s^FS\n", x, printedY, text));
	}

	private int getTotalBirkW(Group group, int weighingId) {
		int total = 0;
		for (int i = 0; i < group.getItemCount(); i++) {
			Item item = group.getItem(i);
			//if (item.weighingId == weighingId) total += item.birk;
			if (item.weighingId == weighingId) total += item.fact + item.pack;
		}
		return total;
	}

	private void addNewPage(boolean printHeader) {
		printedPage++;
		printedPageCount++;

		if (printedPage > 1) printedData.append("\n^XZ\n");

		//printedData.append("\n\n^XA\n\n^CI28\n^A0N,50,50,E:TT0003M_.FNT\n^LH25,30\n^POI\n^PQ1,0,0,N\n\n~JS50\n^MD20\n^PR1,1,1\n^MNM,40\n^LL1050\n^PW900\n");
		if (app.getConfig().getPrinterPaperType() == 1) { //Етикетка
			printedData.append("\n\n^XA\n\n^CI28\n^A0N,50,50,E:TT0003M_.FNT\n^POI\n^MD20\n^PR2,2,2\n^PQ1,0,0,N\n\n^LH25,30\n^LL1050\n^PW900\n");
		} else if (app.getConfig().getPrinterPaperType() == 2) { //Бірка
			printedData.append("\n\n^XA\n\n^CI28\n^A0N,50,50,E:TT0003M_.FNT\n^POI\n^MD20\n^PR2,2,2\n^PQ1,0,0,N\n\n^LH25,0\n^LL1199\n^PW800\n");
		}

		printedY = 0;

		addHeader(printHeader);
	}

	private void addOzm(Group group) {
		String nameLine = group.name.substring(0, Math.min(group.name.length(), 45));
		String sizeLine = Utils.format("%.3fx%.3fx%.3f", group.length, group.width, group.thickness);

		if (nameLine.length() + sizeLine.length() + 1 <= 45) {
			nameLine += " " + sizeLine;
			sizeLine = "";
		}

		printLine(20, nameLine);
		addY(lineHeight);

		if (sizeLine.length() > 0) {
			printLine(20, sizeLine);
			addY(lineHeight);
		}
	}

	private void addHeader(boolean withTitle) {

		addY(lineHeight);

		printLine(20, Utils.format("Транспорт №. %s", printedCarrier));
		printLine(660, Utils.format("Лист %d з {{PAGE_COUNT}}", printedPage));
		addY(lineHeight);
		printLine(20, Utils.format("ТТН: %s", printedTtnNum));
		printLine(180, Utils.format("від %s", printedTtnDate));

		addY(50);
		addY(lineHeight);

		if (withTitle) {
			//"БРУТ. ПАРТІЯ БІРКА БРУТ./УПАК./НЕТ.  Ф.НЕТ."
			printedData.append(Utils.format(
					"^FO60,%d^A0N,27,25^FDБРУТ.^FS\n" +
							"^FO200,%d^A0N,27,25^FDПАРТІЯ^FS\n" +
							"^FO390,%d^A0N,27,25^FDБІРКА БРУТ. / УПАК. / НЕТ.^FS\n" +
							"^FO690,%d^A0N,27,25^FDФ.НЕТ^FS\n",
					printedY, printedY, printedY, printedY
			));

			addY(lineHeight);
			addY(lineHeight / 2);
		}
	}

	private void addY(int value) {
		printedY += value;

		if (value > 0 && printedY > maxY) {
			addNewPage(true);
		}
	}

}
