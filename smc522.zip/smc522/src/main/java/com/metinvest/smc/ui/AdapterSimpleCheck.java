package com.metinvest.smc.ui;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterSimpleCheck extends AbstractFlexibleItem<AdapterSimpleCheck.ViewHolder> {

    private final String id;
    private final String title, content;
    private boolean checked;

    public AdapterSimpleCheck(String id, String title, String content, boolean checked) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.checked = checked;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterSimpleCheck && ((AdapterSimpleCheck) o).getTitle().equalsIgnoreCase(getTitle());
    }

    @Override
    public int hashCode() {
        return getTitle().hashCode();
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    @Override
    public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new ViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {
        String data = Utils.format("<b>%s</b>", getTitle());
        holder.textTitle.setText(App.getInstance().fromHtml(data));
        holder.textContent.setVisibility(getContent() == null ? View.GONE : View.VISIBLE);
        holder.textContent.setText(App.getInstance().fromHtml(getContent()));
        holder.imageCheck.setImageResource(isChecked() ? R.drawable.ic_checkbox_check : R.drawable.ic_checkbox_uncheck);

        View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
        holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
        refreshBackground(holder, holder.itemView.isFocused());
    }

    private void refreshBackground(ViewHolder holder, boolean hasFocus) {
        holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_adapter_light));
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_simple_check;
    }

    public class ViewHolder extends FlexibleViewHolder {

        private final ImageView imageCheck;
        private final TextView textTitle, textContent;

        public ViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.textTitle = view.findViewById(R.id.textTitle);
            this.textContent = view.findViewById(R.id.textContent);
            this.imageCheck = view.findViewById(R.id.imageCheck);
        }
    }
}
