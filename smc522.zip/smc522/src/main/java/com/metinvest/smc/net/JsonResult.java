package com.metinvest.smc.net;

import org.json.JSONObject;

public class JsonResult extends NetworkResult<JSONObject> {

	public JsonResult() {
	}

	public JsonResult(long packetId, LoadResultStatus status, String description, JSONObject data) {
		super(packetId, status, description, data);
	}

	public JsonResult(LoadResultStatus status) {
		super(status);
	}

	public JSONObject getJson() {
		return getData();
	}

	public void setJson(JSONObject json) {
		setData(json);
	}
}
