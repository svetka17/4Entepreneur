package com.metinvest.smc.tools;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ShipReasonData implements Serializable {
	private int plan;
	private int fact;
	private int id;
	private List<String> reasonList;

	public ShipReasonData(int plan, int fact, int id, List<String> reasonList) {
		this.plan = plan;
		this.fact = fact;
		this.id = id;
		this.reasonList = reasonList;
	}

	public int getPlan() {
		return plan;
	}

	public int getFact() {
		return fact;
	}

	public int getId() {
		return id;
	}

	public List<String> getReasonList() {
		return reasonList;
	}

	@Override
	public String toString() {
		return "ShipReasonData{" +
				"plan=" + plan +
				", fact=" + fact +
				", id=" + id +
				", reasonList=" + reasonList +
				'}';
	}

	public static ShipReasonData fromJson(JSONObject json) {
		if (json == null) return null;

		int valPlan = Utils.getJsonIntIgnoreCase(json, "plan");
		int valFact = Utils.getJsonIntIgnoreCase(json, "fact");
		int valId = Utils.getJsonIntIgnoreCase(json, "id");
		JSONArray valArray = Utils.getJsonArray(json, "reasons");
		List<String> valReasonList = new ArrayList<>();
		for (int i = 0; valArray != null && i < valArray.length(); i++) {
			String value = Utils.getJsonString(valArray, i);
			if (value != null) valReasonList.add(value);
		}

		Collections.sort(valReasonList, (s, str) -> {
			if (s.equalsIgnoreCase("Задержка из-за водителя")) return -1;
			if (s.equalsIgnoreCase("Деление пачки")) return 1;
			return s.compareToIgnoreCase(str);
		});

		return new ShipReasonData(valPlan, valFact, valId, valReasonList);
	}
}
