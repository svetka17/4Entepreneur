package com.metinvest.smc.tools;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Weight implements Comparable<Weight>, Parcelable {
    public static final Creator<Weight> CREATOR = new Creator<Weight>() {
        @Override
        public Weight createFromParcel(Parcel in) {
            return new Weight(in);
        }

        @Override
        public Weight[] newArray(int size) {
            return new Weight[size];
        }
    };
    private int netto, pack, brutto;

    public Weight(int pack, int netto) {
        this.pack = pack;
        this.netto = netto;
        this.brutto = pack + netto;
    }

    protected Weight(Parcel in) {
        netto = in.readInt();
        pack = in.readInt();
        brutto = in.readInt();
    }

    public int getNetto() {
        return netto;
    }

    public int getPack() {
        return pack;
    }

    public int getBrutto() {
        return brutto;
    }

    public void setNetto(int netto) {
        this.netto = netto;
    }

    @Override
    public int compareTo(Weight o) {
        return Integer.compare(this.getBrutto(), o.getBrutto());
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(netto);
        dest.writeInt(pack);
        dest.writeInt(brutto);
    }

    @NonNull
    @Override
    public String toString() {
        return String.valueOf(getBrutto());
    }
}
