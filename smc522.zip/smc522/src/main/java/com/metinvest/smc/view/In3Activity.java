package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Carrier;
import com.metinvest.smc.db.NameStore;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemIn2;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class In3Activity extends MyActivity {

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;

    private int weightCrane, packCount;
    private Carrier carrier;
    private NameStore name;
    private ArrayList<Long> wayList;
    private FlexibleAdapter<AdapterItemIn2> adapter;
    private boolean bigOne;
    private long tempWayId;
    private String locationCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in3);
        ButterKnife.bind(this);

        long carrierId = getIntent().getLongExtra("carrierId", 0);
        long nameId = getIntent().getLongExtra("nameId", 0);
        weightCrane = getIntent().getIntExtra("weightCrane", 0);
        packCount = getIntent().getIntExtra("packCount", 0);
        wayList = (ArrayList<Long>) getIntent().getSerializableExtra("wayList");
        bigOne = getIntent().getBooleanExtra("bigOne", false);
        tempWayId = getIntent().getLongExtra("tempWayId", 0);
        locationCode = getIntent().getStringExtra("locationCode");

        carrier = db.carrierDao().getById(carrierId);
        name = db.nameStoreDao().getById(nameId);
        textContentTitle.setText(Utils.format(
                "Вага з крану: %s кг.%nКількість позицій: %s",
                weightCrane, packCount
        ));

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
        listView.setLayoutManager(layoutManager);
        listView.addItemDecoration(dividerItemDecoration);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) buttonAcceptClick();
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        Intent intent = new Intent(this, In4Activity.class);

        intent.putExtra("carrierId", carrier.getId());
        intent.putExtra("nameId", name.getId());
        intent.putExtra("weightCrane", weightCrane);
        intent.putExtra("packCount", packCount);
        intent.putExtra("wayList", wayList);
        intent.putExtra("tempWayId", tempWayId);
        intent.putExtra("locationCode", locationCode);

        int sumW1 = 0;
        int sumW2 = 0;
        int sumW3 = 0;
        ArrayList<Integer> listW1 = new ArrayList<>();
        ArrayList<Integer> listW2 = new ArrayList<>();
        ArrayList<Integer> listW3 = new ArrayList<>();
        for (int i = 0; i < packCount; i++) {
            AdapterItemIn2 item = adapter.getItem(i);
            if (item != null) {
                listW1.add(item.getW1());
                listW2.add(item.getW2());
                listW3.add(item.getW3());
                sumW1 += item.getW1();
                sumW2 += item.getW2();
                sumW3 += item.getW3();

                if (item.getW1() == 0) {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, "Вага бірки має бути більшою за нуль!", null);
                    return;
                }
            }
        }

        intent.putExtra("weightList1", listW1);
        intent.putExtra("weightList2", listW2);
        intent.putExtra("weightList3", listW3);

        startActivityForResult(intent, REQUEST_DEFAULT);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoadList();
    }

    private void beginLoadList() {
        showLoading(R.string.text_please_wait);
        buttonAccept.setEnabled(false);

        Utils.runOnBackground(() -> {

            List<AdapterItemIn2> items = new ArrayList<>(packCount);

            for (int i = 0; i < packCount; i++) {

                Long wayId = wayList.get(i);

                if (wayId == 0) {
                    items.add(new AdapterItemIn2(i, null, 0, 0, 0));
                } else {
                    OnTheWay way = db.onTheWayDao().getById(wayList.get(i));
                    int w = way.getSapWeightNett() - way.getWeightAccepted();
                    if (bigOne) w = w / packCount;
                    items.add(new AdapterItemIn2(i, way, w, 0, 0));
                }
            }

            adapter = new FlexibleAdapter<>(items);

            endLoadList();
        });
    }

    private void endLoadList() {
        hideLoading();

        runOnUiThread(() -> {
            listView.setAdapter(adapter);
            scrollView.post(() -> scrollView.scrollTo(0, 0));
            buttonAccept.setEnabled(adapter.getItemCount() > 0);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_DEFAULT && resultCode == RESULT_OK) {
            setResult(RESULT_OK);
            finish();
        }
    }
}
