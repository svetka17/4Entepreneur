package com.metinvest.smc.ui;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.ShipmentDocument;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterShipData extends AbstractFlexibleItem<AdapterShipData.ViewHolder> {

    private final ShipmentDocument document;
    private String value;

    public AdapterShipData(ShipmentDocument document) {
        this.document = document;
        this.value = document.getSapPoNum();
    }

    public ShipmentDocument getDocument() {
        return document;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterShipData && ((AdapterShipData) o).getDocument().getId() == getDocument().getId();
    }

    @Override
    public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new ViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {

        String title = holder.itemView.getContext().getString(R.string.text_ship_data_item_title, document.getDocNumber());

        holder.textTitle.setText(title);
        holder.textValue.setText(document.getSapPoNum());
        holder.textValue.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                value = s.toString();
                checkTextFields(holder);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        checkTextFields(holder);
    }

    private void checkTextFields(ViewHolder holder) {
        Utils.setCorrectTint(holder.textValue, holder.textValue.getText().toString().length() == 10);
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_ship_data;
    }

    static class ViewHolder extends FlexibleViewHolder {

        @BindView(R.id.textTitle)
        TextView textTitle;
        @BindView(R.id.textValue)
        EditText textValue;

        ViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            ButterKnife.bind(this, view);
        }
    }
}
