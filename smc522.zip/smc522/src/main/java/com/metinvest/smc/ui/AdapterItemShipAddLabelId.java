package com.metinvest.smc.ui;

import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import com.metinvest.smc.R;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemShipAddLabelId extends AbstractFlexibleItem<AdapterItemShipAddLabelId.ViewHolder> {

    private final boolean showButtons;

    public interface Listener {
        void onAddClicked(String labelId);

        void onRClicked();

        void onTClicked();
    }

    private final Listener listener;

    public AdapterItemShipAddLabelId(Listener listener) {
        this(listener, false);
    }

    public AdapterItemShipAddLabelId(Listener listener, boolean showButtons) {
        this.listener = listener;
        this.showButtons = showButtons;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterItemShipAddLabelId && o.equals(this);
    }

    @Override
    public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new ViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {
        if (listener != null) {
            holder.buttonAdd.setOnClickListener(v -> {
                String text = holder.textLabelId.getText().toString();
                if (text.trim().length() > 0) {
                    holder.textLabelId.setText(null);
                    listener.onAddClicked(text);
                }
            });

            if (showButtons) {
                holder.buttonR.setOnClickListener(v -> listener.onRClicked());
                holder.buttonT.setOnClickListener(v -> listener.onTClicked());
            }
        }
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_ship_label_add_label_id;
    }

    class ViewHolder extends FlexibleViewHolder {

        @BindView(R.id.buttonAdd)
        ImageButton buttonAdd;
        @BindView(R.id.textLabelId)
        EditText textLabelId;
        @BindView(R.id.viewButtons)
        View viewButtons;
        @BindView(R.id.buttonR)
        ImageButton buttonR;
        @BindView(R.id.buttonT)
        ImageButton buttonT;

        ViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            ButterKnife.bind(this, view);
        }
    }
}
