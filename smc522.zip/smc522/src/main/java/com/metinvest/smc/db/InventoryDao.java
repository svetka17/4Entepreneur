package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface InventoryDao {

    @Query("SELECT count(1) FROM inventory")
    long getCount();

    @Query("SELECT * FROM inventory")
    List<Inventory> getAll();

    @Query("SELECT * FROM inventory WHERE id = :id")
    Inventory getById(long id);

    @Query("SELECT * FROM inventory WHERE date = :date AND labelId = :labelId AND locationCode = :locationCode")
    Inventory getByLabelIdAndLocation(long date, long labelId, String locationCode);

    @Query("SELECT * FROM inventory WHERE date = :date AND qr = :qr AND locationCode = :locationCode")
    Inventory getByLabelQrAndLocation(long date, String qr, String locationCode);

    @Query("SELECT * FROM inventory WHERE locationCode = :locationCode AND date = :date")
    List<Inventory> getByLocation(long date, String locationCode);

    @Query("SELECT DISTINCT(locationCode) FROM inventory WHERE date = :date")
    List<String> getLocationList(long date);

    @Insert
    long insert(Inventory inventory);

    @Insert
    void insertAll(List<Inventory> inventories);

    @Update
    void update(Inventory inventory);

    @Delete
    void delete(Inventory inventory);

    @Query("DELETE FROM inventory")
    void truncate();
}