package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.Spinner;

import androidx.annotation.Nullable;

import com.metinvest.smc.Config;
import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.IValue;
import com.metinvest.smc.tools.StoreItem;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.tools.Value;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import butterknife.BindView;
import butterknife.ButterKnife;

public class Settings2Activity extends MyActivity {

    @BindView(R.id.spinnerSmc)
    Spinner spinnerSmc;
    @BindView(R.id.spinnerStorage)
    Spinner spinnerStorage;

    @BindView(R.id.partyAUTO)
    CheckBox partyAUTO;

    private List<IValue> list = new ArrayList<>();
    private List<String> listSmcId = new ArrayList<>();
	private List<IValue> listStorage = new ArrayList<>();

    private final ExecutorService executorService = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings2);
        ButterKnife.bind(this);
        //автораспределение всегда включено, не даем пользователям отключать
        //partyAUTO.setChecked(config.partyAUTO());
        partyAUTO.setChecked(false);
        partyAUTO.setEnabled(false);
        spinnerSmc.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                OnSmcChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    @Override
    protected void onFunctionKey(int number) {
        switch (number) {
            case 2:
                startActivity(new Intent(this, PrinterActivity.class));
                break;
            case 3:
                startActivity(new Intent(this, CranesActivity.class));
                break;
            case 4:
                startActivity(new Intent(this, ScalesActivity.class));
                break;
            case 5:
                startActivity(new Intent(this, SettingsOtherActivity.class));
                break;
            case 6:
                buttonSaveClick();
                break;
        }
    }

    private void beginLoadStorageList() {
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {
            Network.NetworkResultValue<List<StoreItem>> result = net.loadStorageList(getSelectedSmc());
            runOnUiThread(() -> endLoadStorageList(result));
        });
    }

    private void endLoadStorageList(Network.NetworkResultValue<List<StoreItem>> result) {
        hideLoading();

        if (result.isOk()) {
            StoreItem storeItem = Utils.getSourceStoreItem(result.getValue());
            if (storeItem == null) {
                showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, R.string.error_data, (dialog, which) -> beginLoadStorageList(), (dialog, which) -> finish());
                return;
            }
			int selectedIndex = 0;
			listStorage = new ArrayList<>();
			for (int i = 0; i < storeItem.getStoreList().size(); i++) {
				if (storeItem.getStoreList().get(i).equalsIgnoreCase(config.getStorage()))
					selectedIndex = i;
				listStorage.add(new Value((long) (i + 1), storeItem.getStoreList().get(i)));
			}

			Utils.fillData(spinnerStorage, listStorage);
			spinnerStorage.setSelection(selectedIndex);
		} else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result.getResult()), (dialog, which) -> beginLoadStorageList(), (dialog, which) -> finish());
        }
    }

    private String getSelectedSmc() {
        int pos = spinnerSmc.getSelectedItemPosition();
        return listSmcId.get(pos);
    }

    private void buttonSaveClick() {
        String smcIdUser = getSelectedSmc();

		int pos = spinnerStorage.getSelectedItemPosition();
		String storage = pos == -1 ? Config.DEFAULT_STORAGE : listStorage.get(pos).getName();

		config.setSmcIdUser(smcIdUser);
		config.setStorage(storage);
        if (config.isEo())
            Utils.runOnBackground(() -> {
                String url = config.getUrlApiEO() + "RouteList/Location";
                url = net.addUrlParam(url, "smcId", config.getSmcId());
                url = net.addUrlParam(url, "stock", storage);
                JsonResult result = net.downloadJson(url);
                JSONObject content = Utils.getJsonObject(result.getJson(),"content");
                if (content != null) {
                    config.setEoLocationId(Utils.getJsonIntIgnoreCase(content, "locationId"));
                    config.setEoLocationName(Utils.getJsonStringIgnoreCase(content, "locationName"));
                } else {
                    //showLoading(getString(R.string.no_settings_oe, config.getSmcId(), config.getStorage()));
                    config.setEoLocationId(0);
                    config.setEoLocationName("");
                    log("no settings for: %s, storage: %s", config.getSmcId(), config.getStorage());
                }

            });
        config.setAUTO(partyAUTO.isChecked());
		config.saveConfig();

        /*TokenCredential credentialToken =
                new TokenCredential() {
                    @Override
                    public Mono<AccessToken> getToken(TokenRequestContext request) {
                        AccessToken tok = new AccessToken(config.getToken(), OffsetDateTime.now().plusHours(3));
                        //return Mono.just(tok) ;
                        return new Mono<AccessToken>() {
                            @Override
                            public void subscribe(CoreSubscriber<? super AccessToken> actual) {
                                try {
                                    AccessToken tok = new AccessToken(config.getToken(), OffsetDateTime.now().plusHours(1));
                                    actual.onNext(tok);
                                } catch (Exception e) {
                                    actual.onError(e); // Передача ошибки подписчику
                                }
                            }
                        };
                    }
                };

        String downloadFilePath = "https://mihwesmcapp11.blob.core.windows.net/install/com.metinvest.smc.test.txt";
        String blobServiceUrl = "https://mihwesmcapp11.blob.core.windows.net/";
        String containerName = "install";
        String blobName = "com.metinvest.smc.test.txt";
        String key1 = "TInwIL8vqkfCXdzxdlhfaJbIMOeXWJ1T6OYw4VjctTyZ14b8C1dyqet+7txH2YJMTZFWf1ZRNaa6+ASt9E3YGg==";
        BlobContainerSasPermission blobContainerSasPermission = new BlobContainerSasPermission()
                .setReadPermission(true)
                //.setWritePermission(true)
                //.setListPermission(true)
                ;
        //StorageSharedKeyCredential credential = new StorageSharedKeyCredential();
        DefaultAzureCredential defaultCredential = new DefaultAzureCredentialBuilder()
                .managedIdentityClientId("0038db9f-b7cb-457e-905c-b283fea587c3")
                .build();

        BlobServiceSasSignatureValues builder = new BlobServiceSasSignatureValues(
                OffsetDateTime.now().plusDays(1), blobContainerSasPermission)
                .setProtocol(SasProtocol.HTTPS_ONLY);
        TokenCredential credential = new DefaultAzureCredentialBuilder()
                .managedIdentityClientId("0038db9f-b7cb-457e-905c-b283fea587c3")
                .tenantId("b0bbbc89-2041-434f-8618-bc081a1a01d4")
                .build();
        // Создание учетных данных общего ключа хранения
        StorageSharedKeyCredential credentialKey = new StorageSharedKeyCredential("mihwesmcapp11", key1);

        ClientSecretCredential credential1 = new ClientSecretCredentialBuilder()
                .clientId("0038db9f-b7cb-457e-905c-b283fea587c3")
                .tenantId("b0bbbc89-2041-434f-8618-bc081a1a01d4")
                .clientSecret("5ZO8Q~Adni1ZS7TAjqKdA0yTAOdCbiNQPGJDxcwA")
                .build();
        TokenCredential credentialMono = new TokenCredential() {
            @Override
            public Mono<AccessToken> getToken(TokenRequestContext request) {
                return Mono.just(new AccessToken(App.getInstance().getConfig().getToken(), OffsetDateTime.now().plusHours(1)));
            }
        };
        ManagedIdentityCredential credential2 = new ManagedIdentityCredentialBuilder()
                .clientId("0038db9f-b7cb-457e-905c-b283fea587c3") // required only for user-assigned
                .build();

        // Создаем объект BlobServiceClient
        BlobServiceClient blobServiceClient = new BlobServiceClientBuilder()
                .endpoint(blobServiceUrl)
                .credential(credentialKey)
                .buildClient();

        //BlobServiceProperties propert = blobServiceClient.getProperties();
        
        //UserDelegationKey userDelegationKey = blobServiceClient.getUserDelegationKey(OffsetDateTime.now(), OffsetDateTime.now().plusHours(1));

        // Получаем ссылку на Blob
        BlobClient blobClient = blobServiceClient.getBlobContainerClient("install").getBlobClient("com.metinvest.smc.txt");
        BlobContainerClient contey = blobServiceClient.getBlobContainerClient("install");
        BlobClient blob = contey.getBlobClient(blobName);

        BlobServiceSasSignatureValues sasSignatureValues = new BlobServiceSasSignatureValues(
                OffsetDateTime.now().plusHours(1), // SAS токен будет действителен в течение 1 часа
                new BlobContainerSasPermission().setReadPermission(true) // Устанавливаем разрешение на чтение
        );
        try {
            // Генерируем SAS токен
            String sasToken = blobClient.generateSas(sasSignatureValues);
        } catch (Exception e) {
            String error = e.toString();
        }
        try {
            String sas = blobClient.generateSas(builder);
        } catch (Exception e) {
            String error = e.toString();
        }

        Utils.runOnBackground(() -> {
            // Асинхронное скачивание контента
            CompletableFuture.supplyAsync(() -> {
                try {
                    return blobClient.downloadContent();
                } catch (BlobStorageException e) {
                    System.err.println("Azure storage error: " + e.getMessage());
                    return null;
                }
            }, executorService).thenAccept(binaryData -> {
                if (binaryData != null) {
                    long size = binaryData.getLength();
                    System.out.println("File size: " + size);
                } else {
                    System.err.println("Failed to download blob content.");
                }
            }).exceptionally(throwable -> {
                System.err.println("Error occurred: " + throwable.getMessage());
                return null;
            });
        });*/

        setResult(RESULT_OK);
        finish();
    }

    private void beginLoad() {
        int selectedIndex = 0;
        JSONArray jsonArray = Utils.getJsonArray(config.getSmcListJson());
        if (jsonArray == null || jsonArray.length() == 0) {
            list.add(new Value(0, Utils.format("[%s]", config.getSmcId())));
            listSmcId.add(config.getSmcId());
        } else {
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = Utils.getJsonObject(jsonArray, i);
                //String parent = Utils.getJsonStringIgnoreCase(jsonObject, "parent");
                String smcid = Utils.getJsonStringIgnoreCase(jsonObject, "smcid");
                String desc = Utils.getJsonStringIgnoreCase(jsonObject, "desc");

                String title = desc.isEmpty() ? Utils.format("[%s]", smcid) : Utils.format("[%s] - %s", smcid, desc);
                list.add(new Value(i, title));
                listSmcId.add(smcid);
                if (smcid.equalsIgnoreCase(config.getSmcIdUser())) selectedIndex = i;
            }
        }

        Utils.fillData(spinnerSmc, list);
        spinnerSmc.setSelection(selectedIndex);
        //OnSmcChanged();
    }

    private void OnSmcChanged() {
        beginLoadStorageList();
    }
}
