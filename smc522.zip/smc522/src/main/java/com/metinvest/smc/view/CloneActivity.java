package com.metinvest.smc.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CloneActivity extends MyActivity implements IScan {

	@BindView(R.id.textLabelId)
	EditText textLabelId;
	@BindView(R.id.buttonClone)
	Button buttonClone;
	@BindView(R.id.textContent)
	TextView textContent;
	@BindView(R.id.viewContentData)
	View viewContentData;
	@BindView(R.id.textNewWeight)
	EditText textNewWeight;

	private Label label;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_clone);
		ButterKnife.bind(this);
		showContent();
		setActionDone(textLabelId, () -> onFunctionKey(2));
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 2) {
			String labelId = textLabelId.getText().toString();
			if (labelId.length() > 0) beginLoadLabel(labelId);
		} else if (number == 5) buttonCloneClick();
	}

	@Override
	public void onBarcodeEvent(String barcodeData) {
		if (isLoading()) return;

		runOnUiThread(() -> {

			ScanItem scanItem = new ScanItem(barcodeData);

			if (!scanItem.isCorrect()) {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_identity_error, null);
			} else {
				if (scanItem.getType() == ScanItem.ScanItemType.LABELID || scanItem.getType() == ScanItem.ScanItemType.SMC06) {
					beginLoadLabel(scanItem.getData(0));
				}
			}
		});
	}

	private void buttonCloneClick() {
		if (isLoading() || !buttonClone.isEnabled() || label == null) return;

		beginClone();
	}

	private void beginClone() {
		int newWeight = Utils.parseInt(textNewWeight.getText().toString());
		if (newWeight == 0) {
			showDialog(R.drawable.ic_error_24dp, R.string.text_error, R.string.warning_birk_zero, null);
			return;
		}

		showLoading(R.string.text_please_wait);
		buttonClone.setEnabled(true);

		String url = config.getUrlApi() + "clonelabel2";
		url = net.addUrlParam(url, "label_id", label.getId());
		url = net.addUrlParam(url, "Weight_nett", newWeight);
		url = net.addUrlParam(url, "Weight_pack", label.getWeightPack());
		url = net.addUrlParam(url, "isclone", "1");
		reqGet(url, this::endAccept);
	}

	private void endAccept(JsonResult result) {
		hideLoading();
		buttonClone.setEnabled(!result.isOk());

		JSONObject json = Utils.getJsonObject(result.getJson(), "data");

		if (result.isOk() && json != null) {
			String newLabelId = Utils.getJsonStringIgnoreCase(json, "label_id");
			Toast.makeText(this, R.string.split_ok, Toast.LENGTH_SHORT).show();
			showInfoByLabelIdList(label.getId(), newLabelId);
			textLabelId.setText(null);
			label = null;
			showContent();
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginClone());
		}
	}

	private void beginLoadLabel(String newLabelId) {
		if (isLoading()) return;

		showLoading(R.string.text_please_wait);
		label = null;
		showContent();

		Utils.runOnBackground(() -> {
			String url = config.getUrlApi() + "getlabelinfo";
			url = net.addUrlParam(url, "label_id", newLabelId);
			JsonResult result = net.downloadJson(url);
			runOnUiThread(() -> endLoadLabel(result, newLabelId));
		});
	}

	private void endLoadLabel(JsonResult result, String newLabelId) {
		hideLoading();

		if (result.isOk()) {
			JSONObject labelJson = Utils.getJsonObject(result.getJson(), "data");
			label = Label.fromJson(labelJson);
			if (label != null) {
				label.setId(newLabelId);
				if (label.isTheor()) {
					showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_clone_theor, null);
					label = null;
				} else if (!label.isRelease()) {
					label = null;
					showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_label_not_released, null);
				}
			}
			showContent();
		} else if (result.getStatus() == LoadResultStatus.ZERO) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.labelid_not_found, null);
		} else if (result.getStatus() == LoadResultStatus.S007) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_s007, null);
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoadLabel(newLabelId));
		}
	}

	private void showContent() {
		if (label == null) {
			viewContentData.setVisibility(View.GONE);
			buttonClone.setEnabled(false);
		} else {
			StringBuilder sb = new StringBuilder();
			sb.append(Utils.format("<b>LabelID: %s</b><br>", label.getId()));
			if (Utils.isNullOrEmpty(label.getZavBatch())) {
				sb.append(Utils.format("Партія: %s<br>", label.getBatch()));
			} else {
				sb.append(Utils.format("Зав. партія: %s<br>", label.getZavBatch()));
			}
			sb.append(Utils.format("Вага НЕТТО, тн: %.3f", label.getWeightNetto() / 1000.0f));
			textContent.setText(app.fromHtml(sb.toString()));
			viewContentData.setVisibility(View.VISIBLE);
			buttonClone.setEnabled(true);
			textNewWeight.setText(String.valueOf(label.getWeightNetto()));
		}
	}

}

