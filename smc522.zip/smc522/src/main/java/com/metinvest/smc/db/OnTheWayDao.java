package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface OnTheWayDao {
    @Query("SELECT * FROM OnTheWay")
    List<OnTheWay> getAll();

    @Query("SELECT * FROM OnTheWay WHERE id = :id")
    OnTheWay getById(long id);

    @Query("SELECT * FROM OnTheWay WHERE carrierId = :carrierId OR :carrierId = 0")
    List<OnTheWay> getByCarrierId(long carrierId);

    @Query("SELECT * FROM OnTheWay WHERE (carrierId = :carrierId OR :carrierId = 0) AND (nameId = :nameId OR :nameId = 0)")
    List<OnTheWay> getByCarrierAndName(long carrierId, long nameId);

    @Query("SELECT * FROM OnTheWay WHERE carrierId = :carrierId AND printed = 1")
    List<OnTheWay> getByCarrierIdPrinted(long carrierId);

    @Query("SELECT * FROM OnTheWay WHERE nameId = :nameId")
    List<OnTheWay> getByNameId(long nameId);

    @Query("SELECT * FROM OnTheWay WHERE carrierId = :carrierId AND nameId = :nameId AND printed = 0 ORDER BY sapWeightNett - weightAccepted DESC")
    List<OnTheWay> getByCarrierAndNameNotPrinted(long carrierId, long nameId);

    @Query("SELECT count(1) FROM OnTheWay")
    long count();

    @Query("SELECT distinct nameId FROM OnTheWay WHERE carrierId = :carrierId")
    List<Long> getNameListByCarrier(long carrierId);

    @Query("SELECT distinct nameId FROM OnTheWay WHERE carrierId = :carrierId AND printed = 0")
    List<Long> getNameListByCarrierNotPrinted(long carrierId);

    @Query("SELECT distinct nameId FROM OnTheWay WHERE carrierId = :carrierId AND printed = 1")
    List<Long> getNameListByCarrierPrinted(long carrierId);

    //@Query("SELECT nameId FROM onetheway")
    //List<Long> getAllIds();

    @Query("SELECT SUM(sapWeightNett) FROM OnTheWay WHERE carrierId = :carrierId AND nameId = :nameId")
    Integer getTotalWeightByCarrierAndName(long carrierId, long nameId);

    @Insert
    long insert(OnTheWay onTheWay);

    @Insert
    void insertAll(List<OnTheWay> onTheWay);

    @Update
    void update(OnTheWay onTheWay);

    @Delete
    void delete(OnTheWay onTheWay);

    @Query("DELETE FROM OnTheWay")
    void truncate();
}