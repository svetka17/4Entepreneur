package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SearchBatchActivity extends MyActivity implements IScan {

    @BindView(R.id.textSearch)
    EditText textSearch;
    @BindView(R.id.buttonAccept)
    Button buttonSearch;
    private String search;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_batch);
        ButterKnife.bind(this);
        textSearch.requestFocus();

        search = getIntent().getStringExtra("search");
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        if (search != null && search.length() > 0) {
            beginSearch(search);
        }
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) textSearch.requestFocus();
        else if (number == 5) buttonSearchClick();
    }

    private void buttonSearchClick() {
        if (isLoading() || !buttonSearch.isEnabled()) return;

        beginSearch();
    }

    @Override
    protected String getHelpContent() {
        return getString(R.string.help_search_batch);
    }

    private void beginSearch(String batch) {
        textSearch.setText(batch);
        beginSearch();
    }

    private void beginSearch() {

        if (isLoading() || !buttonSearch.isEnabled()) return;

        String batch = textSearch.getText().toString();
        if (batch.length() == 0) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.ozm_search_text_null_warning, (dialog, which) -> textSearch.requestFocus());
            return;
        }

        showInfoByBatch(batch);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_DEFAULT && resultCode == RESULT_OK) {
            if (search != null && search.length() > 0) {
                finish();
            } else {
                textSearch.selectAll();
                textSearch.requestFocus();
            }
        }
    }

    private void beginLoadLabel(String labelId) {
        if (isLoading()) return;

        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {
            JsonResult result = net.loadLabelInfo(labelId);
            String batch = null;
            if (result.isOk()) {
                batch = Utils.getJsonStringIgnoreCase(Utils.getJsonObject(result.getJson(), "data"), "saP_Batch");
            }

            String finalBatch = batch;
            runOnUiThread(() -> endLoadLabel(result, finalBatch));
        });
    }

    private void endLoadLabel(JsonResult result, String batch) {
        hideLoading();
        beginSearch(batch);
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {
        if (isLoading()) return;

        runOnUiThread(() -> {

            ScanItem scanItem = new ScanItem(barcodeData);

            if (scanItem.isCorrect()) {
                if (scanItem.getType() == ScanItem.ScanItemType.LABELID) {
                    beginLoadLabel(scanItem.getData(0));
                } else if (scanItem.getType() == ScanItem.ScanItemType.SMC06) {
                    beginSearch(scanItem.getData(11));
                } else if (scanItem.getType() == ScanItem.ScanItemType.SMC07) {
                    checkIsUnknown(scanItem);
                }
            } else {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_barcode_format, null);
            }

        });
    }

    @Override
    protected void onIsUnknown(ScanItem scanItem, boolean unknown, @Nullable Label label) {
        if (unknown) {

        } else if (label != null) {
            beginSearch(label.getBatch());
        }
    }
}
