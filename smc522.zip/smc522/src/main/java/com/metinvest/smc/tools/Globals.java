package com.metinvest.smc.tools;

public class Globals {
    public static Long lastCarrierId;
}
