package com.metinvest.smc.net;

public interface NetworkListener {
    void onNetworkLoaded(JsonResult result);
}
