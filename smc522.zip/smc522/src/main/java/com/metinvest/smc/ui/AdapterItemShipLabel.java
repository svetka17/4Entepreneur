package com.metinvest.smc.ui;

import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.Utils;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemShipLabel extends AbstractFlexibleItem<AdapterItemShipLabel.AdapterItemPrintedViewHolder> {

    public interface IAdapterItemLabelListener {
        void onDeleteClicked(AdapterItemShipLabel item);

        void onSplitClicked(AdapterItemShipLabel item);
        void onSOHClicked(AdapterItemShipLabel item);
    }

    private final Label label;
    private final IAdapterItemLabelListener listener;
    private final Date dateScan;

    private final boolean flagScan;
    private final boolean soh;


    public AdapterItemShipLabel(Label label, IAdapterItemLabelListener listener, boolean soh, boolean flagScan) {
        this.label = label;
        this.listener = listener;
        this.soh = soh;
        this.flagScan = flagScan;
        this.dateScan = Calendar.getInstance().getTime();
    }

    public Date getDateScan() {
        return dateScan;
    }
    public boolean getFlagScan() {
        return flagScan;
    }
    public Label getLabel() {
        return label;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterItemShipLabel && ((AdapterItemShipLabel) o).getLabel().getId().equalsIgnoreCase(getLabel().getId());
    }

    @Override
    public int hashCode() {
        return getLabel().hashCode();
    }

    @Override
    public AdapterItemPrintedViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new AdapterItemPrintedViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemPrintedViewHolder holder, int position, List<Object> payloads) {
        if (flagScan)
            holder.textLabelId.setText(App.getInstance().fromHtml(Utils.format("<b>%s</b> %s", label.getId(), (label.isTheor() ? "(ТВ)" : "(ФВ)"))));
        else
            holder.textLabelId.setText(Utils.format("%s %s", label.getId(), (label.isTheor() ? "(ТВ)" : "(ФВ)")));
        holder.textWeight.setText(Utils.format("%d кг", label.getWeightNetto()));
        if (soh)
            holder.buttonSplit.setVisibility(View.GONE);
        else
            holder.buttonSplit.setVisibility(View.VISIBLE);
        if (listener != null) {
            holder.buttonDelete.setOnClickListener(v -> {
                listener.onDeleteClicked(this);
            });
            holder.buttonSplit.setOnClickListener(v -> {
                listener.onSplitClicked(this);
            });
            holder.buttonSOH.setOnClickListener(v -> {
                listener.onSOHClicked(this);
            });
        }
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_ship_label;
    }

    static class AdapterItemPrintedViewHolder extends FlexibleViewHolder {

        private final TextView textLabelId, textWeight;
        private final ImageButton buttonDelete, buttonSplit;
        private final Button buttonSOH;

        AdapterItemPrintedViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.textLabelId = view.findViewById(R.id.textLabelId);
            this.textWeight = view.findViewById(R.id.textWeight);
            this.buttonDelete = view.findViewById(R.id.buttonDelete);
            this.buttonSplit = view.findViewById(R.id.buttonSplit);
            this.buttonSOH = view.findViewById(R.id.buttonSOH);
        }
    }
}
