package com.metinvest.smc.view;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.inc.Ozm;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.ScalesConfig;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemShipAddLabelId;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class InvWeighingActivity extends MyActivity implements IScan, AdapterItemShipAddLabelId.Listener {

    @BindView(R.id.textWeightCraneBrutto)
    EditText textWeightCraneBrutto;
    @BindView(R.id.textWeightCranePack)
    EditText textWeightCranePack;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;
    @BindView(R.id.textPrompt)
    TextView textPrompt;
    @BindView(R.id.textContent)
    TextView textContent;
    @BindView(R.id.buttonCrane)
    ImageButton buttonCrane;

    @BindView(R.id.buttonZeroCrane)
    ImageButton buttonZeroCrane;

    private String storage, locationCode;
    private Date date;
    private FlexibleAdapter<IFlexible> adapter;

    private Ozm ozm = null;
    private MediaPlayer mPlayer;

    private Vibrator v;

    private byte cmd = 2;
    /*команда 1-тест(посылается в настройках), 2-взвешивание(кнопка с краном buttonCrane), 7-обнуление весов(кнопка sync buttonZeroCrane)*/

    private void createVibrate() {
        v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
    }

    public void vibrate(int millis) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(millis, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            //deprecated in API 26
            v.vibrate(millis);
        }
    }

    @Override
    protected void onDestroy() {
        if (mPlayer != null) {
            if (mPlayer.isPlaying()) mPlayer.stop();
            mPlayer.release();
        }
        super.onDestroy();
    }

    private static class InvItem {
        Label label;
        int birkNetto;
        Date dateScan;
        int nettoFinal;

        public InvItem(Label label, int birkNetto, Date dateScan) {
            this.label = label;
            this.birkNetto = birkNetto;
            this.dateScan = dateScan;
            this.nettoFinal = 0;
        }
    }

    private ArrayList<InvItem> itemList = new ArrayList<>();

    private InvItem getInvItemByLabel(String labelId) {
        for (InvItem item : itemList) {
            if (item.label.getId().equalsIgnoreCase(labelId)) return item;
        }
        return null;
    }

    @Override
    public void onRClicked() {
        Intent intent = new Intent(this, RollActivity.class);
        intent.putExtra("showInv", false);
        startActivity(intent);
    }

    @Override
    public void onTClicked() {
        startActivity(new Intent(this, UnknownActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inv_weighing);
        ButterKnife.bind(this);

        createVibrate();

        date = (Date) getIntent().getSerializableExtra("date");
        storage = getIntent().getStringExtra("storage");
        locationCode = getIntent().getStringExtra("locationCode");

        textWeightCraneBrutto.setText(String.valueOf(0));
        textWeightCranePack.setText(String.valueOf(0));

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                calc();
                refreshButtons();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        };
        textWeightCraneBrutto.addTextChangedListener(textWatcher);
        textWeightCranePack.addTextChangedListener(textWatcher);

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        adapter = new FlexibleAdapter<>(null);
        adapter.addListener(this);
        adapter.addItem(new AdapterItemShipAddLabelId(this, true));
        listView.setAdapter(adapter);

        onItemCountChanged();

        mPlayer = MediaPlayer.create(this, R.raw.error);

        buttonCrane.setOnClickListener(v -> {
                    cmd = 2;
                    loadScalesWeight((byte) 2);
                }
        );
        buttonCrane.setOnLongClickListener(v -> {
            cmd = 2;
            loadScalesWeight((byte)2);
            return true;
        });

        buttonZeroCrane.setOnClickListener(v -> {
                    cmd = 7;
                    loadScalesWeight((byte) 7);
                }
        );
        buttonZeroCrane.setOnLongClickListener(v -> {
            cmd = 7;
            loadScalesWeight((byte)7);
            return true;
        });
    }

    @Override
    protected void onScalesWeight(ScalesConfig scales, long value) {
        if (cmd == 7) {
            if ((byte) value == 1)
                textWeightCraneBrutto.setText("0");
            else
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.error_zero_scales, String.valueOf(value)), null);
        } else
            textWeightCraneBrutto.setText(String.valueOf(value));
        cmd = 2;
        calc();
        refreshButtons();
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        if (getIntent().hasExtra("labelId")) {
            String labelId = getIntent().getStringExtra("labelId");
            int birkNetto = getIntent().getIntExtra("birkNetto", 0);
            Date dateScan = new Date(getIntent().getLongExtra("dateScan", Calendar.getInstance().getTime().getTime()));
            beginScanLabel(labelId, birkNetto, dateScan);
        }
    }

    private void beep() {
        Utils.runOnBackground(() -> {
            Utils.sleep(500);
            runOnUiThread(() -> {
                vibrate(600);
                try {
                    mPlayer.start();
                } catch (Exception ignored) {
                }
            });
        });
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {

        log("barcode: %s", barcodeData);

        if (isLoading()) {
            showToast(R.string.please_wait_obrobka);
            beep();
            return;
        }

        runOnUiThread(() -> {

            ScanItem scanItem = new ScanItem(barcodeData);

            if (!scanItem.isCorrect()) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_identity_error, null);
            } else {

                if (scanItem.getType() == ScanItem.ScanItemType.LABELID || scanItem.getType() == ScanItem.ScanItemType.SMC06 && scanItem.isCorrect()) {
                    beginScanLabel(scanItem.getData(0), Utils.parseInt(scanItem.getData(6)), Calendar.getInstance().getTime());
                } else if (scanItem.getType() == ScanItem.ScanItemType.SMC07) {
                    beginLoadLabelUnknown(scanItem);
                }
            }

        });
    }

    private void beginLoadLabelUnknown(ScanItem scanItem) {
        JSONArray array = Utils.getJsonArray(scanItem.getData(2));
        if (array == null) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_error_scan_item, null);
        } else {
            JSONObject object = Utils.getJsonObject(array, 0);
            int netto = 0;
            String labelId = Utils.getJsonStringIgnoreCase(object, "id");
            if (labelId.isEmpty()) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_error_scan_item, null);
            } else {
                beginScanLabel(labelId, netto, Calendar.getInstance().getTime());
            }
        }
    }

    private void beginScanLabel(String labelId, int birkNetto, Date dateScan) {

        if (getInvItemByLabel(labelId) != null) {
            showToast(R.string.label_already_added);
            beep();
            return;
        }

        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            JsonResult result = net.loadLabelInfo(labelId);
            Label label = null;
            List<Label> labelList = null;
            boolean isTheor = false;
            if (result.isOk()) {
                label = Label.fromJson(Utils.getJsonObject(result.getJson(), "data"));
                if (label != null) {
					String labelStorage = label.getStorage();
					if (!config.getStorage().equalsIgnoreCase(labelStorage)) {
						runOnUiThread(() -> endScanLabelWrongStorage(labelStorage));
						return;
					}

					label.setId(labelId);
					Network.NetworkResultValue<String> resultValue = net.getLocationCodeNet("" + label.getLocationId());
					if (resultValue.isOk()) {
						label.setLocationCode(resultValue.getValue());
						isTheor = label.isTheor();
						if (isTheor) {

                            //
                            String url = config.getUrlApi() + "getlocationinfo2";
                            url = net.addUrlParam(url, "location_code", label.getLocationCode());
                            url = net.addUrlParam(url, "ozm", label.getOzm());
                            url = net.addUrlParam(url, "length", String.valueOf(label.getLength()));
                            url = net.addUrlParam(url, "width", String.valueOf(label.getWidth()));
                            url = net.addUrlParam(url, "thickness", String.valueOf(label.getThickness()));
                            url = net.addUrlParam(url, "nett_weight", String.valueOf(label.getWeightNetto()));
                            url = net.addUrlParam(url, "teor_weight", "1");
                            result = net.downloadJson(url);
                            if (result.isOk()) {
                                JSONObject jsonData = Utils.getJsonObject(result.getJson(), "data");
                                JSONArray array = Utils.getJsonArray(jsonData, "labels");
                                if (array != null) {
                                    for (int i = 0; i < array.length(); i++) {
                                        //JSONObject item = Utils.getJsonObject(array, i);
                                        //Label labelItem = Label.fromJson(item);
                                        String itemLabelId = Utils.getJsonString(array, i);
                                        if (itemLabelId != null && itemLabelId.length() > 0) {
                                            Label labelItem = label.copyLabel(itemLabelId);

                                            if (labelItem != null && labelItem.isTheor()
                                                    && labelItem.getOzm().equalsIgnoreCase(label.getOzm())
                                                    && labelItem.getWeightNetto() == label.getWeightNetto()
                                                    && labelItem.getLength() == label.getLength()
                                                    && labelItem.getWidth() == label.getWidth()
                                                    && labelItem.getThickness() == label.getThickness()
                                            ) {
                                                labelItem.setLocationCode(label.getLocationCode());
                                                if (labelList == null)
                                                    labelList = new ArrayList<>();
                                                labelList.add(labelItem);
                                            }
                                        }

                                    }
                                }
                            }
                            //

                        }
                    } else {
                        label = null;
                    }
                }
            }
            JsonResult finalResult = result;
            List<InvItem> finalLabelList = new ArrayList<>();
            if (labelList != null) {
                for (Label item : labelList) {
                    finalLabelList.add(new InvItem(item, birkNetto, dateScan));
                }
            } else {
                finalLabelList.add(new InvItem(label, birkNetto, dateScan));
            }

            boolean finalIsTheor = isTheor;
            Label finalLabel = label;
            runOnUiThread(() -> endScanLabel(finalResult, labelId, finalIsTheor ? finalLabel.getWeightNetto() : birkNetto, dateScan, finalLabelList));
        });
    }

	private void endScanLabelWrongStorage(String labelWarehouse) {
        hideLoading();
        showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.label_wrong_storage, labelWarehouse), null);
    }

    private void endScanLabel(JsonResult result, String labelId, int birkNetto, Date dateScan, List<InvItem> newItemList) {
        hideLoading();

        if (result.isOk()) {
            if (newItemList.isEmpty()) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_not_found, null);
            } else if (newItemList.get(0).label.getWeightNetto() <= 0) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.warning_birk_zero, null);
            } else {
                if (newItemList.size() > 1) {
                    prepareAddTheorLabels(newItemList);
                } else {
                    processItems(newItemList);
                }
            }
        } else if (result.getStatus() == LoadResultStatus.ZERO) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_id_not_found, null);
        } else if (result.getStatus() == LoadResultStatus.S007) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_s007, null);
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginScanLabel(labelId, birkNetto, dateScan));
        }
    }

    private void prepareAddTheorLabels(List<InvItem> labelList) {
        Intent intent = new Intent(this, TheorCountActivity.class);

        intent.putExtra("maxCount", labelList.size());
        intent.putExtra("inv", true);

        for (int i = 0; i < labelList.size(); i++) {
            intent.putExtra("label" + i, labelList.get(i).label);
            intent.putExtra("birkNetto" + i, labelList.get(i).birkNetto);
            intent.putExtra("dateScan" + i, labelList.get(i).dateScan);
            intent.putExtra("nettoFinal" + i, labelList.get(i).nettoFinal);
        }

        startActivityForResult(intent, REQUEST_COUNT_SELECT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_COUNT_SELECT && resultCode == RESULT_OK && data != null) {
            log("REQUEST_COUNT_SELECT OK");

            int count = data.getIntExtra("count", 0);
            int maxCount = data.getIntExtra("maxCount", 0);

            List<InvItem> list = new ArrayList<>(count);

            for (int i = 0; i < count; i++) {
                Serializable item = data.getSerializableExtra("label" + i);
                int birkNetto = data.getIntExtra("birkNetto" + i, 0);
                Serializable dateScan = data.getSerializableExtra("dateScan" + i);
                int nettoFinal = data.getIntExtra("nettoFinal" + i, 0);
                if (item instanceof Label && dateScan instanceof Date) {
                    InvItem invItem = new InvItem((Label) item, birkNetto, (Date) dateScan);
                    list.add(invItem);
                }
            }

            processItems(list);
        }
    }

    private void processItems(List<InvItem> newItemList) {

        for (InvItem item : newItemList) {
            if (getInvItemByLabel(item.label.getId()) != null) return;
            if (ozm != null && !item.label.getOzm().equalsIgnoreCase(ozm.getOzm())) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.inv_weighing_invalid_ozm /*R.string.ship_ozm_item_not_found*/, null);
                return;
            }
        }

        String newLocationCode = newItemList.get(0).label.getLocationCode();

        if (!newLocationCode.equalsIgnoreCase(locationCode)) {
            showDialogConfirm(R.string.text_warning, getString(R.string.label_in_another_loc_confirm, newLocationCode), (dialog, which) -> beginTransfer(newItemList));
        } else {
            beginCheckItems(newItemList);
        }
    }

    private void beginCheckItems(List<InvItem> newItemList) {

        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {
            String url = config.getUrlApi() + "checkinventoryonline";
            url = net.addUrlParam(url, "wh_type", storage);
            url = net.addUrlParam(url, "inv_date", app.getDateFormat2().format(date));
            url = net.addUrlParam(url, "label_id", newItemList.get(0).label.getId());
            JsonResult result = net.downloadJson(url);

            runOnUiThread(() -> endCheckItems(result, newItemList));

        });
    }

    private void endCheckItems(JsonResult result, List<InvItem> newItemList) {
        hideLoading();

        if (result.isOk()) {

            beep();

            JSONObject json = Utils.getJsonObject(result.getJson(), "data");
            String message = "";
            if (json != null) {
                String jScanDt = Utils.getJsonStringIgnoreCase(json, "scan_dt");
                String jUser = Utils.getJsonStringIgnoreCase(json, "user_login");
                String jLocation = Utils.getJsonStringIgnoreCase(json, "location_code");
                int jFact = Utils.getJsonWeightKgIgnoreCase(json, "netT_Weight_Fact");
                message = Utils.format(
                        "Дата: %s%nКористувач: %s%nВага: %d кг.%nЛокація: %s%n",
                        jScanDt, jUser, jFact, jLocation
                );
            }
            showDialogConfirm(R.string.text_warning, getString(R.string.inv_already_invent_confirm, message), (dialog, which) -> {
                addItems(newItemList);
            });

        } else if (result.getStatus() == LoadResultStatus.PLUS2) {
            addItems(newItemList);
        } else if (result.getStatus() == LoadResultStatus.S007) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_s007, null);
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginCheckItems(newItemList));
        }
    }

    private void beginTransfer(List<InvItem> newItemList) {
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            StringBuilder sb = new StringBuilder();
            sb.append("[");

            for (int i = 0; i < newItemList.size(); i++) {
                InvItem item = newItemList.get(i);
                sb.append(Utils.format(
                        "{\"Label_Id\":%s,\n" +
                                "\"Location_Code\":\"%s\",\n" +
                                "\"Date_FV\":\"%s\"\t}",
                        item.label.getId(), locationCode, app.getDateTimeFormat().format(Calendar.getInstance().getTime())
                ));
                if (i < newItemList.size() - 1) sb.append(",");
            }
            sb.append("]");

            String url = config.getUrlApi() + "sapchangelocation";
            JsonResult result = net.uploadJson(url, sb.toString());

            /*for (InvItem item : newItemList) {
                String url = config.getUrlApi() + "setlabellocation";
                url = net.addUrlParam(url, "label_id", item.label.getId());
                url = net.addUrlParam(url, "location_code", locationCode);
                result = net.uploadJson(url, "");
            }*/

            if (result != null && result.isOk()) {
                for (InvItem invItem : newItemList) {
                    invItem.label.setLocationCode(locationCode);
                }
            }

            runOnUiThread(() -> endTransfer(result, newItemList));
        });
    }

    private void endTransfer(JsonResult result, List<InvItem> newItemList) {
        hideLoading();

        if (result != null && result.isOk()) {
            processItems(newItemList);
        } else {
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginTransfer(newItemList));
        }
    }

    private void addItems(List<InvItem> newItemList) {
        itemList.addAll(newItemList);
        for (InvItem item : newItemList) {
            AdapterItemInvLabel adapterItem = new AdapterItemInvLabel(item.label);
            adapter.addItem(0, adapterItem);
        }

        ozm = new Ozm(newItemList.get(0).label.getOzm(), newItemList.get(0).label.getName(), newItemList.get(0).label.getWidth(), newItemList.get(0).label.getLength(), newItemList.get(0).label.getThickness());

        onItemCountChanged();
    }

    private void deleteItem(InvItem item) {
        for (int i = 0; i < itemList.size(); i++) {
            if (itemList.get(i).label.getId().equalsIgnoreCase(item.label.getId())) {
                itemList.remove(i);
                break;
            }
        }

        List<IFlexible> adapterList = adapter.getCurrentItems();
        for (int i = 0; i < adapterList.size(); i++) {
            if (adapterList.get(i) instanceof AdapterItemInvLabel && ((AdapterItemInvLabel) adapterList.get(i)).getLabel().getId().equalsIgnoreCase(item.label.getId())) {
                adapter.removeItem(i);
            }
        }

        if (itemList.isEmpty()) ozm = null;

        onItemCountChanged();
    }

    private int getTotalLabelNetto() {
        int total = 0;
        for (int i = 0; i < getPackCount(); i++) {
            total += itemList.get(i).label.getWeightNetto();
        }
        return total;
    }

    private int getTotalLabelBrutto() {
        int total = 0;
        for (int i = 0; i < getPackCount(); i++) {
            total += itemList.get(i).label.getWeightNetto() + itemList.get(i).label.getWeightPack();
        }
        return total;
    }

    private void onItemCountChanged() {
        calcCrane();
        calc();
        textPrompt.setVisibility(View.VISIBLE);
        if (itemList.isEmpty()) {
            textPrompt.setText(R.string.inv_scan_prompt);
        } else {
            textPrompt.setText(Utils.format(
                    "Відскановано бірок: %d, брутто: %.3f тн",
                    itemList.size(),
                    getTotalLabelBrutto() / 1000.0f
            ));
        }
        refreshButtons();
        listView.post(() -> listView.requestFocus());

        if (getPackCount() > 0) {
            StringBuilder sb = new StringBuilder();
            sb.append(Utils.format("<b>%s %s</b>", ozm.getName(), app.sizeToString(ozm.getLength(), ozm.getWidth(), ozm.getThickness())));
            textContent.setText(app.fromHtml(sb.toString()));
            textContent.setVisibility(View.VISIBLE);
        } else {
            textContent.setVisibility(View.GONE);
        }
    }

    private void refreshButtons() {
        buttonAccept.setEnabled(!itemList.isEmpty() && getCraneBrutto() >= 0);
    }

    private int getCraneBrutto() {
        return Utils.parseInt(textWeightCraneBrutto.getText().toString());
    }

    private int getCraneNetto() {
        return getCraneBrutto() == 0 ? 0 : getCraneBrutto() - getCranePack();
    }

    private int getCranePack() {
        return Utils.parseInt(textWeightCranePack.getText().toString());
    }

    private int getPackCount() {
        return itemList.size();
    }

    @Override
    public void onAddClicked(String labelId) {
        beginScanLabel(labelId, 0, Calendar.getInstance().getTime());
    }

    public void onDeleteClicked(AdapterItemInvLabel item) {

        InvItem invItem = getInvItemByLabel(item.getLabel().getId());

        if (invItem != null) {
            showDialogConfirm(R.string.text_confirm, R.string.dialog_confirm_delete_item, (dialog, which) -> {
                deleteItem(invItem);
            });
        }
    }

    private void calc() {

        List<Integer> weightListFinal = new ArrayList<>(getPackCount());

        int weightToDivide = getCraneBrutto() - getCranePack() - getTotalNetto();
        int totalNetto = getTotalNetto();
        double weightExtra = 0;

        for (int i = 0; i < getPackCount(); i++) {
            if (getCraneBrutto() == 0) {
                weightListFinal.add(itemList.get(i).label.getWeightNetto());
                itemList.get(i).nettoFinal = itemList.get(i).label.getWeightNetto();
            } else {

                double weightToAdd = 0;

                if (weightToDivide != 0) {
                    double itemPercent = totalNetto == 0 ? 0 : (double) itemList.get(i).label.getWeightNetto() * 100 / totalNetto;
                    weightToAdd = itemPercent * weightToDivide / 100.0f;
                }

                weightExtra += weightToAdd - (int) weightToAdd;
                weightListFinal.add(itemList.get(i).label.getWeightNetto() + (int) weightToAdd);
                itemList.get(i).nettoFinal = itemList.get(i).label.getWeightNetto() + (int) weightToAdd;
            }
        }

        weightExtra = Math.round(weightExtra);

        log("weightExtra: %s", weightExtra);

        if (Math.abs(weightExtra) > 0) {
            int i = 0;
            while (Math.abs(weightExtra) >= 1.0d) {
                weightListFinal.set(i, weightListFinal.get(i) + (weightExtra > 0 ? 1 : -1));
                weightExtra -= (weightExtra > 0 ? 1 : -1);
                i = i == weightListFinal.size() - 1 ? 0 : i + 1;
            }
        }

        log("weightExtra: %s", weightExtra);

        log("Crane netto: %d, pack: %d", getCraneNetto(), getCranePack());
        for (int i = 0; i < getPackCount(); i++) {
            log("[%d] %d -> %d", i + 1, itemList.get(i).label.getWeightNetto(), weightListFinal.get(i));
            itemList.get(i).nettoFinal = weightListFinal.get(i);
        }

        adapter.notifyDataSetChanged();
    }

    private int getTotalNetto() {
        int total = 0;
        for (InvItem item : itemList) {
            total += item.label.getWeightNetto();
        }
        return total;
    }

    private int getTotalBrutto() {
        int total = 0;
        for (InvItem item : itemList) {
            total += item.label.getWeightNetto() + item.label.getWeightPack();
        }
        return total;
    }

    private void calcCrane() {

        textWeightCraneBrutto.setText(null);

        int totalPack = 0;

        for (InvItem item : itemList) {
            totalPack += item.label.getWeightPack();
            textWeightCranePack.setText(String.valueOf(totalPack));
        }

        textWeightCranePack.setText(String.valueOf(totalPack));

        /*int totalNetto = 0, totalPack = 0;

        if (itemList.size() == 1) {
            totalPack = itemList.get(0).label.getWeightPack();
            textWeightCraneBrutto.setText(String.valueOf(0));
            textWeightCranePack.setText(String.valueOf(0));
        } else {
            for (InvItem item : itemList) {
                totalNetto += item.label.getWeightNetto();
                totalPack += item.label.getWeightPack();
                textWeightCraneBrutto.setText(String.valueOf(totalNetto + totalPack));
                textWeightCranePack.setText(String.valueOf(totalPack));
            }
        }*/

    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        Intent data = new Intent();

        int packCount = getPackCount();

        ArrayList<String> listId = new ArrayList<>(packCount);
        ArrayList<String> listDateScan = new ArrayList<>(packCount);
        ArrayList<Integer> listNettoPlan = new ArrayList<>(packCount);
        ArrayList<Integer> listNettoFact = new ArrayList<>(packCount);

        for (int i = 0; i < packCount; i++) {
            listId.add(itemList.get(i).label.getId());
            listDateScan.add(String.valueOf(itemList.get(i).dateScan.getTime()));
            listNettoPlan.add(itemList.get(i).label.getWeightNetto());
            listNettoFact.add(itemList.get(i).nettoFinal);
        }

        data.putExtra("locationCode", locationCode);
        data.putStringArrayListExtra("listId", listId);
        data.putStringArrayListExtra("listDateScan", listDateScan);
        data.putIntegerArrayListExtra("listNettoPlan", listNettoPlan);
        data.putIntegerArrayListExtra("listNettoFact", listNettoFact);

        setResult(RESULT_OK, data);
        finish();
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_CANCELED);
        super.onBackPressed();
    }

    @Override
    protected void onCraneWeight(long craneId, int value) {
        textWeightCraneBrutto.setText(String.valueOf(value));
        calc();
        refreshButtons();
    }

    class AdapterItemInvLabel extends AbstractFlexibleItem<AdapterItemInvLabel.AdapterItemInvLabelViewHolder> {

        private final Label label;
        private final Date dateScan;

        AdapterItemInvLabel(Label label) {
            this.label = label;
            this.dateScan = Calendar.getInstance().getTime();
        }

        public Date getDateScan() {
            return dateScan;
        }

        public Label getLabel() {
            return label;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof AdapterItemInvLabel && ((AdapterItemInvLabel) o).getLabel().getId().equalsIgnoreCase(getLabel().getId());
        }

        @Override
        public int hashCode() {
            return getLabel().hashCode();
        }

        @Override
        public AdapterItemInvLabelViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
            return new AdapterItemInvLabelViewHolder(view, adapter);
        }

        @Override
        public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemInvLabelViewHolder holder, int position, List<Object> payloads) {
            holder.textLabelId.setText(Utils.format("%s %s", label.getId(), (label.isTheor() ? "(ТВ)" : "(ФВ)")));

            InvItem invItem = getInvItemByLabel(label.getId());
            int fact = invItem == null ? 0 : invItem.nettoFinal;

            if (label.getWeightNetto() == fact/* || fact == 0*/) {
                holder.textWeight.setText(Utils.format("Бірка, тн: %.3f", label.getWeightNetto() / 1000.0f));
            } else {
                holder.textWeight.setText(app.fromHtml(
                        Utils.format(
                                fact > 0 ? "Бірка, тн: %.3f<br>Факт, тн: <font color=\"blue\">%.3f</font>" : "Бірка, тн: %.3f<br>Факт, тн: %.3f",
                                label.getWeightNetto() / 1000.0f, fact / 1000.0f
                        )
                ));
            }
            holder.buttonDelete.setOnClickListener(v -> onDeleteClicked(this));
        }

        @Override
        public int getLayoutRes() {
            return R.layout.adapter_inv_label;
        }

        class AdapterItemInvLabelViewHolder extends FlexibleViewHolder {

            private final TextView textLabelId, textWeight;
            private final ImageButton buttonDelete;

            AdapterItemInvLabelViewHolder(View view, FlexibleAdapter adapter) {
                super(view, adapter);
                this.textLabelId = view.findViewById(R.id.textLabelId);
                this.textWeight = view.findViewById(R.id.textWeight);
                this.buttonDelete = view.findViewById(R.id.buttonDelete);
            }
        }
    }
}
