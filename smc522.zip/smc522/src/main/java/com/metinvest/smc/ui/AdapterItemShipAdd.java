package com.metinvest.smc.ui;

import android.view.View;
import android.widget.ImageButton;

import com.metinvest.smc.R;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemShipAdd extends AbstractFlexibleItem<AdapterItemShipAdd.ViewHolder> {

    public interface Listener {
        void onAddClicked();
    }

    private final Listener listener;

    public AdapterItemShipAdd(Listener listener) {
        this.listener = listener;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterItemShipAdd && o.equals(this);
    }

    @Override
    public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new ViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {
        holder.buttonAdd.setOnClickListener(v -> {
            if (listener != null) listener.onAddClicked();
        });
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_ship_label_add;
    }

    class ViewHolder extends FlexibleViewHolder {

        private final ImageButton buttonAdd;

        ViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.buttonAdd = view.findViewById(R.id.buttonAdd);
        }
    }
}
