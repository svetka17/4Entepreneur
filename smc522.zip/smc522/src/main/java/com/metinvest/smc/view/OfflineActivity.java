package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;

import com.metinvest.smc.R;

public class OfflineActivity extends MyActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offline);
    }

    @Override
    protected String getHelpContent() {
        return getString(R.string.select_operation_help);
    }

    @Override
    protected void onFunctionKey(int number) {
        switch (number) {
            case 2:
                startActivity(new Intent(this, OfflineShipActivity.class));
                break;
            case 3:
                startActivity(new Intent(this, OfflineUnknownActivity.class));
                break;
            case 4:
                startActivity(new Intent(this, PrinterActivity.class));
                break;
        }
    }
}
