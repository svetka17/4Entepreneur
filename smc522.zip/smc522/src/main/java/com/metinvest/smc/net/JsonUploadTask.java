package com.metinvest.smc.net;

import android.os.AsyncTask;

public class JsonUploadTask extends AsyncTask<JsonUploadTask.JsonUploadTaskParam, Void, JsonResult> {

	private final JsonUploadTaskListener listener;

	public JsonUploadTask(JsonUploadTaskListener listener) {
		this.listener = listener;
	}

	@Override
	protected JsonResult doInBackground(JsonUploadTaskParam... jsonUploadTaskParams) {
		return Network.getInstance().uploadJson(jsonUploadTaskParams[0].url, jsonUploadTaskParams[0].data, jsonUploadTaskParams[0].packetId);
	}

	@Override
	protected void onPostExecute(JsonResult result) {
		if (listener != null) listener.onLoaderTaskResult(result);
		super.onPostExecute(result);
	}

    public interface JsonUploadTaskListener {
		void onLoaderTaskResult(JsonResult result);
    }

    public static class JsonUploadTaskParam {
        public long packetId;
        public String url;
        public String data;

        public JsonUploadTaskParam(String url, String data) {
            this(url, data, 0);
        }

        public JsonUploadTaskParam(String url, String data, long packetId) {
            this.packetId = packetId;
            this.url = url;
            this.data = data;
        }
    }
}
