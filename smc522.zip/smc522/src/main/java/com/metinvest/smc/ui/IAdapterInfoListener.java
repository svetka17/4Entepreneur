package com.metinvest.smc.ui;

import com.metinvest.smc.view.CatalogTempActivity;

public interface IAdapterInfoListener {
	void onInfoClicked(CatalogTempActivity.AdapterLabel item);
}
