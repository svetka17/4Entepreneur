package com.metinvest.smc.ui;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.db.Weighing;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractExpandableItem;
import eu.davidea.viewholders.ExpandableViewHolder;

public class AdapterOutGroup extends AbstractExpandableItem<AdapterOutGroup.GroupViewHolder, AdapterOut> {

    private Weighing weighing;

    public AdapterOutGroup(Weighing weighing) {
        this.weighing = weighing;
    }

    public Weighing getWeighing() {
        return weighing;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterOutGroup && ((AdapterOutGroup) o).getWeighing().getId() == getWeighing().getId();
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_ship_item_group;
    }

    @Override
    public GroupViewHolder createViewHolder(View view, FlexibleAdapter adapter) {
        return new GroupViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter adapter, GroupViewHolder holder, int position, List payloads) {

        refreshHeader(holder);

        View.OnClickListener headerListener = v -> {
            holder.toggleExpansion();
            refreshHeader(holder);
        };

        holder.itemView.setOnClickListener(headerListener);
        holder.imageExpand.setOnClickListener(headerListener);
        holder.textTitle.setOnClickListener(headerListener);
    }

    private void refreshHeader(GroupViewHolder holder) {
        holder.textTitle.setText(App.getInstance().fromHtml(Utils.format("<b>Зважування №%d</b>", weighing.getNumber()))
        );
        holder.imageExpand.setImageDrawable(ContextCompat.getDrawable(holder.itemView.getContext(), isExpanded() ? R.drawable.ic_keyboard_arrow_down_black_24dp : R.drawable.ic_keyboard_arrow_right_black_24dp));
    }

    static class GroupViewHolder extends ExpandableViewHolder {

        private final ImageView imageExpand;
        private final TextView textTitle;

        GroupViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.textTitle = view.findViewById(R.id.textTitle);
            this.imageExpand = view.findViewById(R.id.imageExpand);
        }

        @Override
        public void toggleExpansion() {
            super.toggleExpansion();
        }
    }
}