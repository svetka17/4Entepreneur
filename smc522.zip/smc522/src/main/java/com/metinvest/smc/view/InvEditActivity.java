package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.metinvest.smc.R;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.Utils;

import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;

public class InvEditActivity extends MyActivity {

    @BindView(R.id.textWeightBrutto)
    EditText textWeightBrutto;
    @BindView(R.id.textWeightPack)
    EditText textWeightPack;
    @BindView(R.id.textTotal)
    TextView textTotal;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;

    private Label label;
    private int nettoNew, packNew, pack;
    private Date dateScan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inv_edit);
        ButterKnife.bind(this);

        label = (Label) getIntent().getSerializableExtra("label");
        nettoNew = getIntent().getIntExtra("nettoNew", 0);
        pack = getIntent().getIntExtra("pack", 0);
        dateScan = (Date) getIntent().getSerializableExtra("dateScan");

        textWeightBrutto.setText(String.valueOf(nettoNew));
        textWeightPack.setText(String.valueOf(pack));

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                calcNetto();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        };
        textWeightBrutto.addTextChangedListener(textWatcher);
        textWeightPack.addTextChangedListener(textWatcher);
        calcNetto();
    }

    private void calcNetto() {
        int weightBrutto = Utils.parseInt(textWeightBrutto.getText().toString());
        int weightPack = Utils.parseInt(textWeightPack.getText().toString());
        //nettoNew = weightBrutto - weightPack;
        //CodeQL requirement
        int nettoNew = 0;
        if (weightPack < Integer.MAX_VALUE)
            nettoNew = weightBrutto - weightPack;
        textTotal.setText(Utils.format("%.3f", nettoNew / 1000.0f));
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        if (nettoNew < 0) {
            showDialog(R.drawable.ic_error_24dp, R.string.text_error, R.string.error_netto_zero, null);
            return;
        }

        beginAccept(nettoNew, packNew);
    }

    private void beginAccept(int nettoNew, int packNew) {
        Intent data = new Intent();
        data.putExtra("label", label);
        data.putExtra("nettoNew", nettoNew);
        data.putExtra("packNew", packNew);
        data.putExtra("dateScan", dateScan);
        setResult(RESULT_OK, data);
        finish();
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_CANCELED);
        super.onBackPressed();
    }
}
