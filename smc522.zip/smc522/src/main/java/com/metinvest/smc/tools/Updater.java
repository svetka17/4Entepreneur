package com.metinvest.smc.tools;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.StrictMode;

import com.metinvest.smc.App;
import com.metinvest.smc.net.StringResult;

import java.io.File;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;

public class Updater {

	public interface UpdaterListener {
		void onStateChanged(UpdaterState stateOld, UpdaterState stateNew);
		void onLog(String message);
		void onEndCheck(boolean success, boolean needUpdate);
		void onEndDownload(boolean success);
	}

	public enum UpdaterState {
		WAITING, CHECKING, DOWNLOADING, UPDATING
	}

	private String updateCheckUrl, updateDownloadUrl;
	//private StorageSharedKeyCredential credentialKey;
	//private BlobServiceSasSignatureValues sasSignatureValues;
	//private BlobServiceClient blobServiceClient;
	private final int currentVersion;
	private final WeakReference<Activity> activityReference;
	private final UpdaterListener updaterListener;
	private final DownloadManager downloadManager;
	private UpdaterState state;
	private final BroadcastReceiver broadcastReceiver;

	private long downloadId = -1;
	private String downloadFileName, downloadMimeType;

	public void setUpdateCheckUrl(String updateCheckUrl) {
		this.updateCheckUrl = updateCheckUrl;
	}

	public void setUpdateDownloadUrl(String updateDownloadUrl) {
		this.updateDownloadUrl = updateDownloadUrl;
	}

	public Updater(Activity activity, UpdaterListener updaterListener, String updateCheckUrl, String updateDownloadUrl, int currentVersion) {
		this.state = UpdaterState.WAITING;
		this.activityReference = new WeakReference<>(activity);
		this.updaterListener = updaterListener;
		this.updateCheckUrl = updateCheckUrl;
		this.updateDownloadUrl = updateDownloadUrl;
		this.currentVersion = currentVersion;
		// Создание учетных данных общего ключа хранения
		/*StorageSharedKeyCredential credentialKey = new StorageSharedKeyCredential(CONST_ACCOUNT_STORAGE, CONST_KEY1_STORAGE);
		TokenCredential tokenCredential = new ClientSecretCredentialBuilder()
				.clientId("0038db9f-b7cb-457e-905c-b283fea587c3")
				.clientSecret("5ZO8Q~Adni1ZS7TAjqKdA0yTAOdCbiNQPGJDxcwA")
				.tenantId("b0bbbc89-2041-434f-8618-bc081a1a01d4")
				.build();
		//ClientOptions clientOpt = new ClientOptions().se;
		DefaultAzureCredential credentialDef = new DefaultAzureCredentialBuilder()
				//.clientOptions(clientOpt)
				//.tenantId("b0bbbc89-2041-434f-8618-bc081a1a01d4")
				.build();
		// Создаем объект BlobServiceClient
		blobServiceClient = new BlobServiceClientBuilder()
				.endpoint(CONST_URL_STORAGE)
				.credential(credentialKey)
				//.credential(tokenCredential)
				//.credential(credentialDef)
				.buildClient();*/

		// String.format("https://%s.blob.core.windows.net", accountName)

		this.broadcastReceiver = new BroadcastReceiver() {
			public void onReceive(Context context, Intent intent) {

				//Fetching the download id received with the broadcast
				long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);

				//Checking if the received broadcast is for our enqueued download by matching download id
				if (downloadId == id) {

					try {
						Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
						m.invoke(null);
					} catch (Exception e) {
						App.getInstance().log(this, e, "disableDeathOnFileUriExposure");
						updaterListener.onLog(e.getLocalizedMessage());
					}

					setState(UpdaterState.WAITING);

					try {
						DownloadManager.Query q = new DownloadManager.Query();
						q.setFilterById(downloadId);
						Cursor c = downloadManager.query(q);

						if (c.moveToFirst()) {
							int indColumnStatus = c.getColumnIndex(DownloadManager.COLUMN_STATUS);
							int indColumnUri = c.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI);
							int indColumnType = c.getColumnIndex(DownloadManager.COLUMN_MEDIA_TYPE);
							int indColumnReason = c.getColumnIndex(DownloadManager.COLUMN_REASON);

							int status = c.getInt(indColumnStatus);
							if (status == DownloadManager.STATUS_SUCCESSFUL) {
								// process download
								String fileName = c.getString(indColumnUri);
								fileName = fileName.replace("file://", "");
								String mimeType = c.getString(indColumnType);
								onDownloadComplete(fileName, mimeType);
							} else {
								onDownloadError(String.valueOf(c.getInt(indColumnReason)));
							}
						}
					} catch (Exception e) {
						App.getInstance().log(this, e, "onDownloadError()");
						onDownloadError(e.getLocalizedMessage());
					}
				}

			}
		};
		downloadManager = (DownloadManager) activity.getSystemService(Context.DOWNLOAD_SERVICE);
		activity.registerReceiver(broadcastReceiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
	}

	public UpdaterState getState() {
		return state;
	}

	private void setState(UpdaterState state) {
		UpdaterState stateOld = this.state;
		this.state = state;
		updaterListener.onStateChanged(stateOld, state);
	}

	public void beginCheck() {
		if (activityReference.get() == null || getState() != UpdaterState.WAITING) return;

		setState(UpdaterState.CHECKING);

		updaterListener.onLog("beginCheckUpdate");

		// Получаем ссылку на Blob
		//BlobClient blobClient = blobServiceClient.getBlobContainerClient("install").getBlobClient("com.metinvest.smc.test.txt");
		//String sasToken = "";
		//try {
			// Генерируем SAS токен
			//sasToken = blobClient.generateSas(sasSignatureValues);
			/*BlobContainerSasPermission blobContainerSasPermission = new BlobContainerSasPermission()
					.setReadPermission(true)
					//.setWritePermission(true)
					//.setListPermission(true)
					;
			sasSignatureValues = new BlobServiceSasSignatureValues(
					OffsetDateTime.now().plusDays(1), blobContainerSasPermission)
					.setProtocol(SasProtocol.HTTPS_ONLY);*/
			//sasToken = blobClient.generateSas(builder);

			// Получение User Delegation Key
/*			OffsetDateTime keyStart = OffsetDateTime.now();
			OffsetDateTime keyExpiry = keyStart.plusDays(1); // Задаем время действия ключа на 1 день
			try {
				sasSignatureValues = new BlobServiceSasSignatureValues()
				.setExpiryTime(keyExpiry)
				.setStartTime(keyStart)
				.setProtocol(SasProtocol.HTTPS_ONLY)
						.setVersion("2022-11-02")
				//sasSignatureValues.setPermissions(new BlobSasPermission().setReadPermission(true));
				.setPermissions(new BlobContainerSasPermission().setReadPermission(true));

				UserDelegationKey userDelegationKey = new UserDelegationKey();
				userDelegationKey.setSignedStart(keyStart);
				userDelegationKey.setSignedExpiry(keyExpiry);
				userDelegationKey.setSignedTenantId("b0bbbc89-2041-434f-8618-bc081a1a01d4");
				userDelegationKey.setSignedVersion("2022-11-02");
				userDelegationKey.setSignedService("b");
				userDelegationKey.setSignedObjectId("84aacba7-11a1-4b57-a4af-b8eba4a387c4");
				userDelegationKey.setValue(CONST_KEY1_STORAGE);
				if (blobClient != null && userDelegationKey != null && sasSignatureValues != null) {
					sasToken = blobClient.generateUserDelegationSas(sasSignatureValues, userDelegationKey);
				}
				//sasToken = blobClient.generateUserDelegationSas(sasSignatureValues, userDelegationKey);
			} catch (Exception e){
				String error = e.toString();
			}

			String temp = updateCheckUrl+"?"+sasToken;
			setUpdateCheckUrl(temp);
		} catch (Exception e) {
			String error = e.toString();
		}*/

		Utils.runOnBackground(() -> endCheckUpdate(request(updateCheckUrl)));
	}

	private void endCheckUpdate(String body) {
		if (activityReference.get() == null) return;

		setState(UpdaterState.WAITING);

		activityReference.get().runOnUiThread(() -> {
			if (body == null) {
				updaterListener.onEndCheck(false, false);
			} else {
				int serverVersion = Utils.parseInt(parseIni(body, "version"));
				updaterListener.onEndCheck(true, serverVersion > currentVersion);
			}
		});

	}

	private String request(String url) {
		StringResult result = App.getInstance().getNetwork().requestString(url, false, false, null, 0);
		return result.isOk() ? result.getData() : null;
	}

	public void beginUpdate() {
		if (activityReference.get() == null || state != UpdaterState.WAITING || downloadFileName == null || downloadFileName.length() == 0)
			return;

		setState(UpdaterState.UPDATING);

		activityReference.get().runOnUiThread(() -> {

			try {
				Intent in = new Intent(Intent.ACTION_VIEW);
				in.setDataAndType(Uri.fromFile(new File(downloadFileName)), downloadMimeType);
				in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				activityReference.get().startActivity(in);
			} catch (Exception e) {
				App.getInstance().log(this, e, "beginUpdate()");
				updaterListener.onLog(e.getMessage());
			} finally {
				setState(UpdaterState.WAITING);
			}

            /*Intent in = new Intent(Intent.ACTION_INSTALL_PACKAGE);
            in.setData(Uri.fromFile(new File(fileName)));
            in.putExtra(Intent.EXTRA_NOT_UNKNOWN_SOURCE, true);
            in.putExtra(Intent.EXTRA_RETURN_RESULT, true);
            in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activityReference.get().startActivity(in);*/
		});
	}

	public void beginDownload() {

		if (activityReference.get() == null || state != UpdaterState.WAITING) return;

		setState(UpdaterState.DOWNLOADING);

		try {
			Uri downloadUri = Uri.parse(updateDownloadUrl);
			DownloadManager.Request r = new DownloadManager.Request(downloadUri);
			r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "application.apk");
			r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
			downloadId = downloadManager.enqueue(r);
		} catch (Exception e) {
			App.getInstance().log(this, e, "beginDownload()");
			setState(UpdaterState.WAITING);
			onDownloadError(e.getLocalizedMessage());
		}
	}

	private void onDownloadError(String message) {
		updaterListener.onLog(Utils.format("onDownloadError: %s", message));
		updaterListener.onEndDownload(false);
	}

	private void onDownloadComplete(final String fileName, final String mimeType) {
		this.downloadFileName = fileName;
		this.downloadMimeType = mimeType;
		updaterListener.onEndDownload(true);
	}

	private String parseIni(String content, String field) {

		String[] lines;

		try {
			lines = content.split("\\r?\\n");
		} catch (Exception ignored) {
			return "";
		}

		for (String line : lines) {

			int i = line.indexOf("=");
			if (i != -1) {
				String lineField = line.substring(0, i);
				if (lineField.compareToIgnoreCase(field) == 0) {
					return line.substring(i + 1);
				}
			}

		}

		return "";
	}

	public void dispose() {
		if (activityReference.get() != null)
			activityReference.get().unregisterReceiver(broadcastReceiver);
	}
}
