package com.metinvest.smc.view;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.JsonUploadTask;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;

public class RolloutActivity extends MyActivity implements IScan {

    @BindView(R.id.frameButtonAccept)
    View frameButtonAccept;
    @BindView(R.id.viewContentData)
    View viewContentData;
    @BindView(R.id.textContentData)
    TextView textContentData;
    @BindView(R.id.textPrompt)
    TextView textPrompt;
    @BindView(R.id.textWeight)
    EditText textWeight;
    private ScanItem item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rollout);
        ButterKnife.bind(this);

        frameButtonAccept.setVisibility(View.GONE);
        viewContentData.setVisibility(View.GONE);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) {
            //beginView(new ScanItem("SMC02|2014|0|XX|0KLRgNGD0LHQsCDQv9GA0L7RhC4xNXgxNdGFMS44INCh0YIy0L/RgSDQvNC10YDQsA==|0024973386|0|0|0|20190417163259"));
            //beginView(new ScanItem("SMC02|170|0|XX|0KLRgNGD0LHQsCDQv9GA0L7RhC4gMTXRhTE10YUxLjIg0KHRgjHQv9GBINC80LXRgNCw|0023258461|0|0|0|20190502000000"));
            //beginView(new ScanItem("SMC02|9380|0|XX|0KLRgNGD0LHQsCDQv9GA0L7RhC4gODDRhTYw0YU0INCh0YIz0L/RgSDQvNC10YDQsA==|0023709705|0|0|0|20190310000000"));
        }
        if (number == 4) buttonAcceptClick();
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {
        if (isLoading()) return;

        runOnUiThread(() -> {

            item = null;
            frameButtonAccept.setVisibility(View.GONE);
            viewContentData.setVisibility(View.GONE);
            textPrompt.setVisibility(View.VISIBLE);

            ScanItem scanItem = new ScanItem(barcodeData);

            if (scanItem.getType() == ScanItem.ScanItemType.SMC02) {
                if (scanItem.isCorrect()) {
                    beginView(scanItem);
                } else {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_label, null);
                }
            }

        });
    }

    private void beginView(ScanItem scanItem) {

        if (isLoading()) return;

        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            String externalId = scanItem.getLine();

            String url = config.getUrlApi() + "getlabelbyexternalid";
            url = net.addUrlParam(url, "external_id", Utils.base64encode(externalId));
            JsonResult result = net.downloadJson(url);

            JSONObject data = Utils.getJsonObject(result.getJson(), "data");

            if (result.isOk() && data != null) {
                JSONObject label = Utils.getJsonObject(data, "label");

                if (label == null) {
                    runOnUiThread(() -> endView(scanItem));
                } else {
                    runOnUiThread(() -> {
                        hideLoading();
                        showDialog(R.drawable.ic_info_24dp, R.string.text_information, "Позиція вже була відсканована раніше!", (dialog, which) -> viewLabel(Utils.getJsonStringIgnoreCase(label, "id")));
                    });
                }
            } else {
                runOnUiThread(() -> {
                    hideLoading();
                    showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginView(scanItem));
                });
            }
        });

    }

    private void endView(ScanItem item) {
        hideLoading();

        this.item = item;

        String name = Utils.base64decode(item.getData(3));
        String netto = item.getData(0);

        String content = "";
        content += Utils.format("<b>%s</b><br>", name);
        content += "Оприходувати з вагою<br>нетто, кг:";

        frameButtonAccept.setVisibility(View.VISIBLE);
        textPrompt.setVisibility(View.GONE);
        viewContentData.setVisibility(View.VISIBLE);
        textContentData.setText(app.fromHtml(content));
        textWeight.setText(netto);
        textWeight.requestFocus();
    }

    private void endLoad(JsonResult result) {
        hideLoading();

        if (result.isOk()) {
            String labelId = Utils.getJsonStringIgnoreCase(Utils.getJsonObject(result.getJson(), "data"), "labelid");
            showDialog(R.drawable.ic_info_24dp, R.string.text_information, R.string.successful_accepted, (dialog, which) -> {
                frameButtonAccept.setVisibility(View.GONE);
                textPrompt.setVisibility(View.VISIBLE);
                viewContentData.setVisibility(View.GONE);
                viewLabel(labelId);
            });
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
        }
    }

    private void viewLabel(String labelId) {
        showInfoByLabelId(labelId);
    }

    private void buttonAcceptClick() {
        if (isLoading() || frameButtonAccept.getVisibility() == View.GONE) return;

        beginLoad();
    }

    private void beginLoad() {
        if (isLoading()) return;
        showLoading(R.string.text_please_wait);

        String url = config.getUrlApi() + "rollout";

        String name = Utils.base64decode(item.getData(3));
        String batch = item.getData(4);
        String netto = item.getData(0);
        String length = item.getData(5);
        String width = item.getData(6);
        String thickness = item.getData(7);
        String pack = item.getData(1);
        String externalId = item.getLine();

        String newNetto = textWeight.getText().toString();

        String uploadData = Utils.format("{%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n}"
                , Utils.format("\"SAP_Matt_Descr\" : \"%s\",", name)
                , Utils.format("\"SAP_Batch\" : \"%s\",", batch)
                , Utils.format("\"SAP_Weight_NETT\" : \"%s\",", newNetto)
                , Utils.format("\"Length\" : \"%s\",", length)
                , Utils.format("\"Width\" : \"%s\",", width)
                , Utils.format("\"Thickness\" : \"%s\",", thickness)
                , Utils.format("\"Pack_Weight\" : \"%s\",", pack)
                , Utils.format("\"Nett_Weight\" : \"%s\",", newNetto)
                , Utils.format("\"External_Id\" : \"%s\"", Utils.base64encode(externalId))
        );
        net.uploadJson(new JsonUploadTask.JsonUploadTaskParam(url, uploadData), this::endLoad);
    }

}
