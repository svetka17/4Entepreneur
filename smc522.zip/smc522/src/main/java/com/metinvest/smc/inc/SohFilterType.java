package com.metinvest.smc.inc;

public enum SohFilterType {
	ALL, SOH_TRUE, SOH_FALSE, NOT_SOH, EO_TRUE
}
