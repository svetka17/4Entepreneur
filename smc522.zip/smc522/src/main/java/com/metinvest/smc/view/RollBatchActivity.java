package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Roll;
import com.metinvest.smc.db.RollName;
import com.metinvest.smc.inc.Weight;
import com.metinvest.smc.tools.Utils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class RollBatchActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;
    @BindView(R.id.buttonManual)
    Button buttonManual;

    private RollName rollName;
    private String locationCode;
    private boolean isTheor;
    private int weightCraneBrutto, weightCraneNetto, packCount;
    private ArrayList<Weight> weightList;
    private List<Roll> rollList, rollListChecked;

    private FlexibleAdapter<Adapter> adapter;
    private int packNum;
    private int baseTheorWeight;
    private String filterMarkdown, filterMera, filterTravl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roll_batch);
        ButterKnife.bind(this);

        long rollNameId = getIntent().getLongExtra("rollNameId", 0);
        rollName = db.rollNameDao().getById(rollNameId);
        if (rollName == null) {
            setResult(RESULT_CANCELED);
            finish();
        }

        filterMarkdown = getIntent().getStringExtra("markdown");
        filterMera = getIntent().getStringExtra("mera");
        filterTravl = getIntent().getStringExtra("travl");

        packNum = getIntent().getIntExtra("packNum", 1);
        isTheor = getIntent().getBooleanExtra("isTheor", false);
        weightCraneBrutto = getIntent().getIntExtra("weightCraneBrutto", 0);
        weightCraneNetto = getIntent().getIntExtra("weightCraneNetto", 0);
        packCount = getIntent().getIntExtra("packCount", 0);
        locationCode = getIntent().getStringExtra("locationCode");
        weightList = new ArrayList<>(getIntent().getParcelableArrayListExtra("weightList"));
        baseTheorWeight = isTheor && !weightList.isEmpty() ? weightList.get(0).getNetto() : 0;

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

        refreshTitle();
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 4) {
            buttonManualClick();
        } else if (number == 5) {
            buttonAcceptClick();
        }
    }

    private int getBusyWeight(Roll roll) {
        int value = 0;
        for (int i = 0; i < rollListChecked.size(); i++) {
            if (rollListChecked.get(i).getId() == roll.getId()) {
                value += weightList.get(i).getNetto();
            }
        }
        return value;
    }

    private void beginLoad() {
        if (isLoading()) return;

        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            rollList = db.rollDao().getByNameAndWeight(rollName.getId(), isTheor ? baseTheorWeight : -1, filterMarkdown, filterMera, filterTravl);
            rollListChecked = new ArrayList<>();

            List<Long> currentRollListChecked = (List<Long>) getIntent().getSerializableExtra("rollListChecked");
            if (currentRollListChecked != null) {
                for (Long id : currentRollListChecked) {
                    rollListChecked.add(db.rollDao().getById(id));
                }
            }

            List<Adapter> list = new ArrayList<>();

            for (int i = 0; i < rollList.size(); i++) {
                list.add(new Adapter(i, rollList.get(i), getBusyWeight(rollList.get(i))));
            }

            Collections.sort(list, (o1, o2) -> {
                if (o1.getRoll().getStock()/*.getAvailableNetto()*/ == 0) return 1;
                if (o2.getRoll().getStock()/*.getAvailableNetto()*/ == 0) return -1;

                int a = getWeightByNum().getNetto();
                int diff1 = o1.getRoll().getStock()/*.getAvailableNetto()*/ - a;
                int diff2 = o2.getRoll().getStock()/*.getAvailableNetto()*/ - a;
                if (diff1 < 0) diff1 *= -1;
                if (diff2 < 0) diff2 *= -1;
                return Integer.compare(diff1, diff2);
            });

            adapter = new FlexibleAdapter<>(list);
            adapter.addListener(this);

            runOnUiThread(this::endLoad);

        });
    }

    private void checkButtonAccept() {
        boolean ready = getCheckedCount() == 1;
        buttonAccept.setEnabled(ready);
    }

    @Override
    public boolean onItemClick(View view, int position) {

        Adapter item = adapter.getItem(position);
        if (item != null) {

            boolean checked = item.isChecked();

            if (!checked) {
                List<Adapter> list = adapter.getCurrentItems();
                for (Adapter listItem : list) {
                    if (!listItem.equals(item)) {
                        listItem.setChecked(false);
                        adapter.updateItem(listItem);
                    }
                }
            }

            item.setChecked(!checked && (item.getRoll().getStock()/*.getAvailableNetto()*/ - item.getBusyWeight() > 0));
            adapter.updateItem(item);
            refreshTitle();
            checkButtonAccept();
            return true;
        }

        return false;
    }

    private void endLoad() {
        hideLoading();

        runOnUiThread(() -> {
            textNotFound.setVisibility(adapter == null || adapter.isEmpty() ? View.VISIBLE : View.GONE);
            listView.setAdapter(adapter);
            scrollView.post(() -> scrollView.scrollTo(0, 0));
            checkButtonAccept();
            buttonManual.setEnabled(getLargerRoll() != null);
        });
    }

    private Weight getWeightByNum() {
        return weightList.get(packNum - 1);
    }

    private void refreshTitle() {
        String text = Utils.format("Партія пачки №%d, %d кг", packNum, getWeightByNum().getNetto());
        textContentTitle.setText(text);
    }

    private int getCheckedCount() {
        int count = 0;
        if (adapter != null) {
            for (Adapter item : adapter.getCurrentItems()) {
                if (item.isChecked()) count++;
            }
        }
        return count;
    }

    private List<Adapter> getCheckedItems() {
        List<Adapter> list = new ArrayList<>();
        if (adapter != null) {
            for (Adapter item : adapter.getCurrentItems()) {
                if (item.isChecked()) list.add(item);
            }
        }
        return list;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ACTION && resultCode == RESULT_OK) {
            setResult(RESULT_OK);
            finish();
        }

        if (requestCode == REQUEST_ACTION && resultCode == RESULT_NEED_REFRESH) {
            setResult(RESULT_NEED_REFRESH);
            finish();
        }

        if (requestCode == REQUEST_ACTION && resultCode == RESULT_DELETED) {
            setResult(RESULT_DELETED);
            finish();
        }
    }

    private Roll getLargerRoll() {

        Roll largerRoll = null;

        for (int i = 0; i < rollList.size(); i++) {
            if (largerRoll == null || rollList.get(0).getStock() > largerRoll.getStock()) {
                largerRoll = rollList.get(0);
            }
        }

        return largerRoll;
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled() || getCheckedCount() == 0) return;
        goNext(getCheckedItems().get(0).getRoll());
    }

    private void buttonManualClick() {
        if (isLoading() || !buttonManual.isEnabled()) return;

        Roll roll = getLargerRoll();

        if (roll != null)
            goNext(roll);
    }

    private void goNext(@NonNull Roll checkedRoll) {

        List<Long> currentRollListChecked = new ArrayList<>();
        for (Roll roll : rollListChecked) {
            currentRollListChecked.add(roll.getId());
        }
        currentRollListChecked.add(checkedRoll.getId());

        if (packNum < packCount) {
            Intent intent = new Intent(this, RollBatchActivity.class);
            intent.putExtra("markdown", filterMarkdown);
            intent.putExtra("mera", filterMera);
            intent.putExtra("travl", filterTravl);
            intent.putExtra("rollNameId", rollName.getId());
            intent.putExtra("isTheor", isTheor);
            intent.putExtra("weightCraneBrutto", weightCraneBrutto);
            intent.putExtra("weightCraneNetto", weightCraneNetto);
            intent.putExtra("packCount", packCount);
            intent.putExtra("locationCode", locationCode);
            intent.putExtra("packNum", packNum + 1);
            intent.putParcelableArrayListExtra("weightList", new ArrayList<>(weightList));
            intent.putExtra("rollListChecked", (Serializable) currentRollListChecked);
            startActivityForResult(intent, REQUEST_ACTION);
        } else {
            Intent intent = new Intent(this, RollResultActivity.class);
            intent.putExtra("markdown", filterMarkdown);
            intent.putExtra("mera", filterMera);
            intent.putExtra("travl", filterTravl);
            intent.putExtra("rollNameId", rollName.getId());
            intent.putExtra("isTheor", isTheor);
            intent.putExtra("weightCraneBrutto", weightCraneBrutto);
            intent.putExtra("weightCraneNetto", weightCraneNetto);
            intent.putExtra("packCount", packCount);
            intent.putExtra("locationCode", locationCode);
            intent.putParcelableArrayListExtra("weightList", new ArrayList<>(weightList));
            intent.putExtra("rollListChecked", (Serializable) currentRollListChecked);
            startActivityForResult(intent, REQUEST_ACTION);
        }
    }

    public static class Adapter extends AbstractFlexibleItem<Adapter.ViewHolder> {

        private final int index;
        private final Roll roll;
        private final int busyWeight;
        private boolean checked;

        Adapter(int index, Roll roll, int busyWeight) {
            this.index = index;
            this.roll = roll;
            this.busyWeight = busyWeight;
            this.setEnabled(true);
        }

        public int getIndex() {
            return index;
        }

        public boolean isChecked() {
            return checked;
        }

        private void setChecked(boolean checked) {
            this.checked = checked;
        }

        public Roll getRoll() {
            return roll;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof Adapter && ((Adapter) o).getRoll().getId() == getRoll().getId();
        }

        @Override
        public int hashCode() {
            return getRoll().hashCode();
        }

        @Override
        public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
            return new ViewHolder(view, adapter);
        }

        @Override
        public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {

            int v = roll.getStock()/*.getAvailableNetto()*/ - busyWeight;
            if (v < 0) v = 0;

            holder.textTitle.setText(roll.getBatch());
            holder.textWeight.setText(String.valueOf(v));
            holder.textWeight.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), v > 0 ? R.color.batch_enabled : R.color.batch_disabled));

            refreshBackground(holder);
        }

        public int getBusyWeight() {
            return busyWeight;
        }

        private void refreshBackground(ViewHolder holder) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), isChecked() ? R.color.batch_selected : R.color.color_adapter_light));
        }

        @Override
        public int getLayoutRes() {
            return R.layout.adapter_inc_batch_row;
        }

        class ViewHolder extends FlexibleViewHolder {

            @BindView(R.id.textTitle)
            TextView textTitle;
            @BindView(R.id.textContent)
            TextView textContent;
            @BindView(R.id.textWeight)
            TextView textWeight;

            ViewHolder(View view, FlexibleAdapter adapter) {
                super(view, adapter);
                ButterKnife.bind(this, view);
            }
        }
    }

}
