package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanIntentResult;
import com.journeyapps.barcodescanner.ScanOptions;
import com.metinvest.smc.BuildConfig;
import com.metinvest.smc.R;
import com.metinvest.smc.db.ShipmentDocument;
import com.metinvest.smc.db.ShipmentTransport;
import com.metinvest.smc.inc.SohFilter;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemTransport;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class ShipCarsActivity extends MyActivity implements IScan, FlexibleAdapter.OnItemClickListener {

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.viewContentData)
    View viewContentData;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    @BindView(R.id.viewButtons)
    View viewButtons;
    @BindView(R.id.textFilter)
    EditText textFilter;
    @BindView(R.id.buttonFilterClear)
    ImageButton buttonFilterClear;

    private Date date, date2;
    private String sohSmcId;
    private SohFilter sohFilter;
    private FlexibleAdapter<AdapterItemTransport> adapter;
    private List<AdapterItemTransport> adapterList;

    private ActivityResultLauncher<Intent> scanLauncher;

    private void scanBarcode() {
        Intent intent = new ScanContract().createIntent(
                this,
                new ScanOptions() //Builder()
                        .setPrompt("Відскануйте штрихкод або QR-код")
                        .setBeepEnabled(true)
                        .setOrientationLocked(true)
                        .setTorchEnabled(true)
                //.build()
        );
        scanLauncher.launch(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ship_cars);
        ButterKnife.bind(this);

        sohSmcId = getIntent().getStringExtra("sohSmcId");
        sohFilter = sohSmcId == null ? SohFilter.NotSoh() : SohFilter.SohInc(sohSmcId);
        date = (Date) getIntent().getSerializableExtra("date");
        date2 = (Date) getIntent().getSerializableExtra("date2");
        textContentTitle.setText(getString(R.string.title_ship_cars, app.getDateFormat().format(date)));

        if (BuildConfig.DEBUG) {
            scanLauncher = registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result != null) {
                            ScanContract scanContract = new ScanContract();
                            ScanIntentResult intentResult = scanContract.parseResult(result.getResultCode(), result.getData());
                            if (intentResult != null) {
                                String cameraBarcode = intentResult.getContents();
                                onBarcodeEvent(cameraBarcode);
                            }
                        }
                    });
            textContentTitle.setOnClickListener(v -> scanBarcode());
            //textContentTitle.setOnClickListener(v -> onBarcodeEvent("0022849739"));
        }

        listView = findViewById(R.id.listView);
        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

        textFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                doFilter();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    protected String getHelpContent() {
        return getString(R.string.ship_cars_help);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) buttonRefreshClick();
        else if (number == 3) buttonFilterClearClick();
    }

    private void buttonFilterClearClick() {
        hideKeyboard();
        textFilter.setText(null);
        buttonFilterClick();
    }

    private void buttonRefreshClick() {
        if (isLoading()) return;

        beginLoad();
    }

    public void itemClick(int position) {
        AdapterItemTransport item = adapter.getItem(position);
        if (item != null) {
            openTransport(item.getShipmentTransport());
        }
    }

    @Override
    public boolean onItemClick(View view, int position) {
        if (position != 0 && config.isEo()) {
            showDialogConfirm(R.string.text_confirm, getString(R.string.ship_no_uno), "Продовжити", "Відміна", (dialog, which) -> itemClick(position), null);
            //return false;
        } else {
            itemClick(position);
        }
        return false;
    }

    private void openTransport(ShipmentTransport shipmentTransport) {
        Intent intent = new Intent(this, ShipCarActivity.class);

        if (config.isEo()) {
            Calendar c = Calendar.getInstance();
            c.setTime(new Date());
            c.add(Calendar.YEAR, -1);
            intent.putExtra("date", c.getTime());
            intent.putExtra("date2", new Date());
            List<ShipmentDocument> docList = db.shipmentDocumentDao().getByTransportId(shipmentTransport.getId());
            ArrayList<String> documentList = new ArrayList<>();
            for (int i = 0; i < docList.size(); i++) {
                documentList.add(docList.get(i).getDocNumber());
            }
            if (documentList.size() > 0)
                intent.putStringArrayListExtra("documentList", documentList);
        } else {
            intent.putExtra("date", date);
            intent.putExtra("date2", date2);
        }
        intent.putExtra("sohSmcId", sohSmcId);
        intent.putExtra("transportName", shipmentTransport.getName());
        intent.putExtra("transportId", shipmentTransport.getId());
        //if (config.getStorage().length() > 1)
        //	intent.putExtra("lgort", config.getStorage());
        startActivityForResult(intent, REQUEST_DEFAULT);
    }

    private void openDocument(ShipmentDocument document) {
        Intent intent = new Intent(this, ShipDetailActivity.class);
        if (config.isEo()) {
            Calendar c = Calendar.getInstance();
            c.setTime(new Date());
            c.add(Calendar.YEAR, -1);
            intent.putExtra("date", c.getTime());
            intent.putExtra("date2", new Date());
            List<ShipmentDocument> docList = db.shipmentDocumentDao().getByTransportId(document.getTransportId());
            ArrayList<String> documentList = new ArrayList<>();
            for (int i = 0; i < docList.size(); i++) {
                documentList.add(docList.get(i).getDocNumber());
            }
            if (documentList.size() > 0)
                intent.putStringArrayListExtra("documentList", documentList);
            intent.putExtra("dateVo", new Date(document.getFirstDate()));
            intent.putExtra("sohSmcId", sohSmcId);
            intent.putExtra("transportName", document.getTransportName());
            intent.putExtra("documentNumber", document.getDocNumber());

            if (document.getTurnId() != 1)
                showDialogConfirm(R.string.text_confirm, getString(R.string.ship_no_uno), "Продовжити", "Відміна", (dialog, which) -> itemClick(document.getTurnId()-1), null);
            else
                startActivityForResult(intent, REQUEST_DEFAULT);
        } else {
            intent.putExtra("date", date);
            intent.putExtra("date2", date2);
            intent.putExtra("dateVo", document.getDateVoDt());
            intent.putExtra("sohSmcId", sohSmcId);
            intent.putExtra("transportName", document.getTransportName());
            intent.putExtra("documentNumber", document.getDocNumber());
            startActivityForResult(intent, REQUEST_DEFAULT);
        }

        //if (config.getStorage().length() > 1)
        //	intent.putExtra("lgort", config.getStorage());

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_DEFAULT && resultCode == RESULT_OK) {
            beginLoad();
        }

        if (requestCode == REQUEST_SEARCH && resultCode == RESULT_OK && data != null) {
            long id = data.getLongExtra("id", 0);
            boolean isTransport = data.getBooleanExtra("isTransport", false);

            if (isTransport) {
                openTransport(db.shipmentTransportDao().getById(id));
            } else {
                openDocument(db.shipmentDocumentDao().getById(id));
            }
        }
    }

    private void beginLoad() {

        if (isLoading()) return;

        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);
        listView.setAdapter(null);
        adapter = null;

        Utils.runOnBackground(() -> {
            JsonResult result;
            if (config.isEo())
                result = app.loadShipmentOrdersEO();
            else
                result = app.loadShipmentOrders(date, date2, null, sohFilter);

            List<AdapterItemTransport> list = new ArrayList<>();

            if (result.isOk()) {
                List<ShipmentTransport> transportList = db.shipmentTransportDao().getAll();

                for (ShipmentTransport shipmentTransport : transportList) {
                    List<ShipmentDocument> documentList = db.shipmentDocumentDao().getByTransportId(shipmentTransport.getId());
                    list.add(new AdapterItemTransport(shipmentTransport, documentList));
                }
            }

            if (config.isEo())
                Collections.sort(list, (o1, o2) -> {
                    int c1 = o1.getShipmentTransport().getOrderCount();
                    int c2 = o2.getShipmentTransport().getOrderCount();
                    int c = Integer.compare(c1, c2);
                    return c;
                });
            else
                //Сортировка машин
                Collections.sort(list, (o1, o2) -> {
                    boolean d1 = o1.getShipmentTransport().isDeleted();
                    boolean d2 = o2.getShipmentTransport().isDeleted();
                    int c = Boolean.compare(d1, d2);

                    //Проверяем время бронирования
                    if (c == 0) {
                        int p1 = o1.getPlanTimeMin() == null ? 1 : 0;
                        int p2 = o2.getPlanTimeMin() == null ? 1 : 0;
                        if (p1 == 0 && p2 == 0) {
                            log(
                                    "Compare plan time: %s %s",
                                    app.getTimeFormat().format(o1.getPlanTimeMin()),
                                    app.getTimeFormat().format(o2.getPlanTimeMin())
                            );
                            c = Long.compare(o1.getPlanTimeMin().getTime(), o2.getPlanTimeMin().getTime());
                        } else {
                            c = Integer.compare(p1, p2);
                        }
                    }

                    //Проверяем № очереди если есть
                    if (c == 0) {
                        int turnId1 = o1.getShipmentTransport().getMinTurnId();
                        int turnId2 = o2.getShipmentTransport().getMinTurnId();
                        if (turnId1 == 0) turnId1 = Integer.MAX_VALUE;
                        if (turnId2 == 0) turnId2 = Integer.MAX_VALUE;
                        c = Integer.compare(turnId1, turnId2);
                    }

                    //Проверяем статус
                    if (c == 0) {
                        int s1 = o1.getShipmentTransport().getStatus();
                        int s2 = o2.getShipmentTransport().getStatus();
                        c = Utils.compareShipStatus(s1, s2);
                    }

                    if (c == 0) {
                        String doc1 = getShipMinDoc(o1.getShipmentTransport());
                        String doc2 = getShipMinDoc(o2.getShipmentTransport());
                        c = doc1.compareTo(doc2);
                    }
                    return c;
                });

            runOnUiThread(() -> endLoad(result, list));

        });
    }

    private String getShipMinDoc(ShipmentTransport transport) {
        List<ShipmentDocument> docs = db.shipmentDocumentDao().getByTransportId(transport.getId());
        return docs != null && !docs.isEmpty() ? docs.get(0).getDocNumber() : "";
    }

    private void endLoad(JsonResult result, List<AdapterItemTransport> list) {
        hideLoading();
        viewButtons.setVisibility(View.VISIBLE);
        this.adapterList = list;
        setAdapter(adapterList);
        viewContentData.setVisibility(result.isOk() && !list.isEmpty() ? View.VISIBLE : View.GONE);
        textNotFound.setVisibility(!result.isOk() || list.isEmpty() ? View.VISIBLE : View.GONE);

        log("endLoad %s cars", list == null ? 0 : list.size());

        if (result.isOk()) {
            buttonFilterClick();
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
        }

    }

    private void setAdapter(List<AdapterItemTransport> list) {
        adapter = new FlexibleAdapter<>(list);
        adapter.addListener(this);
        listView.setAdapter(adapter);
    }

    private void buttonFilterClick() {
        doFilter();
        listView.post(() -> listView.requestFocus());
    }

    private void doFilter() {
        String filterText = textFilter.getText().toString().toLowerCase();
        if (adapter == null) return;

        ShipmentDocument foundDocument = null;
        List<AdapterItemTransport> list = new ArrayList<>();

        for (AdapterItemTransport item : adapterList) {
            if (item.getShipmentTransport().getName().toLowerCase().contains(filterText)
                    || item.containsDocument(filterText.toLowerCase())) {
                list.add(item);
            }
            ShipmentDocument doc = item.getDocument(filterText.toLowerCase());
            if (doc != null) foundDocument = doc;
        }

        setAdapter(list);
        textNotFound.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
        checkTime();

        if (foundDocument != null) {
            buttonFilterClearClick();
            openDocument(foundDocument);
        }
    }

    private void checkTime() {

        runOnUiThread(() -> {

            if (adapter == null) return;

            long mc = BuildConfig.DEBUG ? 60 : 10;

            List<AdapterItemTransport> items = adapter.getCurrentItems();

            long id = -1;
            int indM = 0;

            for (int i = 0; i < items.size(); i++) {
                AdapterItemTransport item = items.get(i);

                if (item.getShipmentTransport().getStatus() == -1) {
                    long dateLong = item.getShipmentTransport().getPlanTime();
                    if (dateLong != 0) {

                        Date eventDate = new Date(dateLong);
                        Date currentDate = Calendar.getInstance().getTime();

                        long diffMillis = eventDate.getTime() - currentDate.getTime();
                        long diffMinutes = diffMillis / 1000 / 60;
                        if (diffMinutes > 0 && diffMinutes < mc) {
                            if (id == -1 || diffMinutes < indM) {
                                indM = (int) diffMinutes;
                                id = item.getShipmentTransport().getId();
                            }
                        }
                    }
                }
            }

            if (id != -1) {
                long finalId = id;
                int finalIndM = indM;
                runOnUiThread(() -> {
                    onAlarm(finalId, finalIndM);
                });
            }
        });
    }

    int findItem(long transportId) {

        if (adapter == null) return -1;
        for (int i = 0; i < adapter.getCurrentItems().size(); i++) {
            if (adapter.getCurrentItems().get(i).getShipmentTransport().getId() == transportId)
                return i;
        }

        return -1;
    }

    private void onAlarm(long transportId, int minutes) {
        log("[%d] %d minutes", transportId, minutes);

        if (adapter == null) return;

        int ind = findItem(transportId);
        if (ind != -1) {
            try {
                adapter.moveItem(ind, 0);
            } catch (Exception ignored) {

            }
        }

        List<AdapterItemTransport> items = adapter.getCurrentItems();
        for (int i = 0; i < items.size(); i++) {
            AdapterItemTransport item = items.get(i);
            if (item.getShipmentTransport().getId() == transportId) {
                item.setHighlighted(true);
                app.beepRepeat(500);
            } else {
                item.setHighlighted(false);
            }
            adapter.updateItem(item);
        }
    }

    @Override
    public void timerEvent() {
        super.timerEvent();
        checkTime();
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {
        if (barcodeData != null && !barcodeData.isEmpty()) beginFindDocument(barcodeData);
    }

    private void beginFindDocument(String docNum) {
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            for (AdapterItemTransport item : adapterList) {
                ShipmentDocument doc = item.getDocument(docNum);
                if (doc != null) {
                    runOnUiThread(() -> endFindDocument(doc));
                    return;
                }
            }

            runOnUiThread(() -> endFindDocument(null));

        });
    }

    private void endFindDocument(ShipmentDocument document) {

        hideLoading();

        if (document == null) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_not_found, null);
            return;
        }

        openDocument(document);
    }
}
