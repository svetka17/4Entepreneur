package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ShipmentItemDao {
    @Query("SELECT * FROM ShipmentItem ORDER BY sapOzm")
    List<ShipmentItem> getAll();

    @Query("SELECT * FROM ShipmentItem WHERE id = :id")
    ShipmentItem getById(long id);

    @Query("SELECT * FROM ShipmentItem WHERE lower(documentNumber) = lower(:documentNumber) and lineId = :lineId")
    ShipmentItem getByLineId(String documentNumber, int lineId);

    @Query("SELECT * FROM ShipmentItem WHERE lower(documentNumber) = lower(:documentNumber) ORDER BY lineId")
    List<ShipmentItem> getByDocument(String documentNumber);

    @Query("SELECT * FROM ShipmentItem WHERE documentNumber in (:documentNumbers) ORDER BY lineId")
    List<ShipmentItem> getByDocuments(List<String> documentNumbers);

    @Insert
    long insert(ShipmentItem shipmentItem);

    @Insert
    void insertAll(List<ShipmentItem> shipmentItem);

    @Update
    void update(ShipmentItem shipmentItem);

    @Delete
    void delete(ShipmentItem shipmentItem);

    @Query("DELETE FROM ShipmentItem WHERE lower(documentNumber) = lower(:documentNumber)")
    void deleteByDocument(String documentNumber);

    @Query("DELETE FROM ShipmentItem")
    void truncate();
}