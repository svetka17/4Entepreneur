package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface InvDao {

    @Query("SELECT * FROM inv ORDER BY id")
    List<Inv> getAll();

    @Query("SELECT count(1) FROM inv")
    long getCount();

    @Query("SELECT * FROM inv WHERE id = :id")
    Inv getById(long id);

    /*@Query("SELECT * FROM inv WHERE " +
            "    (lower(ozm) LIKE lower(:ozm)) " +
            "AND (:width = -1 OR :width = width) " +
            "AND (:length = -1 OR :length = length) " +
            "AND (:thickness = -1 OR :thickness = thickness) ")
    List<Inv> getByOzm(String ozm, float width, float length, float thickness);*/

    @Query("SELECT DISTINCT category FROM inv WHERE lower(storage) = lower(:storage) ORDER BY 1")
    List<String> getCategoryList(String storage);

    @Query("SELECT MAX(percent) FROM inv WHERE lower(storage) = lower(:storage) AND category = :category")
    int getPercentByCategory(String storage, String category);

    @Query("SELECT SUM(stock) FROM inv WHERE lower(storage) = lower(:storage) AND category = :category")
    int getPlanByCategory(String storage, String category);

    @Query("SELECT COUNT(1) FROM inv WHERE lower(storage) = lower(:storage) AND category = :category")
    int getCountByCategory(String storage, String category);

    @Query("SELECT COUNT(DISTINCT batch) FROM inv WHERE lower(storage) = lower(:storage) AND category = :category")
    int getBatchCountByCategory(String storage, String category);

    @Query("SELECT count(1) FROM inv WHERE lower(storage) = lower(:storage)" +
            " AND LOWER(category) = LOWER(:category)" +
            " AND ozm = :ozm" +
            " AND length = :length" +
            " AND width = :width" +
            " AND thickness = :thickness")
    long inCategory(String storage, String category, String ozm, float length, float width, float thickness);

    @Insert
    long insert(Inv inv);

    @Insert
    void insertAll(List<Inv> inv);

    @Update
    void update(Inv inv);

    @Delete
    void delete(Inv inv);

    @Query("DELETE FROM inv")
    void truncate();
}