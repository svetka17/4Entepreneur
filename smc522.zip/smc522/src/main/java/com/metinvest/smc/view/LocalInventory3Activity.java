package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Inventory;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemLocalInventory;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class LocalInventory3Activity extends MyActivity implements IScan, AdapterItemLocalInventory.IAdapterItemInventoryListener {

    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.textPrompt)
    TextView textNotFound;
    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;

    private Date date;
    private String locationCode;

    private FlexibleAdapter<AdapterItemLocalInventory> adapter;

    public static final int MANUAL_ADD_REQUEST = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local_inventory3);
        ButterKnife.bind(this);

        date = new Date(getIntent().getLongExtra("date", 0));
        locationCode = getIntent().getStringExtra("locationCode");
        textContentTitle.setText(Utils.format("Локація: %s", locationCode));
        log("Date: %s", app.getDateFormat().format(date));

        listView = findViewById(R.id.listView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
        listView.setLayoutManager(layoutManager);
        listView.addItemDecoration(dividerItemDecoration);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoadList();
    }

    private void beginLoadList() {
        beginLoadList(-1);
    }

    private void beginLoadList(long highlightId) {
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {
            List<Inventory> list = db.inventoryDao().getByLocation(date.getTime(), locationCode);

            List<AdapterItemLocalInventory> items = new ArrayList<>();
            for (int i = 0; i < list.size(); i++) {
                AdapterItemLocalInventory item = new AdapterItemLocalInventory(list.get(i), this, getColor(R.color.color_yellow), getColor(R.color.color_gray));
                if (highlightId != -1 && list.get(i).getId() == highlightId) {
                    item.setActive(true);
                }
                items.add(item);
            }
            runOnUiThread(() -> endLoadList(items));
        });
    }

    private void endLoadList(List<AdapterItemLocalInventory> items) {
        hideLoading();
        adapter = new FlexibleAdapter<>(items);
        listView.setAdapter(adapter);
        scrollView.post(() -> scrollView.scrollTo(0, 0));
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 4) {
            beginAddManual(0);
        }
    }

    private void beginAddManual(int labelId) {
        if (isLoading()) return;

        Intent intent = new Intent(this, InventoryManualActivity.class);
        if (labelId > 0) intent.putExtra("labelId", labelId);
        startActivityForResult(intent, MANUAL_ADD_REQUEST);
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {
        if (isLoading()) return;

        runOnUiThread(() -> {

            ScanItem scanItem = new ScanItem(barcodeData);

            if (scanItem.getType() == ScanItem.ScanItemType.LABELID) {
                if (scanItem.isCorrect()) {
                    beginAddManual(Utils.parseInt(scanItem.getData(0)));
                } else {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_label, null);
                }
            } else if (scanItem.getType() == ScanItem.ScanItemType.SMC02) {
                if (scanItem.isCorrect()) {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_old_format, null);
                } else {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_label, null);
                }
            } else if (scanItem.getType() == ScanItem.ScanItemType.SMC06/* || scanItem.getType() == ScanItem.ScanItemType.SMC02*/) {
                if (scanItem.isCorrect()) {
                    beginLoadLabel(scanItem, true);
                } else {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_label, null);
                }
            }

        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_DEFAULT && resultCode == RESULT_OK) {
            long id = -1;
            if (data != null) {
                id = data.getLongExtra("id", -1);
            }
            beginLoadList(id);
        } else if (requestCode == MANUAL_ADD_REQUEST && resultCode == RESULT_OK && data != null) {
            String scanData = data.getStringExtra("data");
            beginLoadLabel(new ScanItem(scanData), true);
        }
    }

    private void beginLoadLabel(ScanItem scanItem, boolean autoAdd) {
        beginLoadLabel(scanItem, 0, autoAdd);
    }

    private void beginLoadLabel(ScanItem scanItem, long localId, boolean autoAdd) {
        Intent intent = new Intent(this, LocalInventory4Activity.class);
        intent.putExtra("date", date.getTime());
        intent.putExtra("locationCode", locationCode);
        intent.putExtra("data", scanItem.getLine());
        intent.putExtra("autoAdd", autoAdd);
        if (localId > 0) {
            intent.putExtra("localId", localId);
        }
        startActivityForResult(intent, REQUEST_DEFAULT);
    }

    @Override
    public void onEditClick(int position) {
        AdapterItemLocalInventory item = adapter.getItem(position);
        if (item == null) return;

        beginLoadLabel(new ScanItem(item.getInventory().getQr()), item.getInventory().getId(), false);
    }

    @Override
    public void OnDeleteClick(int position) {

        AdapterItemLocalInventory item = adapter.getItem(position);
        if (item == null) return;

        showDialogConfirm(R.string.text_confirm, R.string.delete_position_confirm, (dialog, which) -> {
            try {
				db.inventoryDao().delete(item.getInventory());
				beginLoadList();
			} catch (Exception e) {
				log(e, "OnDeleteClick(%s)", position);
			}
        });
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        super.onBackPressed();
    }
}
