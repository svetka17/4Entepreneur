package com.metinvest.smc.tools;

import com.metinvest.smc.App;
import com.metinvest.smc.db.ShipmentDocument;
import com.metinvest.smc.db.ShipmentItem;
import com.metinvest.smc.db.ShipmentItemLoc;

import java.util.Calendar;
import java.util.Collections;
import java.util.List;

public class LabelGeneratorCardSaveZpl {
    private final List<ShipmentDocument> documentList;
    private final App app;
    private StringBuilder printedData;
    private int printedY;
    private int printedPage;
    private int printedPageCount;
    private final int maxY = 1000;
    private final int lineHeight = 30;
    private String transportName;

    public LabelGeneratorCardSaveZpl(List<ShipmentDocument> documentList) {
        this.documentList = documentList;
        this.app = App.getInstance();
        this.transportName = documentList.get(0).getTransportName();
    }

    public String generateZpl() {

        long t1 = Calendar.getInstance().getTime().getTime();

        printedData = new StringBuilder();
        printedY = 0;
        printedPage = 0;
        printedPageCount = 0;

        addNewPage(true);

        processItems();

        printedData.append("\n^XZ\n");
        Utils.replaceAll(printedData, "{{PAGE_COUNT}}", String.valueOf(printedPageCount));

        long t2 = Calendar.getInstance().getTime().getTime();

        app.log(this, "TIME FOR GENERATE CARD SAVE ZPL: %d ms", t2 - t1);

        return printedData.toString();
    }

    private void processItems() {

        for (int i = 0; i < documentList.size(); i++ ) {
            ShipmentDocument document = documentList.get(i);
            addY(lineHeight);
            printLine(20, Utils.format("Наряд на відгрузку №: %s", document.getDocNumber()));
            addY(lineHeight);
            addY(lineHeight);
            for (int j = 0; j < document.schipmentItems.size(); j++){
                ShipmentItem item = document.schipmentItems.get(j);
                printLine(20, Utils.format("%s", item.getName()));
                addY(lineHeight);

                String ozm = "";//item.getSapOzm();
                String size = app.sizeToString(item.getLength(), item.getWidth(), item.getThickness());
                String plan = Utils.format(" План: %.3f тн", item.getSapWeightNett() / 1000.0f);

                printLine(20, Utils.format("%s%s%s", size, ozm.length()>0 ? " ОЗМ: " + ozm : "", plan));
                addY(lineHeight);

                Locations(item.shipmentItemLoc);
            }
        }
    }

    private void Locations(List<ShipmentItemLoc> shipmentItemLoc) {
        if(shipmentItemLoc == null || shipmentItemLoc.size() == 0){
            printLine(40, "Відсутній на складі");
            addY(lineHeight);
        }else{
            Collections.sort(shipmentItemLoc, (o1, o2) -> Utils.compareLocations(o1.getLocation(), o2.getLocation()));
            for (int i = 0; i < shipmentItemLoc.size(); i++ ) {
                ShipmentItemLoc loc2 = null;
                ShipmentItemLoc loc1 = shipmentItemLoc.get(i);
                if(i + 1 < shipmentItemLoc.size())
                    loc2 = shipmentItemLoc.get(++i);
                String locText1 = Utils.format("%s %.3f тн", loc1.getLocation(), loc1.getSumWeight() / 1000.0f);
                String locText2 = loc2 != null ? Utils.format("\t\t%s %.3f тн", loc2.getLocation(), loc2.getSumWeight() / 1000.0f) : "";
                printLine(40, Utils.format("%s%s",locText1, locText2));
                addY(lineHeight);
            }
        }
    }

    private void addNewPage(boolean printHeader) {
        printedPage++;
        printedPageCount++;

        if (printedPage > 1) printedData.append("\n^XZ\n");

        printedData.append("\n\n^XA\n\n^CI28\n^A0N,50,50,E:TT0003M_.FNT\n^LH25,30\n^POI\n^PQ1,0,0,N\n\n~JS50\n^MD20\n^PR1,1,1\n^MNM,40\n^LL1050\n^PW900\n");
        if (app.getConfig().getPrinterPaperType() == 1) { //Етикетка
            printedData.append("\n\n^XA\n\n^CI28\n^A0N,50,50,E:TT0003M_.FNT\n^POI\n^MD20\n^PR2,2,2\n^PQ1,0,0,N\n\n^LH25,30\n^LL1050\n^PW900\n");
        } else if (app.getConfig().getPrinterPaperType() == 2) { //Бірка
            printedData.append("\n\n^XA\n\n^CI28\n^A0N,50,50,E:TT0003M_.FNT\n^POI\n^MD20\n^PR2,2,2\n^PQ1,0,0,N\n\n^LH25,0\n^LL1199\n^PW800\n");
        }
        printedY = 0;

        addHeader(printHeader);
    }

    private void addHeader(boolean withTitle) {

        addY(lineHeight);

        printLine(20, Utils.format("Транспорт: %s", transportName));
        printLine(630, Utils.format("Лист %d з {{PAGE_COUNT}}", printedPage));

        addY(lineHeight);
    }
    private void addY(int value) {
        printedY += value;

        if (value > 0 && printedY > maxY) {
            addNewPage(true);
        }
    }
    private void printLine(int x, String text) {
        printedData.append(Utils.format("^FO%d,%d^A0N,27,25^FD%s^FS\n", x, printedY, text));
    }
    public String generateTitle() {
        return Utils.format("<b>Карта зберігання</b><br>Номер машини: %s", transportName);
    }
}
