package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Roll;
import com.metinvest.smc.db.RollName;
import com.metinvest.smc.inc.Weight;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemPack;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.BindViews;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class RollWeighingActivity extends MyActivity implements IScan, AdapterItemPack.Listener {

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.viewContentData)
    View viewContentData;
    @BindView(R.id.buttonToggle)
    Button buttonToggle;
    @BindView(R.id.textWeight)
    EditText textWeight;
    @BindView(R.id.textCount)
    EditText textCount;
    @BindViews({R.id.textLocation1, R.id.textLocation2, R.id.textLocation3})
    EditText[] textLocation;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;
    @BindView(R.id.buttonCrane)
    ImageButton buttonCrane;

    private static final int packLimit = 25;
    private boolean theor = false;
    private FlexibleAdapter<AdapterItemPack> adapter;
    private RollName rollName;
    private String filterMarkdown, filterMera, filterTravl;
    private String storage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roll_weighing);
        ButterKnife.bind(this);

        long rollNameId = getIntent().getLongExtra("rollNameId", 0);
        rollName = db.rollNameDao().getById(rollNameId);
        if (rollName == null) {
            finish();
            return;
        }

        storage = getIntent().getStringExtra("storage");
        filterMarkdown = getIntent().getStringExtra("markdown");
        filterMera = getIntent().getStringExtra("mera");
        filterTravl = getIntent().getStringExtra("travl");

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
        listView.setLayoutManager(layoutManager);
        listView.addItemDecoration(dividerItemDecoration);

        buttonToggle.setOnClickListener(v -> setTheor(!isTheor()));
        textCount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                loadPackGrid();
                checkTextCount();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        TextWatcher checkWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                checkButtonAccept();
                updateNetto();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        };
        textWeight.addTextChangedListener(checkWatcher);
        textLocation[0].addTextChangedListener(checkWatcher);

        viewContentData.setVisibility(View.VISIBLE);
        buttonAccept.setEnabled(true);

        textContentTitle.setText(rollName.getName());

        if (!config.getRollLocation().isEmpty() && app.isLocationCorrect(config.getRollLocation())) {
            setLocationCode(config.getRollLocation());
        }

        buttonCrane.setOnClickListener(v -> loadCraneWeight());
        buttonCrane.setOnLongClickListener(v -> {
            loadCraneTara();
            return true;
        });

        textCount.setText("1");

        textCount.setEnabled(isTheor());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            clearData();
        }
    }

    private void clearData() {
        textWeight.setText("");
        for( EditText et : textLocation )
            et.setText("");
        textCount.setText("");
        textCount.setText("1");
    }

    private void updateNetto() {
        if (adapter != null) {
            AdapterItemPack item = adapter.getItem(0);
            if(item != null){
                int netto = getWeightCraneBrutto() - item.getW3() - item.getW2();
                item.setW0(Math.max(netto, 0));
                adapter.updateItem(item);
            }
        }
    }

    private AdapterItemPack getItemByIndex(int index) {
        if (adapter != null) {
            List<AdapterItemPack> items = adapter.getCurrentItems();
            for (AdapterItemPack item : items) {
                if (item.getIndex() == index) return item;
            }
        }
        return null;
    }

    @Override
    public void onItemDeleteClicked(int index) {

        AdapterItemPack item = getItemByIndex(index);

        if (item != null) {
            showDialogConfirm(R.string.text_confirm, R.string.delete_position_confirm, (dialog, which) -> {
                item.setW1(0);
                item.setW2(0);
                item.setW3(0);
                item.setLabelId("");
                item.setIdQr("");
                adapter.updateItem(item);
            });
        }
    }

    @Override
    public void onItemCalcClicked(int index) {

    }

    private boolean isPackCountCorrect() {
        int packCountOrig = getPackCount();
        return packCountOrig > 0 && packCountOrig <= (isTheor() ? 250 : packLimit);
    }

    private boolean isWeightCorrect() {
        int weight = getWeightCraneBrutto();
        return isTheor() || weight > 0;
    }

    private boolean isLocationCorrect() {
        return Utils.parseInt(textLocation[0].getText().toString()) > 0;
    }

    private boolean isWeightListCorrect() {
        List<Weight> weightList = getWeightList();
        if (weightList.isEmpty()) return false;
        for (Weight weight : weightList) {
            if (weight.getNetto() == 0) return false;
        }
        return true;
    }

    private void checkTextCount() {
        if (isPackCountCorrect()) {
            textCount.setBackgroundTintList(null);
        } else {
            textCount.setBackgroundTintList(ContextCompat.getColorStateList(this, R.color.tint_incorrect));
        }

        checkButtonAccept();
    }

    private void checkButtonAccept() {
        boolean correct = false;

        if (isPackCountCorrect() && isWeightCorrect() && isLocationCorrect() && isWeightListCorrect()) {
            correct = true;
        }

        buttonAccept.setEnabled(correct);
    }

    public boolean isTheor() {
        return theor;
    }

    public void setTheor(boolean theor) {
        setTheor(theor, true);
        checkTextCount();
    }

    public void setTheor(boolean theor, boolean loadPackGrid) {
        this.theor = theor;
        textWeight.setEnabled(!isTheor());
        textCount.setEnabled(isTheor());
        buttonToggle.setBackgroundTintList(ContextCompat.getColorStateList(this, isTheor() ? R.color.toggle_on : R.color.toggle_off));
        if (loadPackGrid) {
            loadPackGrid();
            checkButtonAccept();
        }
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        loadPackGrid();
        checkButtonAccept();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        super.onBackPressed();
    }

    private int getPackCount() {
        return Utils.parseInt(textCount.getText().toString());
    }

    private void setPackCount(int value) {
        textCount.setText(String.valueOf(value));
    }

    private int getWeightCraneBrutto() {
        return Utils.parseInt(textWeight.getText().toString());
    }

    private void setWeightCraneBrutto(int value) {
        textWeight.setText(String.valueOf(value));
    }

    private String getLocationCode() {
        return isLocationCorrect() ? app.fixLocation(Utils.format("%s-%s-%s",
                textLocation[0].getText().toString(),
                textLocation[1].getText().toString(),
                textLocation[2].getText().toString()
        )) : "";
    }

    private void setWeightList(List<Weight> list) {
        if (adapter != null && adapter.getItemCount() == list.size()) {
            for (int i = 0; i < list.size(); i++) {
                AdapterItemPack itemPack = adapter.getItem(i);
                if (itemPack != null) {
                    itemPack.setTitle(Utils.format("<b>Пачка №:%d</b>", i + 1));
                    itemPack.setW1(list.get(i).getNetto());
                    itemPack.setW2(list.get(i).getPack());
                    itemPack.setW3(list.get(i).getTara());
                    adapter.updateItem(itemPack);
                }
            }
        }
    }

    private List<Weight> getWeightList() {

        List<Weight> list = new ArrayList<>();

        if (adapter != null && adapter.getItemCount() > 0) {

            int packCount = getPackCount();

            if (isTheor()) {
                AdapterItemPack item = adapter.getItem(0);
                if (item != null) {
                    for (int i = 0; i < packCount; i++)
                        list.add(new Weight(item.getW1(), item.getW2(), item.getW3()));
                }
            } else {
                for (int i = 0; i < packCount; i++) {
                    AdapterItemPack item = adapter.getItem(i);
                    if (item != null) {
                        list.add(new Weight(item.getW1(), item.getW2(), item.getW3()));
                    }
                }
            }
        }

        return list;
    }

    private void loadPackGrid() {
        listView.setVisibility(View.VISIBLE);

        int packCount = isPackCountCorrect() ? getPackCount() : 0;

        if (packCount == 0) {
            adapter = null;
            listView.setAdapter(null);
        } else {

            int packCountLoad = isTheor() ? 1 : packCount;

            Utils.runOnBackground(() -> {
                List<AdapterItemPack> items = new ArrayList<>(packCount);

                for (int i = 0; i < packCountLoad; i++) {
                    String packNumTheor = packCount > 1 ? "1-" + packCount : "1";
                    String title = isTheor() ? Utils.format("<b>Дані нової бірки №:%s", packNumTheor) : Utils.format("<b>Дані нової бірки №:%d</b>", i + 1);
                    items.add(new AdapterItemPack(i, title, 0, 0, 0, this, true));
                }

                adapter = new FlexibleAdapter<>(items);
                updateNetto();

                if (weightListTemp != null) {
                    setWeightList(weightListTemp);
                    weightListTemp = null;
                }

                runOnUiThread(() -> {
                    listView.setAdapter(adapter);
                    checkButtonAccept();
                });
            });
        }
    }

    private int getTotalBrutto(List<Weight> list) {
        int total = 0;
        for (Weight weight : list) total += weight.getPack() + weight.getTara();
        return total;
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        if (!checkLocationPermit(getLocationCode())) return;

        List<Weight> weightList = getWeightList();

        if (isTheor()) {
            int baseTheorWeight = weightList.get(0).getNetto();
            List<Roll> rollList = db.rollDao().getByNameAndWeight(rollName.getId(), baseTheorWeight, filterMarkdown, filterMera, filterTravl);
            if (rollList.isEmpty()) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.theor_not_fount, null);
            } else {
                int finalPackCount = Math.min(rollList.size(), getPackCount());

                List<Weight> finalWeightList = new ArrayList<>(finalPackCount);
                for (int i = 0; i < finalPackCount; i++) {
                    finalWeightList.add(weightList.get(i));
                }

                int weightCraneBrutto = weightList.get(0).getBrutto() * finalPackCount;
                int weightCraneNetto = weightCraneBrutto - getTotalBrutto(finalWeightList);

                List<Long> currentRollListChecked = new ArrayList<>(finalPackCount);
                for (int i = 0; i < finalPackCount; i++) {
                    currentRollListChecked.add(rollList.get(i).getId());
                }

                Intent intent = new Intent(this, RollResultActivity.class);
                intent.putExtra("markdown", filterMarkdown);
                intent.putExtra("mera", filterMera);
                intent.putExtra("travl", filterTravl);
                intent.putExtra("rollNameId", rollName.getId());
                intent.putExtra("isTheor", isTheor());
                intent.putExtra("weightCraneBrutto", weightCraneBrutto);
                intent.putExtra("weightCraneNetto", weightCraneNetto);
                intent.putExtra("packCount", finalPackCount);
                intent.putExtra("basePackCount", getPackCount());
                intent.putExtra("locationCode", getLocationCode());
                intent.putParcelableArrayListExtra("weightList", new ArrayList<>(finalWeightList));
                intent.putExtra("rollListChecked", (Serializable) currentRollListChecked);
                intent.putExtra("storage", storage);
                startActivityForResult(intent, REQUEST_ACTION);
            }
        } else {
            int weightCraneBrutto = getWeightCraneBrutto();
            //int weightCraneNetto = weightCraneBrutto - getTotalBrutto(weightList);
            //CodeQL requirement
            int weightCraneNetto = 0;
            int v = getTotalBrutto(weightList);
            if (v < Integer.MAX_VALUE)
                weightCraneNetto = weightCraneBrutto - v;

            List<Roll> rollList = new ArrayList<>(getPackCount());// db.rollDao().getByNameAndWeight(rollName.getId(), -1);
            //Roll roll = rollList.isEmpty() ? null : rollList.get(0);

            for (int i = 0; i < getPackCount(); i++) {
                String batch = db.rollDao().getBatchByDate(rollName.getId(), filterMarkdown, filterMera, filterTravl);
                if(batch == null)
                    batch = db.rollDao().getBatchByDateLast(rollName.getId(), filterMarkdown, filterMera, filterTravl);
                if (batch != null) {
                    Roll roll = db.rollDao().getByNameAndBatchLastDt(rollName.getId(), batch);
                    if (roll != null) rollList.add(roll);
                }
            }

            if (rollList.isEmpty() || rollList.size() != getPackCount()) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_not_found, null);
            } else {

                List<Long> currentRollListChecked = new ArrayList<>();
                for (int i = 0; i < getPackCount(); i++)
                    currentRollListChecked.add(rollList.get(i).getId());

                Intent intent = new Intent(this, RollResultActivity.class);
                intent.putExtra("markdown", filterMarkdown);
                intent.putExtra("mera", filterMera);
                intent.putExtra("travl", filterTravl);
                intent.putExtra("rollNameId", rollName.getId());
                intent.putExtra("isTheor", false);
                intent.putExtra("weightCraneBrutto", weightCraneBrutto);
                intent.putExtra("weightCraneNetto", weightCraneNetto);
                intent.putExtra("packCount", getPackCount());
                intent.putExtra("locationCode", getLocationCode());
                intent.putParcelableArrayListExtra("weightList", new ArrayList<>(weightList));
                intent.putExtra("rollListChecked", (Serializable) currentRollListChecked);
                intent.putExtra("storage", storage);
                startActivityForResult(intent, REQUEST_ACTION);

            }

            /*Intent intent = new Intent(this, RollBatchActivity.class);
            intent.putExtra("rollNameId", rollName.getId());
            intent.putExtra("isTheor", isTheor());
            intent.putExtra("weightCraneBrutto", weightCraneBrutto);
            intent.putExtra("weightCraneNetto", weightCraneNetto);
            intent.putExtra("packCount", getPackCount());
            intent.putExtra("locationCode", getLocationCode());
            intent.putParcelableArrayListExtra("weightList", new ArrayList<>(weightList));
            startActivityForResult(intent, REQUEST_DEFAULT);*/
        }
    }

    @Override
    public void onItemPackTextChanged(int index) {
        checkButtonAccept();
    }

    @Override
    public void onItemNettoTextChanged(int index) {
        checkButtonAccept();
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {

        if (isLoading()) return;

        runOnUiThread(() -> {

            ScanItem scanItem = new ScanItem(barcodeData);
            if (!scanItem.isCorrect()) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_label, null);
                return;
            }

            if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONID) {
                String locationId = scanItem.getData(0);
                beginLoadLocation(locationId);
            }

            if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONCODE) {
                String locationCode = scanItem.getData(0);
                setLocationCode(locationCode);
            }

            if (scanItem.getType() == ScanItem.ScanItemType.SMC05 || scanItem.getType() == ScanItem.ScanItemType.SMC07) {
                processUnknown(scanItem, scanItem.getType() == ScanItem.ScanItemType.SMC07);
            }

        });
    }

    private void processUnknown(ScanItem scanItem, boolean isNew) {

        String locationCode = scanItem.getData(5);
        int weightCraneBrutto = Utils.parseInt(scanItem.getData(0));
        int packCount = Utils.parseInt(scanItem.getData(1));

        JSONArray array = Utils.getJsonArray(scanItem.getData(2));
        if (array == null) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_error_scan_item, null);
        } else {

            weightListTemp = new ArrayList<>();
            for (int i = 0; i < getPackCount(); i++) {
                JSONObject object = Utils.getJsonObject(array, i);
                weightListTemp.add(new Weight(
                        Utils.getJsonIntIgnoreCase(object, "netto"),
                        Utils.getJsonIntIgnoreCase(object, "pack"),
                        Utils.getJsonIntIgnoreCase(object, "tara")
                ));

                if (!isNew && i == 0) {
                    weightCraneBrutto += weightListTemp.get(0).getPack() + weightListTemp.get(0).getTara();
                }
            }

            setTheor(false, false);
            setPackCount(packCount);
            setWeightCraneBrutto(weightCraneBrutto);
            if (locationCode != null && app.isLocationCorrect(locationCode))
                setLocationCode(locationCode);
        }
    }

    private List<Weight> weightListTemp;

    private void beginLoadLocation(String locationId) {
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {
            String locationCode = net.getLocationCode(locationId);

            runOnUiThread(() -> {
                if (locationCode == null) {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_location_label, null);
                } else {
                    setLocationCode(locationCode);
                }
            });

        });
    }

    private void setLocationCode(String locationCode) {
        if (app.isLocationCorrect(locationCode)) {
            String[] arr = app.fixLocation(locationCode).split("-");
            for (int i = 0; i < 3; i++) textLocation[i].setText(arr[i]);
            config.setRollLocation(locationCode);
        } else {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_error_location_incorrect, null);
            config.setRollLocation("");
        }

        config.saveConfig();
    }

    @Override
    protected void onCraneWeight(long craneId, int value) {
        setWeightCraneBrutto(value);
        checkButtonAccept();
    }

}
