package com.metinvest.smc.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.metinvest.smc.tools.IValue;
import com.metinvest.smc.tools.Utils;

import java.util.Date;

@Entity
public class ShipmentTransport implements IValue {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private String name;
    private int documentCount;
    private int status;
    private long firstDate, lastDate, planTime;
    private int minTurnId;
    private int orderCount;
    private boolean deleted;
    private String driverPhoneNumber;
    private String driverName;
    private String eoStatus;
    private String currentLocation;

    public ShipmentTransport() {
    }

    @Ignore
    public ShipmentTransport(long id, String name, int documentCount, int status) {
        this.id = id;
        this.name = name;
        this.documentCount = documentCount;
        this.status = status;
        this.firstDate = 0;
        this.lastDate = 0;
        this.orderCount = 0;
        this.deleted = false;
    }

    @Ignore
    public ShipmentTransport(long id, String name, String driverPhoneNumber, String driverName, String eoStatus, int eoStatusCode, int positionInQueue, String currentLocation, int minTurnId, Date firstDate) {
        this.id = id;
        this.name = name;
        this.driverPhoneNumber = driverPhoneNumber;
        this.driverName = driverName;
        this.eoStatus = eoStatus;
        this.status = eoStatusCode;
        this.orderCount = positionInQueue;
        this.currentLocation = currentLocation;
        this.minTurnId = minTurnId;
        this.firstDate = firstDate == null ? 0 : firstDate.getTime();
        this.deleted = false;
    }

    public String getDriverPhoneNumber() {
        return driverPhoneNumber;
    }

    public void setDriverPhoneNumber(String driverPhoneNumber) {
        this.driverPhoneNumber = driverPhoneNumber;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getEoStatus() {
        return eoStatus;
    }

    public void setEoStatus(String eoStatus) {
        this.eoStatus = eoStatus;
    }

    public String getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(String currentLocation) {
        this.currentLocation = currentLocation;
    }

    public int getMinTurnId() {
        return minTurnId;
    }

    public void setMinTurnId(int minTurnId) {
        this.minTurnId = minTurnId;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public int getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(int orderCount) {
        this.orderCount = orderCount;
    }

    public long getFirstDate() {
        return firstDate;
    }

    public void setFirstDate(long firstDate) {
        this.firstDate = firstDate;
    }

    public void setPlanTime(long planTime) {
        this.planTime = planTime;
    }

    public long getPlanTime() {
        return planTime;
    }

    public long getLastDate() {
        return lastDate;
    }

    public void setLastDate(long lastDate) {
        this.lastDate = lastDate;
    }

    @Override
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDocumentCount() {
        return documentCount;
    }

    public void setDocumentCount(int documentCount) {
        this.documentCount = documentCount;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @NonNull
    @Override
    public String toString() {
        return Utils.format("[%s] %s", getId(), getName());
    }
}
