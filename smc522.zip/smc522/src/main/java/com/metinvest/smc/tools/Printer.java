package com.metinvest.smc.tools;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.net.Uri;
import android.nfc.NdefRecord;

import androidx.annotation.NonNull;

import com.metinvest.smc.App;
import com.metinvest.smc.db.Db;
import com.metinvest.smc.db.Dpl;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Calendar;
import java.util.UUID;

public class Printer {

	private static final String className = "Printer";

	public static PrintResult sendCommand(String name, PrinterConfig printer, @NonNull String data) {
		return sendCommand(name, printer, data, true);
	}

	public static PrintResult sendCommand(String name, PrinterConfig printer, @NonNull String data, boolean checkStatus) {
		return sendCommand(name, printer, data, checkStatus, false);
	}

	public static PrintResult sendCommand(String name, PrinterConfig printer, @NonNull String data, boolean checkStatus, boolean ignoreNoPaperType) {
		if (name != null) addHistory(name, data);

		for (int i = 0; i < data.length(); i += 4000) {
			String line = data.substring(i, Math.min(i + 4000, data.length()));
			App.getInstance().log(className, "\n" + line);
		}

		return sendCommand(printer, data.getBytes(StandardCharsets.UTF_8), checkStatus, ignoreNoPaperType);
	}

	public static void addHistory(String name, String data) {
		Db db = App.getInstance().getDb();
		if (db != null && data != null) {

			Dpl last = db.dplDao().getLast();
			if (last != null && last.getData() != null && last.getData().equals(data)) return;

			try {
				long date = Calendar.getInstance().getTime().getTime();
				Dpl dpl = new Dpl(0, date, name, data);
				db.dplDao().insert(dpl);
				App.getInstance().log(className, "addHistory(%s)", name);
			} catch (Exception e) {
				App.getInstance().log(className, e, "db.dplDao().insert()");
			} finally {
				try {
					db.dplDao().deleteOld();
				} catch (Exception e) {
					App.getInstance().log(className, e, "db.dplDao().deleteOld()");
				}
			}
        }
    }

	public static PrintResult sendCommand(PrinterConfig printer, @NonNull byte[] data, boolean checkStatus, boolean ignoreNoPaperType) {

		//Utils.sleep(1000);

		if (!App.getInstance().isPrinterZebra() && checkStatus) {
			PrintResult result = sendCommand(null, printer, (char) 1 + "A", false);

			App.getInstance().log(className, "Printer status: %s", result.getData().length() > 0 ? result.getData() : "null");

			if (result.getStatus() != PrintResultStatus.OK) {
                return result;
            }
        }

		if (printer == null || printer.getMac().length() == 0) {
			return new PrintResult(PrintResultStatus.ERROR_NO_PRINTER);
		}

		if (!ignoreNoPaperType && (App.getInstance().getConfig().getPrinterPaperType() == 0)) {
			return new PrintResult(PrintResultStatus.ERROR_NO_PAPER_TYPE);
		}

        if (!App.getInstance().bluetoothOn()) {
            return new PrintResult(PrintResultStatus.ERROR_BLUETOOTH_OFF);
        }

        if (data.length == 0) {
            return new PrintResult(PrintResultStatus.ERROR_DATA_EMPTY);
        }

        if (App.getInstance().getBluetoothAdapter() == null) {
            return new PrintResult(PrintResultStatus.ERROR_BLUETOOTH_ADAPTER_NULL);
        }

        BluetoothDevice device;

		try {
			device = App.getInstance().getBluetoothAdapter().getRemoteDevice(printer.getMac());
		} catch (Exception e) {
			App.getInstance().log(className, e, "getRemoteDevice(%s)", printer.getMac());
			return new PrintResult(PrintResultStatus.ERROR_BLUETOOTH_MAC_INVALID);
		}

        UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
        final BluetoothSocket socket;

		try {
			//socket = device.createRfcommSocketToServiceRecord(uuid);
			socket = device.createInsecureRfcommSocketToServiceRecord(uuid);
		} catch (Exception e) {
			App.getInstance().log(className, e, "createInsecureRfcommSocketToServiceRecord(%s)", uuid);
			return new PrintResult(PrintResultStatus.ERROR_BLUETOOTH_CONNECTION_ERROR);
		}

        if (!socket.isConnected()) {

			try {
				socket.connect();
			} catch (Exception ignored) {
				Utils.sleep(1000);
				try {
					socket.connect();
				} catch (Exception e) {
					App.getInstance().log(className, e, "socket.connect()");
					return new PrintResult(PrintResultStatus.ERROR_SOCKET_CONNECT);
				}
			}

            long t = System.currentTimeMillis();

            while (!socket.isConnected() && System.currentTimeMillis() - t < 3000) {
                Utils.sleep(10);
            }

            if (!socket.isConnected())
                return new PrintResult(PrintResultStatus.ERROR_SOCKET_CONNECT);

        }

        OutputStream out;

		try {
			out = socket.getOutputStream();
		} catch (Exception e) {
			App.getInstance().log(className, e, "socket.getOutputStream()");
			return new PrintResult(PrintResultStatus.ERROR_SOCKET_STREAM);
		}

        InputStream in = null;

        try {
            in = socket.getInputStream();
        } catch (Exception ignored) {

        }

        String resultMessage = "";

        try {
            out.write(data);

            if (in != null) {

                Utils.sleep(5000);

                if (!App.getInstance().isPrinterZebra()) {
					try {
						int n = in.available();

						if (n > 0) {
							byte[] buffer = new byte[n];
							int bytes = in.read(buffer);
							resultMessage = new String(buffer, 0, bytes);
						}
					} catch (Exception ignored) {

					}
				}
			}
		} catch (Exception e) {
			App.getInstance().log(className, e, "socket.write()");
			return new PrintResult(PrintResultStatus.ERROR_SOCKET_WRITE);
		} finally {
			try {
				socket.close();
			} catch (Exception ignored) {

			}
		}

        if (resultMessage.length() > 0) {
            //App.getInstance().log(App.getInstance(), resultMessage);
        }

        return new PrintResult(PrintResultStatus.OK, resultMessage);
    }

    public enum PrintResultStatus {
		ERROR_NO_PRINTER,
        ERROR_NO_PAPER_TYPE,
        ERROR_BLUETOOTH_OFF,
        ERROR_BLUETOOTH_ADAPTER_NULL,
        ERROR_BLUETOOTH_MAC_INVALID,
        ERROR_BLUETOOTH_CONNECTION_ERROR,
        ERROR_SOCKET_CONNECT,
        ERROR_SOCKET_STREAM,
        ERROR_SOCKET_WRITE,
        ERROR_DATA_EMPTY,
        OK,
        ERROR_INTERPRETER_BUSY,
        ERROR_PAPER_OUT_OR_FAULT,
        ERROR_RIBBON_OUT_OR_FAULT,
        ERROR_PRINTING_BATCH,
        ERROR_BUSY_PRINTING,
        ERROR_PRINTER_PAUSED,
        ERROR_LABEL_PRESENTED
    }

    public static class PrintResult {
		private final PrintResultStatus status;
		private final String data;

		public PrintResult(PrintResultStatus status, String data) {
			this.status = status;
			this.data = data;
		}

		public PrintResult(PrintResultStatus status) {
			this.status = status;
			this.data = "";
		}

        public PrintResultStatus getStatus() {
            return status;
        }

        public String getData() {
            return data;
        }

        @NonNull
        @Override
        public String toString() {
            return Utils.format("[%s] %s", getStatus(), getData());
        }
    }

    public static PrinterConfig detectPrinter(NFC nfc) {

        String printerMac = null, printerModel = null;

        for (NdefRecord record : nfc.getRecords()) {

			Uri uri = record.toUri();
			if (uri != null && uri.getHost() != null && uri.getHost().toLowerCase().contains("zebra.com")) {
				printerMac = uri.getQueryParameter("mBL");
				if (printerMac == null) {
					printerMac = uri.getQueryParameter("mB");
				}
				printerModel = uri.getQueryParameter("c");
				if (printerMac != null && printerModel != null) {
					return new PrinterConfig(PrinterType.ZEBRA, printerModel, printerMac.toUpperCase());
				} else {
					return null;
				}
			}

			String type = record.toMimeType() == null ? "" : record.toMimeType();

			if (type.equals("application/vnd.bluetooth.ep.oob")) {
				byte[] payload = record.getPayload();
				if (payload != null && payload.length >= 6) {
					payload = Utils.reverse(new byte[]{payload[2], payload[3], payload[4], payload[5], payload[6], payload[7]});
					printerMac = Utils.formatMacAddress(payload);
				}
			}

            if (type.equals("text/plain")) {
                try {
                    byte[] payload = record.getPayload();
                    if (payload != null && payload.length > 1) {
                        String textEncoding = ((payload[0] & 0200) == 0) ? "UTF-8" : "UTF-16";
                        int languageCodeLength = payload[0] & 0077;
                        String languageCode = new String(payload, 1, languageCodeLength, StandardCharsets.US_ASCII);

                        payload = Arrays.copyOfRange(payload, languageCodeLength + 1, payload.length - languageCodeLength - 1);

                        String text =
                                new String(payload, languageCodeLength + 1,
                                        payload.length - languageCodeLength - 1, textEncoding).trim();

                        if (text.length() > 0) {

                            if (text.charAt(0) == 'w') {

                                String[] s = text.split(String.valueOf((char) 65533));
                                int i = s[0].trim().lastIndexOf('\u0000');

                                printerModel = s[0].trim().substring(i + 1);
                            }

                        }
                    }
                } catch (Exception ignored) {

                }
            }

        }

        if (printerMac != null && printerMac.length() > 0 && (printerModel == null || printerModel.length() == 0)) {
            printerModel = "RP4";
        }

		if (printerModel != null && printerMac != null && printerModel.length() > 0 && printerMac.length() > 0)
			return new PrinterConfig(PrinterType.HONEYWELL, printerModel, printerMac);
		else
			return null;
    }
}
