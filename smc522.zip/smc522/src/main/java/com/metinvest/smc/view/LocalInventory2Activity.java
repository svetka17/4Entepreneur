package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemLocation;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class LocalInventory2Activity extends MyActivity implements IScan, AdapterItemLocation.IAdapterItemLocationListener {

    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.textPrompt)
    TextView textNotFound;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;

    private Date date;
    private FlexibleAdapter<AdapterItemLocation> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local_inventory2);
        ButterKnife.bind(this);

        date = new Date(getIntent().getLongExtra("date", 0));
        log("Date: %s", app.getDateFormat().format(date));

        listView = findViewById(R.id.listView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
        listView.setLayoutManager(layoutManager);
        listView.addItemDecoration(dividerItemDecoration);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoadList();
    }

    private void beginLoadList() {
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {
            List<String> list = db.inventoryDao().getLocationList(date.getTime());

            List<AdapterItemLocation> items = new ArrayList<>();
            for (int i = 0; i < list.size(); i++) {

                int itemCount = db.inventoryDao().getByLocation(date.getTime(), list.get(i)).size();

                items.add(new AdapterItemLocation(list.get(i), itemCount, this));
            }
            runOnUiThread(() -> endLoadList(items));
        });
    }

    private void endLoadList(List<AdapterItemLocation> items) {
        hideLoading();
        adapter = new FlexibleAdapter<>(items);
        listView.setAdapter(adapter);
        scrollView.post(() -> scrollView.scrollTo(0, 0));
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {
        if (isLoading()) return;

        runOnUiThread(() -> {

            ScanItem scanItem = new ScanItem(barcodeData);

            if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONID) {
                if (scanItem.isCorrect()) {
                    beginLoadLocation(scanItem.getData(0));
                } else {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_location_label, null);
                    return;
                }
            }

            if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONCODE) {
                if (scanItem.isCorrect()) {
                    openLocation(scanItem.getData(0));
                } else {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_location_label, null);
                    return;
                }
            }

        });
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) {
            buttonLocationSelectClick();
        }
    }

    private void buttonLocationSelectClick() {
        if (isLoading()) return;

        Intent intent = new Intent(this, LocationSelectActivity.class);
        startActivityForResult(intent, REQUEST_LOCATION_SELECT);
    }

    @Override
    protected String getHelpContent() {
        return "Відскануйте локацію або натисніть \"F2\" для ручного вводу локації";
    }

    private void beginLoadLocation(String newLocationId) {
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {
            String newLocationCode = net.getLocationCode(newLocationId);
            runOnUiThread(() -> endLoadLocation(newLocationCode));
        });
    }

    private void endLoadLocation(String newLocationCode) {

        hideLoading();

        if (newLocationCode != null && newLocationCode.length() > 0) {
            openLocation(newLocationCode);
        } else {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_location_label, null);
        }
    }

    private void openLocation(String locationCode) {
        Intent intent = new Intent(this, LocalInventory3Activity.class);
        intent.putExtra("date", date.getTime());
        intent.putExtra("locationCode", locationCode);
        startActivityForResult(intent, REQUEST_DEFAULT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_DEFAULT && resultCode == RESULT_OK) {
            beginLoadList();
        } else if (requestCode == REQUEST_LOCATION_SELECT && resultCode == RESULT_OK && data != null) {
            endLoadLocation(data.getStringExtra("locationCode"));
        }
    }

    @Override
    public void OnViewClick(int position) {
        AdapterItemLocation itemLocation = adapter.getItem(position);
        if (itemLocation != null) openLocation(itemLocation.getLocation());
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        super.onBackPressed();
    }
}
