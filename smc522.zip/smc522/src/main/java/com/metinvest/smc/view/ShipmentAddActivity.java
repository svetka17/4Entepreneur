package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.JsonUploadTask;
import com.metinvest.smc.tools.Utils;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ShipmentAddActivity extends MyActivity {

    @BindView(R.id.textWeight)
    EditText textWeight;
    @BindView(R.id.textWeightLabel)
    TextView textWeightLabel;

    private String labelId;
    private String number;
    private int netto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shipment_add);
        ButterKnife.bind(this);

        number = getIntent().getStringExtra("number");
        labelId = getIntent().getStringExtra("labelId");
        netto = getIntent().getIntExtra("netto", 0);

        textWeightLabel.setText(String.valueOf(netto));
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    private boolean zero = false;

    private void buttonAcceptClick() {
        if (isLoading()) return;

        int weight = Utils.parseInt(textWeight.getText().toString());

        if (weight == 0) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.incorrect_weight, null);
            textWeight.requestFocus();
            return;
        }

        if (weight >= netto) {
            zero = true;
        }

        /*if (weight > netto) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.incorrect_weight, null);
            textWeight.requestFocus();
            return;
        }*/

        showLoading(R.string.text_please_wait);

        String url = config.getUrlApi() + "addshipmentitem";

        String data = Utils.format(
                "{ \"ShipmentNumber\" : \"%s\", \"ShipmentWeight\" : \"%s\", \"PackWeight\" : \"%s\", \"LabelId\" : \"%s\" }",
                number, weight, 0, labelId);

        net.uploadJson(new JsonUploadTask.JsonUploadTaskParam(url, data), this::endAdd);

    }

    private void endAdd(JsonResult result) {

        hideLoading();

        if (result.isOk()) {
            Intent data = new Intent();
            data.putExtra("labelId", labelId);
            data.putExtra("zero", zero);
            setResult(RESULT_OK, data);
            finish();
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> buttonAcceptClick());
        }
    }
}
