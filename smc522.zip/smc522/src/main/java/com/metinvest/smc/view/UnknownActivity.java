package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.metinvest.smc.R;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Экран ввода номера транспортного средства и ТТН для создания временной бирки.
 * <img src="https://od.sytecs.com.ua/files/smc_doc/res/view/UnknownActivity.png"/>
 */
public class UnknownActivity extends MyActivity implements IScan {

    @BindView(R.id.textCarrier)
    EditText textCarrier;
    @BindView(R.id.textTtn)
    EditText textTtn;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unknown);
        ButterKnife.bind(this);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    /**
     * Если штрих-код является допустимым штрих-кодом SMC07, загружаем инфо по этикетке.
     *
     * @param barcodeData Данные штрих-кода, которые были отсканированы.
     */
    @Override
    public void onBarcodeEvent(String barcodeData) {
        if (isLoading()) return;

        runOnUiThread(() -> {
            ScanItem scanItem = new ScanItem(barcodeData);

            if (!scanItem.isCorrect()) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_identity_error, null);
                return;
            }

            if (scanItem.getType() == ScanItem.ScanItemType.SMC07) {
                beginLoadLabelUnknown(scanItem);
            }
        });
    }

    /**
     * Метод получения транспортного средства и ТТН из этикетки
     *
     * @param scanItem объект элемента сканирования
     */
    public void beginLoadLabelUnknown(ScanItem scanItem) {
        JSONArray array = Utils.getJsonArray(scanItem.getData(2));
        if (array == null) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_error_scan_item, null);
        } else {
            JSONObject object = Utils.getJsonObject(array, 0);
            String labelId = Utils.getJsonStringIgnoreCase(object, "id");
            if (labelId.isEmpty()) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_error_scan_item, null);
            } else {
                String carrier = scanItem.getData(4);
                String ttn = scanItem.getData(6);
                if (carrier.isEmpty() && ttn.isEmpty()) {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_smc07_carrier_empty, null);
                } else {
                    textCarrier.setText(carrier);
                    textTtn.setText(ttn);
                }
            }
        }
    }

    /**
     * Проверка ввода номера транспорного средства и ТТН и переход на экран создания временной бирки
     * @see com.metinvest.smc.view.Unknown2Activity
     */
    public void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        String carrier = textCarrier.getText().toString().trim();
        String ttn = textTtn.getText().toString().trim();

        if (carrier.isEmpty()) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_error, "Необхідно ввести номер вагону чи авто!", null);
            textCarrier.post(() -> textCarrier.requestFocus());
            return;
        }

        if (ttn.isEmpty()) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_error, "Необхідно ввести номер ТТН чи накладної!", null);
            textTtn.post(() -> textTtn.requestFocus());
            return;
        }

        Intent intent = new Intent(this, Unknown2Activity.class);
        intent.putExtra("carrier", carrier);
        intent.putExtra("ttn", ttn);

        startActivity(intent);
    }
}
