package com.metinvest.smc.ui;

import static com.metinvest.smc.tools.Utils.parseInt;

import android.text.Html;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.ColorRes;
import androidx.core.content.ContextCompat;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.db.ShipmentItem;
import com.metinvest.smc.db.ShipmentItemLoc;
import com.metinvest.smc.tools.Utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemCard extends AbstractFlexibleItem<AdapterItemCard.ViewHolder> {

    public interface AdapterItemCardListener {
        void onViewClick(AdapterItemCard item);
    }

    private final AdapterItemCardListener listener;
    private final ShipmentItem shipmentItem;
    private final App app;
    private List<ShipmentItemLoc> locList;
    private String largerLocation;
    private List<ShipmentItem> anotherShipmentItems;

    public AdapterItemCard(ShipmentItem shipmentItem, List<ShipmentItemLoc> locList, AdapterItemCardListener listener) {
        this.app = App.getInstance();
        this.shipmentItem = shipmentItem;
        this.listener = listener;
        this.anotherShipmentItems = new ArrayList<>();
        setLocList(locList);
    }

    public void addAnotherShipmentItem(ShipmentItem item) {
        this.anotherShipmentItems.add(item);
    }

    public int getSapWeightNettAll() {
        int value = shipmentItem.getSapWeightNett();
        for (ShipmentItem anotherShipmentItem : anotherShipmentItems) {
            value += anotherShipmentItem.getSapWeightNett();
        }
        return value;
    }

    public int getSapWeightNettFactAll() {
        int value = shipmentItem.getSapWeightNettFact();
        for (ShipmentItem anotherShipmentItem : anotherShipmentItems) {
            value += anotherShipmentItem.getSapWeightNettFact();
        }
        return value;
    }

    public List<ShipmentItem> getAnotherShipmentItems() {
        return anotherShipmentItems;
    }

    public void setLocList(List<ShipmentItemLoc> locList) {
        this.locList = locList;
        //Collections.sort(locList, (o1, o2) -> Utils.compareLocations(o2.getLocation(), o1.getLocation()));

        Collections.sort(locList, (o1, o2) ->
                Integer.compare(
                        parseInt(o1.getSapBatch())==0?
                                parseInt(o1.getSapBatch().replaceAll("[[:alpha:]]","9"))>9999?parseInt(o1.getSapBatch().replaceAll("[[:alpha:]]","9")):Integer.MAX_VALUE
    :parseInt(o1.getSapBatch()),
                        parseInt(o2.getSapBatch())==0?
                                parseInt(o2.getSapBatch().replaceAll("[[:alpha:]]","9"))>9999?parseInt(o2.getSapBatch().replaceAll("[[:alpha:]]","9")):Integer.MAX_VALUE
                                :parseInt(o2.getSapBatch())));
        largerLocation = locList != null && !locList.isEmpty() ? locList.get(locList.size() - 1).getLocation() : "0-0-0";
    }

    public String getLargerLocation() {
        return largerLocation;
    }

    public List<ShipmentItemLoc> getLocList() {
        return locList;
    }

    public ShipmentItem getShipmentItem() {
        return shipmentItem;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterItemCard && ((AdapterItemCard) o).getShipmentItem().getId() == getShipmentItem().getId();
    }

    @Override
    public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new ViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {

        String title = Utils.format("%s <b>%s</b>", shipmentItem.getPositionId(), Html.escapeHtml(shipmentItem.getSapMattDescr()));

        holder.textTitle.setText(app.fromHtml(title));

        String size = app.sizeToString(shipmentItem.getWidth(), shipmentItem.getLength(), shipmentItem.getThickness());
        String ts = Utils.format("ОЗМ: %s", shipmentItem.getSapOzm()) + (size.length() > 0 ? "\n" + size : "");
        holder.textSize.setText(ts);
        holder.textWeight.setText(Utils.format(
                "%.3f / %.3f / %.3f",
                getSapWeightNettAll() / 1000.0f,
                getSapWeightNettFactAll() / 1000.0f,
                (getSapWeightNettAll() - getSapWeightNettFactAll() < 0 ? 0 : ((getSapWeightNettAll() - getSapWeightNettFactAll()) / 1000.0f))
                )
        );

        int delta = getSapWeightNettFactAll() - getSapWeightNettAll();

        @ColorRes int imageId = R.color.ship_yellow;

        if (getSapWeightNettFactAll() == 0) {
            imageId = R.color.ship_white;
        } else if (shipmentItem.getDelFlag().equalsIgnoreCase("1")) {
            imageId = R.color.ship_deleted;
        } else if (delta > 100) {
            imageId = R.color.ship_red;
        } else if (delta >= -100) {
            imageId = R.color.ship_green;
        }

        holder.textWeight.setBackgroundColor(app.getColor(imageId));
        holder.textWeightTitle.setBackgroundColor(app.getColor(imageId));

        StringBuilder sb1 = new StringBuilder();
        StringBuilder sb2 = new StringBuilder();

        if (locList.isEmpty()) {
            sb1.append(app.getString(R.string.ozm_not_in_stock));
        } else {
            for (int i = 0; i < locList.size(); i++) {
                //если указана партия, то была отгрузка по биркам
                String templ1 = "%s";
                String templ2 = "%s%n<br>";
                if (locList.get(i).getDivLabel().contains("1")) {
                    templ1 = "<font color=\"blue\"><b>%s</b></font>";
                    templ2 = "<font color=\"blue\"><b>%s%n</b></font><br>";
                }

                sb1.append(
                        //Utils.format((i + 1 == locList.size() ? "<font color=\"yellow\"><b>%s</b></font>" : "%s%n<br>"), locList.get(i).getLocation())
                        Utils.format((i + 1 == locList.size() ? templ1 : templ2), locList.get(i).getLocation())
                );
                sb2.append(Utils.format((i + 1 == locList.size() ? "%.3f т" : "%.3f т%n"), (locList.get(i).getSumWeight() / 1000000.0f)));
            }
        }

        holder.textLocation.setText(App.getInstance().fromHtml(sb1.toString()));
        holder.textLocationWeight.setText(sb2.toString());

        View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
        holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
        refreshBackground(holder, holder.itemView.isFocused());

        holder.buttonView.setVisibility(View.GONE);// locList.isEmpty() ? View.GONE : View.VISIBLE);

        if (listener != null) {
            if (!locList.isEmpty()) {
                View.OnClickListener listenerView = v -> listener.onViewClick(AdapterItemCard.this);
                holder.buttonView.setOnClickListener(listenerView);
                holder.viewLocations.setOnClickListener(listenerView);
            }
        }
    }

    private void refreshBackground(ViewHolder holder, boolean hasFocus) {
        holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_adapter_light));
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_card;
    }

    static class ViewHolder extends FlexibleViewHolder {

        private final TextView textLocation, textLocationWeight, textTitle, textSize, textWeight;
        private final View textWeightTitle;
        private final View viewZone;
        private final ImageButton buttonView;
        private final View viewLocations;

        ViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.textTitle = view.findViewById(R.id.textTitle);
            this.textSize = view.findViewById(R.id.textSize);
            this.textWeight = view.findViewById(R.id.textWeight);
            this.textLocation = view.findViewById(R.id.textLocation);
            this.textLocationWeight = view.findViewById(R.id.textLocationWeight);
            this.textWeightTitle = view.findViewById(R.id.textWeightTitle);
            this.viewZone = view.findViewById(R.id.viewZone);
            this.buttonView = view.findViewById(R.id.buttonView);
            this.viewLocations = view.findViewById(R.id.viewLocations);
        }
    }
}
