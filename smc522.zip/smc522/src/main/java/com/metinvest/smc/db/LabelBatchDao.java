package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface LabelBatchDao {
	@Query("SELECT * FROM labelbatch")
	List<LabelBatch> getAll();

	@Query("SELECT * FROM labelbatch WHERE labelid = :labelId")
	LabelBatch getByLabelId(String labelId);

	@Query("SELECT * FROM labelbatch WHERE batch = :batch")
	LabelBatch getByBatch(String batch);

	@Insert
	long insert(LabelBatch labelBatch);

	@Insert
	void insertAll(List<LabelBatch> labelBatchList);

	@Update
	void update(LabelBatch labelBatch);

	@Delete
	void delete(LabelBatch labelBatch);

	@Query("DELETE FROM labelbatch")
	void truncate();
}