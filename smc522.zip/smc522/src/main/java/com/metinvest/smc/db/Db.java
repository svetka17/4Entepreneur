package com.metinvest.smc.db;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

@Database(entities = {
		OnTheWay.class, Carrier.class, NameStore.class, Printed.class, Dpl.class, Inventory.class,
		ShipmentTransport.class, ShipmentDocument.class, ShipmentItem.class, ShipmentItemLoc.class,
		Weighing.class, Roll.class, RollName.class, RollInfo.class, RollNameInfo.class, Inv.class,
		InvInfo.class, IdQrStore.class, OffShipLabel.class, LabelBatch.class
}, version = 106/*89*/, exportSchema = false)
@TypeConverters({DateConverter.class})
public abstract class Db extends RoomDatabase {

    public abstract OnTheWayDao onTheWayDao();

    public abstract CarrierDao carrierDao();

    public abstract NameStoreDao nameStoreDao();

    public abstract PrintedDao printedDao();

    public abstract DplDao dplDao();

    public abstract InventoryDao inventoryDao();

    public abstract ShipmentTransportDao shipmentTransportDao();

    public abstract ShipmentDocumentDao shipmentDocumentDao();

    public abstract ShipmentItemDao shipmentItemDao();

    public abstract ShipmentItemLocDao shipmentItemLocDao();

    public abstract WeighingDao weighingDao();

    public abstract RollDao rollDao();

    public abstract RollNameDao rollNameDao();

    public abstract RollInfoDao rollInfoDao();

    public abstract RollNameInfoDao rollNameInfoDao();

    public abstract InvDao invDao();

    public abstract InvInfoDao invInfoDao();

    public abstract IdQrStoreDao idQrStoreDao();

    public abstract OffShipLabelDao offShipLabelDao();

    public abstract LabelBatchDao labelBatchDao();

    public void initDb() {
        shipmentTransportDao().truncate();
        shipmentDocumentDao().truncate();
        shipmentItemDao().truncate();
        shipmentItemLocDao().truncate();
    }
}
