package com.metinvest.smc.tools;

import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.Tag;
import android.nfc.tech.Ndef;

import com.metinvest.smc.App;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class NFC {

    private String id;
    private int size, maxsize;
    private List<NdefRecord> records;

    public NFC(Tag tag) {

        this.id = Utils.bytesToHex(tag.getId());
        this.records = new ArrayList<>();

        Ndef ndef = Ndef.get(tag);

        if (ndef != null) {
            try {
                ndef.connect();

				this.maxsize = ndef.getMaxSize();

				NdefMessage messages = ndef.getNdefMessage();

				this.size = messages.getByteArrayLength();

				this.records.addAll(Arrays.asList(messages.getRecords()));

				ndef.close();
			} catch (Exception e) {
				App.getInstance().log(this, e, "ndef.connect()");
			} finally {
				try {
					ndef.close();
				} catch (Exception ignored) {
				}
			}
        }
    }

    public String getId() {
        return id;
    }

    public int getSize() {
        return size;
    }

    public int getMaxsize() {
        return maxsize;
    }

    public List<NdefRecord> getRecords() {
        return records;
    }


}
