package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.BindViews;
import butterknife.ButterKnife;

public class InvLocationActivity extends MyActivity implements IScan {

    @BindViews({R.id.location1, R.id.location2, R.id.location3})
    List<EditText> textLocation;
    @BindView(R.id.buttonReportLocation)
    Button buttonReportLocation;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;
    @BindView(R.id.textContentTitle)
    TextView textContentTitle;

    private Date date;
    private String storage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inv_location);
        ButterKnife.bind(this);

        date = (Date) getIntent().getSerializableExtra("date");
        storage = getIntent().getStringExtra("storage");
        textContentTitle.setText(app.getDateFormat().format(date));
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number >= 2 && number <= 4) textLocation.get(number - 2).requestFocus();
        else if (number == 5) showLocationList();
        else if (number == 6) buttonReportLocationClick();
        else if (number == 7) beginAccept();
    }

    private void buttonReportLocationClick() {
        if (isLoading()) return;

        startActivityForResult(new Intent(this, LocationListActivity.class), REQUEST_LOCATION_SELECT2);
    }

    private void showLocationList() {
        startActivityForResult(new Intent(this, LocationListActivity.class), REQUEST_LOCATION_SELECT);
    }

    private void beginAccept() {

        String locationCode = Utils.format("%s-%s-%s",
                textLocation.get(0).getText().toString(),
                textLocation.get(1).getText().toString(),
                textLocation.get(2).getText().toString()
        );

        if (!app.isLocationCorrect(locationCode) || textLocation.get(0).getText().toString().length() == 0) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.text_error_location_incorrect, null);
            textLocation.get(0).post(() -> textLocation.get(0).requestFocus());
            return;
        }

        Intent intent = new Intent(this, InvListActivity.class);
        intent.putExtra("date", date);
        intent.putExtra("storage", storage);
        intent.putExtra("locationCode", app.fixLocation(locationCode));
        startActivity(intent);
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {
        if (isLoading()) return;

        runOnUiThread(() -> {

            ScanItem scanItem = new ScanItem(barcodeData);

            if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONCODE) {
                if (scanItem.isCorrect()) {
                    endLoadLocation(scanItem.getData(0));
                } else {
                    showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_location_label, null);
                }
            }

        });
    }

    private void endLoadLocation(String newLocationCode) {

        if (app.isLocationCorrect(newLocationCode)) {
            String[] arr = app.fixLocation(newLocationCode).split("-");
            textLocation.get(0).setText(arr[0]);
            textLocation.get(1).setText(arr[1]);
            textLocation.get(2).setText(arr[2]);
            beginAccept();
        } else {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.location_identity_error, null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_LOCATION_SELECT && resultCode == RESULT_OK && data != null) {
            String locationCode = data.getStringExtra("id");
            String[] arr = app.fixLocation(locationCode).split("-");
            for (int i = 0; i < 3; i++) {
                textLocation.get(i).setText(arr[i]);
            }

            beginAccept();
        }

        if (requestCode == REQUEST_LOCATION_SELECT2 && resultCode == RESULT_OK && data != null) {
            String locationCode = data.getStringExtra("id");
            log("location %s", locationCode);
            beginReportLocation(locationCode);
        }

        if (requestCode == REQUEST_VIEW && resultCode == RESULT_OK && data != null) {

            String action = data.getStringExtra("action");
            String locationCode = data.getStringExtra("locationCode");

            if (locationCode != null && action != null && action.equalsIgnoreCase("block")) {
                showDialogConfirm(R.string.text_warning, Utils.format("Завершити інвентаризацію в локації %s?", locationCode), (dialog, which) -> beginBlock(storage, locationCode));
            }
        }
    }

    private void beginReportLocation(String locationCode) {
        showLoading(R.string.text_please_wait);

        String url = config.getUrlApi() + "getinventoryonlinedeltas";
        url = net.addUrlParam(url, "wh_type", storage);
        url = net.addUrlParam(url, "inv_date", app.getDateFormat2().format(date));
        reqGet(url, result -> endReportLocation(result, locationCode));
    }

    private void endReportLocation(JsonResult result, String locationCode) {
        hideLoading();

        if (result.isOk() || result.getStatus() == LoadResultStatus.PLUS2) {
            ArrayList<String> list = new ArrayList<>();

            JSONArray array = Utils.getJsonArray(result.getJson(), "data");
            for (int i = 0; array != null && i < array.length(); i++) {
                JSONObject json = Utils.getJsonObject(array, i);
                if (json != null) {
                    String jsonLoc = Utils.getJsonStringIgnoreCase(json, "location_Code");
                    //String jsonDt = Utils.getJsonStringIgnoreCase(json, "scan_DateTime");

                    if (jsonLoc.equalsIgnoreCase(locationCode))
                        list.add(json.toString());
                }
            }

            openLocationList(locationCode, list);
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginReportLocation(locationCode));
        }
    }

    public void openLocationList(String locationCode, ArrayList<String> checkedLabelList) {
        Intent intent = new Intent(this, BarcodeResultActivity.class);
        intent.putExtra("type", ShowInfoType.BY_LOCATION_CODE);
        intent.putExtra("locationCode", locationCode);
        if (checkedLabelList != null) {
            intent.putStringArrayListExtra("checkedList", checkedLabelList);
            intent.putExtra("canScan", false);
        }
        intent.putExtra("canRefresh", false);
        intent.putExtra("action", "block");
        intent.putExtra("actionTitle", getString(R.string.button_block_location));
        startActivityForResult(intent, REQUEST_VIEW);
    }

    private void beginBlock(String storage, String locationCode) {
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {
            String url = config.getUrlApi() + "blocklocation";
            url = net.addUrlParam(url, "wh_type", storage);
            url = net.addUrlParam(url, "inv_date", app.getDateFormat2().format(date));
            url = net.addUrlParam(url, "location_code", locationCode);

            JsonResult result = net.uploadJson(url, "");
            runOnUiThread(() -> endBlock(result, storage, locationCode));
        });
    }

    private void endBlock(JsonResult result, String storage, String locationCode) {
        hideLoading();

        if (result != null && result.isOk()) {
            showToast(R.string.inv_block_ok);
        } else {
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginBlock(storage, locationCode));
        }
    }
}
