package com.metinvest.smc.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.metinvest.smc.tools.IValue;
import com.metinvest.smc.tools.Utils;

import java.util.Date;
import java.util.List;

@Entity
public class ShipmentDocument implements IValue {

	@Ignore
	public List<ShipmentItem> schipmentItems;

	@PrimaryKey(autoGenerate = true)
	private long id;
	private long transportId;
	private String transportName, transportNameSap;
	private String docNumber, clientNumber;
	private boolean deleted;
	private int status;
	private int plan, fact;
	private long firstDate, lastDate, planTime;
	private String sapPoNum, driverName, creatorName, driverCellPhone;
	private int orderCount;
	private int turnId;

	private int eoLocationId;

	private String eoLocationName;
	private String eoStorage;
	private String eoSmcId;
	private long dateVo;

	public ShipmentDocument() {
	}

	@Ignore
	public ShipmentDocument(long id, long transportId, String transportName, String docNumber, int status,
							int plan, int fact, int orderCount, Date dateVo, int eoLocationId, String eoLocationName,
							String eoSmcId, String eoStorage){
		this.id = id;
		this.transportId = transportId;
		this.transportName = transportName;
		this.docNumber = docNumber;
		this.status = status;
		this.plan = plan;
		this.fact = fact;
		this.orderCount = orderCount;
		this.dateVo = dateVo == null ? 0 : dateVo.getTime();
		this.eoLocationId = eoLocationId;
		this.eoLocationName = eoLocationName;
		this.eoSmcId = eoSmcId;
		this.eoStorage = eoStorage;
	}
	@Ignore
	public ShipmentDocument(long id, long transportId, String transportName, String docNumber, String clientNumber,
							int status, boolean deleted, int plan, int fact, long firstDate, long lastDate, long planTime,
							String sapPoNum, String driverName, String creatorName, String driverCellPhone, int orderCount,
							int turnId, Date dateVo) {
		this.id = id;
		this.transportId = transportId;
		this.transportName = transportName;
		this.docNumber = docNumber;
		this.clientNumber = clientNumber;
		this.status = status;
		this.deleted = deleted;
		this.plan = plan;
		this.fact = fact;
		this.firstDate = firstDate;
		this.lastDate = lastDate;
		this.planTime = planTime;
		this.sapPoNum = sapPoNum;
		this.driverName = driverName;
		this.creatorName = creatorName;
		this.driverCellPhone = driverCellPhone;
		this.orderCount = orderCount;
		this.turnId = turnId;
		this.dateVo = dateVo == null ? 0 : dateVo.getTime();
	}

	public String getTransportNameSap() {
		return transportNameSap;
	}

	public void setTransportNameSap(String transportNameSap) {
		this.transportNameSap = transportNameSap;
	}

	public long getDateVo() {
		return dateVo;
	}

	public Date getDateVoDt() {
		return dateVo == 0 ? null : new Date(dateVo);
	}

	public void setDateVo(long dateVo) {
		this.dateVo = dateVo;
	}

	public int getTurnId() {
		return turnId;
	}

	public void setTurnId(int turnId) {
		this.turnId = turnId;
	}

	public int getOrderCount() {
		return orderCount;
	}

	public void setOrderCount(int orderCount) {
		this.orderCount = orderCount;
	}

	public long getPlanTime() {
		return planTime;
	}

	public void setPlanTime(long planTime) {
		this.planTime = planTime;
	}

	public void setSapPoNum(String sapPoNum) {
		this.sapPoNum = sapPoNum;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public void setDriverCellPhone(String driverCellPhone) {
		this.driverCellPhone = driverCellPhone;
	}

	public String getSapPoNum() {
		return sapPoNum;
	}

	public int getEoLocationId() {
		return eoLocationId;
	}

	public String getEoLocationName() {
		return eoLocationName;
	}

	public String getEoStorage() {
		return eoStorage;
	}

	public String getEoSmcId() {
		return eoSmcId;
	}

	public void setEoLocationId(int eoLocationId) {
		this.eoLocationId = eoLocationId;
	}

	public void setEoLocationName(String eoLocationName) {
		this.eoLocationName = eoLocationName;
	}

	public void setEoStorage(String eoStorage) {
		this.eoStorage = eoStorage;
	}

	public void setEoSmcId(String eoSmcId) {
		this.eoSmcId = eoSmcId;
	}

	public String getDriverName() {
		return driverName;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public String getDriverCellPhone() {
		return driverCellPhone;
	}

	public long getFirstDate() {
		return firstDate;
	}

	public void setFirstDate(long firstDate) {
		this.firstDate = firstDate;
	}

	public long getLastDate() {
		return lastDate;
	}

	public void setLastDate(long lastDate) {
		this.lastDate = lastDate;
	}

	public int getPlan() {
		return plan;
	}

	public void setPlan(int plan) {
		this.plan = plan;
	}

	public int getFact() {
		return fact;
	}

	public void setFact(int fact) {
		this.fact = fact;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	@Override
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getTransportId() {
		return transportId;
	}

	public void setTransportId(long transportId) {
		this.transportId = transportId;
	}

	public String getTransportName() {
		return transportName;
	}

	public void setTransportName(String transportName) {
		this.transportName = transportName;
	}

	public String getDocNumber() {
		return docNumber;
	}

	public void setDocNumber(String docNumber) {
		this.docNumber = docNumber;
	}

	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String getName() {
		return getDocNumber();
	}

	@NonNull
	@Override
	public String toString() {
		return Utils.format("[%s] %s", getId(), getName());
	}
}
