package com.metinvest.smc.net;

import android.net.Uri;

import com.metinvest.smc.App;
import com.metinvest.smc.tools.Utils;

import java.net.SocketTimeoutException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class NetworkRequest {

	private final static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss", Utils.getLocale());

	private final RequestOpt options;

	public NetworkRequest(RequestOpt options) {
		this.options = options;
	}

	private String addUrlParam(String url, String key, String value) {
		return Uri.parse(url == null ? "" : url).buildUpon().
				appendQueryParameter(key, value).
				build().toString();
	}

	private String getUrlFunctionName(String url) {
		String v = url.replace(options.getApiUrl(), "");
		int i = v.indexOf('?');
		if (i == -1) return url;
		v = v.substring(0, i);
		return v;
	}

	public StringResult requestString() {

		StringResult result = new StringResult();

		String finalUrl = options.getUrl();

		if (options.getUserId() > 0) {
			finalUrl = addUrlParam(finalUrl, "user_id", String.valueOf(options.getUserId()));

			if (!finalUrl.contains("smc_id")) {
				finalUrl = addUrlParam(finalUrl, "smc_id", options.getSmcId());
			}

			finalUrl = finalUrl.replace("&smc_id=NULL", "");
		}

		result.setPacketId(options.getPacketId());

		finalUrl = addUrlParam(finalUrl, "version", String.valueOf(options.getVersion()));
		finalUrl = addUrlParam(finalUrl, "device", options.getDeviceId());
		finalUrl = addUrlParam(finalUrl, "requestid", String.valueOf(result.getPacketId()));
		//finalUrl = addUrlParam(finalUrl, "requestTime", dateFormat.format(Calendar.getInstance().getTime()));
		//finalUrl = addUrlParam(finalUrl, "networkType", options.getNetworkType());

		if (options.getUserId() > 0 && !options.isMsal()) {

			finalUrl = addUrlParam(finalUrl, "token", options.getToken());
		}

		result.setFunctionName(getUrlFunctionName(finalUrl));

		log(options.isPost() ? "[POST] %s" : "[GET] %s", finalUrl);

		long nanoTime1 = System.nanoTime();

		try {
			String body = "";
			OkHttpClient client = getUnsafeOkHttpClient(30, 30, 30);
			Request.Builder builder;
			if (finalUrl.contains("install")){
				finalUrl = options.getUrl();
				//SimpleDateFormat fmt = App.getInstance().getDateTimeFormat2() ;
				//fmt.setTimeZone(TimeZone.getTimeZone("GMT"));
				//String date = fmt.format(Calendar.getInstance().getTime()) + " GMT";
				builder = new Request.Builder()
						.url(finalUrl)
						//.addHeader("Authorization", "Bearer " + options.getToken())
						//.addHeader("x-ms-date", date )
						//.addHeader("x-ms-version", "2022-11-02" )
						//.addHeader("Host", "mihwesmcapp11.blob.core.windows.net" )
				;
			}
			else if (options.isMsal()){
				// создаем объект запроса и добавляем заголовок авторизации
				builder = new Request.Builder()
						.url(finalUrl)
						.addHeader("Authorization", "Bearer " + options.getToken());
			} else {
				builder = new Request.Builder()
						.url(finalUrl)
						.addHeader("Content-Type", "application/json");
			}
			if (options.isPost()) {
				RequestBody requestBody = RequestBody.create(options.getPostData(), JSON);
				if (options.isPut())
					builder.put(requestBody);
				else
					builder.post(requestBody);

			}

			Request request = builder.build();

			boolean isSuccessful;
			int httpCode = 0;

			try (Response response = client.newCall(request).execute()) {

				isSuccessful = response.isSuccessful();
				httpCode = response.code();

				if (isSuccessful || options.isPut()) {
					body = response.body().string();
				}
			}

			if (isSuccessful || options.isPut() || httpCode == 409) {
				result.setStatus(LoadResultStatus.OK);
				result.setDescription(String.valueOf(result.getStatus()));
				result.setData(body);
			} else {
				logError(null, "[HTTP %s] %s", httpCode, finalUrl);
				result.setStatus(LoadResultStatus.H004);
				result.setDescription(String.valueOf(httpCode));
				result.setData(null);
			}

		} catch (SocketTimeoutException e) {
			logError(e, "[Timeout]", finalUrl);
			result.setStatus(LoadResultStatus.TIMEOUT);
			result.setDescription("Помилка Timeout");
			result.setData(null);
		} catch (Exception e) {
			logError(e, "[OkHttp] %s %s", finalUrl, e);
			result.setStatus(LoadResultStatus.CONNECT_ERROR);
			result.setDescription("В даний момент відсутній зв'язок з точкою входу");
			result.setData(null);
		}

		long nanoTime2 = System.nanoTime();
		long nanoTime = nanoTime2 - nanoTime1;
		log("TIME: %d msec", nanoTime / 1000000);

		return result;
	}

	public static final MediaType JSON
			= MediaType.get("application/json; charset=utf-8");

	public static OkHttpClient getUnsafeOkHttpClient(int connectTimeout, int writeTimeout, int readTimeout) {
		try {
			// Create a trust manager that does not validate certificate chains
			final TrustManager[] trustAllCerts = new TrustManager[]{
					new X509TrustManager() {
						@Override
						public void checkClientTrusted(java.security.cert.X509Certificate[] chain,
													   String authType) throws CertificateException {
						}

						@Override
						public void checkServerTrusted(java.security.cert.X509Certificate[] chain,
													   String authType) throws CertificateException {
						}

						@Override
						public java.security.cert.X509Certificate[] getAcceptedIssuers() {
							return new X509Certificate[0];
						}
					}
			};

			// Install the all-trusting trust manager
			final SSLContext sslContext = SSLContext.getInstance("SSL");
			sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
			// Create an ssl socket factory with our all-trusting manager
			final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

			return new OkHttpClient.Builder()
					.sslSocketFactory(sslSocketFactory, (X509TrustManager) trustAllCerts[0])
					.hostnameVerifier((hostname, session) -> true)
					.connectTimeout(connectTimeout, TimeUnit.SECONDS)
					.writeTimeout(writeTimeout, TimeUnit.SECONDS)
					.readTimeout(readTimeout, TimeUnit.SECONDS)
					.build();

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	private void log(String message, Object... args) {
		App.getInstance().log(this, message, args);
	}

	private void logError(Exception e, String message, Object... args) {
		App.getInstance().log(this, e, message, args);
	}

}
