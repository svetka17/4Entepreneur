package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface PrintedDao {
    @Query("SELECT * FROM printed ORDER BY weighingId")
    List<Printed> getAll();

    @Query("SELECT * FROM printed WHERE old = 1 ORDER BY weighingId")
    List<Printed> getAllOld();

    @Query("SELECT * FROM printed WHERE old = 0 ORDER BY `temporary`, sapOzm, weighingId")
    List<Printed> getAllNew();

    @Query("UPDATE printed SET old = 1, weighingId = 0 WHERE old = 0")
    void updateNewToOld();

    @Query("SELECT count(1) FROM printed WHERE old = 1")
    long getCountOld();

    @Query("SELECT count(1) FROM printed WHERE old = 0")
    long getCountNew();

    @Query("SELECT * FROM printed WHERE id = :id")
    Printed getById(long id);

    @Query("SELECT * FROM printed WHERE id in (:idList) ORDER BY weighingId")
    List<Printed> getById(List<Long> idList);

    @Query("SELECT * FROM printed WHERE onTheWayId = :onTheWayId ORDER BY weighingId")
    List<Printed> getByOnTheWayId(long onTheWayId);

    @Insert
    long insert(Printed printed);

    @Insert
    void insertAll(List<Printed> printed);

    @Update
    void update(Printed printed);

    @Delete
    void delete(Printed printed);

    @Query("DELETE FROM printed")
    void truncate();
}