package com.metinvest.smc.tools;

import androidx.annotation.NonNull;

import com.metinvest.smc.App;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class ScanItem {

    public enum ScanItemType {
        UNKNOWN, SMC02, SMC05, SMC06, SMC07, LOCATIONID, LOCATIONCODE, LABELID,
        ZAPOR, KOMINMET, TRUBOSTAL, ARCELOR, GALATI
    }

    private String line;
    private String[] data;
    private Date dateScan;
    private boolean correct;
    private ScanItemType type;

    public String getLine() {
        return line;
    }

    public Date getDateScan() {
        return dateScan;
    }

    public ScanItem(String line) {

        this.dateScan = Calendar.getInstance().getTime();
        this.line = line.trim();
        this.type = ScanItemType.UNKNOWN;
        this.correct = false;

        try {

            String[] arr;

            if (this.line.toLowerCase().contains("трубосталь")) {
                arr = this.line.split("&");
                this.data = new String[arr.length - 1];
                System.arraycopy(arr, 1, this.data, 0, arr.length - 1);
                this.type = ScanItemType.TRUBOSTAL;
                this.correct = data.length >= 9;
                return;
            }

            if (this.line.toLowerCase().contains("code gal")) {
                arr = this.line.split("\n");
                this.type = ScanItemType.GALATI;
                this.data = new String[arr.length];
                System.arraycopy(arr, 0, this.data, 0, arr.length);
                this.correct = data.length >= 9;
                return;
            }

            if (this.line.toLowerCase().contains("metinvest.io")
            || this.line.toLowerCase().contains("трубосталь")) {
                arr = this.line.split("&");
            } else {
                arr = this.line.split("\\|");
            }

            if (Utils.isJSONValid(this.line)) {
                JSONObject json = Utils.getJsonObject(this.line);
                if (json != null) {
                    this.type = ScanItemType.KOMINMET;

                    List<String> list = new ArrayList<>();
                    Iterator<String> iterator = json.keys();
                    while (iterator.hasNext()) {
                        list.add(Utils.getJsonStringIgnoreCase(json, iterator.next()));
                    }

                    this.data = list.toArray(new String[0]);
                    this.correct = true;
                    return;
                }
            }

            if (arr.length > 1) {
                this.data = new String[arr.length - 1];
                System.arraycopy(arr, 1, this.data, 0, arr.length - 1);
            }

            if (arr[0].equalsIgnoreCase("SMC02")) {
                this.type = ScanItemType.SMC02;
                this.correct = data.length > 0;
                return;
            }

            if (arr[0].equalsIgnoreCase("SMC05")) {
                this.type = ScanItemType.SMC05;
                this.correct = data.length > 0;
                return;
            }

            if (arr[0].equalsIgnoreCase("SMC06")) {
                this.type = ScanItemType.SMC06;
                this.correct = data.length > 0;
                return;
            }

            if (arr[0].equalsIgnoreCase("SMC07")) {
                this.type = ScanItemType.SMC07;
                this.correct = data.length > 0;
                return;
            }

            if (arr[0].charAt(0) == 'L') {
                this.type = ScanItemType.LOCATIONID;
                this.data = new String[1];
                this.data[0] = arr[0].substring(1);
                this.correct = Utils.parseInt(this.data[0]) > 0;
                return;
            }

            if (arr[0].charAt(0) == 'M' || arr[0].matches("\\d.*-\\d.*$")) {
                this.type = ScanItemType.LOCATIONCODE;
                this.data = new String[1];
                //this.data[0] = arr[0].substring(1);
                this.data[0] = tryPrepareLocationCode(arr[0].replace("M", "")/*.substring(1)*/);
                this.correct = App.getInstance().isLocationCorrect(this.data[0]);
                return;
            }

            if (arr[0].matches("(^\\d+?[-]\\d+?)")) {
                this.type = ScanItemType.LOCATIONCODE;
                this.data = new String[1];
                this.data[0] = tryPrepareLocationCode(arr[0]);
                this.correct = App.getInstance().isLocationCorrect(this.data[0]);
                return;
            }

            if (arr[0].toLowerCase().contains("metinvest.io")) {
                this.type = ScanItemType.ZAPOR;
                this.data = new String[arr.length];
                System.arraycopy(arr, 0, this.data, 0, arr.length);
                this.correct = data.length >= 14;
                return;
            }

            if (arr[0].length() >= 8 && Utils.parseLong(arr[0]) > 0) {
                this.type = ScanItemType.ARCELOR;
                this.data = new String[1];
                this.data[0] = arr[0];
                this.correct = true;
                return;
            }

            this.type = ScanItemType.LABELID;
            this.data = new String[1];
            this.data[0] = arr[0];
            this.correct = Utils.parseInt(this.data[0]) > 0;

        } catch (Exception e) {
            App.getInstance().log(this, e, "new ScanItem(%s)", line);
        }
    }

    private String tryPrepareLocationCode(String text) {

        try {
            String[] arr = text.split("-");
            if (arr[0].length() > 0 && arr[1].length() > 0 && (arr.length == 2 || arr[2].length() == 0)) {
                String textNew = Utils.format("%s-%s-%s", arr[0], arr[1], "0");
                App.getInstance().log(this, "Fix location from \"%s\" to \"%s\"", text, textNew);
                return textNew;
            }
        } catch (Exception ignored) {
        }

        return text;
    }

    public String[] getData() {
        return data;
    }

    public ScanItemType getType() {
        return type;
    }

    public String getData(int index) {
        try {
            return data[index];
        } catch (Exception ignored) {
            return "";
        }
    }

    public boolean isCorrect() {
        return correct;
    }

    @NonNull
    @Override
    public String toString() {
        return Utils.format("[%s] %s", getType(), getLine());
    }
}
