package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.App;
import com.metinvest.smc.BuildConfig;
import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.LabelEditItem;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class InvListActivity extends MyActivity implements IScan {

    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.textPrompt)
    TextView textPrompt;
    @BindView(R.id.viewButtons)
    View viewButtons;
    @BindView(R.id.textLabelId)
    EditText textLabelId;

    private Date date;
    private String storage;
    private String locationCode;
    private FlexibleAdapter<Adapter> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inv_list);
        ButterKnife.bind(this);

        date = (Date) getIntent().getSerializableExtra("date");
        locationCode = getIntent().getStringExtra("locationCode");
        refreshTitle();
        storage = getIntent().getStringExtra("storage");

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, true);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
        listView.setLayoutManager(layoutManager);
        listView.addItemDecoration(dividerItemDecoration);

        adapter = new FlexibleAdapter<>(null);
        listView.setAdapter(adapter);

        if (BuildConfig.DEBUG) {
            textContentTitle.setOnClickListener(v -> {
                //onBarcodeEvent("SMC07|1000|1|[{\"netto\":\"1000\",\"pack\":\"0\",\"tara\":\"0\",\"id\":\"126163\"}]|04.04.2020|test|1-0-0|12345|11.22.33.44.55|test ozm|2000.000000|100.000000|50.000000");
                onBarcodeEvent("SMC06|118346|1406|Рулон х/к 0.7-1.5 Ст3пс О Т|0.000000|1250.000000|1.500000|6750|ФВ|24.11.316200.00230|160|0|0032355883|0|20200404133121|АЕ5034НС П.АЕ2660ХМ");
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        textLabelId.setText(null);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 4) {
            openWeighing();
        } else if (number == 3) {
            String labelId = textLabelId.getText().toString();
            if (labelId.isEmpty()) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_labelid_empty, (dialog, which) -> textLabelId.requestFocus());
            } else {
                beginScanLabel(labelId, 0, Calendar.getInstance().getTime());
            }
        } else if (number == 5) {
            Intent intent = new Intent(this, RollActivity.class);
            intent.putExtra("showInv", false);
            startActivity(intent);
        } else if (number == 6) {
            startActivity(new Intent(this, UnknownActivity.class));
        }
    }

    private void openWeighing() {
        openWeighing(null, 0, null);
    }

    private void openWeighing(String labelId, int birkNetto, Date dateScan) {
        Intent intent = new Intent(this, InvWeighingActivity.class);
        intent.putExtra("date", date);
        intent.putExtra("storage", storage);
        intent.putExtra("locationCode", app.fixLocation(locationCode));
        if (labelId != null) {
            intent.putExtra("labelId", labelId);
            intent.putExtra("birkNetto", birkNetto);
            intent.putExtra("dateScan", dateScan.getTime());
        }
        startActivityForResult(intent, REQUEST_ADD);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    void beginLoad() {
        beginLoad(null);
    }

    void beginLoad(String labelIdtoPrint) {
        if (isLoading()) return;
        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);

        Utils.runOnBackground(() -> {
            String url = config.getUrlApi() + "getinventoryonlinedeltas";
            url = net.addUrlParam(url, "wh_type", storage);
            url = net.addUrlParam(url, "inv_date", app.getDateFormat2().format(date));
            JsonResult result = net.downloadJson(url);

            List<Adapter> itemList = new ArrayList<>();

            if (result.isOk() || result.getStatus() == LoadResultStatus.PLUS2) {

                JSONArray array = Utils.getJsonArray(result.getJson(), "data");
                for (int i = 0; array != null && i < array.length(); i++) {
                    JSONObject json = Utils.getJsonObject(array, i);
                    if (json != null) {
                        Label label = Label.fromJson(json);
                        if (label != null/* && label.getLocationCode().equalsIgnoreCase(locationCode)*/) {
                            String locationCodeLabel = Utils.getJsonStringIgnoreCase(json, "location_Code");
                            if (locationCodeLabel.equalsIgnoreCase(locationCode)) {
                                int nettoLabel = Utils.getJsonWeightKgIgnoreCase(json, "netT_Weight_Label");
                                int nettoFact = Utils.getJsonWeightKgIgnoreCase(json, "netT_Weight_Fact");
                                String dateScanStr = Utils.getJsonStringIgnoreCase(json, "scan_DateTime");
                                label.setWeightNetto(nettoLabel);
                                label.setLocationCode(locationCodeLabel);
                                Adapter item = new Adapter(label, nettoFact, app.parseDfDateTime(dateScanStr), false);
                                itemList.add(item);
                            }
                        }
                    }
                }

                try {
                    Collections.sort(itemList, (o1, o2) -> {
                        Date d1 = o1.getDateScan();
                        Date d2 = o2.getDateScan();
                        int c = 0;
                        if (d1 != null && d2 != null) {
                            c = Long.compare(d1.getTime(), d2.getTime());
                        } else {
                            c = Integer.compare(d1 == null ? 1 : 0, d2 == null ? 1 : 0);
                        }
                        return c;
                    });
                } catch (Exception ignored) {
                }

            }

            runOnUiThread(() -> endLoad(result, itemList, labelIdtoPrint));
        });
    }

    private void endLoad(JsonResult result, List<Adapter> itemList, String labelIdtoPrint) {
        hideLoading();
        viewButtons.setVisibility(View.VISIBLE);

        if (!itemList.isEmpty()) {
            adapter.addItems(0, itemList);
            adapterChanged();

            if (labelIdtoPrint != null) {
                Adapter item = findItem(labelIdtoPrint);
                if (item != null && item.label.getWeightNetto() != item.nettoNew && item.nettoNew > 0) {
                    beginPrint(item);
                }
            }
        }

        if (!result.isOk() && result.getStatus() != LoadResultStatus.PLUS2) {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
        }
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {
        if (isLoading()) return;

        runOnUiThread(() -> {

            ScanItem scanItem = new ScanItem(barcodeData);

            if (!scanItem.isCorrect()) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_identity_error, null);
                return;
            }

            if (scanItem.getType() == ScanItem.ScanItemType.LABELID || scanItem.getType() == ScanItem.ScanItemType.SMC06) {
                beginScanLabel(scanItem.getData(0), Utils.parseInt(scanItem.getData(6)), Calendar.getInstance().getTime());
            } else if (scanItem.getType() == ScanItem.ScanItemType.SMC07) {
                beginLoadLabelUnknown(scanItem);
            }

        });
    }

    private void beginScanLabel(String labelId, int birkNetto, Date dateScan) {
        openWeighing(labelId, birkNetto, dateScan);
    }

    private void beginLoadLabelUnknown(ScanItem scanItem) {
        JSONArray array = Utils.getJsonArray(scanItem.getData(2));
        if (array == null) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_error_scan_item, null);
        } else {
            JSONObject object = Utils.getJsonObject(array, 0);
            String labelId = Utils.getJsonStringIgnoreCase(object, "id");
            if (labelId.isEmpty()) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_error_scan_item, null);
            } else {
                beginScanLabel(labelId, 0, Calendar.getInstance().getTime());
            }
        }
    }

    private void saveItem(Label label, int birkNetto, int pack, Date dateScan, boolean checkLabel, List<Label> labelList) {
        if (checkLabel) {
            beginCheckItem(label, birkNetto, dateScan, true, labelList);
        } else {
            beginUpload(label, birkNetto, pack, dateScan, labelList);
        }
    }

    /*private void beginTransfer(Label label, String labelId, int birkNetto, Date dateScan, List<Label> labelList) {
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            NetworkResult result = null;
            List<Label> list = getTotalList(label, labelList);
            for (Label labelItem : list) {
                String url = config.getUrlApi() + "setlabellocation";
                url = net.addUrlParam(url, "label_id", labelItem.getId());
                url = net.addUrlParam(url, "location_code", locationCode);
                result = net.uploadJson(url, "");
            }

            NetworkResult finalResult = result;
            runOnUiThread(() -> endTransfer(finalResult, label, labelId, birkNetto, dateScan, labelList));
        });
    }

    private void endTransfer(NetworkResult result, Label label, String labelId, int birkNetto, Date dateScan, List<Label> labelList) {
        hideLoading();

        if (result != null && result.isOk()) {
            label.setLocationCode(locationCode);
            if (labelList != null) {
                for (Label labelItem : labelList) {
                    labelItem.setLocationCode(locationCode);
                }
            }
            endScanLabel(result, label, labelId, birkNetto, dateScan, labelList);
        } else {
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginTransfer(label, labelId, birkNetto, dateScan, labelList));
        }
    }*/

    private void editItem(Label label, int nettoNew, Date dateScan, boolean checkLabel) {
        if (checkLabel) {
            beginCheckItem(label, nettoNew, dateScan, false, null);
        } else {
            beginEdit(label, nettoNew, dateScan);
        }
    }

    private void beginCheckItem(Label label, int nettoNew, Date dateScan, boolean isSave, List<Label> labelList) {
        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);

        String url = config.getUrlApi() + "checkinventoryonline";
        url = net.addUrlParam(url, "wh_type", storage);
        url = net.addUrlParam(url, "inv_date", app.getDateFormat2().format(date));
        url = net.addUrlParam(url, "label_id", label.getId());

        reqGet(url, result -> endCheckItem(result, label, nettoNew, label.getWeightPack(), dateScan, isSave, labelList));
    }

    private void endCheckItem(JsonResult result, Label label, int nettoNew, int packNew, Date dateScan, boolean isSave, List<Label> labelList) {
        hideLoading();
        viewButtons.setVisibility(View.VISIBLE);

        if (result.isOk()) {
            JSONObject json = Utils.getJsonObject(result.getJson(), "data");
            String message = "";
            if (json != null) {
                String jScanDt = Utils.getJsonStringIgnoreCase(json, "scan_dt");
                String jUser = Utils.getJsonStringIgnoreCase(json, "user_login");
                String jLocation = Utils.getJsonStringIgnoreCase(json, "location_code");
                int jFact = Utils.getJsonWeightKgIgnoreCase(json, "netT_Weight_Fact");
                message = Utils.format(
                        "Дата: %s%nКористувач: %s%nВага: %d кг.%nЛокація: %s%n",
                        jScanDt, jUser, jFact, jLocation
                );
            }
            showDialogConfirm(R.string.text_warning, getString(R.string.inv_already_invent_confirm, message), (dialog, which) -> {
                if (isSave)
                    saveItem(label, nettoNew, packNew, dateScan, false, labelList);
                else
                    beginEdit(label, nettoNew, dateScan);
            });
        } else if (result.getStatus() == LoadResultStatus.PLUS2) {
            if (isSave)
                saveItem(label, nettoNew, packNew, dateScan, false, labelList);
            else
                beginEdit(label, nettoNew, dateScan);
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginCheckItem(label, nettoNew, dateScan, isSave, labelList));
        }
    }

    private void beginEdit(Label label, int nettoNew, Date dateScan) {
        Intent intent = new Intent(this, InvEditActivity.class);
        intent.putExtra("label", label);
        intent.putExtra("nettoNew", nettoNew);
        intent.putExtra("pack", label.getWeightPack());
        intent.putExtra("dateScan", dateScan);
        startActivityForResult(intent, REQUEST_EDIT);
    }

    private Adapter findItem(String labelId) {

        List<Adapter> list = adapter.getCurrentItems();

        for (Adapter item : list) {
            if (item.getLabel().getId().equalsIgnoreCase(labelId)) {
                return item;
            }
        }

        return null;
    }

    public void OnAdapterDelete(Adapter item) {
        log("OnAdapterDelete %s", item.getLabel().getId());

        showDialogConfirm(R.string.text_confirm, R.string.delete_position_confirm, (dialog, which) -> beginDelete(item));
    }

    private void beginDelete(Adapter item) {
        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);

        String url = config.getUrlApi() + "deleteinventoryonline";

        url = net.addUrlParam(url, "wh_type", storage);
        url = net.addUrlParam(url, "inv_date", app.getDateFormat2().format(date));
        url = net.addUrlParam(url, "label_id", item.getLabel().getId());

        reqGet(url, result -> endDelete(result, item));
    }

    private void endDelete(JsonResult result, Adapter item) {
        hideLoading();
        viewButtons.setVisibility(View.VISIBLE);

        if (result.isOk()) {
            int pos = adapter.getGlobalPositionOf(item);
            if (pos != -1) adapter.removeItem(pos);
            adapterChanged();
            showToast(R.string.successful_deleted);
        } else if (result.getStatus() == LoadResultStatus.PLUS2) {
            showDialog(R.drawable.ic_error_24dp, R.string.text_error, R.string.labelid_not_found, null);
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginDelete(item));
        }
    }

    public void OnAdapterEdit(Adapter item) {
        log("OnAdapterEdit %s", item.getLabel().getId());
        editItem(item.getLabel(), item.getNettoNew(), item.dateScan, false);
    }

    public void OnAdapterPrint(Adapter item) {
        log("OnAdapterPrint %s", item.getLabel().getId());
        /*showDialogConfirm(getString(R.string.text_warning),
                Utils.format("Бажаєте оновити вагу бірки на %d кг?", item.getNettoNew()),
                (dialog, which) -> beginPrint(item, true), (dialog, which) -> */
        beginPrint(item);
        //);
    }

    private void beginPrint(Adapter item) {
        if (isLoading()) return;
        showLoading(R.string.text_printing_title);
        viewButtons.setVisibility(View.GONE);

        Utils.runOnBackground(() -> {

            //NetworkResult networkResult = null;

            /*if (changeNetto) {

                networkResult = app.loadLabelInfo(item.getLabel().getId());
                if (networkResult.isOk()) {

                    JSONObject data = Utils.getJsonObject(networkResult.getJson(), "data");
                    Label label = Label.fromJson(data);
                    int pack = label == null ? item.getLabel().getWeightPack() : label.getWeightPack();

                    networkResult = app.editLabelWeight(
                            item.getLabel().getId(), item.getNettoNew(), pack,
                            Calendar.getInstance().getTime(), item.getLabel().getId()
                    );
                }
            }*/

            Utils.NetworkPrintResult printResult;

            //if (networkResult.isOk()) {
            printResult = Utils.printLabel(item.getLabel().getId());
            //} else {
            //    printResult = new Utils.NetworkPrintResult(networkResult, null);
            //}

            Utils.NetworkPrintResult finalResult = printResult;
            runOnUiThread(() -> endPrint(item, finalResult));
        });

    }

    private void endPrint(Adapter item, Utils.NetworkPrintResult result) {

        hideLoading();
        viewButtons.setVisibility(View.VISIBLE);

        if (result == null) return;

        if (result.getNetworkResult().isOk()) {

            if (result.getPrintResult().getStatus() == Printer.PrintResultStatus.OK) {
                showToast(R.string.text_print_result_succeeded);
                //app.sendFaPrint();
            } else {
                @StringRes final int message = app.getPrintResultMessage(result.getPrintResult());
                showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> beginPrint(item));
            }
        } else if (result.getNetworkResult().getStatus() == LoadResultStatus.PLUS2) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.set_label_weight_error_plus2, null);
        } else {
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result.getNetworkResult()), (dialog, which) -> beginPrint(item));
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_ADD && resultCode == RESULT_OK && data != null) {
            log("request add");

            List<String> listLabelId = data.getStringArrayListExtra("listId");
            List<String> listDateScanStr = data.getStringArrayListExtra("listDateScan");
            List<Date> listDateScan = new ArrayList<>();
            if (listDateScanStr != null) {
                for (String item : listDateScanStr) {
                    listDateScan.add(new Date(Utils.parseLong(item)));
                }
            }

            List<Integer> listNettoPlan = data.getIntegerArrayListExtra("listNettoPlan");
            List<Integer> listNettoFact = data.getIntegerArrayListExtra("listNettoFact");

            if (listLabelId != null && listDateScanStr != null && listNettoPlan != null && listNettoFact != null) {
                int packCount = listLabelId.size();
                for (int i = 0; i < packCount; i++) {
                    log("[%s] %s %d->%d", listLabelId.get(i), app.getDateTimeFormat().format(listDateScan.get(i)), listNettoPlan.get(i), listNettoFact.get(i));
                }

                beginUpload2(listLabelId, listDateScan, listNettoPlan, listNettoFact);
            }
        }

        if (requestCode == REQUEST_EDIT && resultCode == RESULT_OK && data != null) {
            Label label = (Label) data.getSerializableExtra("label");
            int nettoNew = data.getIntExtra("nettoNew", 0);
            int packNew = data.getIntExtra("packNew", 0);
            Date dateScan = (Date) data.getSerializableExtra("dateScan");
            beginUpload(label, nettoNew, packNew, dateScan, null);
        }
    }

    private void beginUpload2(List<String> listLabelId, List<Date> listDateScan, List<Integer> listNettoPlan, List<Integer> listNettoFact) {
        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);

        Utils.runOnBackground(() -> {

            int packCount = listLabelId.size();

            String url = config.getUrlApi() + "writeinventoryonline";
            url = net.addUrlParam(url, "wh_type", storage);
            url = net.addUrlParam(url, "inv_date", app.getDateFormat2().format(date));

            JsonResult result = null;
            List<LabelEditItem> labelEditItemList = new ArrayList<>();

            StringBuilder sb = new StringBuilder();
            sb.append("[");

            for (int i = 0; i < packCount; i++) {

                boolean changeNetto = (int) listNettoPlan.get(i) != (int) listNettoFact.get(i);

                if (changeNetto) {
                    result = net.loadLabelInfo(listLabelId.get(i));
                    if (!result.isOk()) break;

                    JSONObject data = Utils.getJsonObject(result.getJson(), "data");
                    Label label1 = Label.fromJson(data);
                    int packNew = label1 == null ? 0 : label1.getWeightPack();
                    labelEditItemList.add(new LabelEditItem(listLabelId.get(i), App.getInstance().getSmcIdCurrent(), listNettoFact.get(i), packNew, null, null, label1 != null && label1.isRelease()));
                }

                sb.append("{").append(Utils.format(
                        "\"Label_ID\":%s," +
                                "\"Category\":\"%s\"," +
                                "\"Location_Code\":\"%s\"," +
                                "\"Scan_Dt\":\"%s\"," +
                                "\"NETT_Weight_Label\":\"%s\"," +
                                "\"NETT_Weight_Fact\":\"%s\"",
                        listLabelId.get(i),
                        "",
                        locationCode,
                        app.getDateTimeFormat().format(listDateScan.get(i)),
                        listNettoPlan.get(i),
                        listNettoFact.get(i)
                )).append("}");

                if (i < packCount - 1) sb.append(",");
            }
            sb.append("]");

            result = net.uploadJson(url, sb.toString());

            if (result != null && result.isOk() && !labelEditItemList.isEmpty()) {
                result = app.editLabelWeight(labelEditItemList, Calendar.getInstance().getTime(), String.valueOf(app.getConfUserId()));
            }

            JsonResult finalResult = result;
            runOnUiThread(() -> endUpload2(finalResult, listLabelId, listDateScan, listNettoPlan, listNettoFact));
        });
    }

    private void endUpload2(JsonResult result, List<String> listLabelId, List<Date> listDateScan, List<Integer> listNettoPlan, List<Integer> listNettoFact) {
        hideLoading();
        viewButtons.setVisibility(View.VISIBLE);

        if (result != null && result.isOk()) {
            try {
                adapter.clear();
            } catch (Exception ignored) {

            }
            if (listLabelId.size() == 1) {
                beginLoad(listLabelId.get(0));
            } else {
                beginLoad();
            }
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginUpload2(listLabelId, listDateScan, listNettoPlan, listNettoFact));
        }
    }

    private void beginUpload(Label label, int nettoNew, int packNew, Date dateScan, List<Label> labelList) {
        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);

        Utils.runOnBackground(() -> {

            List<Label> list = getTotalList(label, labelList);

            String url = config.getUrlApi() + "writeinventoryonline";
            url = net.addUrlParam(url, "wh_type", storage);
            url = net.addUrlParam(url, "inv_date", app.getDateFormat2().format(date));

            JsonResult result = null;
            List<LabelEditItem> labelEditItemList = new ArrayList<>();

            for (Label labelItem : list) {

                boolean changeNetto = labelItem.getWeightNetto() != nettoNew
                        || labelItem.getWeightPack() != packNew;

                if (changeNetto) {
					result = net.loadLabelInfo(labelItem.getId());
                    if (!result.isOk()) break;

                    JSONObject data = Utils.getJsonObject(result.getJson(), "data");
                    Label label1 = Label.fromJson(data);
                   // int packNew = label1 == null ? 0 : label1.getWeightPack();

					labelEditItemList.add(new LabelEditItem(labelItem.getId(), App.getInstance().getSmcIdCurrent(), nettoNew, packNew, null, null, label1 != null && label1.isRelease()));
                }

                String sb = "[{" +
                        Utils.format(
                                "\"Label_ID\":%s," +
                                        "\"Category\":\"%s\"," +
                                        "\"Location_Code\":\"%s\"," +
                                        "\"Scan_Dt\":\"%s\"," +
                                        "\"NETT_Weight_Label\":\"%s\"," +
                                        "\"NETT_Weight_Fact\":\"%s\"",
                                labelItem.getId(),
                                "",
                                labelItem.getLocationCode(),
                                app.getDateTimeFormat().format(dateScan),
                                labelItem.getWeightNetto(),
                                nettoNew
                        ) +
                        "}]";
                result = net.uploadJson(url, sb);
                if (!result.isOk()) break;
            }

            if (result != null && result.isOk() && !labelEditItemList.isEmpty()) {
				result = app.editLabelWeight(labelEditItemList, Calendar.getInstance().getTime(), String.valueOf(app.getConfUserId()));
            }

            JsonResult finalResult = result;
            runOnUiThread(() -> endUpload(finalResult, label, nettoNew, packNew, dateScan, labelList));
        });
    }

    private List<Label> getTotalList(Label label, List<Label> labelList) {
        List<Label> list = new ArrayList<>();
        if (labelList == null) {
            list.add(label);
        } else {
            list.addAll(labelList);
        }
        return list;
    }

    private void endUpload(JsonResult result, Label label, int nettoNew, int packNew, Date dateScan, List<Label> labelList) {
        hideLoading();
        viewButtons.setVisibility(View.VISIBLE);

        if (result != null && result.isOk()) {

            List<Label> list = getTotalList(label, labelList);

            for (Label labelItem : list) {
                Adapter item = findItem(labelItem.getId());
                Adapter itemNew = new Adapter(labelItem, nettoNew, dateScan, labelList != null);
                if (item == null) {
                    adapter.addItem(itemNew);
                } else {
                    adapter.updateItem(itemNew);
                }
            }

            adapterChanged();

        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginUpload(label, nettoNew, packNew, dateScan, labelList));
        }
    }

    public class Adapter extends AbstractFlexibleItem<Adapter.ViewHolder> {

        private final Label label;
        private final int nettoNew;
        private String content;
        private final Date dateScan;
        private final boolean inGroup;
        private int index;

        public Adapter(Label label, int nettoNew, Date dateScan, boolean inGroup) {
            this.label = label;
            this.nettoNew = nettoNew;
            this.dateScan = dateScan;
            this.inGroup = inGroup;
            this.index = 0;

            updateContent();
        }

        private void updateContent() {
            StringBuilder sb = new StringBuilder();

            sb.append(Utils.format("%s <b>%s</b>", index + 1, label.getName()));

            String size = App.getInstance().sizeToString(label.getWidth(), label.getLength(), label.getThickness());
            if (size.length() > 0) sb.append(Utils.format("<br>%s", size));
            sb.append(Utils.format("<br>ОЗМ: %s", label.getOzm()));
            sb.append(Utils.format("<br>LabelID: %s", label.getId()));
            sb.append(Utils.format("<br>Скан: %s", App.getInstance().getDateTimeFormat().format(this.dateScan)));
            sb.append(Utils.format("<br>НЕТТО бірка, тн: %.3f", label.getWeightNetto() / 1000.0f));
            sb.append(Utils.format(
                    nettoNew != label.getWeightNetto() ? "<br>НЕТТО факт, тн: <font color=\"blue\"><b>%.3f</b></font>" : "<br>НЕТТО факт, тн: %.3f"
                    , nettoNew / 1000.0f));

            this.content = sb.toString();
        }

        public Label getLabel() {
            return label;
        }

        public Date getDateScan() {
            return dateScan;
        }

        public int getNettoNew() {
            return nettoNew;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof Adapter && ((Adapter) o).getLabel().getId().equalsIgnoreCase(getLabel().getId());
        }

        @Override
        public int hashCode() {
            return getLabel().getId().hashCode();
        }

        @Override
        public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
            return new ViewHolder(view, adapter);
        }

        @Override
        public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {
            holder.buttonDelete.setOnClickListener(v -> OnAdapterDelete(Adapter.this));
            holder.buttonEdit.setOnClickListener(v -> OnAdapterEdit(Adapter.this));
            holder.buttonPrint.setOnClickListener(v -> OnAdapterPrint(Adapter.this));
            holder.textContent.setText(App.getInstance().fromHtml(content));
            holder.buttonEdit.setVisibility(inGroup ? View.GONE : View.VISIBLE);
        }

        @Override
        public int getLayoutRes() {
            return R.layout.adapter_inv;
        }

        public void setIndex(int index) {
            this.index = index;
            updateContent();
        }

        public int getIndex() {
            return index;
        }

        public class ViewHolder extends FlexibleViewHolder {

            @BindView(R.id.textContent)
            TextView textContent;
            @BindView(R.id.buttonDelete)
            ImageButton buttonDelete;
            @BindView(R.id.buttonEdit)
            ImageButton buttonEdit;
            @BindView(R.id.buttonPrint)
            ImageButton buttonPrint;

            public ViewHolder(View view, FlexibleAdapter adapter) {
                super(view, adapter);
                ButterKnife.bind(this, view);
            }
        }
    }

    private void adapterChanged() {
        log("adapterChanged");
        refreshTitle();

        if (adapter == null) {
            textPrompt.setText(R.string.inv_scan_prompt);
            return;
        }
        List<Adapter> list = adapter.getCurrentItems();

        for (int i = 0; i < list.size(); i++) {
            Adapter item = list.get(i);
            //item.setIndex(list.size() - i - 1);
            item.setIndex(i);
            adapter.updateItem(item);
        }
    }

    private void refreshTitle() {

        StringBuilder sb = new StringBuilder();
        sb.append(Utils.format("Локація: %s", locationCode));

        if (adapter != null) {

            List<Adapter> list = adapter.getCurrentItems();

            if (!list.isEmpty()) {
                int total = 0;

                for (int i = 0; i < list.size(); i++) {
                    total += list.get(i).nettoNew;
                }

                sb.append(Utils.format(", нетто: %.3f тн", total / 1000.0f));
            }
        }

        textContentTitle.setText(sb.toString());
    }
}
