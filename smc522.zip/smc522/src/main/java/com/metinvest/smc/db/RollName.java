package com.metinvest.smc.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.metinvest.smc.App;
import com.metinvest.smc.tools.IValue;
import com.metinvest.smc.tools.Utils;

@Entity
public class RollName implements IValue {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private String ozm, matt;
    private float width, length, thickness;

    public RollName() {
    }

    @Ignore
    public RollName(long id, String ozm, String matt, float width, float length, float thickness) {
        this.id = id;
        this.ozm = ozm;
        this.matt = matt;
        this.width = width;
        this.length = length;
        this.thickness = thickness;
    }

    @Override
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getOzm() {
        return ozm;
    }

    public void setOzm(String ozm) {
        this.ozm = ozm;
    }

    @Override
    public String getName() {
        return Utils.format("%s %s", getMatt(), getSize().length() > 0 ? ("(" + getSize() + ")") : "");
    }

    public String getMatt() {
        return matt;
    }

    public void setMatt(String matt) {
        this.matt = matt;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getLength() {
        return length;
    }

    public void setLength(float length) {
        this.length = length;
    }

    public float getThickness() {
        return thickness;
    }

    public void setThickness(float thickness) {
        this.thickness = thickness;
    }

    public String getSize() {
        return App.getInstance().sizeToString(width, length, thickness);
    }

    @NonNull
    @Override
    public String toString() {
        return Utils.format("[%s] %s %s", getId(), getName(), getSize());
    }
}
