package com.metinvest.smc.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.metinvest.smc.tools.IValue;
import com.metinvest.smc.tools.Utils;

@Entity
public class Dpl implements IValue {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private long date;
    private String name;
    private String data;

    public Dpl() {
    }

    @Ignore
    public Dpl(long id, long date, String name, String data) {
        this.id = id;
        this.date = date;
        this.name = name;
        this.data = data;
    }

    @Override
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @NonNull
    @Override
    public String toString() {
        return Utils.format("[%s] %s", getId(), getName());
    }
}
