package com.metinvest.smc.ui;

import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.db.Inventory;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemLocalInventory extends AbstractFlexibleItem<AdapterItemLocalInventory.AdapterItemInventoryViewHolder> {

    private final IAdapterItemInventoryListener listener;
    private int colorActive, colorNormal;

    public interface IAdapterItemInventoryListener {
        void onEditClick(int position);

        void OnDeleteClick(int position);
    }

    private final Inventory inventory;
    private boolean active;

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public AdapterItemLocalInventory(Inventory inventory, IAdapterItemInventoryListener listener, int colorActive, int colorNormal) {
        this.inventory = inventory;
        this.listener = listener;
        this.colorActive = colorActive;
        this.colorNormal = colorNormal;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterItemLocalInventory && ((AdapterItemLocalInventory) o).getInventory().getId() == getInventory().getId();
    }

    public Inventory getInventory() {
        return inventory;
    }

    @Override
    public AdapterItemInventoryViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new AdapterItemInventoryViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemInventoryViewHolder holder, int position, List<Object> payloads) {

        holder.textTitle.setText(inventory.getMatt());

        holder.viewBg.setBackgroundColor(isActive() ? colorActive : colorNormal);

        String sb = Utils.format("LabelID: %s<br>", inventory.getLabelId() == 0 ? "-" : inventory.getLabelId()) +
                Utils.format("%s<br>", App.getInstance().sizeToString(inventory.getWidth(), inventory.getLength(), inventory.getThickness())) +
                Utils.format("Вага нетто: %d кг<br>", inventory.getNetto()) +
                Utils.format("Вага упаковки: %d кг", inventory.getPack());
        holder.textContent.setText(App.getInstance().fromHtml(sb));
        holder.buttonEdit.setOnClickListener(v -> {
            if (listener != null) listener.onEditClick(position);
        });
        holder.buttonDelete.setOnClickListener(v -> {
            if (listener != null) listener.OnDeleteClick(position);
        });
    }

    @Override
    public void unbindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemInventoryViewHolder holder, int position) {
        //empty
    }

    @Override
    public void onViewAttached(FlexibleAdapter<IFlexible> adapter, AdapterItemInventoryViewHolder holder, int position) {
        //empty
    }

    @Override
    public void onViewDetached(FlexibleAdapter<IFlexible> adapter, AdapterItemInventoryViewHolder holder, int position) {
        //empty
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_local_inventory_row;
    }

    /**
     * The ViewHolder used by this item.
     * Extending from FlexibleViewHolder is recommended especially when you will use
     * more advanced features.
     */
    public class AdapterItemInventoryViewHolder extends FlexibleViewHolder {

        private final View viewBg;

        public TextView textTitle, textContent;
        public ImageButton buttonDelete, buttonEdit;

        public AdapterItemInventoryViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.viewBg = view.findViewById(R.id.viewBg);
            this.textTitle = view.findViewById(R.id.textTitle);
            this.textContent = view.findViewById(R.id.textContent);
            this.buttonEdit = view.findViewById(R.id.buttonEdit);
            this.buttonDelete = view.findViewById(R.id.buttonDelete);
        }
    }
}
