package com.metinvest.smc.view;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.tools.ShipReasonData;
import com.metinvest.smc.tools.Utils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class ShipReasonActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

	@BindView(R.id.textCarrier)
	TextView textCarrier;
	@BindView(R.id.textContent)
	TextView textContent;
	@BindView(R.id.scrollView)
	NestedScrollView scrollView;
	@BindView(R.id.listView)
	RecyclerView listView;
	@BindView(R.id.buttonAccept)
	Button buttonAccept;

	private ShipReasonData reasonData;
	private String transportName;
	private int planTime;
	private FlexibleAdapter<Adapter> adapter;
	private List<Adapter> listItems;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ship_reason);
		ButterKnife.bind(this);

		transportName = getIntent().getStringExtra("transportName");
		reasonData = (ShipReasonData) getIntent().getSerializableExtra("reasonData");
		planTime = getIntent().getIntExtra("planTime", 0);
		listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		showContent();
	}

	private void showContent() {
		textCarrier.setText(transportName);
		//textContent.setText(getString(R.string.reason_content, reasonData.getPlan(), reasonData.getFact()));
		textContent.setText(getString(R.string.reason_content, planTime, reasonData.getFact()));
		loadList();
		refreshButtonAccept();
	}

	private void loadList() {
		listItems = new ArrayList<>();
		for (String reason : reasonData.getReasonList()) {
			listItems.add(new Adapter(reason, false, false));
		}

		updateAdapter();
	}

	private void addCustomReason(String title) {
		for (Adapter listItem : listItems) {
			if (listItem.isManual()) {
				listItems.remove(listItem);
				break;
			}
		}

		for (Adapter listItem : listItems) {
			listItem.setChecked(false);
		}

		listItems.add(0, new Adapter(title, true, true));

		updateAdapter();
		refreshButtonAccept();
	}

	private void updateAdapter() {
		adapter = new FlexibleAdapter<>(listItems);
		adapter.addListener(this);
		listView.setAdapter(adapter);
		scrollView.post(() -> scrollView.scrollTo(0, 0));
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 4) buttonManualClick();
		else if (number == 5) beginAccept();
	}

	private void buttonManualClick() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle(null);
		builder.setMessage("Вкажіть причину перевищення:");

		final EditText input = new EditText(this);
		input.setInputType(InputType.TYPE_CLASS_TEXT);
		input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);

		/*int px = Utils.dpToPx(5);
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
		params.leftMargin = px;
		params.rightMargin = px;
		input.setLayoutParams(params);*/
		builder.setView(input);

		builder.setPositiveButton(R.string.button_ok, (dialog, which) -> {
			String text = input.getText().toString();
			if (text.trim().length() > 0) addCustomReason(text);
		});
		builder.setNegativeButton(R.string.button_cancel, (dialog, which) -> dialog.cancel());

		builder.show();
	}

	@Override
	public void onBackPressed() {
		//setResult(RESULT_CANCELED);
		//super.onBackPressed();
		showToast("Необхідно вказати причину!");
	}

	private void beginAccept() {
		if (isLoading() || !buttonAccept.isEnabled()) return;

		Adapter item = getCheckedItem();
		if (item == null) return;

		accept(item);
	}

	private void accept(Adapter item) {
		Intent data = new Intent();
		data.putExtra("id", reasonData.getId());
		data.putExtra("reason", item.getTitle());
		setResult(RESULT_OK, data);
		finish();
	}

	private Adapter getCheckedItem() {
		if (adapter != null) {
			List<Adapter> list = adapter.getCurrentItems();
			for (Adapter item : list) {
				if (item.isChecked()) return item;
			}
		}
		return null;
	}

	@Override
	public boolean onItemClick(View view, int position) {
		Adapter item = adapter.getItem(position);
		if (item != null) {

			Adapter itemChecked = getCheckedItem();
			if (itemChecked != null && !itemChecked.equals(item)) {
				itemChecked.setChecked(false);
				adapter.updateItem(itemChecked);
			}

			item.setChecked(!item.isChecked());
			adapter.notifyItemChanged(position);
			refreshButtonAccept();
			return true;
		}
		return false;
	}

	private void refreshButtonAccept() {
		buttonAccept.setEnabled(getCheckedItem() != null);
	}

	public class Adapter extends AbstractFlexibleItem<Adapter.ViewHolder> {

		private final String title;
		private boolean checked;
		private final boolean manual;

		public Adapter(String title, boolean checked, boolean manual) {
			this.title = title;
			this.checked = checked;
			this.manual = manual;
		}

		public boolean isManual() {
			return manual;
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof Adapter && ((Adapter) o).getTitle().equalsIgnoreCase(getTitle());
		}

		@Override
		public int hashCode() {
			return getTitle().hashCode();
		}

		public String getTitle() {
			return title;
		}


		public boolean isChecked() {
			return checked;
		}

		public void setChecked(boolean checked) {
			this.checked = checked;
		}

		@Override
		public Adapter.ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
			return new Adapter.ViewHolder(view, adapter);
		}

		@Override
		public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, Adapter.ViewHolder holder, int position, List<Object> payloads) {
			String data = Utils.format("%s", getTitle());
			holder.textTitle.setText(App.getInstance().fromHtml(data));

			if (isEnabled()) {
				holder.imageCheck.setImageResource(isChecked() ? R.drawable.ic_checkbox_check : R.drawable.ic_checkbox_uncheck);
			} else {
				holder.imageCheck.setImageResource(isChecked() ? R.drawable.ic_checkbox_check_disabled : R.drawable.ic_checkbox_uncheck_disabled);
			}

			holder.textTitle.setTextColor(getColor(isEnabled() ? R.color.tint_black : R.color.tint_disabled));

			View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
			holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
			refreshBackground(holder, holder.itemView.isFocused());
		}

		private void refreshBackground(Adapter.ViewHolder holder, boolean hasFocus) {
			holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_background));
		}

		@Override
		public int getLayoutRes() {
			return R.layout.adapter_inc_status;
		}

		public class ViewHolder extends FlexibleViewHolder {

			@BindView(R.id.imageCheck)
			ImageView imageCheck;
			@BindView(R.id.textTitle)
			TextView textTitle;

			public ViewHolder(View view, FlexibleAdapter adapter) {
				super(view, adapter);
				ButterKnife.bind(this, view);
			}
		}
	}
}
