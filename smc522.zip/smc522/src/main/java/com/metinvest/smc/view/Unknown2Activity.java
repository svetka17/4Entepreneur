package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanIntentResult;
import com.journeyapps.barcodescanner.ScanOptions;
import com.metinvest.smc.BuildConfig;
import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.ScalesConfig;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemInUnknown;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

/**
 * Экран создания временных бирок
 * <img src="https://od.sytecs.com.ua/files/smc_doc/res/view/Unknown2Activity.png"/>
 */
public class Unknown2Activity extends MyActivity implements IScan, AdapterItemInUnknown.Listener {

    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;
    @BindView(R.id.location1)
    EditText location1;
    @BindView(R.id.location2)
    EditText location2;
    @BindView(R.id.location3)
    EditText location3;
    @BindView(R.id.textWeightCrane)
    EditText textWeightCrane;
    @BindView(R.id.textCount)
    EditText textCount;
    @BindView(R.id.textContent)
    TextView textContent;
    @BindView(R.id.textOzm)
    EditText textOzm;
    @BindView(R.id.textName)
    EditText textName;
    @BindView(R.id.textLength)
    EditText textLength;
    @BindView(R.id.textWidth)
    EditText textWidth;
    @BindView(R.id.textThickness)
    EditText textThickness;
    @BindView(R.id.buttonCrane)
    ImageButton buttonCrane;

    @BindView(R.id.buttonZeroCrane)
    ImageButton buttonZeroCrane;
    @BindView(R.id.textContentTitle)
    TextView textContentTitle;

    private String carrier, ttn;
    private int weightCrane, packCount;
    private FlexibleAdapter<AdapterItemInUnknown> adapter;

    private ActivityResultLauncher<Intent> scanLauncher;

    private byte cmd = 2;
    /*команда 1-тест(посылается в настройках), 2-взвешивание(кнопка с краном buttonCrane), 7-обнуление весов(кнопка sync buttonZeroCrane)*/

    private void scanBarcode() {
        Intent intent = new ScanContract().createIntent(
                this,
                new ScanOptions() //Builder()
                        .setPrompt("Відскануйте штрихкод або QR-код")
                        .setBeepEnabled(true)
                        .setOrientationLocked(true)
                        .setTorchEnabled(true)
                //.build()
        );
        scanLauncher.launch(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unknown2);
        ButterKnife.bind(this);

        carrier = getIntent().getStringExtra("carrier");
        ttn = getIntent().getStringExtra("ttn");

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
        listView.setLayoutManager(layoutManager);
        listView.addItemDecoration(dividerItemDecoration);

        if (!config.getUnknownLocation().isEmpty() && app.isLocationCorrect(config.getUnknownLocation())) {
            setLocationCode(config.getUnknownLocation());
        }

        buttonCrane.setOnClickListener(v -> {
                    cmd = 2;
                    loadScalesWeight((byte) 2);
                }
        );
        buttonCrane.setOnLongClickListener(v -> {
            cmd = 2;
            loadScalesWeight((byte)2);
            return true;
        });
        buttonZeroCrane.setOnClickListener(v -> {
                    cmd = 7;
                    loadScalesWeight((byte) 7);
                }
        );
        buttonZeroCrane.setOnLongClickListener(v -> {
            cmd = 7;
            loadScalesWeight((byte)7);
            return true;
        });

        textWeightCrane.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                onWeightCraneChanged(Utils.parseInt(s.toString()));
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        textCount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) onPackCountChanged(Utils.parseInt(s.toString()));
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        if (BuildConfig.DEBUG)
        {
            scanLauncher = registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result != null) {
                            ScanContract scanContract = new ScanContract();
                            ScanIntentResult intentResult = scanContract.parseResult(result.getResultCode(), result.getData());
                            if (intentResult != null) {
                                String cameraBarcode = intentResult.getContents();
                                onBarcodeEvent(cameraBarcode);
                            }
                        }
                    });

            textContentTitle.setOnClickListener(v -> {
                scanBarcode();
            });
        }

    }

    /**
     * Когда вес буртто крана меняется, обновляем текстовое поле новым значением.
     *
     * @param craneId Идентификатор крана.
     * @param value вес брутто
     */
    @Override
    protected void onCraneWeight(long craneId, int value) {
        textWeightCrane.setText(String.valueOf(value));
    }

    @Override
    protected void onScalesWeight(ScalesConfig scales, long value) {
        if (cmd == 7) {
            if ((byte) value == 1)
                textWeightCrane.setText("0");
            else
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.error_zero_scales, String.valueOf(value)), null);

        } else
            textWeightCrane.setText(String.valueOf(value));
        cmd = 2;
    }

    /**
     * Метод вызывается при ручном вводе веса брутто на кране
     *
     * @param value вес брутто
     */
    public void onWeightCraneChanged(int value) {
        weightCrane = value;
        refreshContent();
        refreshButtonAccept();
    }

    /**
     * "Если количество упаковок изменилось, то добавляем или удаляем элементы из адаптера."
     *
     * Функция вызывается при изменении количества пачек. Количество упаковок хранится в переменной
     * `packCount`. Функция вызывается с новым значением `value` в качестве параметра.
     *
     * @param value Количество пачек.
     */
    public void onPackCountChanged(int value) {
        int packCountOld = packCount;
        packCount = value;
        if (adapter != null) {
            if (packCount > packCountOld) {
                for (int i = 0; i < (packCount - packCountOld); i++) {
                    if (newItem != null) {
                        adapter.addItem(newItem);
                        newItem = null;
                    } else {
                        adapter.addItem(new AdapterItemInUnknown(packCountOld + i, "", 0, 0, this));
                    }
                }
            } else {
                List<Integer> posList = new ArrayList<>();
                for (int i = packCount; i < adapter.getItemCount(); i++) {
                    posList.add(i);
                    log("REMOVE ITEM #%d", i);
                }
                adapter.removeItems(posList);
            }
        }

        new Timer().schedule(
                new TimerTask() {
                    @Override
                    public void run() {
                        try {
                            refreshContent();
                            refreshButtonAccept();
                        } catch (Exception ignored) {

                        }
                    }
                },
                100
        );
    }

    /**
     * Проверка кода локации на корректность и обновление тестовых полей кода локации
     *
     * @param locationCode Код локации, который вы хотите установить.
     */
    public void setLocationCode(String locationCode) {
        if (app.isLocationCorrect(locationCode)) {
            String[] arr = app.fixLocation(locationCode).split("-");
            location1.setText(arr[0]);
            location2.setText(arr[1]);
            location3.setText(arr[2]);
        }
    }

    /**
     * Функция обратного вызова, которая вызывается, когда сканер считывает штрих-код.
     *
     * @param barcodeData данные штрих-кода
     */
    @Override
    public void onBarcodeEvent(String barcodeData) {
        if (isLoading()) return;

        runOnUiThread(() -> {

            ScanItem scanItem = new ScanItem(barcodeData);

            if (!scanItem.isCorrect()) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_label, null);
                return;
            }

            if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONCODE) {
                setLocationCode(scanItem.getData(0));
            } else if (scanItem.getType() == ScanItem.ScanItemType.SMC06) {
                String labelId = scanItem.getData(0);
                int netto = Utils.parseInt(scanItem.getData(6));
                int pack = Utils.parseInt(scanItem.getData(9));
                String sapOzmName = scanItem.getData(2);
                String sapOzmCode = scanItem.getData(8);
                float length = Utils.parseFloat(scanItem.getData(3));
                float width = Utils.parseFloat(scanItem.getData(4));
                float thickness = Utils.parseFloat(scanItem.getData(5));
                beginLoadLabel(labelId, sapOzmCode, sapOzmName, width, length, thickness, netto, pack);
            } else if (scanItem.getType() == ScanItem.ScanItemType.SMC07) {

            } else if (scanItem.getType() == ScanItem.ScanItemType.KOMINMET) {
                beginLoadKominmet(scanItem);
            } else if (scanItem.getType() == ScanItem.ScanItemType.ZAPOR) {
                beginLoadZapor(scanItem);
            } else if (scanItem.getType() == ScanItem.ScanItemType.TRUBOSTAL) {
                beginLoadTrubostal(scanItem);
            } else if (scanItem.getType() == ScanItem.ScanItemType.ARCELOR) {
                beginLoadArcelor(scanItem);
            }

        });
    }

    private void beginLoadZapor(ScanItem scanItem) {
        StringBuilder sb = new StringBuilder();
        try {

            String name = scanItem.getData(12);
            int netto = Utils.parseInt(scanItem.getData(10));
            int brutto = Utils.parseInt(scanItem.getData(11));
            int pack = brutto - netto;
            String batchNum = scanItem.getData(8);
            String id = Utils.format("%s&%s&%s&%s",
                    scanItem.getData(1),
                    scanItem.getData(2),
                    scanItem.getData(3),
                    scanItem.getData(4)
            );

            float[] size = Utils.parseSize(scanItem.getData(13));
            float thickness = size[0];
            float width = size[1];
            float length = size[2];

            textName.setText(name);
            textWidth.setText(width > 0 ? String.valueOf(width) : "0");
            textLength.setText(length > 0 ? String.valueOf(length) : "0");
            textThickness.setText(thickness > 0 ? String.valueOf(thickness) : "0");

            addItem(netto, pack, id);

        } catch (Exception ignored) {

        }
    }

    private void beginLoadLabel(String labelId, String sapOzmCode, String sapOzmName, float width, float length, float thickness, int netto, int pack) {

        if (textOzm.getText().length() == 0) textOzm.setText(sapOzmCode);
        if (textName.getText().length() == 0) textName.setText(sapOzmName);

        if (Utils.parseInt(textWidth.getText().toString()) == 0 &&
                Utils.parseInt(textLength.getText().toString()) == 0 &&
                Utils.parseInt(textThickness.getText().toString()) == 0) {
            textWidth.setText(width > 0 ? String.valueOf(width) : "");
            textLength.setText(length > 0 ? String.valueOf(length) : "");
            textThickness.setText(thickness > 0 ? String.valueOf(thickness) : "");
        }

        addItem(netto, pack, labelId);
    }

    private void beginLoadKominmet(ScanItem scanItem) {
        StringBuilder sb = new StringBuilder();
        try {

            String name = scanItem.getData(12);
            int netto = (int) Math.round(Utils.parseDouble(scanItem.getData(9)) /**/ * 1000);
            int pack = 0;
            String batchNum = scanItem.getData(3);
            String id = scanItem.getData(1);
            String[] size = app.stringToSize(scanItem.getData(5));

            addItem(netto, pack, id);

        } catch (Exception ignored) {

        }
    }

    private void beginLoadArcelor(ScanItem scanItem) {
        try {

            String name = "";
            int netto = 0;
            int brutto = 0;
            int pack = brutto - netto;
            String id = scanItem.getData(0);

            float thickness = 0;
            float width = 0;
            float length = 0;

            textName.setText(name);
            textWidth.setText(width > 0 ? String.valueOf(width) : "0");
            textLength.setText(length > 0 ? String.valueOf(length) : "0");
            textThickness.setText(thickness > 0 ? String.valueOf(thickness) : "0");

            addItem(netto, pack, id);

        } catch (Exception ignored) {

        }
    }

    private void beginLoadTrubostal(ScanItem scanItem) {
        try {

            String name = Utils.format("Труба %s %s", scanItem.getData(0), scanItem.getData(4));

            String id = scanItem.getData(8);

            /*float[] size = Utils.parseSize(scanItem.getData(0));
            float thickness = size[0];
            float width = size[1];
            float length = size[2];*/

            int length = Utils.parseInt(scanItem.getData(4));

            textName.setText(name);
            textWidth.setText("0");
            textLength.setText(length > 0 ? String.valueOf(length) : "0");
            textThickness.setText("0");

            addItem(0, 0, id);

        } catch (Exception ignored) {

        }
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        beginLoadList();
        onPackCountChanged(0);

        /*if (BuildConfig.DEBUG) {
            textContentTitle.setOnClickListener(v -> {
                onBarcodeEvent("Трубосталь&80х60х4&ГОСТ8639-82&Ст2пс&1211500-1&12000&08-19/21&www.trubostal.net&2000000000398&c9f28ad6-f5a6-11eb-a28f-0cc47ada5628");
            });
        }*/
    }

    /**
     * Обновляем информацию об транспорте, ТТН и кол-ве пачек
     */
    public void refreshContent() {
        textContent.setText(getString(
                R.string.text_unknown2_content,
                carrier,
                ttn,
                0,
                packCount
        ));
    }

    private AdapterItemInUnknown newItem;

    /**
     * Добавляем новую пачку.
     *
     * @param netto вес нетто
     * @param pack вес упаковки
     * @param idQr идентификатор продукта idQr
     */
    public void addItem(int netto, int pack, String idQr) {
        newItem = new AdapterItemInUnknown(packCount, idQr, pack, netto, this);
        textCount.setText(String.valueOf(packCount + 1));
    }

    private void beginLoadList() {
        Utils.runOnBackground(() -> {
            List<AdapterItemInUnknown> itemList = new ArrayList<>();
            adapter = new FlexibleAdapter<>(itemList);
            endLoadList();
        });
    }

    private void endLoadList() {
        runOnUiThread(() -> {
            listView.setAdapter(adapter);
            scrollView.post(() -> scrollView.scrollTo(0, 0));
        });
    }

    /**
     * Возвращает список элементов, находящихся в данный момент в адаптере
     *
     * @return Список объектов AdapterItemInUnknown.
     */
    private List<AdapterItemInUnknown> getItemList() {
        return adapter == null ? new ArrayList<>() : adapter.getCurrentItems();
    }

    /**
     * Возвращает сумму веса нетто всех элементов в списке
     *
     * @return Общий вес нетто
     */
    public int getItemTotalNetto() {
        int ret = 0;
        List<AdapterItemInUnknown> itemList = getItemList();
        for (AdapterItemInUnknown item : itemList) {
            ret += item.getNetto();
        }
        return ret;
    }

    /**
     * Возвращает сумму веса упаковок всех элементов в списке
     *
     * @return Общее вес упаковок
     */
    public int getItemTotalPack() {
        int ret = 0;
        List<AdapterItemInUnknown> itemList = getItemList();
        for (AdapterItemInUnknown item : itemList) {
            ret += item.getPack();
        }
        return ret;
    }

    private void refreshButtonAccept() {
        buttonAccept.setEnabled(weightCrane > 0 && packCount > 0 && getItemTotalNetto() > 0);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    /**
     * Функция вызывается, когда пользователь нажимает кнопку «Принять». Он проверяет правильность
     * локации, а затем вычисляет общий вес нетто, упаковки и брутто. Если общий нетто равен
     * нулю, отображается предупреждение. Вызывается метод печати бирок
     */
    public void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        String location = Utils.format("%s-%s-%s",
                location1.getText().toString(),
                location2.getText().toString(),
                location3.getText().toString()
        );

        if (!checkLocationPermit(location)) return;

        int totalNetto = getItemTotalNetto();
        int totalPack = getItemTotalPack();
        int totalBrutto = totalNetto + totalPack;

        if (totalNetto == 0) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.warning_birk_zero, null);
        }

        location = app.fixLocation(location);

        saveLocation(location);

        ArrayList<Integer> listNetto = new ArrayList<>();
        ArrayList<Integer> listPack = new ArrayList<>();
        ArrayList<Integer> listNettoFinal = new ArrayList<>();
        ArrayList<String> listQr = new ArrayList<>();
        for (int i = 0; i < packCount; i++) {
            AdapterItemInUnknown item = adapter.getItem(i);
            if (item != null) {
                listNettoFinal.add(item.getNetto());
                listNetto.add(item.getNetto());
                listPack.add(item.getPack());
                //if (BuildConfig.DEBUG) {
                //    listQr.add("4900&1&070&24459633");
                //} else {
                    listQr.add(item.getQr());
                //}
            }
        }

        int weightToDivide = weightCrane - totalBrutto;
        double weightExtra = 0;

        for (int i = 0; i < packCount; i++) {

            double weightToAdd = 0;

            if (weightToDivide != 0) {
                double itemPercent = totalNetto == 0 ? 0 : (double) listNetto.get(i) * 100 / totalNetto;
                weightToAdd = itemPercent * weightToDivide / 100.0f;
            }

            weightExtra += weightToAdd - (int) weightToAdd;
            listNettoFinal.set(i, listNetto.get(i) + (int) weightToAdd);
        }

        weightExtra = Math.round(weightExtra);

        log("weightExtra: %.3f", weightExtra);

        if (Math.abs(weightExtra) > 0) {
            int i = 0;
            while (Math.abs(weightExtra) >= 1.0f) {
                listNettoFinal.set(i, listNettoFinal.get(i) + (weightExtra > 0 ? 1 : -1));
                weightExtra -= (weightExtra > 0 ? 1 : -1);
                i = i == listNettoFinal.size() - 1 ? 0 : i + 1;
            }
        }

        log("weightExtra: %.3f", weightExtra);

        beginAccept(location, listNetto, listPack, listNettoFinal, listQr);
    }

    private float getLength() {
        return Utils.parseFloat(textLength.getText().toString());
    }

    private float getWidth() {
        return Utils.parseFloat(textWidth.getText().toString());
    }

    private float getThickness() {
        return Utils.parseFloat(textThickness.getText().toString());
    }

    /**
     * Метод для отправки новых бирок на сервер
     *
     * @param location код локации
     * @param listNetto список весов нетто
     * @param listPack список веса упаковки
     * @param listNettoFinal список весов нетто итоговый
     * @param listQr список QR-кодов
     */
    public void beginAccept(String location, ArrayList<Integer> listNetto, ArrayList<Integer> listPack, ArrayList<Integer> listNettoFinal, ArrayList<String> listQr) {
        buttonAccept.setEnabled(false);
        showLoading(R.string.text_please_wait);

        String ozm = getOzmCode();
        String name = getOzmName();
        float length = getLength();
        float width = getWidth();
        float thickness = getThickness();

        Utils.runOnBackground(() -> {

            String url = config.getUrlApi() + "rollout";
            url = net.addUrlParam(url, "location", location);

            JsonResult result;
            List<String> listLabelId = new ArrayList<>();

            StringBuilder sb = new StringBuilder();

            sb.append("[");

            for (int i = 0; i < packCount; i++) {

                sb.append(Utils.format("{%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n}"
                        , Utils.format("\"SAP_Matt_Descr\" : %s,", Utils.quoteJsonString(name))
                        , Utils.format("\"SAP_Ozm\" : \"%s\",", ozm)
                        , Utils.format("\"SAP_Batch\" : \"%s\",", "TEMP")
                        , Utils.format("\"SAP_Weight_NETT\" : \"%s\",", listNettoFinal.get(i))
                        , Utils.format("\"Length\" : \"%s\",", length)
                        , Utils.format("\"Width\" : \"%s\",", width)
                        , Utils.format("\"Thickness\" : \"%s\",", thickness)
                        , Utils.format("\"Pack_Weight\" : \"%s\",", listPack.get(i))
                        , Utils.format("\"Nett_Weight\" : \"%s\",", listNettoFinal.get(i))
                        , Utils.format("\"TTN_CARIER_ID\" : %s,", Utils.quoteJsonString(carrier))
                        , Utils.format("\"TTN_NUM\" : %s,", Utils.quoteJsonString(ttn))
                        , Utils.format("\"ID_QR\" : \"%s\",", listQr.get(i))
                        , "\"External_Id\" : null"
                ));

                if (i + 1 < packCount) sb.append(",");

            }

            sb.append("]");

            result = net.uploadJson(url, sb.toString());

            if (result.isOk()) {
                JSONArray jsonArray = Utils.getJsonArray(result.getJson(), "data");
                for (int i = 0; jsonArray != null && i < jsonArray.length(); i++) {
                    String labelId = Utils.getJsonString(jsonArray, i);
                    listLabelId.add(labelId == null ? "" : labelId);
                }
            }

            runOnUiThread(() -> endAccept(result, location, listNetto, listPack, listNettoFinal, listQr, listLabelId));
        });
    }

    private String getOzmCode() {
        return textOzm.getText().toString();
    }

    private String getOzmName() {
        return textName.getText().toString();
    }

    /**
     * Результат создания бирок на сервере
     *
     * @param result результат запроса
     * @param location код локации
     * @param listNetto список значений нетто
     * @param listPack список веса упаковок
     * @param listNettoFinal список занчений нетто итоговый.
     * @param listQr список QR-кодов
     * @param labelIds список идентификаторов этикеток для печати
     */
    public void endAccept(JsonResult result, String location, ArrayList<Integer> listNetto, ArrayList<Integer> listPack, ArrayList<Integer> listNettoFinal, ArrayList<String> listQr, List<String> labelIds) {

        hideLoading();
        buttonAccept.setEnabled(false);

        if (result.isOk()) {
            beginPrint(location, listNetto, listPack, listNettoFinal, listQr, labelIds);
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginAccept(location, listNetto, listPack, listNettoFinal, listQr));
        }
    }

    /**
     * Сохраняем код локации в файле конфигурации.
     *
     * @param location код локации.
     */
    public void saveLocation(String location) {
        config.setUnknownLocation(location);
        config.saveConfig();
    }

    /**
     * Метод печати этикеток
     *
     * @param location код локации
     * @param listNetto список значений нетто
     * @param listPack список веса упаковок
     * @param listNettoFinal список занчений нетто итоговый.
     * @param listQr список QR-кодов
     * @param labelIds список идентификаторов этикеток для печати
     */
    public void beginPrint(String location, ArrayList<Integer> listNetto, ArrayList<Integer> listPack, ArrayList<Integer> listNettoFinal, ArrayList<String> listQr, List<String> labelIds) {

        buttonAccept.setEnabled(false);
        showLoading(R.string.text_printing_title);

        String name = getOzmName();

        Utils.runOnBackground(() -> {

            StringBuilder dplName = new StringBuilder("<b>Тимчасова бірка</b><br>");
            dplName.append(Utils.format("Назва: %s кг.<br>", name.length() > 0 ? name : "-"));
            dplName.append(Utils.format("Вага з крану: %s кг.<br>", weightCrane));
            dplName.append(Utils.format("Кількість позицій: %s<br>", packCount));
            for (int i = 0; i < packCount; i++) {
                dplName.append(Utils.format("Позиція №%s: %s кг", i + 1, listNetto.get(i)));
                if (i + 1 < packCount) dplName.append("<br>");
            }

            StringBuilder data = new StringBuilder();

            for (int i = 0; i < packCount; i++) {

                data.append(generateItem(location,
                        listNettoFinal.get(i) + listPack.get(i),
                        listNetto.get(i),
                        listPack.get(i),
                        labelIds.get(i),
                        listQr.get(i))
                );

            }
            final Printer.PrintResult result = Printer.sendCommand(dplName.toString(), config.getPrinter(), data.toString());
            if (result.getStatus() == Printer.PrintResultStatus.OK)
            {
                String url = config.getUrlApi() + "setPrintLabel";
                StringBuilder sb = new StringBuilder();
                sb.append("[");

                for (int i = 0; i < labelIds.size(); i++) {
                    sb.append(Utils.format("%s", labelIds.get(i) ));
                    if (i + 1 < labelIds.size()) sb.append(",");
                }

                sb.append("]");
                //если успешно напечатано, то в labels обновляем printLabel = 2 по label_id
                JsonResult resultPrintLabel = net.uploadJson(url, sb.toString(), 0);
            }
            runOnUiThread(() -> endPrint(result, location, listNetto, listPack, listNettoFinal, listQr, labelIds));
        });
    }

    /**
     * Результат печати этикеток
     *
     * @param result Результат операции печати.
     * @param location код локации
     * @param listNetto список значений нетто
     * @param listPack список веса упаковок
     * @param listNettoFinal список занчений нетто итоговый.
     * @param listQr список QR-кодов
     * @param labelIds список идентификаторов этикеток для печати
     */
    public void endPrint(Printer.PrintResult result, String location, ArrayList<Integer> listNetto, ArrayList<Integer> listPack, ArrayList<Integer> listNettoFinal, ArrayList<String> listQr, List<String> labelIds) {
        buttonAccept.setEnabled(true);
        hideLoading();

        if (result.getStatus() == Printer.PrintResultStatus.OK) {
            showToast(R.string.text_print_result_succeeded);
            //setResult(RESULT_OK);
            //finish();
            textCount.setText("");
            //onPackCountChanged(0);
            //app.sendFaPrint(packCount);
        } else {
            @StringRes final int message = app.getPrintResultMessage(result);

            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> {
                dialog.dismiss();
                beginPrint(location, listNetto, listPack, listNettoFinal, listQr, labelIds);
            });
        }
    }

    /**
     * Генерация DPL/ZPL строки этикетки для принтера
     *
     * @param location код локации
     * @param wCrane вес на кране
     * @param wNetto чистый нетто
     * @param wPack вес упаковки
     * @param labelId идентификатор этикетки
     * @param idQr QR код
     * @return строка DPL/ZPL
     */
    public String generateItem(String location, int wCrane, int wNetto, int wPack, String labelId, String idQr) {

        String ozm = getOzmCode();
        String name = getOzmName();

        return app.generateDplUnknown(
                Calendar.getInstance().getTime(),
                wCrane,
                carrier, name, ozm,
                getWidth(), getLength(), getThickness(),
                wNetto, wPack, 0,
                location, labelId, ttn, idQr);
    }

    @Override
    public void onNettoChanged(AdapterItemInUnknown item) {
        refreshButtonAccept();
        refreshContent();
    }

    @Override
    public void onPackChanged(AdapterItemInUnknown item) {
        refreshButtonAccept();
        refreshContent();
    }
}
