package com.metinvest.smc.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.metinvest.smc.tools.IValue;

@Entity
public class ShipmentItemLoc implements IValue {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private long itemId;
    private String location;
    private int sumWeight;

    private String sapBatch;

    private String divLabel;

    public ShipmentItemLoc() {
    }

    @Ignore
    public ShipmentItemLoc(long id, long itemId, String location, int sumWeight, String sapBatch, String divLabel) {
        this.id = id;
        this.itemId = itemId;
        this.location = location;
        this.sumWeight = sumWeight;
        this.sapBatch = sapBatch;
        this.divLabel = divLabel;
    }

    public String getSapBatch() {
        return sapBatch;
    }

    public void setSapBatch(String sapBatch) {
        this.sapBatch = sapBatch;
    }

    public String getDivLabel() {
        return divLabel;
    }

    public void setDivLabel(String divLabel) {
        this.divLabel = divLabel;
    }
    @Override
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getItemId() {
        return itemId;
    }

    public void setItemId(long itemId) {
        this.itemId = itemId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getSumWeight() {
        return sumWeight;
    }

    public void setSumWeight(int sumWeight) {
        this.sumWeight = sumWeight;
    }

    @Override
    public String getName() {
        return getLocation();
    }

    @NonNull
    @Override
    public String toString() {
        return getLocation();
    }
}
