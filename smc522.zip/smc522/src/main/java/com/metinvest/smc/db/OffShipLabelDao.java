package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface OffShipLabelDao {

    @Query("SELECT * FROM offshiplabel ORDER BY id DESC")
    List<OffShipLabel> getAll();

    @Query("SELECT * FROM offshiplabel WHERE labelId = :labelId ORDER BY id")
    List<OffShipLabel> getByLabelAll(String labelId);

    @Query("SELECT * FROM offshiplabel WHERE labelId = :labelId ORDER BY id LIMIT 1")
    OffShipLabel getByLabel(String labelId);

    @Query("SELECT DISTINCT labelId FROM offshiplabel")
    List<String> getAllLabels();

    @Query("SELECT SUM(nettoBefore - nettoAfter) FROM offshiplabel WHERE labelId = :labelId")
    int getTotalLabelShipped(String labelId);

    @Query("SELECT MIN(nettoBefore) FROM offshiplabel WHERE labelId = :labelId")
    int getLabelNettoOrig(String labelId);

    @Query("SELECT count(1) FROM offshiplabel")
    long getCount();

    @Query("SELECT * FROM offshiplabel WHERE id = :id")
    OffShipLabel getById(long id);

    @Insert
    long insert(OffShipLabel offShipLabel);

    @Insert
    void insertAll(List<OffShipLabel> offShipLabel);

    @Update
    void update(OffShipLabel offShipLabel);

    @Delete
    void delete(OffShipLabel offShipLabel);

    @Query("DELETE FROM offshiplabel")
    void truncate();
}