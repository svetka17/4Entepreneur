package com.metinvest.smc.view;

import static com.metinvest.smc.tools.Utils.parseInt;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanIntentResult;
import com.journeyapps.barcodescanner.ScanOptions;
import com.metinvest.smc.BuildConfig;
import com.metinvest.smc.R;
import com.metinvest.smc.db.ShipmentItem;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.FindOzmStatus;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.LabelEditItem;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.ScalesConfig;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemShipLabel;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class ShipAddActivity extends MyActivity implements AdapterItemShipLabel.IAdapterItemLabelListener, IScan {

    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.textWeightOut)
    TextView textWeightOut;

    @BindView(R.id.textWeightNeed)
    TextView textWeightNeed;

    @BindView(R.id.textWeightCraneBrutto)
    EditText textWeightCraneBrutto;
    @BindView(R.id.textWeightCranePack)
    EditText textWeightCranePack;
    @BindView(R.id.textWeightSumBrutto)
    TextView textWeightSumBrutto;

    @BindView(R.id.imagePrinter)
    ImageView imagePrinter;
    @BindView(R.id.textWarning)
    TextView textWarning;

    @BindView(R.id.frameButtonAccept)
    View frameButtonAccept;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;

    @BindView(R.id.viewAdd)
    View viewAdd;
    @BindView(R.id.viewAddTheor)
    View viewAddTheor;
    @BindView(R.id.viewAddFact)
    View viewAddFact;
    @BindView(R.id.textLabelIdFact)
    EditText textLabelIdFact;
    @BindView(R.id.buttonCrane)
    ImageButton buttonCrane;

    @BindView(R.id.buttonZeroCrane)
    ImageButton buttonZeroCrane;

    @BindView(R.id.textName)
    TextView textName;
    private String tempStorage;

    private ShipmentItem shipmentItem;
    private List<ShipmentItem> shipmentItemsExtra;
    private Date date;

    private boolean soh;
    private String smcIdSoh;
    private FlexibleAdapter<AdapterItemShipLabel> adapter;
    private AdapterItemShipLabel itemTheor;
    private List<Label> theorLabels = null;
    //private List<Label> listToPrintSoh = null;
    private boolean isTheorWeight;

    private boolean canAddLabel = true;
    private boolean accepted = false;
    private String labelRest = null;
    private boolean isSchipAll = false;

    private ActivityResultLauncher<Intent> scanLauncher;

    private void scanBarcode() {
        Intent intent = new ScanContract().createIntent(
                this,
                new ScanOptions() //Builder()
                        .setPrompt("Відскануйте штрихкод або QR-код")
                        .setBeepEnabled(true)
                        .setOrientationLocked(true)
                        .setTorchEnabled(true)
                //.build()
        );
        scanLauncher.launch(intent);
    }
    class LabelPrintSoh {
    String labelId;
    boolean soh;
        public LabelPrintSoh(String labelId, boolean soh) {
            this.labelId = labelId;
            this.soh = soh;
        }
        public String getLabelId() {
            return labelId;
        }
        public void setLabelId(String labelId) {
            this.labelId = labelId;
        }
        public boolean isSoh() {
            return soh;
        }
        public void setSoh(boolean soh) {
            this.soh = soh;
        }

        @Override
        public boolean equals(@Nullable Object obj) {
            if (obj == null) return false;
            if (obj == this) return true;
            if (!(obj instanceof LabelPrintSoh)) return false;
            LabelPrintSoh o = (LabelPrintSoh) obj;
            return (o.labelId == this.labelId) && (o.soh == this.soh);
        }
    }
    private List<LabelPrintSoh> labelToPrintSoh = null;
    private byte cmd = 2;
    /*команда 1-тест(посылается в настройках), 2-взвешивание(кнопка с краном buttonCrane), 7-обнуление весов(кнопка sync buttonZeroCrane)*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ship_add);
        ButterKnife.bind(this);
        tempStorage = config.getStorage();
        date = (Date) getIntent().getSerializableExtra("date");
        soh = (Boolean) getIntent().getSerializableExtra("soh");
        if (getIntent().hasExtra("smcIdSoh")) {
            smcIdSoh = (String) getIntent().getStringExtra("smcIdSoh");
        } else {
            smcIdSoh = "";
        }
        long itemId = getIntent().getLongExtra("itemId", 0);
        if (itemId == 0) {
            finish();
            return;
        }
        shipmentItem = db.shipmentItemDao().getById(itemId);
        if (shipmentItem == null) {
            finish();
            return;
        }

        textName.setText(shipmentItem.getSapMattDescr());

        shipmentItemsExtra = new ArrayList<>();
        ArrayList<Long> anotherList = (ArrayList<Long>) getIntent().getSerializableExtra("anotherList");
        if (anotherList != null) {
            for (Long aLong : anotherList) {
                shipmentItemsExtra.add(db.shipmentItemDao().getById(aLong));
            }
        }

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        adapter = new FlexibleAdapter<>(null);
        adapter.addListener(this);
        listView.setAdapter(adapter);

        textWeightNeed.setText(Utils.format("%d", shipmentItem.getSapWeightNett() - shipmentItem.getSapWeightNettFact()));

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                checkWeight();
            }
        };

        textWeightCraneBrutto.addTextChangedListener(textWatcher);
        textWeightCranePack.addTextChangedListener(textWatcher);

        textContentTitle.setText(shipmentItem.getTransportName());

        viewAddFact.setVisibility(View.GONE);
        viewAddTheor.setVisibility(View.GONE);


        if (getIntent().getBooleanExtra("isTheorWeight", false)) {
            setTheor(true);
        }

        buttonCrane.setOnClickListener(v -> {
            cmd = 2;
            loadScalesWeight((byte) 2);
                }
        );
        buttonCrane.setOnLongClickListener(v -> {
            cmd = 2;
            loadScalesWeight((byte)2);
            return true;
        });
        buttonZeroCrane.setOnClickListener(v -> {
            cmd = 7;
            loadScalesWeight((byte) 7);
                }
        );
        buttonZeroCrane.setOnLongClickListener(v -> {
            cmd = 7;
            loadScalesWeight((byte)7);
            return true;
        });
        if (BuildConfig.DEBUG)
        {
            scanLauncher = registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result != null) {
                            ScanContract scanContract = new ScanContract();
                            ScanIntentResult intentResult = scanContract.parseResult(result.getResultCode(), result.getData());
                            if (intentResult != null) {
                                String cameraBarcode = intentResult.getContents();
                                onBarcodeEvent(cameraBarcode);
                            }
                        }
                    });

            textContentTitle.setOnClickListener(v -> {
                scanBarcode();
            });
        }
    }

    @Override
    protected void onScalesWeight(ScalesConfig scales, long value) {
        setWeightCraneBrutto(value);
    }

    private void setWeightCraneBrutto(long value) {
        if (cmd == 7){
            if ((byte)value == 1)
                textWeightCraneBrutto.setText("0");
            else
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.error_zero_scales, String.valueOf(value)), null);

        } else
            textWeightCraneBrutto.setText(String.valueOf(value));
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        String labelId = getIntent().getStringExtra("labelId");
        boolean flagScan = false;
        if (getIntent().hasExtra("flagScan")) {
            flagScan = (Boolean) getIntent().getSerializableExtra("flagScan");
        }

        if (isTheorWeight) {
            beginAddTheorZero(labelId);
        } else {
            beginAddLabel(labelId, flagScan);
        }
    }

    private void beginAddTheorZero(String labelId) {
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            JsonResult result = net.loadLabelInfo(shipmentItem.getSmcId(), labelId);
            JSONObject json = Utils.getJsonObject(result.getJson(), "data");
            Label label = Label.fromJson(json);
            List<Label> labelList = null;

            if (result.isOk() && json != null && label != null) {
                String scannedLocationId = Utils.getJsonStringIgnoreCase(json, "location_id");
                Network.NetworkResultValue<String> resultValue = net.getLocationCodeNet(scannedLocationId);

                if (resultValue.isOk()) {
                    String locationCode = resultValue.getValue();
                    label.setId(labelId);
                    label.setLocationCode(locationCode);

                    //
                    String url = config.getUrlApi() + "getlocationinfo2";
                    url = net.addUrlParam(url, "location_code", locationCode);
                    url = net.addUrlParam(url, "ozm", label.getOzm());
                    url = net.addUrlParam(url, "length", String.valueOf(label.getLength()));
                    url = net.addUrlParam(url, "width", String.valueOf(label.getWidth()));
                    url = net.addUrlParam(url, "thickness", String.valueOf(label.getThickness()));
                    url = net.addUrlParam(url, "nett_weight", String.valueOf(label.getWeightNetto()));
                    url = net.addUrlParam(url, "teor_weight", "1");

                    result = net.downloadJson(url);
                    if (result.isOk()) {
                        JSONObject jsonData = Utils.getJsonObject(result.getJson(), "data");
                        JSONArray array = Utils.getJsonArray(jsonData, "labels");
                        labelList = new ArrayList<>();
                        if (array != null) {
                            for (int i = 0; i < array.length(); i++) {
                                String itemLabelId = Utils.getJsonString(array, i);
                                if (itemLabelId != null && itemLabelId.length() > 0) {
                                    Label labelTemp = label.copyLabel(itemLabelId);

                                    if (labelTemp != null && labelTemp.isTheor()
                                            && labelTemp.getOzm().equalsIgnoreCase(label.getOzm())
                                            && labelTemp.getWeightNetto() == label.getWeightNetto()
                                            && labelTemp.getLength() == label.getLength()
                                            && labelTemp.getWidth() == label.getWidth()
                                            && labelTemp.getThickness() == label.getThickness()
                                    ) {
                                        labelList.add(labelTemp);
                                    }
                                }


                            }
                        }
                    }
                    //

                } else {
                    result = resultValue.getResult();
                    label = null;
                }
            }

            JsonResult finalResult = result;
            Label finalLabel = label;
            List<Label> finalLabelList = labelList;
            runOnUiThread(() -> endAddTheorZero(labelId, finalResult, finalLabel, finalLabelList));
        });
    }

    private void endAddTheorZero(String labelId, JsonResult result, Label label, List<Label> labelList) {
        hideLoading();

        if (result.isOk() && label != null) {
            this.theorLabels = labelList;
            this.itemTheor = new AdapterItemShipLabel(label, null, soh, false);
            onAdapterChanged();
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginAddTheorZero(labelId));
        }
    }

    private void beginAddLabel(String labelId, boolean flagScan) {
        if (soh && adapter.getCurrentItems().size() >= 1) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_one_label_soh, null);
            //return;
        }
        else
            beginAddLabel(labelId, false, false, flagScan);
    }

    private void beginAddLabel(String labelId, boolean ignoreWarning, boolean ignoreLength, boolean flagScan) {

        if (findLabel(labelId) >= 0) {
            Toast.makeText(this, R.string.label_already_added, Toast.LENGTH_SHORT).show();
            return;
        }

        List<String> list = new ArrayList<>();
        list.add(labelId);
        beginAddLabel(list, ignoreWarning, ignoreLength, flagScan);
    }

    private void beginAddLabel(List<String> labelIdList, boolean ignoreWarning, boolean ignoreLength, boolean flagScan) {
        if (isLoading() || labelIdList.isEmpty()) return;

        showLoading(R.string.text_please_wait);
        viewAdd.setVisibility(View.GONE);

        Utils.runOnBackground(() -> {

            JsonResult result = null;
            List<String> locationList = new ArrayList<>();
            List<JSONObject> listJson = new ArrayList<>();

            for (String labelId : labelIdList) {
                result = net.loadLabelInfo(shipmentItem.getSmcId(), labelId);

                if (result.isOk()) {
                    listJson.add(Utils.getJsonObject(result.getJson(), "data"));
                    String locationId = Utils.getJsonStringIgnoreCase(Utils.getJsonObject(result.getJson(), "data"), "location_id");
                    locationList.add(net.getLocationCode(locationId));
                } else {
                    break;
                }
            }

            JsonResult finalResult = result;
            runOnUiThread(() -> endLoadLabel(finalResult, labelIdList, locationList, listJson, ignoreWarning, ignoreLength, flagScan));
        });
    }

    private void endLoadLabel(JsonResult result, List<String> labelIdList, List<String> locationList, List<JSONObject> listJson, boolean ignoreWarning, boolean ignoreLength, boolean flagScan) {
        hideLoading();
        viewAdd.setVisibility(View.VISIBLE);

        if (result.isOk()) {

            if (!listJson.isEmpty()) {

                for (int i = 0; i < listJson.size(); i++) {

                    JSONObject json = listJson.get(i);
                    String labelId = labelIdList.get(i);
                    String locationCode = locationList.get(i);

                    Label label = Label.fromJson(json);
                    if (label == null) return;
                    label.setId(labelId);
                    label.setLocationCode(locationCode);

                    if (labelIdList.size() == 1 && label.isTemp()) {
                        showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_ship_label_temp, null);
                        return;
                    }

                    if (labelIdList.size() == 1 && label.getWeightNetto() <= 0) {
                        showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.ship_label_netto_zero, null);
                        return;
                    }

                    if (labelIdList.size() == 1 && isTheorWeight && getItemZero() != null && label.getWeightNetto() != getItemZero().getLabel().getWeightNetto()) {
                        showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.ship_label_netto_invalid, null);
                        return;
                    }

                    if (labelIdList.size() == 1 && !config.isEo() && !config.getStorage().equalsIgnoreCase(label.getStorage()) && !label.getStorage().contains("0001")) {
                        showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.label_wrong_storage, label.getStorage()), null);
                        return;
                    }

                    AdapterItemShipLabel itemZero = getItemZero();

                    if (itemZero != null && getLabelCount() > 0) {

                        if (label.isTheor() != isTheorWeight) {
                            return;
                        }

                        FindOzmStatus findStatus = getOzmStatus(label.getOzm(), label.getWidth(), label.getLength(), label.getThickness(), ignoreLength);

                        if (findStatus == FindOzmStatus.ERROR_LENGTH) {
                            showDialogConfirm(R.string.text_warning, R.string.ship_ozm_size_length_not_found, (dialog, which) -> beginAddLabel(labelId, ignoreWarning, true, flagScan));
                            return;
                        } else if (findStatus == FindOzmStatus.ERROR_SIZE) {
                            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.ship_ozm_size_not_found, null);
                            return;
                        } else if (findStatus == FindOzmStatus.NOT_FOUNT) {
                            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.ship_ozm_not_found, null);
                            return;
                        }
                    }

                    setTheor(label.isTheor());
                    AdapterItemShipLabel item = new AdapterItemShipLabel(label, this, soh, flagScan);

                    if (!addLabel(item)) {
                        break;
                    }
                }
            }

        } else if (result.getStatus() == LoadResultStatus.ZERO) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.labelid_not_found, null);
        } else if (result.getStatus() == LoadResultStatus.S007) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_s007, null);
        } else {
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginAddLabel(labelIdList, ignoreWarning, ignoreLength, flagScan));
        }

    }

    private FindOzmStatus getOzmStatus(String ozm, float width, float length, float thickness, boolean ignoreLength) {

        AdapterItemShipLabel itemZero = getItemZero();
        if (itemZero == null) return FindOzmStatus.NOT_FOUNT;

        if (itemZero.getLabel().getOzm().equalsIgnoreCase(ozm)) {

            if (itemZero.getLabel().getWidth() == width &&
                    itemZero.getLabel().getThickness() == thickness) {
                if (itemZero.getLabel().getLength() == length || ignoreLength)
                    return FindOzmStatus.OK;
                else
                    return FindOzmStatus.ERROR_LENGTH;
            } else {
                return FindOzmStatus.ERROR_SIZE;
            }
        }

        return FindOzmStatus.NOT_FOUNT;
    }

    private boolean addLabel(AdapterItemShipLabel item) {
        if (!canAddLabel) return false;
        //removeAddItem();
        adapter.addItem(item);
        onAdapterChanged();
        return true;
    }

    private void setTheor(boolean value) {
        isTheorWeight = value;
        textWeightCraneBrutto.setEnabled(!isTheorWeight);
        textWeightCranePack.setEnabled(!isTheorWeight);
        //textWeightCraneBrutto.setText("0");

        viewAddFact.setVisibility(isTheorWeight ? View.GONE : View.VISIBLE);
        viewAddTheor.setVisibility(isTheorWeight ? View.VISIBLE : View.GONE);
    }

    private int getLabelRestNetto() {
        int itemCount = finalList.size();

        if (itemCount == 0) return 0;

        FinalStruct data = finalList.get(itemCount - 1);
        ShipmentItem shipItem = getAllShipItems().get(data.shipmentIndex);
        int res = data.label.getLabel().getWeightNetto() - data.labelNettoSet;

        return res;
    }

    private int getLabelTotalNetto() {
        int value = 0;

        for (AdapterItemShipLabel item : adapter.getCurrentItems()) {
            value += item.getLabel().getWeightNetto();
        }
        return value;
    }

    private int getLabelTotalPack() {
        int value = 0;

        for (AdapterItemShipLabel item : adapter.getCurrentItems()) {
            value += item.getLabel().getWeightPack();
        }
        return value;
    }

    private void onAdapterChanged() {

        int totalLabelPack = getLabelTotalPack();
        int totalLabelNetto = getLabelTotalNetto();
        textWeightCranePack.setText(Utils.format("%d", totalLabelPack));
        textWeightCraneBrutto.setText(Utils.format("%d", totalLabelNetto + totalLabelPack));
        textWeightSumBrutto.setText(Utils.format("%d", totalLabelNetto + totalLabelPack));

        checkWeight();
        scrollView.post(() -> scrollView.scrollTo(0, 0));
        textWeightCraneBrutto.post(() -> {
            textWeightCraneBrutto.selectAll();
            textWeightCraneBrutto.requestFocus();
        });
    }

    private AdapterItemShipLabel getItemZero() {
        if (isTheorWeight) return itemTheor;
        List<AdapterItemShipLabel> list = adapter.getCurrentItems();
        return list.isEmpty() ? null : list.get(0);
    }

    private int getLabelCount() {
        int c = 0;
        List<AdapterItemShipLabel> list = adapter.getCurrentItems();
        for (int i = 0; i < list.size(); i++) {
            c++;
        }
        return c;
    }

    @Override
    public void onDeleteClicked(AdapterItemShipLabel item) {

        if (accepted) return;

        if (getLabelCount() == 1 && !isTheorWeight && !soh) {
            Intent intent = new Intent();
            setResult(RESULT_OK, intent);
            finish();
            //showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.cant_remove_last_label, null);
            return;
        }

        int index = findLabel(item.getLabel().getId());
        if (index >= 0) {
            adapter.removeItem(index);
            onAdapterChanged();
        }
    }

    @Override
    public void onSplitClicked(AdapterItemShipLabel item) {
        if (accepted) return;

        Intent intent = new Intent(this, SplitActivity.class);
        intent.putExtra("labelId", item.getLabel().getId());
        intent.putExtra("weight", item.getLabel().getWeightNetto());
        startActivityForResult(intent, REQUEST_SPLIT);
    }

    @Override
    public void onSOHClicked(AdapterItemShipLabel item) {
        if (accepted) return;

        Intent intent = new Intent(this, SOHActivity.class);
        intent.putExtra("labelId", item.getLabel().getId());
        intent.putExtra("weight", item.getLabel().getWeightNetto());
        startActivityForResult(intent, REQUEST_SPLIT);
    }

    private int findLabel(String labelId) {
        List<AdapterItemShipLabel> list = adapter.getCurrentItems();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getLabel().getId().equalsIgnoreCase(labelId)) {
                return i;
            }
        }
        return -1;
    }

    private AdapterItemShipLabel findLabelItem(String labelId) {
        List<AdapterItemShipLabel> list = adapter.getCurrentItems();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getLabel().getId().equalsIgnoreCase(labelId)) {
                return list.get(i);
            }
        }
        return null;
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {
        if (isLoading() || accepted) return;

        runOnUiThread(() -> {

            ScanItem scanItem = new ScanItem(barcodeData);

            if (!scanItem.isCorrect()) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_label, null);
                return;
            }

            if (scanItem.getType() == ScanItem.ScanItemType.LABELID) {
                    beginAddLabel(scanItem.getData(0), true);
            }

            if (scanItem.getType() == ScanItem.ScanItemType.SMC06) {
                    beginAddLabel(scanItem.getData(0), true);
            }

            if (scanItem.getType() == ScanItem.ScanItemType.SMC07) {
                checkIsUnknown(scanItem);
            }
        });
    }

    @Override
    protected void onIsUnknown(ScanItem scanItem, boolean unknown, Label label) {
        if (unknown) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_ship_label_temp, null);
        } else {
            beginAddLabel(label.getId(), false);
        }
    }

    private ArrayList<String> getLabelIdList() {

        ArrayList<String> list = new ArrayList<>();

        for (AdapterItemShipLabel item : adapter.getCurrentItems()) {
            list.add(item.getLabel().getId());
        }

        return list;
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) buttonAcceptClick();
    }

    private void buttonAcceptClick() {
        if (isLoading() || frameButtonAccept.getVisibility() != View.VISIBLE || !buttonAccept.isEnabled())
            return;

        beginAccept(true);
    }

    private void beginAccept() {
        beginAccept(false);
    }

    private void beginAccept(boolean allowWarning) {

        if (adapter.isEmpty()) return;

        finalCraneBrutto = parseInt(textWeightCraneBrutto.getText().toString());
        if (finalCraneBrutto == 0 && !isTheorWeight) return;

        if (allowWarning && !finalAllowPercent && finalCraneBrutto > getLabelTotalNetto() + getLabelTotalPack()) {
            showDialogConfirm(R.string.text_confirm, getString(R.string.ship_to_large_weight_diff), "Все вірно", "Відміна", (dialog, which) -> beginAccept(false), null);
            return;
        }

        isSchipAll = false;
        int rest = getLabelRestNetto();
        if (finalAllowPercent && rest > 0) {
            if (config.isPrintLabelRestShip()) {
                String msg = Utils.format("Маркувати залишок %d кг чи обнулити?", rest);
                showDialogConfirm(R.string.text_warning, msg,
                        "Обнулити",
                        "Маркувати",
                        (dialog, which) -> ShipAll(),
                        (dialog, which) -> AddSapShipmentItem(false));
            } else {
                AddSapShipmentItem(true);
            }
        } else {
            AddSapShipmentItem(false);
        }


    }

    private void ShipAll() {
        AddSapShipmentItem(true);
    }

    private void AddSapShipmentItem(boolean isSchipAll) {
        showLoading(R.string.text_please_wait);
        buttonAccept.setEnabled(false);
        viewAdd.setVisibility(View.GONE);

        Utils.runOnBackground(() -> {

            String json = generateJson(isSchipAll);
            log(json);

            String url = config.getUrlApi() + "addsapshipmentitem";
            if (soh) url = config.getUrlApi() + "addsapshipmentitemsoh";
            url = net.addUrlParam(url, "craneID", (int)(config.getCraneId()));
            if (smcIdSoh != null && smcIdSoh != "")
                url = net.addUrlParam(url, "smc_id", smcIdSoh);
            JsonResult result = net.uploadJson(url, json);
            if (soh && result.isOk()) {
                //listToPrintSoh = new ArrayList<>();
                labelToPrintSoh = new ArrayList<>();
                if (labelRest != null) labelToPrintSoh.add(new LabelPrintSoh(labelRest, false));
                JSONArray labelArray = Utils.getJsonArray(result.getJson(), "data");
                if (labelArray != null) {
                    for (int i = 0; labelArray != null && i < labelArray.length(); i++) {
                        JSONObject jsonLabel = Utils.getJsonObject(labelArray, i);
                        int labelSoh_id = Utils.getJsonIntIgnoreCase(jsonLabel, "labelSoh_Id");
                        if (labelSoh_id > 0) {
                            labelToPrintSoh.add(new LabelPrintSoh(String.valueOf(labelSoh_id), true));
                            /*Network.NetworkResultValue<Label> resultValue = getLabel(String.valueOf(labelSoh_id));
                            if (resultValue.isOk()) {
                                //runOnUiThread(() -> {
                                listToPrintSoh.add(resultValue.getValue());
                                //endPreparePrint(resultValue.getValue());
                                //});
                            }*/
                        }
                    }
                }
                /*if (listToPrintSoh.size() > 0 && labelRest != null) {
                    Network.NetworkResultValue<Label> resultValue = getLabel(labelRest);
                    if (resultValue.isOk()) {
                        //runOnUiThread(() -> {
                        listToPrintSoh.add(resultValue.getValue());
                        //endPreparePrint(resultValue.getValue());
                        //});
                    }
                }*/
            }

            runOnUiThread(() -> endAccept(result));

        });
    }

    private List<AdapterItemShipLabel> getLabelList() {
        List<AdapterItemShipLabel> list = new ArrayList<>(adapter.getCurrentItems());
        Collections.sort(list, (o1, o2) -> Integer.compare(o1.getLabel().getWeightNetto(), o2.getLabel().getWeightNetto()));
        return list;
    }

    private void endAccept(JsonResult result) {

        hideLoading();
        buttonAccept.setEnabled(!result.isOk());
        viewAdd.setVisibility(result.isOk() ? View.GONE : View.VISIBLE);

        if (result.isOk()) {
            finishAccept();
        } else if (result.getStatus() == LoadResultStatus.PLUS2) {
            showDialog(R.drawable.ic_error_24dp, R.string.text_error, "Заблоковано. Запис з таким Label_Id і датою вже є", null);
        } else if (result.getStatus() == LoadResultStatus.MINUS1) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_inc_add_minus1_error, (dialog1, which) -> {
                setResult(RESULT_OK);
                finish();
            });
        } else {
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginAccept());
        }
    }

    private void finishAccept() {
        accepted = true;
        Toast.makeText(this, R.string.ship_ok, Toast.LENGTH_SHORT).show();
        frameButtonAccept.setVisibility(View.GONE);
        if (soh) requestPrintSoh();
        else if (labelRest != null) {
                beginPreparePrint(labelRest, false);
            //if (soh) requestPrintSoh();
        } else {
            //if (soh) requestPrintSoh();
            //beginPrintSoh(); else
            close();
        }
    }

    private Network.NetworkResultValue<Label> getLabel(String labelId) {
        JsonResult result = net.loadLabelInfo(shipmentItem.getSmcId(), labelId);
        JSONObject json = Utils.getJsonObject(result.getJson(), "data");
        if (result.isOk() && json != null) {
            Label label = Label.fromJson(json);
            if (label != null) {
                label.setId(labelId);
                return new Network.NetworkResultValue<>(result, label);
            } else {
                result.setStatus(LoadResultStatus.S006);
                return new Network.NetworkResultValue<>(result, null);
            }
        }
        return new Network.NetworkResultValue<>(null, null);
    }

    private void beginPreparePrint(String label, boolean isSoh) {

        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {
            Network.NetworkResultValue<Label> resultValue = getLabel(label);
            if (resultValue.isOk()) {
                runOnUiThread(() -> {
                    hideLoading();
                    endPreparePrint(resultValue.getValue(), isSoh);
                });
            } else {
                runOnUiThread(() -> {
                    hideLoading();
                    showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(resultValue.getResult()), (dialog, which) -> beginPreparePrint(label, isSoh));
                });
            }
        });

    }

    private void endPreparePrint(Label label, boolean isSoh) {
        if (label.getWeightNetto() <= 0) {
            close();
        } else {
            if (getLabelTotalPack() == 0 && parseInt(textWeightCranePack.getText().toString()) == 0) {
                if (isSoh)
                    beginRestTransfer(label, isSoh);
                else
                    requestRestTransfer(label, isSoh);
            }
            else
            if (smcIdSoh != null && smcIdSoh != "")
                requestRestTransfer(label, isSoh);
            else
                showDialogConfirm(getString(R.string.text_warning), getString(R.string.ship_rest_confirm_set_zero_soh, "Бірка " + label.getId() + (isSoh?" НОВА СОХ ":" ОСНОВНИЙ СКЛАД ")),
                        (dialog, which) -> beginZeroRest(label, isSoh),
                        (dialog, which) -> {
                            if (isSoh)
                                beginRestTransfer(label, isSoh);
                            else
                                requestRestTransfer(label, isSoh);
                        });
        }
    }

    private void beginZeroRest(Label label, boolean isSoh) {
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {
            JsonResult result = app.editLabelWeight(
                    new LabelEditItem(label.getId(), label.getSmcId(), label.getWeightNetto(), 0, null, label.getLowPricePercent(), label.isRelease()),
                    Calendar.getInstance().getTime(),
                    label.getId()
            );
            runOnUiThread(() -> endZeroRest(result, label, isSoh));
        });
    }

    private void endZeroRest(JsonResult result, Label label, boolean isSoh) {
        hideLoading();

        if (result.isOk()) {
            if (isSoh)
                beginRestTransfer(label, isSoh);
            else
                requestRestTransfer(label, isSoh);
        } else {
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginZeroRest(label, isSoh));
        }
    }

    private void requestRestTransfer(Label label, boolean isSoh) {
        if (config.isShipRestTransfer()) {
            if (smcIdSoh != null && smcIdSoh != "")
                requestPrint(label, isSoh);
            else
                showDialogConfirm(getString(R.string.text_warning), getString(R.string.ship_rest_confirm_transfer_soh, (isSoh ? "СОХ " : "") + label.getId()),
                        (dialog, which) -> beginRestTransfer(label, isSoh),
                        (dialog, which) -> requestPrint(label, isSoh)
                );
        } else {
            requestPrint(label, isSoh);
        }
    }

    private Label labelRestLabel;

    private void beginRestTransfer(Label label, boolean isSoh) {
        labelRestLabel = label;

        Intent intent = new Intent(this, LocationSelectActivity.class);
        intent.putExtra("isSoh", isSoh);
        intent.putExtra("labelId", label.getId());
        startActivityForResult(intent, REQUEST_LOCATION_SELECT);
    }

    private void processRestTransfer(Label label, String locationCode, boolean isSoh) {
        if (locationCode == null && !isSoh) {
            requestPrint(label, isSoh);
            return;
        }

        Utils.runOnBackground(() -> {
            log("beginTransferLabel(%s, %s)", label.getId(), locationCode);

            showLoading(R.string.text_please_wait);

            StringBuilder sb = new StringBuilder();
            sb.append("[");
            sb.append(Utils.format(
                    "{\"Label_Id\":%s,\n" +
                            "\"Location_Code\":\"%s\",\n" +
                            "\"Date_FV\":\"%s\"\t}",
                    label.getId(), locationCode, app.getDateTimeFormat().format(Calendar.getInstance().getTime())
            ));
            sb.append("]");

            String url = config.getUrlApi() + "sapchangelocation";
            if (isSoh) url = config.getUrlApi() + "sapchangelocationsoh";
            JsonResult result = net.uploadJson(url, sb.toString());

            runOnUiThread(() -> endRestTransfer(result, label, locationCode, isSoh));
        });
    }

    private void endRestTransfer(JsonResult result, Label label, String locationCode, boolean isSoh) {
        hideLoading();

        if (result.isOk()) {
            requestPrint(label, isSoh);
        } else {
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> processRestTransfer(label, locationCode, isSoh));
        }
    }

    private void requestPrint(Label label, boolean isSoh) {
		/*if (!config.isPrintLabelRestShip()) {
			showDialogConfirm(getString(R.string.text_warning), getString(R.string.ship_rest_confirm_print, label.getWeightNetto()),
					(dialog, which) -> beginPrint(label),
					(dialog, which) -> close());
		}else*/
        beginPrint(label, isSoh);

    }

    private void requestPrintSoh() {
        if (labelToPrintSoh == null || labelToPrintSoh.size() == 0) {
            close();
        } else {
            showLoading(R.string.text_printing_title_soh);
            for (LabelPrintSoh label : labelToPrintSoh) {
                beginPreparePrint(label.getLabelId(), label.isSoh());
            }
        }
    }

    private void beginPrint(Label label, boolean isSoh) {

        showLoading(R.string.text_printing_title);

        Utils.runOnBackground(() -> {
            if (isSoh || (smcIdSoh != null && smcIdSoh != "") )
                config.setStorage("0001");
            else config.setStorage(tempStorage);
            Utils.NetworkPrintResult result = Utils.printLabel(label.getId(), shipmentItem.getSmcId());
            runOnUiThread(() -> endPrint(result, label, isSoh));
        });
    }

    private void endPrint(Utils.NetworkPrintResult result, Label label, boolean isSoh) {

        hideLoading();

        if (result.getNetworkResult().isOk()) {

            if (result.getPrintResult().getStatus() == Printer.PrintResultStatus.OK) {
                String message = getString(R.string.printer_ship_ok, label.getId(), (isSoh?"(НОВА СОХ)":""), label.getWeightNetto());
                showDialog(R.drawable.ic_info_24dp, R.string.text_information, message, (dialog, which) -> {

                    if (labelToPrintSoh != null)
                        labelToPrintSoh.remove(new LabelPrintSoh(String.valueOf(label.getId()), isSoh));
                    if (labelToPrintSoh == null || labelToPrintSoh.size() == 0)
                        try {
                            close();
                        } catch (Exception ignored) {

                        }
                });
            } else {
                final int message = app.getPrintResultMessage(result.getPrintResult());
                showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message,
                        (dialog, which) -> beginPreparePrint(label.getId(), isSoh),
                        (dialog, which) -> showDialogPrintCanceled(label.getId(), isSoh, label.getWeightNetto()));
            }

        } else {
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result.getNetworkResult()), (dialog, which) -> endPreparePrint(label, isSoh));
        }

    }

    private void showDialogPrintCanceled(String labelId, boolean isSoh, int netto) {
        String message = getString(R.string.printer_ship_canceled, labelId, (isSoh?"(НОВА СОХ)":""), netto);
        showDialog(R.drawable.ic_info_24dp, R.string.text_information, message,
                (dialog, which) -> {
                    if (labelToPrintSoh != null)
                        labelToPrintSoh.remove(new LabelPrintSoh(labelId, isSoh));
                    if (labelToPrintSoh == null || labelToPrintSoh.size() == 0)
                        close();
                })
                .setCanceledOnTouchOutside(false);
    }

    @Override
    public void onBackPressed() {
        close();
        super.onBackPressed();
    }

    private void close() {
        config.setStorage(tempStorage);
        Intent intent = new Intent();

        if (config.isEo()) {
            StringBuilder sb = new StringBuilder();
            sb.append(Utils.format("<b>%s</b>", "ЗАКРИТИ НАРЯД"));
            sb.append(Utils.format("<br><i>%s</i>", getString(R.string.ship_eo_close)));
            //<div style = "text-transform: lowercase">
            //String str = Utils.format("<font color=\"#43A047\"><b>%s</b><i> %s</i></font>", "ЗАКРИТИ НАРЯД",
            //        "");
            StringBuilder sb1 = new StringBuilder();
            sb1.append(Utils.format("<b>%s</b>", "ЧАСТКОВО ЗАКРИТИ НАРЯД"));
            sb1.append(Utils.format("<br><i>%s</i>", getString(R.string.ship_eo_part)));
            showDialogConfirmNoButton(R.string.text_confirm, getString(R.string.text_end_pogruzka),
                    sb1.toString(),
                    sb.toString(),
                    (dialog, which) -> {
                        setResult(RESULT_OK, intent);
                        finish();
                    },
                    (dialog, which) -> {
                        setResult(REQUEST_CLOSE_NARAD, intent);
                        finish();
                    });
        } else {
            setResult(RESULT_OK, intent);
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

		/*if (requestCode == REQUEST_SEARCH && resultCode == RESULT_OK && data != null) {

			ArrayList<String> list = data.getStringArrayListExtra("labelIdList");

			adapter.clear();
			beginAddLabel(list, true, true);

		} else */
        if (requestCode == REQUEST_SPLIT && resultCode == RESULT_OK & data != null) {
            String oldLabelId = data.getStringExtra("labelId");
            //String newLabelId = data.getStringExtra("newLabelId");
            int weightSplit = data.getIntExtra("weightSplit", 0);

            AdapterItemShipLabel item = findLabelItem(oldLabelId);
            if (item != null) {
                item.getLabel().setWeightNetto(item.getLabel().getWeightNetto() - weightSplit);
                adapter.updateItem(item);
            }

            onAdapterChanged();
        } else if (requestCode == REQUEST_LOCATION_SELECT) {
            boolean isSoh = data.getBooleanExtra("isSoh", false);
            if (resultCode == RESULT_OK && data != null) {
                String locationCode = data.getStringExtra("locationCode");
                processRestTransfer(labelRestLabel, locationCode, isSoh);
            } else {
                processRestTransfer(labelRestLabel, null, isSoh);
            }
        } else if (requestCode == REQUEST_COUNT_SELECT && resultCode == RESULT_OK && data != null) {
            log("REQUEST_COUNT_SELECT OK");

            int count = data.getIntExtra("count", 0);
            int maxCount = data.getIntExtra("maxCount", 0);
            List<String> list = new ArrayList<>(maxCount);

            for (int i = 0; i < count; i++) {
                Serializable item = data.getSerializableExtra("label" + i);
                if (item instanceof Label) list.add(((Label) item).getId());
            }

            adapter.clear();
            beginAddLabel(list, true, true, false);

        }
    }

    private static class FinalStruct {
        public AdapterItemShipLabel label;
        public int shippedNetto;
        public int shipmentIndex;
        public int labelNettoSet;

        public FinalStruct(AdapterItemShipLabel label, int shipmentIndex, int shippedNetto, int labelNettoSet) {
            this.label = label;
            this.shipmentIndex = shipmentIndex;
            this.shippedNetto = shippedNetto;
            this.labelNettoSet = labelNettoSet;
        }
    }

    private List<FinalStruct> finalList;
    private int finalCraneBrutto;
    private boolean finalAllowPercent;

    private void checkWeight() {

        if (accepted) return;

        labelRest = null;

        finalCraneBrutto = parseInt(textWeightCraneBrutto.getText().toString());
        int finalCranePack = parseInt(textWeightCranePack.getText().toString());

        //int weightOut = finalCraneBrutto == 0 ? 0 : finalCraneBrutto - finalCranePack;
        //int finalCraneNetto = finalCraneBrutto - finalCranePack;
        //CodeQL requirement
        int weightOut = 0;
        int finalCraneNetto = 0;
        if (finalCranePack < Integer.MAX_VALUE) {
            finalCraneNetto = finalCraneBrutto - finalCranePack;
            weightOut = finalCraneBrutto == 0 ? 0 : finalCraneNetto;
        }

        if (weightOut < 0) weightOut = 0;
        textWeightOut.setText(Utils.format("%s", weightOut));
        buttonAccept.setEnabled(weightOut > 0);

        int finalLabelNetto = getLabelTotalNetto();
        int finalDiffNetto = finalCraneNetto - finalLabelNetto;
        float finalDiffPercent = finalLabelNetto > 0 ? (float) finalDiffNetto * 100.0f / (float) finalLabelNetto : 0.0f;
        if (finalDiffPercent < 0) finalDiffPercent *= -1;
        float finalPlanPercent = finalLabelNetto >= 5000 ? 1.0f : 2.0f;
        finalAllowPercent = finalDiffPercent <= finalPlanPercent;

        List<AdapterItemShipLabel> list = getLabelList();
        int itemCount = list.size();
        finalList = new ArrayList<>();

        imagePrinter.setVisibility(View.GONE);
        textWarning.setText(null);

        int totalShippedNetto = 0;
        log("\n======================================");

        int restNetto = 0;

        for (int i = 0; i < itemCount; i++) {
            AdapterItemShipLabel item = list.get(i);
            boolean isLarger = i + 1 == itemCount;
            int nettoLeft = finalCraneNetto - totalShippedNetto;
            int wl;
            int ws;
            boolean wlFull;

            boolean vlazit = nettoLeft >= item.getLabel().getWeightNetto();

            if (vlazit) {
                ws = item.getLabel().getWeightNetto();
                wl = item.getLabel().getWeightNetto();
                wlFull = true;
            } else {
                ws = nettoLeft;
                wl = nettoLeft;
                wlFull = false;
            }

            totalShippedNetto += ws;

            if (isLarger) {

                if (item.getLabel().getWeightNetto() - wl > 0) {

                    float leftPercent = finalLabelNetto == 0 ? 0 : (float) (item.getLabel().getWeightNetto() - wl) * 100.0f / (float) finalLabelNetto;
                    restNetto = item.getLabel().getWeightNetto() - wl;

                    //if (leftPercent < finalPlanPercent) {
                    //	wl = 0;
                    //	wlFull = true;
                    //	restNetto = 0;
                    //} else {
                    labelRest = item.getLabel().getId();
                    //}
                }

                if (finalCraneNetto - totalShippedNetto > 0) {
                    ws += finalCraneNetto - totalShippedNetto;
                }

            }

            addShipItem(i, item.getLabel().getId(), ws, wl, wlFull);

        }

        if (isTheorWeight) {
            textWarning.setText("Теоретична вага");
        } else /*if (restNetto > 0 && finalCraneBrutto > 0 && weightOut > 0)*/ {
            imagePrinter.setVisibility(View.VISIBLE);
            textWarning.setText(Utils.format("Залишок (%.1f%%), кг: %d", finalDiffPercent, restNetto));
        }
    }

    private List<ShipmentItem> getAllShipItems() {
        List<ShipmentItem> list = new ArrayList<>();
        list.add(shipmentItem);
        list.addAll(shipmentItemsExtra);
        Collections.sort(list, (o1, o2) -> o1.getDocumentNumber().compareToIgnoreCase(o2.getDocumentNumber()));
        return list;
    }

    private int getFirstFreeShipmentItem() {
        List<ShipmentItem> list = getAllShipItems();
        for (int i = 0; i < list.size(); i++) {
            ShipmentItem item = list.get(i);
            int freeNetto = item.getSapWeightNett() - item.getSapWeightNettFact();
            if (freeNetto > 0) return i;
        }
        return 0;
    }

    private int getShipItemFreeNetto(int index) {
        ShipmentItem item = getAllShipItems().get(index);
        int value = 0;
        for (FinalStruct finalStruct : finalList) {
            if (finalStruct.shipmentIndex == index) {
                value += finalStruct.shippedNetto;
            }
        }
        return item.getSapWeightNett() - item.getSapWeightNettFact() - value;
    }

    private void addShipItem(int n, String labelId, int weightToShip, int weightLabelSet, boolean weightLabelSetFull) {

        log("%d. WS=%d, WLFULL=%s, WL=%d", n + 1, weightToShip, weightLabelSetFull, weightLabelSet);

        int startIndex = getFirstFreeShipmentItem();
        List<ShipmentItem> list = getAllShipItems();

        AdapterItemShipLabel label = findLabelItem(labelId);
        if (label == null) return;

        int weightLabelLeft = weightLabelSet;
        int weightLeft = weightToShip;

        for (int i = startIndex; i < list.size() && weightLeft > 0; i++) {
            ShipmentItem item = list.get(i);
            int itemFreeNetto = getShipItemFreeNetto(i);

            if (itemFreeNetto > 0 || i == list.size() - 1) {
                int itemWeightToShip = i == list.size() - 1 ? weightLeft : (weightLeft > itemFreeNetto ? itemFreeNetto : weightLeft);

                weightLeft -= itemWeightToShip;

                //int itemLabelWeightToShip = weightLeft > 0 ? itemWeightToShip : weightLabelLeft;
                int itemLabelWeightToShip;
                if (weightLeft > 0) {
                    itemLabelWeightToShip = itemWeightToShip;
                } else {
                    if (weightLabelLeft > 0) {
                        itemLabelWeightToShip = weightLabelLeft;
                    } else {
                        itemLabelWeightToShip = label.getLabel().getWeightNetto();
                    }
                }

                weightLabelLeft -= itemLabelWeightToShip;

                finalList.add(new FinalStruct(
                        label, i, itemWeightToShip, itemLabelWeightToShip
                ));

                log("DOC #%s, %d кг, label%s: -> %d, %d left", item.getDocumentNumber(), itemWeightToShip, labelId, itemLabelWeightToShip, weightLeft);
            }
        }
    }

    private String generateJson(boolean isSchipAll) {

        int itemCount = finalList.size();

        if (itemCount == 0) return "";

        StringBuilder sb = new StringBuilder();
        sb.append("[");

        for (int i = 0; i < itemCount; i++) {

            FinalStruct data = finalList.get(i);

            ShipmentItem shipItem = getAllShipItems().get(data.shipmentIndex);

            int weightToShipNetto = data.shippedNetto;

            int weightToShipNettoLabel = isSchipAll ? data.label.getLabel().getWeightNetto() : data.labelNettoSet;

            log("labelNettoSet = %d", data.label.getLabel().getWeightNetto() - data.labelNettoSet);

            int labelAutoClearValue = 0;
			/*int wlAfter = data.label.getLabel().getWeightNetto() - data.labelNettoSet;
			if (wlAfter <= 15) {
				log("Label #%s <= 15 (%d kg) - %d", data.label.getLabel().getId(), wlAfter, data.label.getLabel().getWeightNetto());
				weightToShipNettoLabel = data.label.getLabel().getWeightNetto();
				labelAutoClearValue = wlAfter;
				if (labelRest != null && labelRest.equalsIgnoreCase(data.label.getLabel().getId())) {
					labelRest = null;
				}
			}*/

            //Если отгружаем бирку в 0 то также списываем вес упаковки
            int weightToShipPack = weightToShipNettoLabel == data.label.getLabel().getWeightNetto() ?
                    data.label.getLabel().getWeightPack() :
                    0;
            boolean flagScan = data.label.getFlagScan();
            //Если отгружаем без остатка вес упаковки: оригинальный вес упаковки
            //Если отгружаем с остатком вес упаковки: 0
            sb.append(Utils.format("{%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%s%n}"
                    , Utils.format("\"ID_TERMINAL\":\"%s\",", "")
                    , Utils.format("\"PLAN_LINE_ID\":%s,", shipItem.getLineId())
                    , Utils.format("\"DATE_FV\":\"%s\",", app.getDateTimeFormat().format(data.label.getDateScan()))
                    , Utils.format("\"MENGE_BIRK\":\"%s\",", weightToShipNetto)
                    , Utils.format("\"SAP_WEIGHT_NETT\":\"%s\",", weightToShipNetto)
                    , Utils.format("\"SAP_WEIGHT_PACK\":\"%s\",", weightToShipPack)
                    , Utils.format("\"LABEL_WEIGHT_NETT\":\"%s\",", weightToShipNettoLabel)
                    , Utils.format("\"LabelId\":%s,", data.label.getLabel().getId())
                    , Utils.format("\"ID_QR\":\"%s\",", "")
                    , Utils.format("\"TTN_DATE\":\"%s\",", app.getDateFormat().format(Calendar.getInstance().getTime()))
                    , Utils.format("\"TTN_NUM\":\"%s\",", "0")
                    , Utils.format("\"TYPEDIFF\":\"%s\",", "0")
                    , Utils.format("\"DIFF\":\"%s\",", "0")
                    , Utils.format("\"LABEL_AUTO_CLEAR\":\"%s\",", labelAutoClearValue)
                    , Utils.format("\"SCANLABEL\":\"%s\"", flagScan?1:2)
            ));

            if (i + 1 < itemCount) sb.append(",");

        }

        sb.append("]");

        return sb.toString();
    }

    public void buttonAddFactClick(View view) {
        String labelId = textLabelIdFact.getText().toString();
        if (labelId.trim().length() == 0) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_labelid_empty, (dialog, which) -> textLabelIdFact.requestFocus());
            return;
        }

        beginAddLabel(labelId, false);
    }

    public void buttonAddTheorClick(View view) {
        log("onAddClicked");

        AdapterItemShipLabel itemZero = getItemZero();
        if (itemZero == null || theorLabels == null || theorLabels.isEmpty()) return;

		/*Intent intent = new Intent(this, ShipLabelListActivity.class);

		intent.putExtra("theor", itemZero.getLabel().isTheor());
		intent.putExtra("id", itemZero.getLabel().getId());
		intent.putExtra("locationCode", itemZero.getLabel().getLocationCode());
		intent.putExtra("netto", itemZero.getLabel().getWeightNetto());
		intent.putExtra("ozm", itemZero.getLabel().getOzm());
		intent.putExtra("length", itemZero.getLabel().getLength());
		intent.putExtra("width", itemZero.getLabel().getWidth());
		intent.putExtra("thickness", itemZero.getLabel().getThickness());
		intent.putExtra("isTheorWeight", itemZero.getLabel().isTheor());
		intent.putStringArrayListExtra("labelIdList", getLabelIdList());

		startActivityForResult(intent, REQUEST_SEARCH);*/

        Intent intent = new Intent(this, TheorCountActivity.class);
        intent.putExtra("maxCount", theorLabels.size());
        for (int i = 0; i < theorLabels.size(); i++) {
            intent.putExtra("label" + i, theorLabels.get(i));
        }
        startActivityForResult(intent, REQUEST_COUNT_SELECT);
    }

    private boolean checkLabelStatus(String status) {
        return status.equalsIgnoreCase("7") ||
                status.equalsIgnoreCase("90") ||
                status.equalsIgnoreCase("91");
    }

    @Override
    protected void onCraneWeight(long craneId, int value) {
        textWeightCraneBrutto.setText(String.valueOf(value));
        checkWeight();
    }
}
