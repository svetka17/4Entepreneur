package com.metinvest.smc.view;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractExpandableItem;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.ExpandableViewHolder;
import eu.davidea.viewholders.FlexibleViewHolder;

public class ShipBatchActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener, IScan {

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.buttonRefresh)
    Button buttonRefresh;
    @BindView(R.id.frameButtonRefresh)
    View frameButtonRefresh;
    @BindView(R.id.viewContentData)
    View viewContentData;
    @BindView(R.id.textNotFound)
    TextView textNotFound;

    private Date date, dateVo;
    private String documentNumber;
    private String transportName;

    private String sohSmcId;
    private final boolean readOnly = app.getSmcIdCurrent().equalsIgnoreCase("1406");
    private FlexibleAdapter<IFlexible> adapter;

    @Override
    public void onBarcodeEvent(String barcodeData) {
        if (isLoading()) return;

        runOnUiThread(() -> {

            ScanItem scanItem = new ScanItem(barcodeData);
            if (!scanItem.isCorrect()) {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_label, null);
                return;
            }

            if (scanItem.getType() == ScanItem.ScanItemType.LABELID) {
                String newLabelId = scanItem.getData(0);
                beginLoadLabel(newLabelId);
            } else if (scanItem.getType() == ScanItem.ScanItemType.SMC06) {
                String newLabelId = scanItem.getData(0);
                beginLoadLabel(newLabelId);
            } else if (scanItem.getType() == ScanItem.ScanItemType.SMC07) {
                checkIsUnknown(scanItem);
            }

        });
    }

    @Override
    protected void onIsUnknown(ScanItem scanItem, boolean unknown, @Nullable Label label) {
        if (!unknown && label != null) {
            beginLoadLabel(label.getId());
        }
    }

    private void beginLoadLabel(String newLabelId) {
        log("labelId %s", newLabelId);

        Adapter item = null;

        if (adapter != null) {
            List<IFlexible> list = adapter.getCurrentItems();
            for (IFlexible iFlexible : list) {
                if (iFlexible instanceof Adapter) {
                    Adapter obj = (Adapter) iFlexible;
                    if (obj.idQr.equalsIgnoreCase(newLabelId)) {
                        item = obj;
                        break;
                    }
                }
            }
        }

        if (item == null) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.labelid_not_found, null);
        } else {
            openEdit(item.getPlanLineId(), item.getLineId(), item.getIdQr(), item.getFact(), item.getLineId());
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ship_batch);
        ButterKnife.bind(this);

        date = (Date) getIntent().getSerializableExtra("date");
        dateVo = (Date) getIntent().getSerializableExtra("dateVo");
        documentNumber = getIntent().getStringExtra("documentNumber");
        transportName = getIntent().getStringExtra("transportName");
        sohSmcId = getIntent().getStringExtra("sohSmcId");
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
        listView.setLayoutManager(layoutManager);
        listView.addItemDecoration(dividerItemDecoration);

        textContentTitle.setText(Utils.format("Наряд %s", documentNumber));
    }

    /*private void openEdit(int planLineId, int fact) {
        Intent intent = new Intent(this, ShipReverseActivity.class);
        intent.putExtra("date", date);
        intent.putExtra("documentNumber", documentNumber);
        intent.putExtra("transportName", transportName);
        intent.putExtra("planLineId", planLineId);
        intent.putExtra("fact", fact);
        startActivityForResult(intent, REQUEST_DEFAULT);
    }*/

    private void openEdit(AdapterGroup item, int fact) {
        Intent intent = new Intent(this, ShipReverseActivity.class);
        intent.putExtra("date", date);
        intent.putExtra("dateVo", dateVo);
        intent.putExtra("documentNumber", documentNumber);
        intent.putExtra("transportName", transportName);
        intent.putExtra("planLineId", item.getPlanLineId());
        intent.putExtra("idPos", item.getIdPos());
        intent.putExtra("smcIdSoh", sohSmcId);
        intent.putExtra("fact", fact);
        startActivityForResult(intent, REQUEST_DEFAULT);
    }

    private void openEdit(int planLineId, int lineId, String idQr, int fact, int labelSohId) {
        Intent intent = new Intent(this, ShipReverseActivity.class);
        intent.putExtra("date", date);
        intent.putExtra("documentNumber", documentNumber);
        intent.putExtra("transportName", transportName);
        intent.putExtra("planLineId", planLineId);
        intent.putExtra("lineId", lineId);
        intent.putExtra("idQr", idQr);
        intent.putExtra("fact", fact);
        intent.putExtra("smcIdSoh", sohSmcId);
        intent.putExtra("labelSohId", labelSohId);
        startActivityForResult(intent, REQUEST_DEFAULT);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_DEFAULT && resultCode == RESULT_OK) {
            beginLoad();
        }
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        super.onBackPressed();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) buttonRefreshClick();
    }

    private void buttonRefreshClick() {
        if (isLoading()) return;

        beginLoad();
    }

    private void beginLoad() {
        showLoading(R.string.text_please_wait);
        buttonRefresh.setEnabled(false);

        Utils.runOnBackground(() -> {

            String url = config.getUrlApi() + "getsapshippedozm";
            url = net.addUrlParam(url, "date_vo", app.getDateFormat().format(dateVo == null ? date : dateVo));
            url = net.addUrlParam(url, "id_doc", documentNumber);
            url = net.addUrlParam(url, "car", transportName);
            if (sohSmcId != null && sohSmcId != "")
                url = net.addUrlParam(url, "smc_id", sohSmcId);
            JsonResult result = net.downloadJson(url);

            JSONObject jsonObject = Utils.getJsonObject(result.getJson(), "data");

            List<IFlexible> list = new ArrayList<>();

            if (result.isOk() && jsonObject != null) {
                JSONArray ozmArray = Utils.getJsonArray(jsonObject, "ozms");
                for (int i = 0; ozmArray != null && i < ozmArray.length(); i++) {
                    JSONObject jsonOzm = Utils.getJsonObject(ozmArray, i);

                    String name = Utils.getJsonStringIgnoreCase(jsonOzm, "saP_MATT_DESCR");
                    String ozm = Utils.getJsonStringIgnoreCase(jsonOzm, "saP_OZM");
                    float width = Utils.getJsonFloatIgnoreCase(jsonOzm, "width");
                    float length = Utils.getJsonFloatIgnoreCase(jsonOzm, "length");
                    float thickness = Utils.getJsonFloatIgnoreCase(jsonOzm, "thickness");
                    int plan = Utils.getJsonWeightKgIgnoreCase(jsonOzm, "plaN_Weight");
                    int fact = Utils.getJsonWeightKgIgnoreCase(jsonOzm, "facT_Weight");
                    JSONArray arrayBatches = Utils.getJsonArray(jsonOzm, "ozmBatches");
                    String idPos = Utils.getJsonStringIgnoreCase(jsonOzm, "iD_POS");

                    AdapterGroup group = new AdapterGroup(name, ozm, width, length, thickness, plan, fact, idPos, false);

                    if (arrayBatches != null) {

                        List<Adapter> listItems = new ArrayList<>();

                        int batchCount = arrayBatches.length();
                        for (int j = 0; j < batchCount; j++) {
                            JSONObject jsonBatch = Utils.getJsonObject(arrayBatches, j);

                            if (jsonBatch != null) {
                                String batch = Utils.getJsonStringIgnoreCase(jsonBatch, "saP_Batch");
                                int factNetto = Utils.getJsonWeightKgIgnoreCase(jsonBatch, "facT_Weight");
                                int planLineId = Utils.getJsonIntIgnoreCase(jsonBatch, "pLanLineId");
                                String status = Utils.getJsonStringIgnoreCase(jsonBatch, "saP_FACT_STATUS_OUT");

                                JSONArray arrayLabels = Utils.getJsonArray(jsonBatch, "lidsByBatch");

                                for (int z = 0; z < (arrayLabels == null ? 0 : arrayLabels.length()); z++) {
                                    JSONObject jsonLabel = Utils.getJsonObject(arrayLabels, z);
                                    if (jsonLabel != null) {
                                        int lineId = Utils.getJsonIntIgnoreCase(jsonLabel, "line_Id");
                                        String idQR = Utils.getJsonStringIgnoreCase(jsonLabel, "iD_QR");
                                        int nett = Utils.getJsonWeightKgIgnoreCase(jsonLabel, "saP_WEIGHT_NETT");
                                        int labelSohId = Utils.getJsonIntIgnoreCase(jsonLabel, "labelSohId");
                                        int ind = findLabel(listItems, idQR);
                                        ind = -1;

                                        if (ind != -1) {
                                            listItems.get(ind).setFact(listItems.get(ind).getFact() + nett);
                                        } else {
                                            Adapter item = new Adapter(planLineId, lineId, batch, idQR, nett, status, false, labelSohId);
                                            listItems.add(item);
                                        }
                                    }
                                }
                            }
                        }

                        for (Adapter listItem : listItems) {
                            if (listItem.getFact() > 0) group.addSubItem(listItem);
                        }

                    }

                    list.add(group);
                }
            }

            runOnUiThread(() -> endLoad(result, list));
        });
    }

    private int findLabel(List<Adapter> list, String labelId) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).idQr.equalsIgnoreCase(labelId)) return i;
        }
        return -1;
    }

    private void endLoad(JsonResult result, List<IFlexible> list) {
        hideLoading();
        buttonRefresh.setEnabled(true);
        viewContentData.setVisibility(result.isOk() && !list.isEmpty() ? View.VISIBLE : View.GONE);
        textNotFound.setVisibility(!result.isOk() || list.isEmpty() ? View.VISIBLE : View.GONE);

        if (result.isOk()) {
            adapter = new FlexibleAdapter<>(list);
            listView.setAdapter(adapter);
            adapter.collapseAll();
            adapter.addListener(this);
            scrollView.post(() -> scrollView.scrollTo(0, 0));
        } else {
            listView.setAdapter(null);
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
        }
    }

    private void OnEditOzmClick(AdapterGroup item, int planLineId, int fact) {
        if (readOnly) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_denied_1406, null);
            return;
        }

        log("OnEditOzmClick(%s)", planLineId);

        showDialogConfirm(R.string.text_warning, getString(R.string.ship_edit_ozm_warning),
                "Весь ОЗМ", "Певна бірка", (dialog, which) -> openEdit(item, fact), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //adapter.expand(adapter.getGlobalPositionOf(item), true);
                        //item.setExpanded(true);
                        //adapter.updateItem(item);
                        /*if (item.getSubItemsCount() > 0) {
                            int pos = adapter.getGlobalPositionOf(item.getSubItem(0));
                            if (pos != -1) adapter.smoothScrollToPosition(pos);
                        }*/
                    }
                });
    }

    private void OnEditLabelClick(int planLineId, int lineId, String idQr, int fact, int labelSohId) {
        /*if (readOnly) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_denied_1406, null);
            return;
        }*/

        log("OnEditLabelClick(%s, %s, %s, %s)", lineId, idQr, fact, labelSohId);
        openEdit(planLineId, lineId, idQr, fact, labelSohId);
    }

    @Override
    public boolean onItemClick(View view, int position) {
        IFlexible iFlexible = adapter.getItem(position);
        if (iFlexible instanceof AdapterGroup) {

        }
        return false;
    }

    public class AdapterGroup extends AbstractExpandableItem<AdapterGroup.ViewHolder, Adapter> {

        private final String name;
        private final String ozm;
        private final float width;
        private final float length;
        private final float thickness;
        private final int plan;
        private final int fact;
        private final String content;
        private final String idPos;
        private final boolean readOnly;

        AdapterGroup(String name, String ozm, float width, float length, float thickness, int plan, int fact, String idPos, boolean readOnly) {
            this.name = name;
            this.ozm = ozm;
            this.width = width;
            this.length = length;
            this.thickness = thickness;
            this.plan = plan;
            this.fact = fact;
            this.idPos = idPos;
            this.readOnly = readOnly;

            StringBuilder sb = new StringBuilder();
            sb.append(Utils.format("<b>%s</b><br>", Html.escapeHtml(name)));
            if (app.sizeToString(width, length, thickness).trim().length() > 0)
                sb.append(Utils.format("%s<br>", app.sizeToString(width, length, thickness)));
            sb.append(Utils.format("ОЗМ: %s<br>", ozm));
            sb.append(Utils.format("План, тн: %.3f<br>", plan / 1000.0f));
            sb.append(Utils.format("Факт, тн: %s %s", Utils.factToString(fact), getTotalWeightPercentString()));
            this.content = sb.toString();
        }

        public String getIdPos() {
            return idPos;
        }

        public String getName() {
            return name;
        }

        public String getOzm() {
            return ozm;
        }

        public float getWidth() {
            return width;
        }

        public float getLength() {
            return length;
        }

        public float getThickness() {
            return thickness;
        }

        public int getPlan() {
            return plan;
        }

        public int getFact() {
            return fact;
        }

        public int getPlanLineId() {
            return hasSubItems() ? getSubItem(0).getPlanLineId() : -1;
        }

        public boolean isReadOnly() {
            return readOnly;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof AdapterGroup && (((AdapterGroup) o).getName().equals(getName()));
        }

        @Override
        public int hashCode() {
            return getName().hashCode();
        }

        @Override
        public int getLayoutRes() {
            return R.layout.adapter_ship_ozm_group;
        }

        @Override
        public ViewHolder createViewHolder(View view, FlexibleAdapter adapter) {
            return new ViewHolder(view, adapter);
        }

        @Override
        public void bindViewHolder(FlexibleAdapter adapter, ViewHolder holder, int position, List payloads) {
            holder.textTitle.setText(app.fromHtml(content));
            View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
            holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
            refreshBackground(holder, holder.itemView.isFocused());

            View.OnClickListener headerListener = v -> {
                holder.toggleExpansion();
                refreshExpand(holder);
            };

            holder.imageExpand.setVisibility(hasSubItems() ? View.VISIBLE : View.INVISIBLE);

            holder.itemView.setOnClickListener(headerListener);
            holder.imageExpand.setOnClickListener(headerListener);
            holder.textTitle.setOnClickListener(headerListener);

            refreshExpand(holder);

            if (getPlanLineId() != -1 && !isReadOnly()) {
                holder.buttonEdit.setVisibility(View.VISIBLE);
                holder.buttonEdit.setOnClickListener(v -> OnEditOzmClick(this, getPlanLineId(), fact));
            } else {
                holder.buttonEdit.setVisibility(View.GONE);
            }
        }

        private void refreshExpand(ViewHolder holder) {
            holder.imageExpand.setImageDrawable(ContextCompat.getDrawable(holder.itemView.getContext(),
                    isExpanded() ? R.drawable.ic_keyboard_arrow_down_black_24dp : R.drawable.ic_keyboard_arrow_right_black_24dp));
        }

        private String getTotalWeightPercentString() {
            return Utils.getTotalWeightPercentString(plan, fact);
        }

        private void refreshBackground(ViewHolder holder, boolean hasFocus) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_adapter_light));
        }

        class ViewHolder extends ExpandableViewHolder {

            @BindView(R.id.textTitle)
            TextView textTitle;
            @BindView(R.id.imageExpand)
            ImageView imageExpand;
            @BindView(R.id.buttonEdit)
            ImageButton buttonEdit;

            ViewHolder(View view, FlexibleAdapter adapter) {
                super(view, adapter);
                ButterKnife.bind(this, view);
            }

            @Override
            public void toggleExpansion() {
                super.toggleExpansion();
            }
        }
    }

    public class Adapter extends AbstractFlexibleItem<Adapter.ViewHolder> {

        private final String idQr, batch;
        private final boolean readOnly;
        private int fact;
        private final int lineId;

        private final int labelSohId;
        private String content;
        private final String status;
        private final int planLineId;

        //Adapter(String batch, int fact, int lineId, String status) {
        Adapter(int planLineId, int lineId, String batch, String idQr, int fact, String status, boolean readOnly, int labelSohId) {
            this.batch = batch;
            this.idQr = idQr;
            this.fact = fact;
            this.planLineId = planLineId;
            this.lineId = lineId;
            this.status = status;
            this.readOnly = readOnly;
            this.labelSohId = labelSohId;
            refreshContent();
        }

        private void refreshContent() {
            StringBuilder sb = new StringBuilder();
            sb.append(Utils.format("<b>LabelID: </b>%s<br>", idQr));
            sb.append(Utils.format("<b>Партія: </b>%s<br>", batch));
            sb.append(Utils.format("Вага НЕТТО, тн: %.3f", fact / 1000.0f));
            //sb.append(Utils.format("Статус: %s", status));
            this.content = sb.toString();
        }

        public void setFact(int fact) {
            this.fact = fact;
            refreshContent();
        }

        public int getLabelSohId() {
            return labelSohId;
        }

        public String getStatus() {
            return status;
        }

        public String getBatch() {
            return batch;
        }

        public int getFact() {
            return fact;
        }

        public String getIdQr() {
            return idQr;
        }

        public int getLineId() {
            return lineId;
        }

        public boolean isReadOnly() {
            return readOnly;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof Adapter
                    && ((Adapter) o).getBatch().equalsIgnoreCase(getBatch())
                    && ((Adapter) o).getFact() == getFact()
                    && ((Adapter) o).getLineId() == getLineId();
        }

        @Override
        public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
            return new ViewHolder(view, adapter);
        }

        @Override
        public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {
            holder.textContent.setText(App.getInstance().fromHtml(content));
            View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
            holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
            refreshBackground(holder, holder.itemView.isFocused());

            holder.textTitle.setVisibility(View.GONE);
            holder.buttonEdit.setVisibility(isReadOnly() ? View.GONE : View.VISIBLE);
            holder.buttonEdit.setOnClickListener(v -> OnEditLabelClick(getPlanLineId(), lineId, idQr, fact, labelSohId));
        }

        private void refreshBackground(ViewHolder holder, boolean hasFocus) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_adapter_light));
        }

        @Override
        public int getLayoutRes() {
            return R.layout.adapter_ship_batch;
        }

        public int getPlanLineId() {
            return planLineId;
        }

        class ViewHolder extends FlexibleViewHolder {

            @BindView(R.id.textTitle)
            TextView textTitle;
            @BindView(R.id.textContent)
            TextView textContent;
            @BindView(R.id.buttonEdit)
            ImageButton buttonEdit;

            ViewHolder(View view, FlexibleAdapter adapter) {
                super(view, adapter);
                ButterKnife.bind(this, view);
            }
        }
    }

}
