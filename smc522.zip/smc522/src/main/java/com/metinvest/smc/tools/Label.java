package com.metinvest.smc.tools;

import com.metinvest.smc.App;

import org.json.JSONObject;

import java.io.Serializable;

public class Label
		implements Serializable {

	//BASE
	private String data;

	private String smcId;
	private String id;
	private String name;
	private float length, width, thickness;
	private int weightNetto, weightPack, weightStart;
	private String batch, ozm;

	//OTHER
	private int locationId;
	private String locationCode;
	private String carrier;
	private String status;
	private boolean theor;
	private String lowPricePercent;
	private String discount, batchUcenka, lineId;
	private boolean release;

	private String zavBatch, zavPlavka, zavOdin;
	private String storage;

	private String manufacturer;

	private String sortCriterion;

	public Label() {
	}

	public Label copyLabel(String newLabelId) {
		Label label = new Label();
		label.data = data;
		label.id = newLabelId;
		label.name = name;
		label.length = length;
        label.width = width;
        label.thickness = thickness;
        label.weightNetto = weightNetto;
		label.weightStart = weightStart;
		label.weightPack = weightPack;
		label.batch = batch;
		label.ozm = ozm;
		label.locationId = locationId;
		label.locationCode = locationCode;
		label.carrier = carrier;
		label.status = status;
		label.theor = theor;
		label.lowPricePercent = lowPricePercent;
		label.release = release;
		label.zavBatch = zavBatch;
		label.zavPlavka = zavPlavka;
		label.zavOdin = zavOdin;
		label.storage = storage;
		label.manufacturer = manufacturer;
		label.sortCriterion = sortCriterion;
		label.discount = discount;
		label.batchUcenka = batchUcenka;
		label.lineId = lineId;
		return label;
	}

	public String getBatchUcenka() {
		return batchUcenka;
	}

	public void setBatchUcenka(String batchUcenka) {
		this.batchUcenka = batchUcenka;
	}

	public String getZavOdin() {
		return zavOdin;
	}

	public void setZavOdin(String zavOdin) {
		this.zavOdin = zavOdin;
	}

	public String getZavBatch() {
		return zavBatch;
	}

	public void setZavBatch(String zavBatch) {
		this.zavBatch = zavBatch;
	}

	public String getZavPlavka() {
		return zavPlavka;
	}

	public void setZavPlavka(String zavPlavka) {
		this.zavPlavka = zavPlavka;
	}

	public boolean isRelease() {
		return release;
	}

	public void setRelease(boolean release) {
		this.release = release;
	}

	public String getData() {
		return data;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
        this.id = id;
    }

    public boolean isTheor() {
        return theor;
    }

    public void setTheor(boolean theor) {
        this.theor = theor;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getLength() {
        return length;
    }

    public void setLength(float length) {
        this.length = length;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getThickness() {
        return thickness;
    }

    public void setThickness(float thickness) {
        this.thickness = thickness;
    }

    public int getWeightNetto() {
        return weightNetto;
    }

    public void setWeightNetto(int weightNetto) {
        this.weightNetto = weightNetto;
    }

	public int getWeightStart() {
		return weightStart;
	}

	public void setWeightStart(int weightStart) {
		this.weightStart = weightStart;
	}

    public int getWeightPack() {
        return weightPack;
    }

    public void setWeightPack(int weightPack) {
        this.weightPack = weightPack;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public String getOzm() {
        return ozm;
    }

    public void setOzm(String ozm) {
        this.ozm = ozm;
    }

    public int getLocationId() {
        return locationId;
    }

    public void setLocationId(int locationId) {
        this.locationId = locationId;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSmcId() {
		return smcId;
	}

	public void setSmcId(String smcId) {
		this.smcId = smcId;
	}

	public boolean isTemp() {
		return batch.equalsIgnoreCase("TEMP");
	}

	public String getStorage() {
		return storage;
	}

	public void setStorage(String storage) {
		this.storage = storage;
	}

	public String getDiscount() {
		return discount;
	}

	public void setDiscount(String discount) {
		this.discount = discount;
	}

	public String getLineId() {
		return lineId;
	}

	public void setLineId(String lineId) {
		this.lineId = lineId;
	}

	public static Label fromJson(JSONObject jsonObject) {
		return fromJson(jsonObject, null);
	}

	public static Label fromJson(String jsonString) {
		return fromJson(jsonString, null);
	}

	public static Label fromJson(JSONObject jsonObject, String labelId) {
		return jsonObject == null ? null : fromJson(jsonObject.toString(), labelId);
	}

	public static Label empty() {
		Label label = new Label();
		label.data = "";
		label.name = "";
		label.width = -1;
		label.length = -1;
		label.thickness = -1;
		label.batch = "";
		label.ozm = "";
		label.weightNetto = -1;
		label.weightPack = 0;
		label.locationCode = "";
		label.locationId = 0;
		label.carrier = "";
		label.theor = false;
		label.status = "";
		label.lowPricePercent = "";
		label.release = false;
		label.smcId = App.getInstance().getSmcIdCurrent();
		label.zavBatch = "";
		label.zavPlavka = "";
		label.zavOdin = "";
		label.storage = "";
		label.manufacturer = "";
		label.sortCriterion = "";
		label.discount = "";
		label.batchUcenka = "";
		label.lineId = "";
		return label;
	}

	public static Label fromJson(String jsonString, String labelId) {

		if (jsonString == null) return null;
		JSONObject json = Utils.getJsonObject(jsonString);
		if (json == null) return null;

		Label label = new Label();

		label.data = jsonString;
        if (labelId != null) {
            label.id = labelId;
        } else {
			label.id = Utils.jsonExist(json, "label_Id") ?
					Utils.getJsonStringIgnoreCase(json, "label_Id") :
					(
							Utils.jsonExist(json, "labelId") ?
									Utils.getJsonStringIgnoreCase(json, "labelId") :
									Utils.getJsonStringIgnoreCase(json, "id")
					);
		}
		label.name = Utils.jsonExist(json, "sap_matt_descr") ? Utils.getJsonStringIgnoreCase(json, "sap_matt_descr") : Utils.getJsonStringIgnoreCase(json, "name");
		label.width = Utils.getJsonFloatIgnoreCase(json, "width");
		label.length = Utils.getJsonFloatIgnoreCase(json, "length");
		label.thickness = Utils.getJsonFloatIgnoreCase(json, "thickness");
		label.batch = Utils.jsonExist(json, "saP_Batch") ? Utils.getJsonStringIgnoreCase(json, "saP_Batch") : Utils.getJsonStringIgnoreCase(json, "batch");
		label.ozm = Utils.jsonExist(json, "saP_Ozm") ? Utils.getJsonStringIgnoreCase(json, "saP_Ozm") : Utils.getJsonStringIgnoreCase(json, "ozm");
		label.weightNetto = Utils.getJsonIntIgnoreCase(json, "netT_Weight");
		label.weightStart = Utils.getJsonIntIgnoreCase(json, "start_Weight");
		label.weightPack = Utils.getJsonIntIgnoreCase(json, "pack_Weight");
		label.locationCode = Utils.getJsonStringIgnoreCase(json, "locationCode");
		label.locationId = Utils.getJsonIntIgnoreCase(json, "location_id");
		label.carrier = Utils.getJsonStringIgnoreCase(json, "ttN_Carier_ID");
		if (Utils.isNullOrEmpty(label.carrier))
			label.carrier = Utils.getJsonStringIgnoreCase(json, "ttN_Carrier_ID");
		label.theor = Utils.getJsonStringIgnoreCase(json, "teoR_Weight").equalsIgnoreCase("true");
		label.status = Utils.getJsonStringIgnoreCase(json, "statuS_OUT");
		label.lowPricePercent = Utils.getJsonString(json, "loW_PRICE_PERCENT");
		label.release = Utils.getJsonStringIgnoreCase(json, "release").equalsIgnoreCase("true");
		//if (label.weightNetto < 0) label.weightNetto = 0;
		if (label.weightPack < 0) label.weightPack = 0;
		label.smcId = Utils.getJsonStringIgnoreCase(json, "smC_ID");
		label.storage = Utils.getJsonStringIgnoreCase(json, "lgort");
		label.manufacturer = Utils.getJsonStringIgnoreCase(json, "PROIZVOD");
		label.sortCriterion = Utils.getJsonStringIgnoreCase(json, "PRICHINA_OTSORT");
		String qrCode = Utils.getJsonStringIgnoreCase(json, "qr_code");
		if (qrCode.length() > 0) {
			ScanItem scanItem = new ScanItem(qrCode);
			if (scanItem.isCorrect()) {
				if (scanItem.getType() == ScanItem.ScanItemType.KOMINMET) {
					label.zavPlavka = scanItem.getData(2);
					label.zavBatch = scanItem.getData(3);
				} else if (scanItem.getType() == ScanItem.ScanItemType.ZAPOR) {
					label.zavPlavka = scanItem.getData(7);
					label.zavBatch = scanItem.getData(8);
					label.zavOdin = scanItem.getData(9);
				} else if (scanItem.getType() == ScanItem.ScanItemType.TRUBOSTAL) {
					label.zavPlavka = scanItem.getData(3);
					label.zavBatch = "";
				} else if (scanItem.getType() == ScanItem.ScanItemType.ARCELOR) {
					label.zavPlavka = "";
					label.zavBatch = "";
				}
			}
		}

		if (label.zavBatch == null)
			label.zavBatch = Utils.getJsonStringIgnoreCase(json, "zavBatch");
		if (label.zavPlavka == null)
			label.zavPlavka = Utils.getJsonStringIgnoreCase(json, "plavka");
		if (label.zavOdin == null) label.zavOdin = Utils.getJsonStringIgnoreCase(json, "zavOdin");

		return label;
	}

    public String getLowPricePercent() {
        return lowPricePercent;
    }

    public void setLowPricePercent(String lowPricePercent) {
        this.lowPricePercent = lowPricePercent;
    }

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getSortCriterion() {
		return sortCriterion;
	}

	public void setSortCriterion(String sortCriterion) {
		this.sortCriterion = sortCriterion;
	}
}
