package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Carrier;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.tools.DplGeneratorTransport;
import com.metinvest.smc.tools.IValue;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemOnTheWay;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class ComingListActivity extends MyActivity implements AdapterItemOnTheWay.IAdapterItemOnTheWayListener {

    @BindView(R.id.spinnerCarrier)
    Spinner spinnerCarrier;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    @BindView(R.id.buttonPrint)
    Button buttonPrint;

    private FlexibleAdapter<AdapterItemOnTheWay> adapter;

    private long carrierId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coming_list);
        ButterKnife.bind(this);

        textNotFound.setVisibility(View.GONE);

        spinnerCarrier.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                carrierId = id;
                beginLoadData();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
        listView.setLayoutManager(layoutManager);
        listView.addItemDecoration(dividerItemDecoration);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoadCarrierList();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) {
            spinnerCarrier.requestFocus();
            spinnerCarrier.performClick();
        } else if (number == 4) {
            buttonPrintClick();
        }
    }

    private void beginLoadCarrierList() {

        showLoading(R.string.text_please_wait);

        runOnUiThread(() -> {
            List<Carrier> carriers = new ArrayList<>();

            long cId = getIntent().getLongExtra("carrierId", 0);
            if (cId > 0) {
                Carrier carrier = db.carrierDao().getById(cId);
                if (carrier != null) carriers.add(carrier);
            }

            if (carriers.isEmpty()) carriers = db.carrierDao().getAll();

            ArrayList<IValue> list = new ArrayList<>(new ArrayList<IValue>(carriers));

            runOnUiThread(() -> endLoadCarrierList(list));
        });
    }

    private void endLoadCarrierList(ArrayList<IValue> list) {
        Utils.fillData(spinnerCarrier, list);
        hideLoading();
    }

    private void beginLoadData() {

        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            List<OnTheWay> list;

            list = db.onTheWayDao().getByCarrierId(carrierId);

            List<AdapterItemOnTheWay> items = new ArrayList<>(list.size());
            for (int i = 0; i < list.size(); i++) {
                items.add(new AdapterItemOnTheWay(list.get(i), this));
            }

            adapter = new FlexibleAdapter<>(items);

            endLoadData();
        });
    }

    private void endLoadData() {
        hideLoading();

        runOnUiThread(() -> {
            listView.setAdapter(adapter);
            scrollView.post(() -> scrollView.scrollTo(0, 0));
            textNotFound.setVisibility(adapter.getItemCount() > 0 ? View.GONE : View.VISIBLE);
        });
    }

    @Override
    public void onViewClicked(int position) {
        AdapterItemOnTheWay item = adapter.getItem(position);
        if (item != null) {
            OnTheWay way = item.getOnTheWay();
            if (way != null) {
                Intent intent = new Intent(this, WayActivity.class);
                intent.putExtra("wayId", way.getId());
                startActivityForResult(intent, REQUEST_DEFAULT);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_DEFAULT && resultCode == RESULT_OK) {
            beginLoadData();
        }
    }

    private void buttonPrintClick() {
        if (isLoading() || !buttonPrint.isEnabled()) return;

        beginPrint();
    }

    private void beginPrint() {

        buttonPrint.setEnabled(false);
        showLoading(R.string.text_printing_title);

        Utils.runOnBackground(() -> {

            DplGeneratorTransport gen = new DplGeneratorTransport(carrierId);
            String title = gen.generateTitle();
            String dpl = gen.generateDpl();

            if (dpl.isEmpty()) {
                runOnUiThread(() -> endPrint(null));
            } else {
                final Printer.PrintResult result = Printer.sendCommand(title, config.getPrinter(), dpl);
                runOnUiThread(() -> endPrint(result));
            }

        });
    }

    private void endPrint(@Nullable Printer.PrintResult result) {

        buttonPrint.setEnabled(true);
        hideLoading();
        scrollView.post(() -> scrollView.scrollTo(0, 0));

        if (result == null) {
            showToast(R.string.error_weighing_list_empty);
        } else if (result.getStatus() == Printer.PrintResultStatus.OK) {
            showToast(R.string.text_print_result_succeeded);
			//app.sendFaPrint();
        } else {
            @StringRes final int message = app.getPrintResultMessage(result);

            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> {
                dialog.dismiss();
                buttonPrintClick();
            });
        }

    }
}
