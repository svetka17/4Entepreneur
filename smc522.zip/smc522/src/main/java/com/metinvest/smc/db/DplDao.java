package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface DplDao {
    @Query("SELECT * FROM dpl ORDER BY id DESC")
    List<Dpl> getAll();

    @Query("SELECT * FROM dpl ORDER BY id DESC LIMIT 1")
    Dpl getLast();

    @Insert
    long insert(Dpl dpl);

    @Insert
    void insertAll(List<Dpl> dplList);

    @Update
    void update(Dpl dpl);

    @Delete
    void delete(Dpl dpl);

    @Query("DELETE FROM dpl where id NOT IN (SELECT id from dpl ORDER BY id DESC LIMIT 25)")
    void deleteOld();

    @Query("DELETE FROM dpl")
    void truncate();
}