package com.metinvest.smc.view;

import android.os.Bundle;
import android.widget.TextView;

import com.metinvest.smc.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class HelpActivity extends MyActivity {

    @BindView(R.id.textContent)
    TextView textContent;
    @BindView(R.id.buttonBack)
    TextView buttonBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        ButterKnife.bind(this);

        String content = getIntent().getStringExtra("content");
        textContent.setText(content);
        buttonBack.setFocusableInTouchMode(true);
        buttonBack.requestFocus();
    }
}
