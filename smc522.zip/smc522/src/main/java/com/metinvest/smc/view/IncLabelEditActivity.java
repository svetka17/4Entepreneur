package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.inc.Order;
import com.metinvest.smc.inc.SohFilter;
import com.metinvest.smc.inc.TTN;
import com.metinvest.smc.inc.TransportDoc;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.JsonUploadTask;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.Utils;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class IncLabelEditActivity extends MyActivity {

	@BindView(R.id.textContent)
	TextView textContent;
	@BindView(R.id.textWeightNetto)
	EditText textWeightNetto;
	@BindView(R.id.textWeightPack)
	EditText textWeightPack;
	@BindView(R.id.textBatch)
	TextView textBatch;
	@BindView(R.id.viewContentData)
	View viewContentData;
	@BindView(R.id.buttonBatch)
	ImageButton buttonBatch;
	@BindView(R.id.buttonAccept)
	Button buttonAccept;
	@BindView(R.id.viewBatch)
	View viewBatch;

	private String labelId;
	private Date dateFrom, dateTo, date;
	private String transportName;
	private TTN ttn;
	private String status;
	private ArrayList<String> batchList;
	private ArrayList<Integer> weightList;
	private SohFilter sohFilter;
	private String sohSmcId;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_inc_label_edit);
		ButterKnife.bind(this);

		sohSmcId = getIntent().getStringExtra("sohSmcId");
		sohFilter = sohSmcId == null ? SohFilter.NotSoh() : SohFilter.SohInc(sohSmcId);
		dateFrom = (Date) getIntent().getSerializableExtra("dateFrom");
		dateTo = (Date) getIntent().getSerializableExtra("dateTo");
		date = (Date) getIntent().getSerializableExtra("date");
		transportName = getIntent().getStringExtra("transportName");
		ttn = (TTN) getIntent().getSerializableExtra("ttn");
		status = getIntent().getStringExtra("status");
		labelId = getIntent().getStringExtra("labelId");

		textBatch.setClickable(true);
		textBatch.setShowSoftInputOnFocus(false);
		textBatch.setOnClickListener(v -> buttonBatchClick());
		buttonBatch.setOnClickListener(v -> buttonBatchClick());
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		beginLoad();
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 5) {
			buttonAcceptClick();
		}
	}

	private void buttonAcceptClick() {
		if (isLoading() || !buttonAccept.isEnabled()) return;

		beginAccept();
	}

	private void beginLoad() {
		if (isLoading()) return;

		viewBatch.setVisibility(View.GONE);
		showLoading(R.string.text_please_wait);
		viewContentData.setVisibility(View.GONE);

		Utils.runOnBackground(() -> {
			String smcId = sohFilter.getSohSmcId();
			JsonResult result = net.loadLabelInfo(smcId, labelId);

			Label label = null;
			List<Order> listDoc = null;

			if (result.isOk()) {
				JSONObject json = Utils.getJsonObject(result.getJson(), "data");
				label = Label.fromJson(json);

				Network.NetworkResultValue<TransportDoc> resultDoc = app.loadIncTransportDoc(date, dateFrom, dateTo, transportName, ttn, sohFilter);

				listDoc = new ArrayList<>();
				if (resultDoc.getResult().isOk() && resultDoc.getValue() != null) {
					Network.NetworkResultValue<List<Order>> resultDocuments = app.loadIncOrderList(date, resultDoc.getValue(), sohFilter);
					if (resultDocuments.getResult().isOk()) {
						listDoc = resultDocuments.getValue();
					} else {
						result = resultDocuments.getResult();
					}
				}
			}

			JsonResult finalResult = result;

			List<Order> finalListDoc = listDoc;
			Label finalLabel = label;
			runOnUiThread(() -> endLoad(finalResult, finalLabel, finalListDoc));
		});
	}

	private void endLoad(JsonResult result, Label label, List<Order> finalListDoc) {

		hideLoading();

		if (result.isOk() && label != null && finalListDoc != null) {
			viewContentData.setVisibility(View.VISIBLE);
			textContent.setText(app.fromHtml(Utils.format("<b>%s</b>", label.getName())));
			textWeightNetto.setText(String.valueOf(label.getWeightNetto()));
			textWeightPack.setText(String.valueOf(label.getWeightPack()));
			textBatch.setText(String.valueOf(label.getBatch()));
			viewBatch.setVisibility(label.isRelease() ? View.VISIBLE : View.GONE);

			batchList = new ArrayList<>();
			weightList = new ArrayList<>();
			for (Order order : finalListDoc) {
				if (order.getSapOzm().equalsIgnoreCase(label.getOzm())) {
					batchList.add(order.getBatch());
					weightList.add(order.getWeightPlan() - order.getWeightFact());
				}
			}
		} else {
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad(), (dialogInterface, i) -> {
				setResult(RESULT_CANCELED);
				finish();
			});
		}
	}

	private void beginAccept() {
		showLoading(R.string.text_please_wait);
		buttonAccept.setEnabled(false);

		int nettoNew = Utils.parseInt(textWeightNetto.getText().toString());
		int packNew = Utils.parseInt(textWeightPack.getText().toString());
		String batch = textBatch.getText().toString();

		String url = config.getUrlApi() + "editsapinboundlabel";
		url = net.addUrlParam(url, "LabelId", labelId);
		url = net.addUrlParam(url, "NettWeight", String.valueOf(nettoNew));
		url = net.addUrlParam(url, "PackWeight", String.valueOf(packNew));
		url = net.addUrlParam(url, "batch", batch);
		if (sohFilter.getSohSmcId() != null)
			url = net.addUrlParam(url, "smc_id", sohFilter.getSohSmcId());

		net.uploadJson(new JsonUploadTask.JsonUploadTaskParam(url, ""), result -> endAccept(result, nettoNew, packNew));
	}

	@Override
	public void onBackPressed() {
		setResult(RESULT_CANCELED);
		super.onBackPressed();
	}

	private void endAccept(JsonResult result, int netto, int pack) {
		if (result.isOk()) {
			Toast.makeText(this, R.string.successful_accepted, Toast.LENGTH_SHORT).show();
			Intent data = new Intent();
			data.putExtra("labelId", labelId);
			data.putExtra("netto", netto);
			data.putExtra("pack", pack);
			setResult(RESULT_OK, data);
			finish();
		} else if (result.getStatus() == LoadResultStatus.PLUS2) {
			hideLoading();
			showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.set_label_weight_error_plus2, null);
		} else {
			hideLoading();
			buttonAccept.setEnabled(true);
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginAccept());
		}
	}

	public void buttonBatchClick() {
		Intent intent = new Intent(this, BatchSelectActivity.class);
		intent.putStringArrayListExtra("batchList", batchList);
		intent.putIntegerArrayListExtra("weightList", weightList);
		startActivityForResult(intent, REQUEST_EDIT);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == REQUEST_EDIT && resultCode == RESULT_OK && data != null) {
			String batchNew = data.getStringExtra("batch");
			textBatch.setText(batchNew);
		}
	}
}
