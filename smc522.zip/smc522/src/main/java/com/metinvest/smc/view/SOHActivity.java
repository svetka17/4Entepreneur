package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.Utils;

import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SOHActivity extends MyActivity {

	@BindView(R.id.buttonAccept)
	Button buttonAccept;
	@BindView(R.id.textWeight)
	TextView textWeight;
	@BindView(R.id.textSOHWeight)
	EditText textSOHWeight;
	@BindView(R.id.buttonCrane)
	ImageButton buttonCrane;

	private String labelId;
	private int weight;
	private int splitWeight;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_soh);
		ButterKnife.bind(this);

		labelId = getIntent().getStringExtra("labelId");
		weight = getIntent().getIntExtra("weight", 0);

		textWeight.setText(Utils.format("%d кг", weight));
		textSOHWeight.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				onSplitWeightChanged();
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		});
		onSplitWeightChanged();

		setActionDone(textSOHWeight, buttonAccept);

		buttonCrane.setOnClickListener(v -> loadCraneWeight());
		buttonCrane.setOnLongClickListener(v -> {
			loadCraneTara();
			return true;
		});
	}

	@Override
	protected void onCraneWeight(long craneId, int value) {
		textSOHWeight.setText(String.valueOf(value));
		onSplitWeightChanged();
	}

	private void onSplitWeightChanged() {
		splitWeight = Utils.parseInt(textSOHWeight.getText().toString());
		buttonAccept.setEnabled(splitWeight > 0 && splitWeight < weight);
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 5) {
            buttonAcceptClick();
        }
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        beginAccept();
    }

    private void beginAccept() {
        showLoading(R.string.text_please_wait);
        buttonAccept.setEnabled(true);

        String url = config.getUrlApi() + "clonelabel";
        url = net.addUrlParam(url, "label_id", labelId);
		url = net.addUrlParam(url, "sox", 1);
        url = net.addUrlParam(url, "Weight_nett", splitWeight);
        url = net.addUrlParam(url, "Weight_pack", 0);
        reqGet(url, this::endAccept);
    }

	private void endAccept(JsonResult result) {
		hideLoading();
		buttonAccept.setEnabled(!result.isOk());

		JSONObject json = Utils.getJsonObject(result.getJson(), "data");

		if (result.isOk() && json != null) {

			String newLabelId = Utils.getJsonStringIgnoreCase(json, "label_id");

			showDialog(R.drawable.ic_info_24dp, R.string.text_information, "Розміщуйте залишок в окремій стопці", (dialog, which) -> {
				//Toast.makeText(this, R.string.split_ok, Toast.LENGTH_SHORT).show();
				Intent data = new Intent();
				data.putExtra("labelId", labelId);
				data.putExtra("newLabelId", newLabelId);
				data.putExtra("weightSplit", splitWeight);
				setResult(RESULT_OK, data);
				//finish();
				beginPreparePrint(newLabelId);
			});

		} else if (result.getStatus() == LoadResultStatus.PLUS2) {
			showDialog(R.drawable.ic_error_24dp, R.string.text_error, "Заблоковано. позицію переведено в статус, що не дозволяє операцію!", null);
		} else if (result.getStatus() == LoadResultStatus.PLUS3) {
			showDialog(R.drawable.ic_error_24dp, R.string.text_error, "Вага нової етикетки більша за стару! Оновіть дані.", null);
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginAccept());
		}
    }

	private void beginPrint(Label label) {

		showLoading(R.string.text_printing_title);

		Utils.runOnBackground(() -> {
			Utils.NetworkPrintResult result = Utils.printLabel(label.getId());
			runOnUiThread(() -> endPrint(result, label));
		});
	}

	private void endPrint(Utils.NetworkPrintResult result, Label label) {

		hideLoading();

		if (result.getNetworkResult().isOk()) {

			if (result.getPrintResult().getStatus() == Printer.PrintResultStatus.OK) {
				String message = getString(R.string.printer_ship_ok, label.getId(), "", label.getWeightNetto());
				showDialog(R.drawable.ic_info_24dp, R.string.text_information, message, (dialog, which) -> {
					try {
						close();
					} catch (Exception ignored) {

					}
				});
			} else {
				final int message = app.getPrintResultMessage(result.getPrintResult());
				showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> beginPreparePrint(label.getId()), (dialog, which) -> showDialogPrintCanceled(label.getId(), label.getWeightNetto()));
			}

		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result.getNetworkResult()), (dialog, which) -> endPreparePrint(label));
		}

	}

	private void close() {
		Intent intent = new Intent();
		setResult(RESULT_OK, intent);
		finish();
	}

	private void showDialogPrintCanceled(String labelId, int netto) {
		String message = getString(R.string.printer_ship_canceled, labelId, "", netto);
		showDialog(R.drawable.ic_info_24dp, R.string.text_information, message, (dialog, which) -> close()).setCanceledOnTouchOutside(false);
	}

	private void beginPreparePrint(String newLabelId) {

		showLoading(R.string.text_please_wait);

		Utils.runOnBackground(() -> {
			Label label;
			if (newLabelId != null) {
				String urlLabel = config.getUrlApi() + "getlabelinfo";
				urlLabel = net.addUrlParam(urlLabel, "label_id", newLabelId);
				urlLabel = net.addUrlParam(urlLabel, "smc_id", "NULL");
				JsonResult resultLabel = net.downloadJson(urlLabel);
				if (resultLabel.isOk()) {
					//GET LABEL
					JSONObject json = Utils.getJsonObject(resultLabel.getJson(), "data");
					label = Label.fromJson(json, newLabelId);
					runOnUiThread(() -> {
						hideLoading();
						endPreparePrint(label);
					});
				}
				else {
					runOnUiThread(() -> {
						hideLoading();
						showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, "LabelId ERROR", (dialog, which) -> beginPreparePrint(newLabelId));
					});
				}
			}
		});
	}

	private void endPreparePrint(Label label) {

		if (label.getWeightNetto() <= 0) {
			close();
		} else {
			showDialogConfirm(getString(R.string.text_warning), getString(R.string.inc_print_soh),
					(dialog, which) -> requestPrint(label));
		}
	}

	private void requestPrint(Label label){
		beginPrint(label);
	}
}
