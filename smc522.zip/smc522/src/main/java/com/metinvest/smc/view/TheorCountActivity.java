package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

import com.metinvest.smc.R;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.Utils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class TheorCountActivity extends MyActivity {

    @BindView(R.id.buttonAccept)
    Button buttonAccept;
    @BindView(R.id.textCount)
    EditText textCount;

    private int maxCount;
    private int count;
    private List<Label> labelList;
    private List<Integer> birkNettoList;
    private List<Serializable> dateScanList;
    private List<Integer> nettoFinalList;
    private boolean isInv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theor_count);
        ButterKnife.bind(this);

        maxCount = getIntent().getIntExtra("maxCount", 0);
        isInv = getIntent().getBooleanExtra("inv", false);
        labelList = new ArrayList<>(maxCount);
        if (isInv) {
            birkNettoList = new ArrayList<>(maxCount);
            dateScanList = new ArrayList<>(maxCount);
            nettoFinalList = new ArrayList<>(maxCount);
        }

        for (int i = 0; i < maxCount; i++) {
            Serializable item = getIntent().getSerializableExtra("label" + i);
            if (item instanceof Label) labelList.add((Label) item);

            if (isInv) {
                birkNettoList.add(getIntent().getIntExtra("birkNetto" + i, 0));
                dateScanList.add(getIntent().getSerializableExtra("dateScan" + i));
                nettoFinalList.add(getIntent().getIntExtra("nettoFinal" + i, 0));
            }
        }

        textCount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                onTextCountChanged(Utils.parseInt(s.toString()));
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        textCount.setText(String.valueOf(maxCount));

        setActionDone(textCount, this::buttonAcceptClick);
    }

    private void onTextCountChanged(int newCount) {
        this.count = newCount;
        boolean ok = count > 0 && count <= maxCount;
        buttonAccept.setEnabled(ok);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    private void buttonAcceptClick() {
        if (!buttonAccept.isEnabled()) return;

        Intent data = new Intent();
        data.putExtra("count", count);
        data.putExtra("maxCount", maxCount);
        data.putExtra("inv", isInv);

        for (int i = 0; i < maxCount; i++) {
            data.putExtra("label" + i, labelList.get(i));
            if (isInv) {
                data.putExtra("birkNetto" + i, birkNettoList.get(i));
                data.putExtra("dateScan" + i, dateScanList.get(i));
                data.putExtra("nettoFinal" + i, nettoFinalList.get(i));
            }
        }

        setResult(RESULT_OK, data);
        finish();
    }

}
