package com.metinvest.smc.view;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.IValue;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.tools.Value;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CranesActivity extends MyActivity {

    @BindView(R.id.textContent)
    TextView textContent;
    @BindView(R.id.viewButtons)
    View viewButtons;
    @BindView(R.id.buttonCheck)
    Button buttonCheck;
    @BindView(R.id.buttonTara)
    Button buttonTara;
    @BindView(R.id.buttonSave)
    Button buttonSave;
    @BindView(R.id.spinnerCrane)
    Spinner spinnerCrane;

    private List<JSONObject> craneList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cranes);
        ButterKnife.bind(this);

        log("craneId = %d", config.getCraneId());

        buttonCheck.setEnabled(false);

        spinnerCrane.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                refreshButtonCheck();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                refreshButtonCheck();
            }
        });
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 3) {
            buttonCheckClick();
        } else if (number == 4) {
            buttonTaraClick();
        } else if (number == 5) {
            buttonSaveClick();
        }
    }

    private void buttonCheckClick() {
        if (buttonCheck.isEnabled()) {
            showLoading(R.string.text_please_wait);
            buttonCheck.setEnabled(false);
            loadCraneWeight(getSpinnerCraneId());
        }
    }

    private void buttonTaraClick() {
        if (buttonTara.isEnabled()) {
            loadCraneTara(getSpinnerCraneId());
        }
    }

    private long getSpinnerCraneId() {
        return spinnerCrane.getAdapter() == null ? 0 : spinnerCrane.getSelectedItemId();
    }

    private void refreshButtonCheck() {
        buttonCheck.setEnabled(getSpinnerCraneId() > 0);
        buttonTara.setEnabled(getSpinnerCraneId() > 0);
    }

    private void buttonSaveClick() {

        long craneId = getSpinnerCraneId();

        config.setCraneId(craneId < 0 ? 0 : craneId);
        config.saveConfig();

        log("new craneId = %d", craneId);

        if (craneId > 0) setResult(RESULT_OK);
        finish();
    }

    private void beginLoad() {
        showLoading(R.string.text_please_wait);
        viewButtons.setVisibility(View.GONE);
        craneList.clear();

        Utils.runOnBackground(() -> {

            //String url = "http://dc00-apps-16.metinvest.ua:8088/Api/Crane_List";
            //url = net.addUrlParam(url, "label_id", labelId);
            //Map<String, String> headers = new HashMap<>();
            //headers.put("AuthHeader", "Basic dXNlcm5hbWUKUGFzc3dvcmQ=");
            //JsonResult result = net.requestProxy(url, false, headers, null);
            String url = config.getUrlApi() + "getSprCranes";
            url = net.addUrlParam(url, "smc_id", config.getSmcId());
            JsonResult result = net.downloadJson(url);

            craneList.clear();

            if (result.isOk()) {

                log("RES: %s", result.getJson().toString());

                JSONArray jsonArray = Utils.getJsonArray(Utils.getJsonStringIgnoreCase(result.getJson(), "data"));
                //String jsonArray = Utils.getJsonStringIgnoreCase(result.getJson(), "data");
                for (int i = 0; jsonArray != null && i < jsonArray.length(); i++) {
                    craneList.add(Utils.getJsonObject(jsonArray, i));
                }
            }

            runOnUiThread(() -> endLoad(result));
        });
    }

	private void endLoad(JsonResult result) {

		hideLoading();
		viewButtons.setVisibility(View.VISIBLE);

		showContent();

		if (!result.isOk()) {
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
		}
	}

    @Override
    protected void onCraneWeight(long craneId, int value) {
        log("Crane #%d = %d kg", craneId, value);

        showDialog(R.drawable.ic_info_24dp, R.string.text_information,
                Utils.format("Вага на крані: %d кг", value)
                , null);

        refreshButtonCheck();
        hideLoading();
    }

    private void showContent() {
        StringBuilder sb = new StringBuilder();

        if (craneList.isEmpty()) {
            sb.append(getString(R.string.text_cranes_not_found));
        } else {
            sb.append(getString(R.string.text_prompt_select_crane));
        }

        textContent.setText(app.fromHtml(sb.toString()));

        int selectedIndex = 0;

        List<IValue> list = new ArrayList<>(craneList.size() + 1);
        list.add(new Value(-1, "[Не обрано]"));
        for (int i = 0; i < craneList.size(); i++) {
            JSONObject jsonObject = craneList.get(i);

            long craneId = Utils.getJsonLongIgnoreCase(jsonObject, "id");
            String craneName = Utils.getJsonStringIgnoreCase(jsonObject, "description");

            //JSONObject wightScale = Utils.getJsonObject(jsonObject, "wightScale");
            //String weightName = Utils.getJsonStringIgnoreCase(wightScale, "name");

            //JSONObject position = Utils.getJsonObject(jsonObject, "position");
            String num_crane = Utils.getJsonStringIgnoreCase(jsonObject, "num_crane");
            String def_crane = Utils.getJsonStringIgnoreCase(jsonObject, "default_crane");

            String finalName = Utils.format(
                    "%s%s",
                    num_crane,
                    (craneName.length() > 0 ? Utils.format(" (%s)", craneName) : "")
            );

            list.add(new Value(craneId, finalName));

            if (craneId == config.getCraneId()) {
                selectedIndex = i + 1;
            }
            else if (def_crane == "true" && config.getCraneId() == 0) {
                selectedIndex = i + 1;
            }
        }

        Utils.fillData(spinnerCrane, list);
        spinnerCrane.setSelection(selectedIndex);

    }
}
