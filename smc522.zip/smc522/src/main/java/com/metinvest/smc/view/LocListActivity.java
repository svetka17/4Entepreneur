package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterSimple;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class LocListActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.textNotFound)
    TextView textNotFound;

    private FlexibleAdapter<AdapterSimple> adapter;
    private ArrayList<String> locationList;

    private ArrayList<String> sapBatchList;
    private ArrayList<Integer> weightList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loc_list);
        ButterKnife.bind(this);

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        locationList = new ArrayList<>(getIntent().getStringArrayListExtra("locationList"));
        sapBatchList = new ArrayList<>(getIntent().getStringArrayListExtra("sapBatchList"));
        weightList = new ArrayList<>(getIntent().getIntegerArrayListExtra("weightList"));

        beginLoad();
    }

    private void beginLoad() {
        if (isLoading()) return;

        Utils.runOnBackground(() -> {
            List<AdapterSimple> list = new ArrayList<>();

            for (int i = 0; locationList != null && i < locationList.size(); i++) {
                String content = Utils.format("Загальна вага тн.: <b>%.3f</b>", weightList.get(i) / 1000000.0f);
                String location = locationList.get(i);
                if (sapBatchList.get(i).equalsIgnoreCase("1")) {
                    location = Utils.format("<font color=\"blue\"><b>%s</b></font>", locationList.get(i));
                }
                AdapterSimple item = new AdapterSimple(null, location, content);
                list.add(item);
            }

            endLoad(list);
        });
    }

    private void endLoad(List<AdapterSimple> list) {
        hideLoading();

        adapter = new FlexibleAdapter<>(list);
        adapter.addListener(this);
        listView.setAdapter(adapter);
        scrollView.post(() -> scrollView.scrollTo(0, 0));
        textNotFound.setVisibility(adapter.getItemCount() > 0 ? View.GONE : View.VISIBLE);
    }

    @Override
    public boolean onItemClick(View view, int position) {
        AdapterSimple item = adapter.getItem(position);
        if (item != null) {
            Intent data = new Intent();
            data.putExtra("locationCode", item.getTitle());
            data.putExtra("id", getIntent().getLongExtra("id", -1));
            setResult(RESULT_OK, data);
            finish();
        }
        return false;
    }
}
