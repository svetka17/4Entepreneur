package com.metinvest.smc.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.metinvest.smc.tools.IValue;
import com.metinvest.smc.tools.Utils;

@Entity
public class IdQrStore implements IValue {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private String name;

    public IdQrStore() {
    }

    @Ignore
    public IdQrStore(long id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NonNull
    @Override
    public String toString() {
        return Utils.format("[%s] %s", getId(), getName());
    }
}
