package com.metinvest.smc.ui;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.db.ShipmentDocument;
import com.metinvest.smc.db.ShipmentTransport;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemDocument extends AbstractFlexibleItem<AdapterItemDocument.AdapterItemShipViewHolder> {

    public interface Listener {
        void onItemCheck(AdapterItemDocument item, boolean checked);
    }

    private final ShipmentDocument document;
    private final App app;
    private final /*List<ShipmentItem>*/ ShipmentTransport shipmentItems;
    private final Listener listener;
    private boolean checked;

    public AdapterItemDocument(ShipmentDocument document, /*List<ShipmentItem>*/ShipmentTransport shipmentItems, Listener listener) {
        this.listener = listener;
        this.app = App.getInstance();
        this.document = document;
        this.shipmentItems = shipmentItems;
        this.checked = false;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public ShipmentDocument getDocument() {
        return document;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterItemDocument && ((AdapterItemDocument) o).getDocument().getId() == getDocument().getId();
    }

    @Override
    public AdapterItemShipViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new AdapterItemShipViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemShipViewHolder holder, int position, List<Object> payloads) {

        holder.textTitle.setText(app.fromHtml(Utils.format("Наряд <b>%s</b>", document.getDocNumber())));

        StringBuilder sb = new StringBuilder();

        if (document.isDeleted()) {
            sb.append("ВП видалено<br>");
        }

        if (document.getDateVoDt() != null) {
            sb.append(Utils.format("Дата VO: %s<br>", app.getDateFormat().format(document.getDateVoDt())));
        }
        sb.append(Utils.format("План, тн: %.3f<br>", document.getPlan() / 1000.f));
        sb.append(Utils.format("Факт, тн: %s<br>", Utils.factToString(document.getFact())));
        if (app.getConfig().isEo())
            sb.append(Utils.format("%s", Utils.shipStatusToStringEO(document.getStatus())));
        else
            sb.append(Utils.format("%s", Utils.shipStatusToString(document.getStatus())));

        holder.textContent.setText(app.fromHtml(sb.toString()));
        if (app.getConfig().isEo())
            holder.imageStatus.setImageResource(Utils.shipStatusToImageShipEO(document.getStatus()));
        else
            holder.imageStatus.setImageResource(document.isDeleted() ? R.drawable.ic_ship_black : Utils.shipStatusToImageShip(document.getStatus()));

        View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
        holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
        refreshBackground(holder, holder.itemView.isFocused());

        View.OnClickListener listenerCheck = v -> {
            checked = !checked;
            refreshCheck(holder);
            if (listener != null) {
                listener.onItemCheck(this, checked);
            }
        };
        holder.imageCheck.setOnClickListener(listenerCheck);
        holder.imageStatus.setOnClickListener(listenerCheck);
        /*if (app.getConfig().isEo())
            holder.orderCount.setText(String.valueOf(shipmentItems.getOrderCount()));
        else*/
            holder.orderCount.setText(String.valueOf(document.getOrderCount()));
        refreshCheck(holder);
    }

    private void refreshCheck(AdapterItemShipViewHolder holder) {
        holder.imageStatus.setVisibility(!isChecked() ? View.VISIBLE : View.GONE);
        holder.imageCheck.setVisibility(isChecked() ? View.VISIBLE : View.GONE);
    }

    private void refreshBackground(AdapterItemShipViewHolder holder, boolean hasFocus) {
        holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.imageStatus.getContext(), hasFocus ? R.color.color_yellow : R.color.color_adapter_light));
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_ship;
    }

    static class AdapterItemShipViewHolder extends FlexibleViewHolder {

        @BindView(R.id.textTitle)
        TextView textTitle;
        @BindView(R.id.textContent)
        TextView textContent;
        @BindView(R.id.imageStatus)
        ImageView imageStatus;
        @BindView(R.id.imageCheck)
        ImageView imageCheck;
        @BindView(R.id.orderCount)
        TextView orderCount;

        AdapterItemShipViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            ButterKnife.bind(this, view);
        }
    }
}
