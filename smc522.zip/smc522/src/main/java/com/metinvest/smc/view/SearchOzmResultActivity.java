package com.metinvest.smc.view;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.inc.Ozm;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.Location;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterSimple;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class SearchOzmResultActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.textNotFound)
    TextView textNotFound;

    private String text;
    private boolean fullName;
    private float length, width, thickness;

    private ArrayList<ArrayList<Location>> locationList;
    private ArrayList<Ozm> ozmList;

    private int page = 1;
    private int currentOzm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_ozm_result);
        ButterKnife.bind(this);

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        textNotFound.setVisibility(View.GONE);
        listView.setVisibility(View.GONE);

        text = getIntent().getStringExtra("text");
        fullName = getIntent().getBooleanExtra("fullName", true);
        length = getIntent().getFloatExtra("length", -1);
        width = getIntent().getFloatExtra("width", -1);
        thickness = getIntent().getFloatExtra("thickness", -1);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginSearch();
    }

    private void beginSearch() {

        showLoading(R.string.text_please_wait);
        textNotFound.setVisibility(View.GONE);
        listView.setVisibility(View.GONE);

        Utils.runOnBackground(() -> {
            page = 1;
            locationList = new ArrayList<>();
            ozmList = new ArrayList<>();

            String url = config.getUrlApi() + (fullName ? "getozmbyfullname" : "getozmbyname");
            url = net.addUrlParam(url, "SAP_Matt_Descr", text);
            JsonResult result = net.downloadJson(url);

            if (result.isOk()) {

                JSONArray array = Utils.getJsonArray(result.getJson(), "data");
                if (array != null) {
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject json = Utils.getJsonObject(array, i);

                        String ozmOzm = Utils.getJsonStringIgnoreCase(json, "saP_Ozm");
                        String ozmName = Utils.getJsonStringIgnoreCase(json, "saP_Matt_Descr");
                        float itemWidth = Utils.getJsonFloatIgnoreCase(json, "width");
                        float itemLength = Utils.getJsonFloatIgnoreCase(json, "length");
                        float itemThickness = Utils.getJsonFloatIgnoreCase(json, "thickness");

                        if (length != -1 && length != itemLength
                                || width != -1 && width != itemWidth
                                || thickness != -1 && thickness != itemThickness) {
                            continue;
                        }

                        ozmList.add(new Ozm(ozmOzm, ozmName, itemWidth, itemLength, itemThickness));
                        ArrayList<Location> ozmLocationList = new ArrayList<>();

                        JSONArray ozmLocList = Utils.getJsonArray(json, "ozmLocations");
                        for (int j = 0; ozmLocList != null && j < ozmLocList.length(); j++) {
                            JSONObject ozmLoc = Utils.getJsonObject(ozmLocList, j);
                            if (ozmLoc != null) {
                                String location = Utils.getJsonStringIgnoreCase(ozmLoc, "locationCode");
                                int nett = Utils.getJsonWeightKgIgnoreCase(ozmLoc, "sumWeight");
                                ozmLocationList.add(new Location(location, nett));
                            }
                        }

                        Collections.sort(ozmLocationList, (o1, o2) -> Utils.compareLocations(o1.code, o2.code));
                        locationList.add(ozmLocationList);
                    }
                }

            }

            runOnUiThread(() -> endSearch(result));
        });
    }

    private void endSearch(JsonResult result) {
        hideLoading();

        if (result.isOk()) {

            if (locationList.isEmpty()) textNotFound.setVisibility(View.VISIBLE);
            if (!locationList.isEmpty()) listView.setVisibility(View.VISIBLE);

            showOzmList();

        } else {
            textNotFound.setVisibility(View.VISIBLE);
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginSearch());
        }
    }

    private void showOzmList() {
        List<AdapterSimple> list = new ArrayList<>();
        for (int i = 0; i < ozmList.size(); i++) {
            Ozm ozm = ozmList.get(i);

            StringBuilder sb = new StringBuilder();
            sb.append(Utils.format("ОЗМ: %s", ozm.getOzm()));
            String size = app.sizeToString(ozm.getWidth(), ozm.getLength(), ozm.getThickness());
            if (size.length() > 0) sb.append(Utils.format("<br>%s", size));

            AdapterSimple item = new AdapterSimple(String.valueOf(i), ozm.getName(), sb.toString());
            list.add(item);
        }

        FlexibleAdapter<AdapterSimple> adapter = new FlexibleAdapter<>(list);
        adapter.addListener(this);
        listView.setAdapter(adapter);
        scrollView.post(() -> scrollView.scrollTo(0, 0));
    }

    private void showOzm(int ozmIndex) {
        page = 2;
        currentOzm = ozmIndex;

        List<AdapterSimple> list = new ArrayList<>();

        for (int i = 0; i < locationList.get(currentOzm).size(); i++) {
            String content = Utils.format("Загальна вага тн.: <b>%.3f</b>", locationList.get(currentOzm).get(i).weight / 1000.0f);
            AdapterSimple item = new AdapterSimple(String.valueOf(i), locationList.get(currentOzm).get(i).code, content);
            list.add(item);
        }

        FlexibleAdapter<AdapterSimple> adapter = new FlexibleAdapter<>(list);
        adapter.addListener(this);
        listView.setAdapter(adapter);
        scrollView.post(() -> scrollView.scrollTo(0, 0));
    }

    /*private void addLocation(String location, int weight) {

        int index = getLocationIndex(location);

        if (index == -1) {
            locationList.add(new Location(location, weight));
        } else {
            locationList.get(index).weight += weight;
        }
    }*/

    /*private int getLocationIndex(String location) {
        for (int i = 0; i < locationList.size(); i++) {
            if (locationList.get(i).code.equalsIgnoreCase(location)) {
                return i;
            }
        }
        return -1;
    }*/

    private AdapterSimple getAdapterItem(int position) {
        if (listView.getAdapter() != null) {
            try {
                FlexibleAdapter<AdapterSimple> adapter = (FlexibleAdapter<AdapterSimple>) listView.getAdapter();
                return adapter.getItem(position);
            } catch (Exception ignored) {
            }
        }
        return null;
    }

    @Override
    public boolean onItemClick(View view, int position) {

        if (page == 1) {
            onOzmClick(position);
        } else {
            onLocationClick(position);
        }

        return true;
    }

    private void onOzmClick(int position) {
        showOzm(position);
    }

    private void onLocationClick(int position) {
        try {
            Location location = locationList.get(currentOzm).get(position);
            List<Ozm> list = new ArrayList<>();
            list.add(ozmList.get(currentOzm));
            showInfoByLocationCodeOzm(list, location.code);
        } catch (Exception ignored) {

        }
    }

    @Override
    public void onBackPressed() {
        if (page == 2) {
            page = 1;
            currentOzm = -1;
            showOzmList();
        } else {
            setResult(RESULT_OK);
            super.onBackPressed();
        }
    }
}
