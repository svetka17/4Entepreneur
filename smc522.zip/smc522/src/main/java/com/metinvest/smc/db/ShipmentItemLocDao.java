package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ShipmentItemLocDao {
    @Query("SELECT * FROM ShipmentItemLoc ORDER BY location")
    List<ShipmentItemLoc> getAll();

    @Query("SELECT * FROM ShipmentItemLoc WHERE id = :id")
    ShipmentItemLoc getById(long id);

    @Query("SELECT * FROM ShipmentItemLoc WHERE itemId = :itemId")
    List<ShipmentItemLoc> getByItem(long itemId);

    @Insert
    long insert(ShipmentItemLoc shipmentItemLoc);

    @Insert
    void insertAll(List<ShipmentItemLoc> shipmentItemLoc);

    @Update
    void update(ShipmentItemLoc shipmentItemLoc);

    @Delete
    void delete(ShipmentItemLoc shipmentItemLoc);

    @Query("DELETE FROM ShipmentItemLoc WHERE itemId = :itemId")
    void deleteByItem(long itemId);

    @Query("DELETE FROM ShipmentItemLoc")
    void truncate();
}