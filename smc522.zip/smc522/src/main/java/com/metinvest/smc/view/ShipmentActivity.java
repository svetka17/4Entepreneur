package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.Utils;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ShipmentActivity extends MyActivity {

    final int REQUEST_NEW = 1;
    final int REQUEST_VIEW = 2;

    @BindView(R.id.textNumber)
    EditText textNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shipment);
        ButterKnife.bind(this);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) buttonAcceptClick();
    }

    private void buttonAcceptClick() {
        if (isLoading()) return;

        if (textNumber.getText().length() == 0) {
            textNumber.requestFocus();
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, "Будь-ласка, заповніть номер наряду!", null);
            return;
        }

        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> beginLoad(textNumber.getText().toString()));
    }

    private void beginLoad(String number) {
        String url = config.getUrlApi() + "shipmentinfo";
        url = net.addUrlParam(url, "shipment_number", number);
        reqGet(url, (result) -> runOnUiThread(() -> endLoad(result, number)));
    }

	private void endLoad(JsonResult result, String number) {

		if (result.isOk()) {
			openShipmentView(number, Utils.jsonToString(result.getJson()));
			hideLoading();
		} else if (result.getStatus() == LoadResultStatus.ZERO) {
			showDialogConfirm(R.string.text_confirm, getString(R.string.error_shipment_not_found, number), (dialog, which) -> {
				Intent intent = new Intent(ShipmentActivity.this, ShipmentNewActivity.class);
				intent.putExtra("number", number);
				startActivityForResult(intent, REQUEST_NEW);
			});
			hideLoading();
		} else {
			hideLoading();
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> buttonAcceptClick());
		}
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == REQUEST_VIEW) {
            hideLoading();
        } else if (requestCode == REQUEST_NEW && resultCode == RESULT_OK && data != null) {
            String number = data.getStringExtra("number");
            String json = data.getStringExtra("json");
            openShipmentView(number, json);
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void openShipmentView(String number, String json) {
        Intent intent = new Intent(this, ShipmentViewActivity.class);
        intent.putExtra("number", number);
        intent.putExtra("json", json);
        startActivityForResult(intent, 1);
    }
}
