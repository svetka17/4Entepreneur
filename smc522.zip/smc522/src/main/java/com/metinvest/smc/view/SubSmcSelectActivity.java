package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Spinner;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.tools.IValue;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.tools.Value;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SubSmcSelectActivity extends MyActivity {

    @BindView(R.id.spinnerSmc)
    Spinner spinnerSmc;
    List<IValue> list = new ArrayList<>();
    List<String> listSmcId = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_smc_select);
        ButterKnife.bind(this);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    private void buttonAcceptClick() {
        int pos = spinnerSmc.getSelectedItemPosition();
        String smcId = listSmcId.get(pos);
        Intent data = new Intent();
        data.putExtra("smc_id", smcId);
        setResult(RESULT_OK, data);
        finish();
    }

    private void beginLoad() {
        int selectedIndex = 0;
        JSONArray jsonArray = Utils.getJsonArray(config.getSmcListJson());

        for (int i = 0; jsonArray != null && i < jsonArray.length(); i++) {
            JSONObject jsonObject = Utils.getJsonObject(jsonArray, i);
            int parent = Utils.getJsonIntIgnoreCase(jsonObject, "parent");
            if (parent == 0) continue;

            String smcid = Utils.getJsonStringIgnoreCase(jsonObject, "smcid");
            String desc = Utils.getJsonStringIgnoreCase(jsonObject, "desc");

            String title = desc.isEmpty() ? Utils.format("[%s]", smcid) : Utils.format("[%s] - %s", smcid, desc);
            list.add(new Value(i, title));
            listSmcId.add(smcid);
            if (smcid.equalsIgnoreCase(config.getSmcIdUser())) selectedIndex = i;
        }

        Utils.fillData(spinnerSmc, list);
        spinnerSmc.setSelection(selectedIndex);
    }
}
