package com.metinvest.smc.view;

import android.os.Bundle;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Carrier;
import com.metinvest.smc.db.NameStore;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.db.Printed;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.Utils;

import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PrintedEditActivity extends MyActivity {

    @BindView(R.id.textWeightNetto)
    EditText textWeightNetto;
    @BindView(R.id.textWeightPack)
    EditText textWeightPack;
    @BindView(R.id.textWeightTara)
    EditText textWeightTara;

    private Printed printed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_printed_edit);
        ButterKnife.bind(this);

        long id = getIntent().getLongExtra("id", 0);
        printed = db.printedDao().getById(id);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    private void buttonAcceptClick() {

        if (isLoading()) return;

        int weightNetto = Utils.parseInt(textWeightNetto.getText().toString());
        int weightPack = Utils.parseInt(textWeightPack.getText().toString());
        int weightTara = Utils.parseInt(textWeightTara.getText().toString());

        if (weightNetto <= 0) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_netto_zero, null);
            return;
        }

        try {
			printed.setWeightNetto(weightNetto);
			printed.setWeightPack(weightPack);
			printed.setWeightTara(weightTara);
			db.printedDao().update(printed);
		} catch (Exception e) {
			app.log(this, e, "db.printedDao().update(%s)", printed);
		}

        setResult(RESULT_OK);
        beginPrint();
    }

    private void beginPrint() {
        showLoading(R.string.text_printing_title);

        Utils.runOnBackground(() -> {

            OnTheWay way = db.onTheWayDao().getById(printed.getOnTheWayId());
            NameStore nameStore = db.nameStoreDao().getById(way.getNameId());
            Carrier dbCarrier = db.carrierDao().getById(way.getCarrierId());

            String dplName = "";
            dplName += Utils.format("<b>%s</b><br>", nameStore.getMatt());
            dplName += Utils.format("Розмір: %s<br>", nameStore.getSize());
            dplName += Utils.format("Вага брутто: %s<br>", printed.getWeightNetto());
            dplName += Utils.format("Партія: %s", way.getSapBatch());

            String dpl = "";
            try {
                dpl = app.generateDplLabel(
						String.valueOf(printed.getId()), new Date(printed.getDate()), nameStore.getMatt(),
						nameStore.getWidth(), nameStore.getLength(), nameStore.getThickness(),
						printed.getWeightNetto(), printed.getWeightPack(), printed.getWeightTara(),
						nameStore.getOzm(), printed.isTemporary() ? "TEMP" : way.getSapBatch(),
						dbCarrier.getName(), 0,
						printed.isTheor(), 0, printed.getLocation(), "",
						printed.getPlavka(), "", null, "", "", null);
            } catch (Exception e) {
                log(e, "generateDplLabel()");
            }

            final Printer.PrintResult result = Printer.sendCommand(dplName, config.getPrinter(), dpl);

            runOnUiThread(() -> endPrint(result));
        });
    }

    private void endPrint(Printer.PrintResult result) {
        hideLoading();

        if (result.getStatus() == Printer.PrintResultStatus.OK) {
            showToast(R.string.text_print_result_succeeded);
           // app.sendFaPrint();
            finish();
        } else {
            @StringRes final int message = app.getPrintResultMessage(result);
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> beginPrint());
        }
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    private void beginLoad() {
        textWeightNetto.setText(String.valueOf(printed.getWeightNetto()));
        textWeightPack.setText(String.valueOf(printed.getWeightPack()));
        textWeightTara.setText(String.valueOf(printed.getWeightTara()));
    }
}
