package com.metinvest.smc.view;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.BuildConfig;
import com.metinvest.smc.R;
import com.metinvest.smc.db.OffShipLabel;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class OfflineShipActivity extends MyActivity implements IScan {

	@BindView(R.id.textLabelId)
	EditText textLabelId;
	@BindView(R.id.textNetto)
	EditText textNetto;
	@BindView(R.id.buttonPrint)
	Button buttonPrint;
	@BindView(R.id.textContentTitle)
	TextView textContentTitle;
	@BindView(R.id.textPrompt)
	TextView textPrompt;
	@BindView(R.id.viewContentData)
	View viewContentData;
	@BindView(R.id.viewList)
	View viewList;
	@BindView(R.id.listView)
	RecyclerView listView;
	@BindView(R.id.scrollView)
	NestedScrollView scrollView;

	private String labelId;
	private int labelNetto, labelPack;
	private FlexibleAdapter<Adapter> adapter;
	private String qrData;
	private int labelNettoShipped;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_offline_ship);
		ButterKnife.bind(this);

		if (BuildConfig.DEBUG) {
			textContentTitle.setOnClickListener(v -> {

				//onBarcodeEvent("SMC06|2540|1434|Тестовий ОЗМ|2500.000000|0.000000|5.000000|2540|ФВ|00.999.888.77|0|0|0099988877|0|20200326152744|XX12345XX");
				onBarcodeEvent("SMC06|2541|1434|Тестовий ОЗМ|2500.000000|0.000000|5.000000|3326|ФВ|00.999.888.77|0|0|0099988877|0|20200326152821|XX12345XX");

				//onBarcodeEvent("SMC06|110622|1438|Лист г/к 8-20 S355J2 О НТ@1224|6000.000000|2000.000000|20.000000|1884|ТВ|24.11.311200.00470|0|0|0032001958|0|20200326104708|");
			});
		}
		textNetto.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				checkAccept();
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		});

		LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
		DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
		listView.setLayoutManager(layoutManager);
		listView.addItemDecoration(dividerItemDecoration);
		adapter = new FlexibleAdapter<>(null);
		listView.setAdapter(adapter);
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		setLabelId(null, 0, 0);
		beginLoad();
	}

	private void beginLoad() {
		viewList.setVisibility(View.GONE);
		showLoading(R.string.text_please_wait);

		Utils.runOnBackground(() -> {

			List<OffShipLabel> list = db.offShipLabelDao().getAll();
			List<Adapter> itemList = new ArrayList<>(list.size());

			for (OffShipLabel item : list) {
				itemList.add(new Adapter(item));
			}

			adapter = new FlexibleAdapter<>(itemList);

			runOnUiThread(this::endLoad);
		});
	}

	private void endLoad() {
		hideLoading();
		viewList.setVisibility(adapter.getItemCount() > 0 ? View.VISIBLE : View.GONE);
		listView.setAdapter(adapter);
		scrollView.post(() -> scrollView.scrollTo(0, 0));
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 5) {
			buttonPrintClick();
		}
	}

	private int getNetto() {
		return Utils.parseInt(textNetto.getText().toString());
	}

	private void setLabelId(String value, int netto, int pack) {
		this.labelId = value;

		if (labelId == null) {

			labelNettoShipped = 0;
			textPrompt.setVisibility(View.VISIBLE);
			viewContentData.setVisibility(View.GONE);

		} else {

			textPrompt.setVisibility(View.GONE);
			viewContentData.setVisibility(View.VISIBLE);

			this.labelNetto = netto;

			textLabelId.setText(labelId);

			labelNettoShipped = db.offShipLabelDao().getTotalLabelShipped(labelId);
			int nettoFinal = labelNetto - labelNettoShipped;

			textNetto.setText(nettoFinal > 0 ? String.valueOf(nettoFinal) : null);
		}

		checkAccept();
	}

	private void checkAccept() {
		buttonPrint.setEnabled(labelId != null && getNetto() > 0 && getNetto() <= labelNetto - labelNettoShipped);
	}

	private void buttonPrintClick() {
		if (isLoading() || !buttonPrint.isEnabled()) return;
		beginAccept(qrData, labelId, labelNetto, labelNetto - getNetto(), labelPack);
	}

	private void beginAccept(String qrData, String labelId, int nettoBefore, int nettoAfter, int labelPack) {
		showLoading(R.string.text_please_wait);

		Utils.runOnBackground(() -> {

			OffShipLabel offShipLabel;

			offShipLabel = new OffShipLabel(
					0, qrData, app.getSmcIdCurrent(), labelId, Calendar.getInstance().getTime().getTime(),
					nettoBefore, nettoAfter, labelPack
			);

			try {
				db.offShipLabelDao().insert(offShipLabel);
			} catch (Exception e) {
				app.log(this, e, "db.offShipLabelDao().insert(%s)", offShipLabel);
				offShipLabel = null;
			}

			int rest = offShipLabel == null ? 0 : db.offShipLabelDao().getLabelNettoOrig(offShipLabel.getLabelId()) - db.offShipLabelDao().getTotalLabelShipped(offShipLabel.getLabelId());

			OffShipLabel finalOffShipLabel = offShipLabel;
			runOnUiThread(() -> endAccept(finalOffShipLabel, qrData, labelId, nettoBefore, nettoAfter, labelPack, rest));
		});
	}

	private void endAccept(OffShipLabel offShipLabel, String qrData, String labelId, int nettoBefore, int nettoAfter, int labelPack, int rest) {
		hideLoading();
		setLabelId(null, 0, 0);

		if (rest > 0) {
			beginPrint(offShipLabel, rest);
		} else {
			String message = Utils.format("Бірка №%s: відвантажено %d кг.", labelId, nettoBefore - nettoAfter);
			showToast(message);
			beginLoad();
		}
	}

	@Override
	public void onBarcodeEvent(String barcodeData) {
		if (isLoading()) return;

		setLabelId(null, 0, 0);
		qrData = barcodeData;

		runOnUiThread(() -> {

			ScanItem scanItem = new ScanItem(barcodeData);
			if (!scanItem.isCorrect()) {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_label, null);
				return;
			}

			if ((scanItem.getType() == ScanItem.ScanItemType.SMC06)) {
				onLabelScan(scanItem);
			}
		});
	}

	private void onLabelScan(ScanItem scanItem) {
		String labelId = scanItem.getData(0);
		String smcId = scanItem.getData(1);
		int netto = Utils.parseInt(scanItem.getData(6));
		int pack = Utils.parseInt(scanItem.getData(9));
		String sapOzm = scanItem.getData(8);
		float length = Utils.parseFloat(scanItem.getData(3));
		float width = Utils.parseFloat(scanItem.getData(4));
		float thickness = Utils.parseFloat(scanItem.getData(5));

		if (!smcId.equalsIgnoreCase(app.getSmcIdCurrent())) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_scan_label_another_smcid, null);
			return;
		}

		setLabelId(labelId, netto, pack);
	}

	public void onDeleteClicked(Adapter item) {
		showDialogConfirm(R.string.text_confirm, R.string.delete_position_confirm, (dialog, which) -> {
			try {
				db.offShipLabelDao().delete(item.getOffShipLabel());
			} catch (Exception ignored) {
			}
			beginLoad();
			setLabelId(labelId, labelNetto, labelPack);
		});
	}

	public void beginPrint(OffShipLabel offShipLabel, int rest) {
		if (isLoading()) return;

		showLoading(R.string.text_printing_title);

		Utils.runOnBackground(() -> {

			ScanItem scanItem = new ScanItem(offShipLabel.getQrData());

			String content = "";
			String dplTitle = "";

			//int netto = offShipLabel.getNettoAfter();//Utils.parseInt(scanItem.getData(6));
			int netto = rest;
			int pack = offShipLabel.getPack();// Utils.parseInt(scanItem.getData(9));
			String batch = scanItem.getData(11);
			String ozm = scanItem.getData(8);
			String matt = scanItem.getData(2);
			float length = Utils.parseFloat(scanItem.getData(3));
			float width = Utils.parseFloat(scanItem.getData(4));
			float thickness = Utils.parseFloat(scanItem.getData(5));
			String carrier = scanItem.getData(14);
			boolean theor = scanItem.getData(7).equalsIgnoreCase("ТВ");

			//TODO Unknown location code
			content = app.generateDplLabel(
					offShipLabel.getLabelId(), Calendar.getInstance().getTime(), matt,
					width, length, thickness, netto, pack,
					0, ozm, batch,
					carrier, 0, theor, 0, null,
					"", "", "", null, "", "", null);

			dplTitle += Utils.format("<b>%s</b><br>", matt);
			dplTitle += Utils.format("Розмір: %s<br>", app.sizeToString(width, length, thickness));
			dplTitle += Utils.format("Вага нетто: %s<br>", Math.max(netto, 0));
			dplTitle += Utils.format("Партія: %s", batch);


			final Printer.PrintResult result = Printer.sendCommand(dplTitle, config.getPrinter(), content);
			runOnUiThread(() -> endPrint(offShipLabel, rest, result));
		});
	}

	private void endPrint(OffShipLabel offShipLabel, int rest, Printer.PrintResult result) {
		hideLoading();

		if (result.getStatus() == Printer.PrintResultStatus.OK) {
			showToast(R.string.text_print_result_succeeded);
			//app.sendFaPrint();
			beginLoad();
		} else {
			@StringRes final int message = app.getPrintResultMessage(result);
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> beginPrint(offShipLabel, rest), (dialog, which) -> beginLoad());
		}
	}

	public class Adapter extends AbstractFlexibleItem<Adapter.AdapterViewHolder> {

		private final OffShipLabel offShipLabel;

		public Adapter(OffShipLabel offShipLabel) {
			this.offShipLabel = offShipLabel;
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof Adapter && ((Adapter) o).getOffShipLabel().getId() == getOffShipLabel().getId();
		}

		public OffShipLabel getOffShipLabel() {
			return offShipLabel;
		}

		@Override
		public int hashCode() {
			return getOffShipLabel().hashCode();
		}

		@Override
		public AdapterViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
			return new AdapterViewHolder(view, adapter);
		}

		@Override
		public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterViewHolder holder, int position, List<Object> payloads) {
			holder.textLabelId.setText(getOffShipLabel().getLabelId());
			holder.textWeight.setText(Utils.format("-%d кг", getOffShipLabel().getNettoBefore() - getOffShipLabel().getNettoAfter()));
			holder.buttonSplit.setVisibility(View.GONE);
			holder.buttonDelete.setOnClickListener(v -> onDeleteClicked(this));
		}

		@Override
		public int getLayoutRes() {
			return R.layout.adapter_ship_label;
		}

		class AdapterViewHolder extends FlexibleViewHolder {

			private final TextView textLabelId, textWeight;
			private final ImageButton buttonDelete, buttonSplit;

			AdapterViewHolder(View view, FlexibleAdapter adapter) {
				super(view, adapter);
				this.textLabelId = view.findViewById(R.id.textLabelId);
				this.textWeight = view.findViewById(R.id.textWeight);
				this.buttonDelete = view.findViewById(R.id.buttonDelete);
				this.buttonSplit = view.findViewById(R.id.buttonSplit);
			}
		}
	}

}
