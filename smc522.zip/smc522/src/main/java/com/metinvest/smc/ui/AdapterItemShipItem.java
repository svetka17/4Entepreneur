package com.metinvest.smc.ui;

import android.view.View;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.db.ShipmentItem;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemShipItem extends AbstractFlexibleItem<AdapterItemShipItem.PlaceAdapterViewHolder> {

    private ShipmentItem shipmentItem;

    public AdapterItemShipItem(ShipmentItem shipmentItem) {
        this.shipmentItem = shipmentItem;
    }

    public ShipmentItem getShipmentItem() {
        return shipmentItem;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterItemShipItem && ((AdapterItemShipItem) o).getShipmentItem().getId() == getShipmentItem().getId();
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_ship_item;
    }

    @Override
    public PlaceAdapterViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new PlaceAdapterViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, PlaceAdapterViewHolder holder, int position, List<Object> payloads) {

        StringBuilder sb = new StringBuilder();
        sb.append(Utils.format("Відвантажено: %.3f т", (shipmentItem.getSapWeightNettFact() / 1000.0f)));

        holder.textTitle.setText(App.getInstance().fromHtml(sb.toString()));
        holder.buttonEdit.setOnClickListener(v -> {
            if (adapter.mItemClickListener != null)
                adapter.mItemClickListener.onItemClick(holder.itemView, position);
        });
        holder.buttonEdit.setEnabled(shipmentItem.getSapWeightNettFact() > 0);

        View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
        holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
        refreshBackground(holder, holder.itemView.isFocused());
    }

    private void refreshBackground(PlaceAdapterViewHolder holder, boolean hasFocus) {
        holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_background));
    }

    static class PlaceAdapterViewHolder extends FlexibleViewHolder {

        private final TextView textTitle;
        private final View buttonEdit;

        PlaceAdapterViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.textTitle = view.findViewById(R.id.textTitle);
            this.buttonEdit = view.findViewById(R.id.buttonEdit);
        }
    }
}
