package com.metinvest.smc.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.inc.AdapterItemDoc;
import com.metinvest.smc.inc.SohFilter;
import com.metinvest.smc.inc.TTN;
import com.metinvest.smc.inc.Transport;
import com.metinvest.smc.inc.TransportDoc;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.Utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.IFlexible;

public class IncTransportListActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

    @BindView(R.id.textContentTitle)
    TextView textContentTitle;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.viewButtons)
    View viewButtons;
    @BindView(R.id.viewContentData)
    View viewContentData;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    @BindView(R.id.textFilter)
    EditText textFilter;
    @BindView(R.id.buttonFilterClear)
    ImageButton buttonFilterClear;

    private Date dateFrom, dateTo;
    private FlexibleAdapter<IFlexible> adapter;
    private List<IFlexible> adapterList;
    private boolean isManager;
    private String sohSmcId;
    private SohFilter sohFilter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inc_transport_list);
        ButterKnife.bind(this);

        sohSmcId = getIntent().getStringExtra("sohSmcId");
        sohFilter = sohSmcId == null ? SohFilter.NotSoh() : SohFilter.SohInc(sohSmcId);

        dateFrom = (Date) getIntent().getSerializableExtra("dateFrom");
        dateTo = (Date) getIntent().getSerializableExtra("dateTo");
        textContentTitle.setText(Utils.format("%s - %s%s",
                app.getDateFormat().format(dateFrom),
                app.getDateFormat().format(dateTo),
                sohSmcId == null ? "" : Utils.format(" (COX %s)", sohSmcId)
        ));

        if (sohSmcId != null) log("sohSmcId: %s", sohSmcId);

        isManager = getIntent().getBooleanExtra("isManager", false);
        if (isManager) log("isManager");

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        textFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                applyFilter();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    protected String getHelpContent() {
        return getString(R.string.inc_transport_list_help);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) buttonRefreshClick();
        else if (number == 3) buttonFilterClearClick();
    }

    private void buttonFilterClearClick() {
        hideKeyboard();
        textFilter.setText(null);
        buttonFilterClick();
    }

    private void buttonRefreshClick() {
        if (isLoading()) return;
        beginLoad();
    }

    @Override
    public boolean onItemClick(View view, int position) {
        IFlexible item = adapter.getItem(position);
        /*if (item instanceof AdapterItemTransport) {
            openDocList((AdapterItemTransport) item);
        } else */
        if (item instanceof AdapterItemDoc) {
            openDoc((AdapterItemDoc) item);
        }
        return false;
    }

    /*private void openDocList(AdapterItemTransport item) {

        //showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, "Помилка! За даним вагоном декілька нарядів!", null);

        Intent intent = new Intent(this, IncDocListActivity.class);
        intent.putExtra("dateFrom", dateFrom);
        intent.putExtra("dateTo", dateTo);
        intent.putExtra("transportName", item.getTransport().getName());
        intent.putExtra("isNew", getIntent().getBooleanExtra("isNew", false));
        intent.putExtra("isManager", isManager);
        intent.putExtra("sohSmcId", sohSmcId);
        startActivityForResult(intent, REQUEST_DEFAULT);
    }*/

    private void openDoc(AdapterItemDoc item) {
        Intent intent = new Intent(this, IncDocActivity.class);
        intent.putExtra("date", item.getDoc().getTransport().getDate());
        intent.putExtra("dateFrom", dateFrom);
        intent.putExtra("dateTo", dateTo);
        intent.putExtra("transportName", item.getDoc().getTransport().getName());
        intent.putExtra("ttn", item.getDoc().getTtn());
        intent.putExtra("isNew", getIntent().getBooleanExtra("isNew", false));
        intent.putExtra("isManager", isManager);
        intent.putExtra("sohSmcId", sohSmcId);
        startActivityForResult(intent, REQUEST_DEFAULT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_DEFAULT) {
            if (resultCode == RESULT_OK || resultCode == RESULT_DELETED) {
				String transportName = data == null ? null : data.getStringExtra("transportName");
				TTN ttn = data == null ? null : (TTN) data.getSerializableExtra("ttn");
				Date date = data == null ? null : (Date) data.getSerializableExtra("date");
				beginLoad(transportName, ttn, date);
			}
        }
    }

    private AdapterItemDoc findTransportTtn(String transportName, TTN ttn) {
        return null;
    }

    private void beginLoad() {
		beginLoad(null, null, null);
    }

    private void beginLoad(String transportName) {
		beginLoad(transportName, null, null);
    }

	private void beginLoad(String transportName, TTN ttn, Date date) {

		if (isLoading()) return;

		showLoading(R.string.text_please_wait);
		viewButtons.setVisibility(View.GONE);

		setAdapter(null);

		Utils.runOnBackground(() -> {

            Network.NetworkResultValue<List<Transport>> result = app.loadIncTransportList(dateFrom, dateTo, null, sohFilter);

            List<IFlexible> list = new ArrayList<>();

            if (result.getResult().isOk()) {

                for (Transport transport : result.getValue()) {

                    List<TTN> ttnList = transport.getTtnList();

                    //if (ttnList.size() == 1) {
                    //    list.add(new AdapterItemDoc(TransportDoc.fromTransport(transport, ttnList.get(0))));
                    //} else {
                    //    //list.add(new AdapterItemTransport(transport));
                    for (int i = 0; i < ttnList.size(); i++) {
                        TransportDoc transportDoc = TransportDoc.fromTransport(transport, ttnList.get(i));
                        if (transportDoc != null/* && app.isTransportFor(transportDoc, isManager)*/) {
							list.add(new AdapterItemDoc(transportDoc, isManager));
						}
                    }
                    //}

                }

                Collections.sort(list, (o1, o2) -> {

                    int c = 0;

                    if (o1 instanceof AdapterItemDoc && o2 instanceof AdapterItemDoc) {
                        AdapterItemDoc d1 = ((AdapterItemDoc) o1);
                        AdapterItemDoc d2 = ((AdapterItemDoc) o2);
                        String status1 = d1.getDoc().getStatus();
                        String status2 = d2.getDoc().getStatus();
                        c = TransportDoc.compareStatus(status1, status2);
                    }

                    if (c == 0) {
                        Date d1 = null;
                        Date d2 = null;
                        /*if (o1 instanceof AdapterItemTransport)
                            d1 = ((AdapterItemTransport) o1).getTransport().getDate();
                        if (o2 instanceof AdapterItemTransport)
                            d2 = ((AdapterItemTransport) o2).getTransport().getDate();*/
                        if (o1 instanceof AdapterItemDoc)
                            d1 = ((AdapterItemDoc) o1).getDoc().getTransport().getDate();
                        if (o2 instanceof AdapterItemDoc)
                            d2 = ((AdapterItemDoc) o2).getDoc().getTransport().getDate();
                        if (d1 != null && d2 != null) {
                            c = Long.compare(d1.getTime(), d2.getTime());
                        }
                    }
                    if (c == 0) {
                        String name1 = null;
                        String name2 = null;
                        /*if (o1 instanceof AdapterItemTransport)
                            name1 = ((AdapterItemTransport) o1).getTransport().getName();
                        if (o2 instanceof AdapterItemTransport)
                            name2 = ((AdapterItemTransport) o2).getTransport().getName();*/
                        if (o1 instanceof AdapterItemDoc)
                            name1 = ((AdapterItemDoc) o1).getDoc().getTransport().getName();
                        if (o2 instanceof AdapterItemDoc)
                            name2 = ((AdapterItemDoc) o2).getDoc().getTransport().getName();
                        if (name1 != null && name2 != null) {
                            c = name1.compareToIgnoreCase(name2);
                        }
                    }

                    return c;
                });
            }

            runOnUiThread(() -> endLoad(result.getResult(), list, transportName, ttn, date));
        });
    }

    private void endLoad(JsonResult result, List<IFlexible> list, String transportName, TTN ttn, Date date) {
        hideLoading();
        viewButtons.setVisibility(View.VISIBLE);

        this.adapterList = list;
        setAdapter(adapterList);
        viewContentData.setVisibility(result.isOk() && !list.isEmpty() ? View.VISIBLE : View.GONE);
        textNotFound.setVisibility(!result.isOk() || list.isEmpty() ? View.VISIBLE : View.GONE);

        if (result.isOk() && !list.isEmpty()) {
            buttonFilterClick();

            if (transportName != null) {
                highlightItem(transportName, ttn, date);
            }
        }

        if (!result.isOk()) {
            if (result.getStatus() == LoadResultStatus.TIMEOUT) {
                showDialog(R.drawable.ic_error_24dp, R.string.text_error, R.string.inc_timeout_transport_list, (dialog, which) -> onBackPressed());
            } else {
                showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
            }
        }

    }

    private void setAdapter(List<IFlexible> list) {
        if (list == null) {
            adapter = null;
        } else {
            adapter = new FlexibleAdapter<>(list);
            adapter.addListener(this);
        }
        listView.setAdapter(adapter);
    }

    private void buttonFilterClick() {
        listView.post(() -> listView.requestFocus());

        applyFilter();
    }

    private void applyFilter() {
        String filterText = textFilter.getText().toString();
        if (adapter == null) return;

        List<IFlexible> list = new ArrayList<>();

        for (IFlexible item : adapterList) {
            /*if (item instanceof AdapterItemTransport) {
                AdapterItemTransport itemTransport = (AdapterItemTransport) item;
                if (itemTransport.getTransport().getName().toLowerCase().contains(filterText.toLowerCase())) {
                    list.add(item);
                }
            } else */
            if (item instanceof AdapterItemDoc) {
                AdapterItemDoc itemDoc = (AdapterItemDoc) item;
                if (itemDoc.getDoc().getTransport().getName().toLowerCase().contains(filterText.toLowerCase())) {
                    list.add(item);
                }
            }
        }

        setAdapter(list);
        textNotFound.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
    }

	private void highlightItem(String transportName, TTN ttn, Date date) {

        if (adapter == null) return;

        IFlexible foundItem = null;

        for (IFlexible item : adapterList) {
                /*if (ttn == null) {
                    if (item instanceof AdapterItemTransport) {
                        AdapterItemTransport itemTransport = (AdapterItemTransport) item;
                        if (itemTransport.getTransport().getName().equalsIgnoreCase(transportName)) {
                            if (date == null || itemTransport.getTransport().getDate().getTime() == date.getTime())
                                foundItem = item;
                        }
                    }
                } else {*/
            if (item instanceof AdapterItemDoc) {
                AdapterItemDoc itemDoc = (AdapterItemDoc) item;
                if (itemDoc.getDoc().getTransport().getName().equalsIgnoreCase(transportName) && itemDoc.getDoc().getTtn().equals(ttn)) {
                    if (date == null || itemDoc.getDoc().getTransport().getDate().getTime() == date.getTime())
                        foundItem = item;
                }
            }
            //}
        }

        if (foundItem != null) {
            int pos = adapter.getGlobalPositionOf(foundItem);
            if (pos != -1) {
                listView.scrollToPosition(pos);
                animItem(foundItem);
            }
        }

    }

    private void animItem(IFlexible item) {
        int colorFrom = getColor(R.color.color_adapter_light);
        int colorTo = getColor(R.color.color_yellow);
        animStart(item, colorFrom, colorTo);
    }

    private void animStart(IFlexible item, int colorFrom, int colorTo) {

        ValueAnimator colorAnimation = ValueAnimator.ofObject(new ArgbEvaluator(), colorFrom, colorTo);
        colorAnimation.setDuration(1000);
        colorAnimation.addUpdateListener(animator -> setItemColor(item, (int) animator.getAnimatedValue()));
        colorAnimation.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                animStop(item, colorFrom, colorTo);
                super.onAnimationEnd(animation);
            }
        });
        colorAnimation.start();
    }

    private void animStop(IFlexible item, int colorFrom, int colorTo) {
        ValueAnimator colorAnimation = ValueAnimator.ofObject(new ArgbEvaluator(), colorTo, colorFrom);
        colorAnimation.setDuration(1000);
        colorAnimation.addUpdateListener(animator -> setItemColor(item, (int) animator.getAnimatedValue()));
        colorAnimation.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                setItemColor(item, -1);
                super.onAnimationEnd(animation);
            }
        });
        colorAnimation.start();
    }

    private void setItemColor(IFlexible item, int color) {
        if (item == null || adapter == null) return;

        if (item instanceof AdapterItemDoc) ((AdapterItemDoc) item).setBackgroundColor(color);
        //else if (item instanceof AdapterItemTransport)
        //    ((AdapterItemTransport) item).setBackgroundColor(color);

        adapter.updateItem(item);
    }

	/*public static class AdapterItemTransport extends AbstractFlexibleItem<AdapterItemTransport.TransportViewHolder> {

		private final Transport transport;
		private final App app;
		private int backgroundColor = -1;

		AdapterItemTransport(Transport transport) {
			this.app = App.getInstance();
			this.transport = transport;
		}

        public void setBackgroundColor(int backgroundColor) {
            this.backgroundColor = backgroundColor;
        }

        Transport getTransport() {
            return transport;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof AdapterItemTransport && ((AdapterItemTransport) o).getTransport().equals(getTransport());
        }

        @Override
        public int hashCode() {
            return getTransport().hashCode();
        }

        @Override
        public int getLayoutRes() {
            return R.layout.adapter_inc_transport;
        }

        @Override
        public TransportViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
            return new TransportViewHolder(view, adapter);
        }

        @Override
        public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, TransportViewHolder holder, int position, List<Object> payloads) {
            String title = Utils.format("<b>%s</b>", transport.getName());

            StringBuilder sb = new StringBuilder();

            StringBuilder sbIdDoc = new StringBuilder();
            for (int i = 0; i < transport.getTtnList().size(); i++) {
                sbIdDoc.append(transport.getTtnList().get(i).getNum());
                if (i + 1 < transport.getTtnList().size()) sbIdDoc.append(", ");
            }

            if (!transport.getTtnList().isEmpty()) {
                String ttnText = transport.getTtnList().size() > 1 ? "Містить декілька ТТН" : transport.getTtnList().get(0).getNum();
                sb.append(Utils.format("%s", ttnText));
            }

            holder.textTitle.setText(app.fromHtml(title));
            holder.textContent.setText(app.fromHtml(sb.toString()));

            View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
            holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
            refreshBackground(holder, holder.itemView.isFocused());
        }

        private void refreshBackground(TransportViewHolder holder, boolean hasFocus) {
            if (backgroundColor == -1) {
                holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_adapter_light));
            } else {
                holder.itemView.setBackgroundColor(backgroundColor);
            }
        }

		static class TransportViewHolder extends FlexibleViewHolder {

			@BindView(R.id.textTitle)
			TextView textTitle;
			@BindView(R.id.textContent)
			TextView textContent;

			TransportViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
				super(view, adapter);
				ButterKnife.bind(this, view);
			}
        }
    }*/
}
