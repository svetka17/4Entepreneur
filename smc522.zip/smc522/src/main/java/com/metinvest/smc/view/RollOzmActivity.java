package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.RollInfo;
import com.metinvest.smc.db.RollName;
import com.metinvest.smc.tools.IValue;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.tools.Value;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class RollOzmActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

    @BindView(R.id.textOzm)
    EditText textOzm;
    @BindView(R.id.textThickness)
    EditText textThickness;
    @BindView(R.id.textWidth)
    EditText textWidth;
    @BindView(R.id.textLength)
    EditText textLength;
    @BindView(R.id.buttonRefresh)
    View buttonRefresh;
    @BindView(R.id.spinnerMarkdown)
    Spinner spinnerMarkdown;
    @BindView(R.id.spinnerMera)
    Spinner spinnerMera;
    @BindView(R.id.spinnerTravl)
    Spinner spinnerTravl;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    @BindView(R.id.listView)
    RecyclerView listView;

    private RollInfo rollInfo;
    private ArrayList<IValue> markdownList, meraList, travlList;
    private FlexibleAdapter<Adapter> adapter;
    private String storage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roll_ozm);
        ButterKnife.bind(this);

        storage = getIntent().getStringExtra("storage");

        List<RollInfo> info = db.rollInfoDao().getAll();
        if (info.isEmpty()) finish();
        else rollInfo = info.get(0);

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        textNotFound.setVisibility(View.GONE);
        listView.setVisibility(View.GONE);

        config.setRollLocation("");
        config.saveConfig();
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginLoad();
    }

    private void beginLoad() {
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            List<String> list = db.rollDao().getMarkdownList();
            markdownList = new ArrayList<>(list.size());
            markdownList.add(new Value(-1, "[Усі]"));
            for (int i = 0; i < list.size(); i++) markdownList.add(new Value(i, list.get(i)));

            Collections.sort(markdownList, (o1, o2) -> {
                if (o1.getName().equalsIgnoreCase("нет")) return -1;
                else if (o2.getName().equalsIgnoreCase("нет")) return 1;
                return 0;
            });

            list = db.rollDao().getMeraList();
            meraList = new ArrayList<>(list.size());
            meraList.add(new Value(-1, "[Усі]"));
            for (int i = 0; i < list.size(); i++) meraList.add(new Value(i, list.get(i)));

            list = db.rollDao().getTravlList();
            travlList = new ArrayList<>(list.size());
            travlList.add(new Value(-1, "[Усі]"));
            for (int i = 0; i < list.size(); i++) travlList.add(new Value(i, list.get(i)));

            runOnUiThread(this::endLoad);

        });
    }

    private void endLoad() {
        Utils.fillData(spinnerMarkdown, markdownList);
        Utils.fillData(spinnerMera, meraList);
        Utils.fillData(spinnerTravl, travlList);
        hideLoading();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            beginLoadList();
        } else if (number == 6) {
            startActivity(new Intent(this, UnknownActivity.class));
        }
    }

    public void buttonThicknessClearClick(View view) {
        textThickness.setText(null);
    }

    public void buttonWidthClearClick(View view) {
        textWidth.setText(null);
    }

    public void buttonLengthClearClick(View view) {
        textLength.setText(null);
    }

    private IValue getFilterMarkdown() {
        return (IValue) spinnerMarkdown.getSelectedItem();
    }

    private IValue getFilterMera() {
        return (IValue) spinnerMera.getSelectedItem();
    }

    private IValue getFilterTravl() {
        return (IValue) spinnerTravl.getSelectedItem();
    }

    private void beginLoadList() {
        if (isLoading()) return;
        showLoading(R.string.text_please_wait);

        String searchMatt = "%" + textOzm.getText().toString() + "%";
        float searchWidth = textWidth.getText().toString().isEmpty() ? -1 : Utils.parseFloat(textWidth.getText().toString());
        float searchLength = textLength.getText().toString().isEmpty() ? -1 : Utils.parseFloat(textLength.getText().toString());
        float searchThickness = textThickness.getText().toString().isEmpty() ? -1 : Utils.parseFloat(textThickness.getText().toString());

        IValue ivalMarkdown = getFilterMarkdown();
        IValue ivalMera = getFilterMera();
        IValue ivalTravl = getFilterTravl();

        Utils.runOnBackground(() -> {

            List<RollName> rollNameList = db.rollNameDao().find(
                    ivalMarkdown.getId() == -1 ? null : ivalMarkdown.getName(),
                    ivalMera.getId() == -1 ? null : ivalMera.getName(),
                    ivalTravl.getId() == -1 ? null : ivalTravl.getName(),
                    searchMatt, searchWidth, searchLength, searchThickness);

            List<Adapter> adapterList = new ArrayList<>();
            for (RollName rollName : rollNameList) {
                adapterList.add(new Adapter(rollName));
            }

            adapter = new FlexibleAdapter<>(adapterList);
            adapter.addListener(this);

            runOnUiThread(this::endLoadList);
        });
    }

    private void endLoadList() {
        hideLoading();
        listView.setAdapter(adapter);
        listView.setVisibility(adapter == null || adapter.isEmpty() ? View.GONE : View.VISIBLE);
        textNotFound.setVisibility(adapter == null || adapter.isEmpty() ? View.VISIBLE : View.GONE);
        listView.setVisibility(adapter != null && !adapter.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public boolean onItemClick(View view, int position) {
        Adapter item = adapter.getItem(position);
        if (item != null) {
            IValue ivalMarkdown = getFilterMarkdown();
            IValue ivalMera = getFilterMera();
            IValue ivalTravl = getFilterTravl();

            Intent intent = new Intent(this, RollWeighingActivity.class);
            intent.putExtra("rollNameId", item.getRollName().getId());
            intent.putExtra("markdown", ivalMarkdown.getId() == -1 ? null : ivalMarkdown.getName());
            intent.putExtra("mera", ivalMera.getId() == -1 ? null : ivalMera.getName());
            intent.putExtra("travl", ivalTravl.getId() == -1 ? null : ivalTravl.getName());
            intent.putExtra("storage", storage);
            startActivity(intent);
            return true;
        }
        return false;
    }

    public class Adapter extends AbstractFlexibleItem<Adapter.ViewHolder> {

        private final RollName rollName;

        public Adapter(RollName rollName) {
            this.rollName = rollName;
        }

        RollName getRollName() {
            return rollName;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof Adapter && ((Adapter) o).getRollName().getId() == getRollName().getId();
        }

        @Override
        public int hashCode() {
            return getRollName().hashCode();
        }

        @Override
        public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
            return new ViewHolder(view, adapter);
        }

        @Override
        public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {
            String data = Utils.format("%s", getRollName().getName());
            holder.textTitle.setText(data);

            View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
            holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
            refreshBackground(holder, holder.itemView.isFocused());
        }

        private void refreshBackground(ViewHolder holder, boolean hasFocus) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_adapter_light));
        }

        @Override
        public int getLayoutRes() {
            return R.layout.adapter_roll_name;
        }

        public class ViewHolder extends FlexibleViewHolder {

            @BindView(R.id.textTitle)
            TextView textTitle;

            public ViewHolder(View view, FlexibleAdapter adapter) {
                super(view, adapter);
                ButterKnife.bind(this, view);
            }
        }
    }
}
