package com.metinvest.smc.tools;

public interface INfc {
    void onNfcEvent(NFC nfc);
}
