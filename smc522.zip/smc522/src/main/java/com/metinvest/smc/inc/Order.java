package com.metinvest.smc.inc;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.metinvest.smc.tools.Utils;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Order {

    private final JSONObject json;
    private final String name, batch, sapOzm;
    private final int weightPlan, weightFact;
    private final float width, length, thickness;
    private final int lineId;
    private final Ozm ozm;
    private final String idQr;
    private final String idPos;
    //private final String proizvod, postavkaMera, lowPrice;

    public Order(String json) {
        this(Utils.getJsonObject(json));
    }

    public Order(JSONObject json) {
        this.json = json;
        this.lineId = Utils.getJsonIntIgnoreCase(json, "line_Id");
        this.name = Utils.getJsonStringIgnoreCase(json, "sap_matt_descr");
        this.weightPlan = Utils.getJsonIntIgnoreCase(json, "saP_Weight_NETT");
        this.weightFact = Utils.getJsonIntIgnoreCase(json, "saP_Weight_NETT_FACT");
        this.batch = Utils.getJsonStringIgnoreCase(json, "saP_Batch");
        this.sapOzm = Utils.getJsonStringIgnoreCase(json, "saP_Ozm");
        this.width = Utils.getJsonFloatIgnoreCase(json, "width");
        this.length = Utils.getJsonFloatIgnoreCase(json, "length");
        this.thickness = Utils.getJsonFloatIgnoreCase(json, "thickness");
        this.ozm = new Ozm(sapOzm, name, width, length, thickness);
        this.idQr = Utils.getJsonStringIgnoreCase(json, "iD_QR");
        this.idPos = Utils.getJsonStringIgnoreCase(json, "iD_POS");

        /*this.proizvod = Utils.getJsonStringIgnoreCase(json, "iD_POS");
        this.postavkaMera = Utils.getJsonStringIgnoreCase(json, "iD_POS");
        this.lowPrice = Utils.getJsonStringIgnoreCase(json, "iD_POS");*/
    }

    public int getAvailableNetto() {
        int availableNetto = getWeightPlan() - getWeightFact();
        if (availableNetto < 0) availableNetto = 0;
        return availableNetto;
    }

    public String getIdPos() {
        return idPos;
    }

    public Ozm getOzm() {
        return ozm;
    }

    public JSONObject getJson() {
        return json;
    }

    public int getLineId() {
        return lineId;
    }

    public String getName() {
        return name;
    }

    public String getBatch() {
        return batch;
    }

    public String getSapOzm() {
        return sapOzm;
    }

    public float getWidth() {
        return width;
    }

    public float getLength() {
        return length;
    }

    public float getThickness() {
        return thickness;
    }

    public int getWeightPlan() {
        return weightPlan;
    }

    public int getWeightFact() {
        return weightFact;
	}

	public String getIdQr() {
		return idQr;
	}

	public float getWeightPercent() {
		return weightFact * 100.0f / weightPlan;
	}

	@Override
	public int hashCode() {
		return ((Object) getLineId()).hashCode();
	}

    /*public String getProizvod() {
        return proizvod;
    }

    public String getPostavkaMera() {
        return postavkaMera;
    }

    public String getLowPrice() {
        return lowPrice;
    }*/

    @Override
	public boolean equals(@Nullable Object obj) {
		return obj instanceof Order && ((Order) obj).getLineId() == getLineId();
	}

	@NonNull
	@Override
	public String toString() {
		return Utils.format("%s %d/%d", getName(), getWeightPlan(), getWeightFact());
    }

    public static List<Ozm> getOzmList(List<Order> orderList) {
        List<Ozm> list = new ArrayList<>();
        for (Order order : orderList) {
            if (Ozm.findOzm(list, order.getOzm()) == null)
                list.add(order.getOzm());
        }
        return list;
    }

    public static List<Order> getByOzm(List<Order> orderList, Ozm ozm) {
        List<Order> list = new ArrayList<>();
        for (Order order : orderList) {
            if (order.getOzm().equals(ozm)) list.add(order);
        }
        return list;
    }

    public static int getTotalWeightPlan(List<Order> orderList) {
        int total = 0;
        for (Order order : orderList) {
            total += order.getWeightPlan();
        }
        return total;
    }

    public static int getTotalWeightFact(List<Order> orderList) {
        int total = 0;
        for (Order order : orderList) {
            total += order.getWeightFact();
        }
        return total;
    }
}
