package com.metinvest.smc.inc;

import androidx.annotation.NonNull;

import com.metinvest.smc.App;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Transport {

    private JSONObject json;
    private String name;
    private Date date;

    private int totalWeightPlan, totalWeightFact, totalWeightFactTemp;

    private List<TTN> ttnList;

    private Transport() {

    }

    public void setJson(JSONObject json) {
        this.json = json;
    }

    public Date getDate() {
        return date;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setTtnList(List<TTN> ttnList) {
        this.ttnList = ttnList;
    }

    public List<TTN> getTtnList() {
        return ttnList;
    }

    public void setTotalWeightPlan(int totalWeightPlan) {
        this.totalWeightPlan = totalWeightPlan;
    }

    public void setTotalWeightFact(int totalWeightFact) {
        this.totalWeightFact = totalWeightFact;
    }

    public void setTotalWeightFactTemp(int totalWeightFactTemp) {
        this.totalWeightFactTemp = totalWeightFactTemp;
    }

    public int getTotalWeightPlan() {
        return totalWeightPlan;
    }

    public int getTotalWeightFact() {
        return totalWeightFact;
    }

    public int getTotalWeightFactTemp() {
        return totalWeightFactTemp;
    }

    public int getTotalWeightPercent() {
        return Math.round(totalWeightFact * 100.0f / totalWeightPlan);
    }

    public JSONObject getJson() {
        return json;
    }

	public String getName() {
		return name;
	}

	@NonNull
	@Override
	public String toString() {
		return getName();
	}

	public static Transport fromJson(String jsonTransport, SohFilter sohFilter) {
		return fromJson(Utils.getJsonObject(jsonTransport), sohFilter);
	}

	public static Transport fromJson(JSONObject jsonTransport, SohFilter sohFilter) {
		if (jsonTransport == null) return null;

		Transport transport = new Transport();

		transport.setJson(jsonTransport);
		transport.setName(Utils.getJsonStringIgnoreCase(jsonTransport, "ttN_CARIER_ID"));

		String dt = Utils.getJsonStringIgnoreCase(jsonTransport, "ttN_DATE");
		if (dt.length() == 0) dt = Utils.getJsonStringIgnoreCase(jsonTransport, "plaN_DATE");

		transport.setDate(App.getInstance().parseDfDate(dt));
		transport.setTotalWeightPlan(0);
		transport.setTotalWeightFact(0);
		transport.setTotalWeightFactTemp(0);

        /*if (transport.getName().equalsIgnoreCase("ВМ3123АК-ВМ7652ХХ")) {
        	transport.setName(transport.getName());
		}*/

		List<TTN> ttnList = new ArrayList<>();
		JSONArray arrayTtn = Utils.getJsonArray(jsonTransport, "ttN_NUMBERS");
		if (arrayTtn != null && arrayTtn.length() > 0) {

			int totalWeightPlan = 0, totalWeightFact = 0, totalWeightFactTemp = 0;

			for (int j = 0; j < arrayTtn.length(); j++) {
				JSONObject jsonTtn = Utils.getJsonObject(arrayTtn, j);
				String ttnNum = Utils.getJsonStringIgnoreCase(jsonTtn, "ttN_NUM");

				if (isTtnExistInList(ttnList, ttnNum)) {
					App.getInstance().log("Transport", "Double TTN_NUM #%s (TRANSPORT \"%s\")", ttnNum, transport.getName());
					continue;
				}

				String ttnId = Utils.getJsonStringIgnoreCase(jsonTtn, "ttN_ID");
				//String status = Utils.getJsonStringIgnoreCase(jsonTtn, "statuS_OUT");
				int weightPlan = Utils.getJsonWeightKgIgnoreCase(jsonTtn, "suM_PLAN_WEIGHT");
				int weightFact = Utils.getJsonWeightKgIgnoreCase(jsonTtn, "suM_FACT_WEIGHT");
				int weightFactTemp = Utils.getJsonWeightKgIgnoreCase(jsonTtn, "suM_FACT_TEMP_WEIGHT");
				Boolean ttnSoh = null;
				String sohStr = Utils.getJsonStringIgnoreCase(jsonTtn, "soh");
				if (sohStr.equalsIgnoreCase("true")) ttnSoh = true;
				else if (sohStr.equalsIgnoreCase("false")) ttnSoh = false;

				if (sohFilter != null) {
					if (sohFilter.getType() == SohFilterType.NOT_SOH && ttnSoh != null) continue;
					if (sohFilter.getType() == SohFilterType.SOH_TRUE && !sohStr.equalsIgnoreCase("true"))
						continue;
					if (sohFilter.getType() == SohFilterType.SOH_FALSE && !sohStr.equalsIgnoreCase("false"))
						continue;
				}

				ttnList.add(new TTN(/*ttnId, */ttnNum, ttnSoh));
				totalWeightPlan += weightPlan;
				totalWeightFact += weightFact;
				totalWeightFactTemp += weightFactTemp;
			}

			transport.setTotalWeightPlan(totalWeightPlan);
			transport.setTotalWeightFact(totalWeightFact);
			transport.setTotalWeightFactTemp(totalWeightFactTemp);
		}
		transport.setTtnList(ttnList);

		return transport;
	}

	private static boolean isTtnExistInList(List<TTN> ttnList, String ttnNum) {
		for (TTN ttn : ttnList) {
			if (ttn.getNum().equalsIgnoreCase(ttnNum)) return true;
		}
		return false;
	}
}
