package com.metinvest.smc.view;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Inventory;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.JsonUploadTask;
import com.metinvest.smc.tools.Utils;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LocalInventoryActivity extends MyActivity {

	@BindView(R.id.frameButtonSend)
	View frameButtonSend;
	@BindView(R.id.frameButtonClear)
	View frameButtonClear;
	@BindView(R.id.buttonAccept)
	Button buttonAccept;
	@BindView(R.id.buttonSend)
	Button buttonSend;
	@BindView(R.id.buttonDate)
	Button buttonDate;
	@BindView(R.id.buttonClear)
	Button buttonClear;

	private Date date;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_local_inventory);
		ButterKnife.bind(this);

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(Calendar.getInstance().getTime());
		date = calendar.getTime();
		refreshButtons();
		buttonDate.requestFocus();
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		beginLoad();
	}

	private void beginLoad() {
		long count = db.inventoryDao().getCount();
		frameButtonSend.setVisibility(count > 0 ? View.VISIBLE : View.GONE);
		buttonSend.setEnabled(count > 0);
		frameButtonClear.setVisibility(count > 0 ? View.VISIBLE : View.GONE);
	}

	private void refreshButtons() {
		buttonDate.setText(app.getDateFormat().format(date));
	}

	@Override
	protected String getHelpContent() {
		return "Для початку інвентаризації оберіть дату та натисніть \"F5 - Почати інвентаризацію\"\n\nЩоб очистити список проінвентаризованого натисніть \"F4\"";
	}

	@Override
	protected void onFunctionKey(int number) {
		switch (number) {
			case 2:
				buttonDateClick();
				break;
			case 4:
				buttonResetClick();
				break;
			case 5:
				buttonAcceptClick();
				break;
			case 6:
				buttonSendClick();
				break;
		}
	}

	private void buttonResetClick() {

		if (isLoading() || frameButtonClear.getVisibility() != View.VISIBLE || !buttonClear.isEnabled())
			return;

		showDialogConfirm(R.string.text_confirm, "Ви дійсно бажаєте очистити список проінвентаризованого?", (dialog, which) -> {
			try {
				db.inventoryDao().truncate();
			} catch (Exception e) {
				log(e, "db.inventoryDao().truncate()");
			}
			showToast("Список проінвентаризованого очищено!");
			finish();
		});
	}

	private void buttonAcceptClick() {
		if (isLoading() || !buttonAccept.isEnabled()) return;

		try {

			String df = app.getDateFormat().format(date);
			date = app.getDateFormat().parse(df);

			Intent intent = new Intent(this, LocalInventory2Activity.class);
			intent.putExtra("date", date.getTime());
			startActivityForResult(intent, REQUEST_DEFAULT);
		} catch (Exception e) {
			log(e, "buttonAcceptClick()");
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == REQUEST_DEFAULT && resultCode == RESULT_OK) {
			beginLoad();
		}
	}

	private void buttonDateClick() {
		Calendar calendar = Utils.toCalendar(date);

		DatePickerDialog dialog = new DatePickerDialog(this,
				(view1, year, month, dayOfMonth) -> {
					Calendar calendar1 = Calendar.getInstance();
					calendar1.set(year, month, dayOfMonth);
					date = calendar1.getTime();
					refreshButtons();
				}, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DATE));
		dialog.show();
	}

	private void buttonSendClick() {
		if (isLoading() || frameButtonSend.getVisibility() != View.VISIBLE || !buttonSend.isEnabled())
			return;

		showLoading(R.string.text_please_wait);
		buttonSend.setEnabled(false);
		buttonClear.setEnabled(false);
		buttonAccept.setVisibility(View.GONE);

		Utils.runOnBackground(() -> {

			StringBuilder sb = new StringBuilder();

			List<Inventory> list = db.inventoryDao().getAll();

			sb.append("[");

			for (int i = 0; i < list.size(); i++) {

				Inventory item = list.get(i);

				String outDatePrint = "null";
				if (item.getDatePrint() > 0) {
					outDatePrint = Utils.format("\"%s\"", app.getDateTimeFormat().format(new Date(item.getDatePrint())));
				}

				sb.append(Utils.format("{%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n}"
						, Utils.format("\"Inv_Date\":\"%s\",", app.getDateFormat().format(new Date(item.getDate())))
						, Utils.format("\"Location_Code\":\"%s\",", item.getLocationCode())
						, Utils.format("\"Label_Id\":%s,", item.getLabelId() == 0 ? "null" : item.getLabelId())
						, Utils.format("\"NETT_Weight\":\"%s\",", item.getNetto())
						, Utils.format("\"PACK_Weight\":\"%s\",", item.getPack())
						, Utils.format("\"Scan_DateTime\":\"%s\",", app.getDateTimeFormat().format(new Date(item.getDateScan())))
						, Utils.format("\"Print_DateTime\":%s,", outDatePrint)
						, Utils.format("\"SAP_BATCH\":\"%s\",", item.getBatch())
						, Utils.format("\"SAP_OZM\":\"%s\",", item.getOzm())
						, Utils.format("\"SAP_MATT_Descr\":\"%s\",", item.getMatt())
						, Utils.format("\"Width\":\"%s\",", item.getWidth())
						, Utils.format("\"Length\":\"%s\",", item.getLength())
						, Utils.format("\"Thickness\":\"%s\"", item.getThickness())
				));

				if (i + 1 < list.size()) sb.append(",");

			}

			sb.append("]");

			String url = app.getConfig().getUrlApi() + "InvByDateWriteInventory1";
			net.uploadJson(new JsonUploadTask.JsonUploadTaskParam(url, sb.toString()), this::endSend);

		});

	}

	private void endSend(JsonResult result) {

		hideLoading();
		buttonSend.setEnabled(true);
		buttonClear.setEnabled(true);
		buttonAccept.setVisibility(View.VISIBLE);

		if (result.isOk()) {

			try {
				db.inventoryDao().truncate();
			} catch (Exception e) {
				log(e, "db.inventoryDao().truncate()");
			}
			showToast(R.string.successful_sended);
			finish();

		} else {

			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, getString(R.string.text_upload_coming_list_error, result.getStatus()), (dialog, which) -> buttonSendClick());
		}
	}
}
