package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Carrier;
import com.metinvest.smc.db.NameStore;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.Globals;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemPack;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class InActivity extends MyActivity implements IScan {

	@BindView(R.id.buttonCarrier)
	Button buttonCarrier;
	@BindView(R.id.spinnerName)
	Spinner spinnerName;
	@BindView(R.id.textWeight)
	EditText textWeight;
	@BindView(R.id.textCount)
	EditText textCount;
	@BindView(R.id.textEmpty)
	TextView textEmpty;
	@BindView(R.id.buttonAccept)
	Button buttonAccept;
	@BindView(R.id.textLocation1)
	EditText textLocation1;
	@BindView(R.id.textLocation2)
	EditText textLocation2;
	@BindView(R.id.textLocation3)
	EditText textLocation3;
	@BindView(R.id.listView)
	RecyclerView listView;
	@BindView(R.id.textInFromTo)
	TextView textInFromTo;
	@BindView(R.id.buttonToggle)
	Button buttonToggle;
	@BindView(R.id.buttonCrane)
	ImageButton buttonCrane;

	private Carrier carrier;
	private long nameId;
	private FlexibleAdapter<AdapterItemPack> adapter;
	private boolean theor = false;
	private final int packLimit = 25;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_in);
		ButterKnife.bind(this);

		LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
		DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
		listView.setLayoutManager(layoutManager);
		listView.addItemDecoration(dividerItemDecoration);

		buttonToggle.setOnClickListener(v -> onToggle(!isTheor()));

		textCount.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				loadPackGrid();
				checkTextCount();
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		});

		spinnerName.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				nameId = id;
				refreshFromTo();
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

		buttonCrane.setOnClickListener(v -> loadCraneWeight());
		buttonCrane.setOnLongClickListener(v -> {
			loadCraneTara();
			return true;
		});
	}

	public boolean isTheor() {
		return theor;
	}

	private void onToggle(boolean isToggle) {
		theor = isToggle;
		textWeight.setEnabled(!isTheor());

		buttonToggle.setBackgroundTintList(ContextCompat.getColorStateList(this, isTheor() ? R.color.toggle_on : R.color.toggle_off));

		loadPackGrid();
	}

	private void changeCarrier(long id) {
		carrier = db.carrierDao().getById(id);

		List<OnTheWay> rowsTotal = db.onTheWayDao().getByCarrierId(carrier.getId());

		carrier.setName(Utils.format("%s (позицій: %d)", carrier.getName(), rowsTotal.size()));

		buttonCarrier.setText(carrier.getName());
		Globals.lastCarrierId = id;
		beginLoadNameList();
	}

	private void refreshFromTo() {
        /*float w1 = 0;
        float w2 = 0;

        textInFromTo.setText(getString(R.string.text_in_from_to, app.floatToStringSize(w1), app.floatToStringSize(w2)));*/
	}

	private void loadPackGrid() {

		int packCountOrig = Utils.parseInt(textCount.getText().toString());
		int packCount = packCountOrig > 0 && packCountOrig <= packLimit ? (isTheor() ? 1 : packCountOrig) : 0;

		Utils.runOnBackground(() -> {
			List<AdapterItemPack> items = new ArrayList<>(packCount);

			for (int i = 0; i < packCount; i++) {
				String title = isTheor() ? Utils.format("<b>Пачка №:%s", packCountOrig > 1 ? "1-" + packCountOrig : String.valueOf(packCountOrig)) : Utils.format("<b>Пачка №:%d</b>", i + 1);
				items.add(new AdapterItemPack(i, title, 0, 0, 0, null));
			}

			adapter = new FlexibleAdapter<>(items);

			runOnUiThread(() -> {
				listView.setAdapter(adapter);
				buttonAccept.setEnabled(packCount > 0);
			});
		});

	}

	@Override
	public void onBarcodeEvent(String barcodeData) {
		if (isLoading()) return;

		runOnUiThread(() -> {
			ScanItem scanItem = new ScanItem(barcodeData);
			if (!scanItem.isCorrect()) {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_label, null);
			} else if (scanItem.getType() == ScanItem.ScanItemType.SMC06) {
				processLabel(scanItem);
			} else if (scanItem.getType() == ScanItem.ScanItemType.SMC05 || scanItem.getType() == ScanItem.ScanItemType.SMC07) {
				checkIsUnknown(scanItem);
			} else if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONID) {
				beginLoadLocation(scanItem);
			} else if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONCODE) {
				endLoadLocation(scanItem.getData(0));
			}
		});
	}

	@Override
	protected void onIsUnknown(ScanItem scanItem, boolean unknown, @Nullable Label label) {
		if (unknown) {
			processUnknown(scanItem, scanItem.getType() == ScanItem.ScanItemType.SMC07);
		} else if (label != null) {
			processLabel(label.getId(), label.getBatch(), label.getWeightNetto(), label.getWeightPack());
		}
	}

	private void processLabel(String labelId, String batch, int netto, int pack) {
		showLoading(R.string.text_please_wait);

		Utils.runOnBackground(() -> {
			int brutto = netto + pack;
			String locationCode = null;

			JsonResult result = net.loadLabelInfo(labelId);
			JSONObject json = Utils.getJsonObject(result.getJson(), "data");
			if (result.isOk() && json != null) {
				String locationId = Utils.getJsonStringIgnoreCase(json, "location_id");
				locationCode = net.getLocationCode(locationId);
			}

			String finalLocationCode = locationCode;
			runOnUiThread(() -> endProcessLabel(netto, pack, brutto, finalLocationCode));
		});
	}

	private void processLabel(ScanItem scanItem) {
		if (scanItem.getType() == ScanItem.ScanItemType.SMC06) {
			String labelId = scanItem.getData(0);
			String batch = scanItem.getData(11);
			int netto = Utils.parseInt(scanItem.getData(6));
			int pack = Utils.parseInt(scanItem.getData(9));
			processLabel(labelId, batch, netto, pack);
		}
	}

	private void endProcessLabel(int netto, int pack, int brutto, String locationCode) {
		hideLoading();

		textWeight.setText(String.valueOf(brutto));
		textCount.setText(String.valueOf(1));

		if (locationCode != null) {
			String[] arr = app.fixLocation(locationCode).split("-");
			String r = arr[0];
			String p = arr[1];
			String t = arr[2];
			textLocation1.setText(r);
			textLocation2.setText(p);
			textLocation3.setText(t);
		}

		loadPackGrid();

		AdapterItemPack itemPackZero = adapter.getItem(0);
		if (itemPackZero != null) {
			itemPackZero.setW1(netto);
			itemPackZero.setW2(pack);
			itemPackZero.setW3(0);
			adapter.updateItem(itemPackZero);
		}

		if (locationCode != null) {
			buttonAcceptClick();
		}
	}

	private void beginLoadLocation(ScanItem scanItem) {
		showLoading(R.string.text_please_wait);

		Utils.runOnBackground(() -> {
			String newLocationCode = net.getLocationCode(scanItem.getData(0));
			runOnUiThread(() -> endLoadLocation(newLocationCode));
		});
	}

	private void endLoadLocation(String newLocationCode) {

		hideLoading();

		if (app.isLocationCorrect(newLocationCode)) {
			String[] arr = app.fixLocation(newLocationCode).split("-");
			textLocation1.setText(arr[0]);
			textLocation2.setText(arr[1]);
			textLocation3.setText(arr[2]);
		} else {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.location_identity_error, null);
		}
	}

	private void processUnknown(ScanItem scanItem, boolean isNew) {

		String itemLocation = scanItem.getData(5);

		if (itemLocation.length() == 0) {
			itemLocation = app.fixLocation(Utils.format("%s-%s-%s",
					textLocation1.getText().toString(),
					textLocation2.getText().toString(),
					textLocation3.getText().toString()
			));
		}

		if (!app.isLocationCorrect(itemLocation)) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.text_error_location_incorrect, null);
			textLocation1.post(() -> textLocation1.requestFocus());
			return;
		}

		try {
			int sWeightCrane = Utils.parseInt(scanItem.getData(0));
			int sPackCount = Utils.parseInt(scanItem.getData(1));
			JSONArray array = new JSONArray(scanItem.getData(2));
			String sDate = scanItem.getData(3);
            /*String sTransport = scanItem.getData(4);
            String sName = scanItem.getData(5);

            byte[] bytes = sTransport.getBytes(StandardCharsets.ISO_8859_1);
            sTransport = new String(bytes);

            bytes = sName.getBytes(StandardCharsets.ISO_8859_1);
            sName = new String(bytes);

            for (int i = 0; i < spinnerCarrier.getAdapter().getCount(); i++) {
                Carrier carrier = (Carrier) spinnerCarrier.getAdapter().getItem(i);

                String carrierName = carrier.getShipmentItem();
                int j = carrierName.indexOf("(");
                if (j != -1) carrierName = carrierName.substring(0, j - 1);

                if (carrierName.equalsIgnoreCase(sTransport)) {
                    spinnerCarrier.setSelection(i);
                    break;
                }
            }*/

			ArrayList<Integer> wListNetto = new ArrayList<>(sPackCount);
			ArrayList<Integer> wListPack = new ArrayList<>(sPackCount);
			ArrayList<Integer> wListTara = new ArrayList<>(sPackCount);
			for (int i = 0; i < sPackCount; i++) {
				JSONObject object = Utils.getJsonObject(array, i);
				wListNetto.add(Utils.getJsonIntIgnoreCase(object, "netto"));
				wListPack.add(Utils.getJsonIntIgnoreCase(object, "pack"));
				wListTara.add(Utils.getJsonIntIgnoreCase(object, "tara"));
			}

			textWeight.setText(String.valueOf(sWeightCrane));
			textCount.setText(String.valueOf(sPackCount));

			beginAccept(carrier.getId(), spinnerName.getSelectedItemId(), false, sWeightCrane, sPackCount, itemLocation, wListNetto, wListPack, wListTara);

		} catch (Exception e) {
			log(e, "processUnknown(%s)", scanItem);
			showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.error_identity_temp_label, null);
		}

	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		loadCarrier();
		loadPackGrid();
	}

	private void loadCarrier() {

		long id;

		boolean lastExist = Globals.lastCarrierId != null && db.carrierDao().getById(Globals.lastCarrierId) != null;

		if (lastExist) {
			id = Globals.lastCarrierId;
		} else {
			List<Carrier> carriers = db.carrierDao().getAll();
			id = carriers.get(0).getId();
		}

		changeCarrier(id);
	}

	private void beginLoadNameList() {

		Utils.runOnBackground(() -> {
			List<Long> rows = db.onTheWayDao().getNameListByCarrier(carrier.getId());

			long oldNameId = nameId;
			int namePos = -1;

			List<NameStore> nameList = db.nameStoreDao().getById(rows);
			Collections.sort(nameList, (o1, o2) -> o1.getName().compareToIgnoreCase(o2.getName()));

			for (int i = 0; i < nameList.size(); i++) {
				if (nameList.get(i).getId() == oldNameId) {
					namePos = i;
					break;
				}
			}

			int finalNamePos = namePos;
			runOnUiThread(() -> endLoadNameList(nameList, finalNamePos));
		});

	}

	private void endLoadNameList(List<NameStore> list, int pos) {
		Utils.fillData(spinnerName, new ArrayList<>(list));
		if (pos != -1) spinnerName.setSelection(pos);

		textEmpty.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
		buttonAccept.setEnabled(!list.isEmpty());
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 2) {
			buttonCarrier.requestFocus();
			openTransportList();
		} else if (number == 3) {
			spinnerName.requestFocus();
			spinnerName.performClick();
		} else if (number == 5) buttonAcceptClick();
		else if (number == 7) buttonReportClick();
	}

	private void openTransportList() {
		Intent intent = new Intent(this, CarriersActivity.class);
		startActivityForResult(intent, REQUEST_ACTION);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == REQUEST_DEFAULT && resultCode == RESULT_OK) {
			textWeight.setText(null);
		}

		if (requestCode == REQUEST_ACTION && resultCode == RESULT_OK && data != null) {
			long id = data.getLongExtra("carrierId", 0);
			changeCarrier(id);
		}
	}

	private void buttonReportClick() {
		Intent intent = new Intent(this, ComingListActivity.class);
		intent.putExtra("carrierId", carrier.getId()/* spinnerCarrier.getSelectedItemId()*/);
		//intent.putExtra("nameId", spinnerName.getSelectedItemId());
		startActivity(intent);
	}

	private void buttonAcceptClick() {
		if (isLoading() || !buttonAccept.isEnabled()) return;

		int weightCrane = Utils.parseInt(textWeight.getText().toString());
		int packCount = Utils.parseInt(textCount.getText().toString());
		String locationCode = Utils.format("%s-%s-%s",
				textLocation1.getText().toString(),
				textLocation2.getText().toString(),
				textLocation3.getText().toString()
		);

		if (!isTheor() && weightCrane <= 0) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.text_error_weight, null);
			textWeight.post(() -> textWeight.requestFocus());
			return;
		}

		if (packCount <= 0) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.text_error_packcount, null);
			textCount.post(() -> textCount.requestFocus());
			return;
		}

		if (packCount > packLimit) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.text_error_packcount_overflow, null);
			textCount.post(() -> textCount.requestFocus());
			return;
		}

		//if (locationCode.length() == 0) locationCode = "0";

		if (!app.isLocationCorrect(locationCode)) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.text_error_location_incorrect, null);
			textLocation1.post(() -> textLocation1.requestFocus());
			return;
		}

		//
		ArrayList<Integer> sListW1 = new ArrayList<>(packCount);
		ArrayList<Integer> sListW2 = new ArrayList<>(packCount);
		ArrayList<Integer> sListW3 = new ArrayList<>(packCount);

		AdapterItemPack itemPackZero = adapter.getItem(0);

		for (int i = 0; i < packCount; i++) {

			AdapterItemPack itemPack = adapter.getItem(i);

			if (isTheor() && i > 0 && itemPackZero != null) {

				sListW1.add(itemPackZero.getW1());
				sListW2.add(itemPackZero.getW2());
				sListW3.add(itemPackZero.getW3());

			} else {

				if (itemPack != null) {
					sListW1.add(itemPack.getW1());
					sListW2.add(itemPack.getW2());
					sListW3.add(itemPack.getW3());

					if (itemPack.getW1() == 0) {
						showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.error_netto_zero, null);
						listView.requestFocus();
						return;
					}
				} else {
					sListW1.add(0);
					sListW2.add(0);
					sListW3.add(0);
				}
			}
		}
		//

		if (isTheor()) {
			weightCrane = sListW1.get(0) * packCount;
		}

		beginAccept(carrier.getId(), nameId, isTheor(), weightCrane, packCount, locationCode, sListW1, sListW2, sListW3);
	}

	private void beginAccept(long carrierId, long nameId, boolean useTheor, int weightCrane, int packCount, String locationCode,
							 ArrayList<Integer> listW1, ArrayList<Integer> listW2, ArrayList<Integer> listW3) {
		Intent intent = new Intent(this, In2Activity.class);
		intent.putExtra("carrierId", carrierId);
		intent.putExtra("nameId", nameId);
		intent.putExtra("isTheor", useTheor);
		intent.putExtra("weightCrane", weightCrane);
		intent.putExtra("packCount", packCount);
		intent.putExtra("locationCode", locationCode);
		intent.putExtra("hasWeightList", true);
		intent.putExtra("weightList1", listW1);
		intent.putExtra("weightList2", listW2);
		intent.putExtra("weightList3", listW3);
		startActivityForResult(intent, REQUEST_DEFAULT);
	}

	private void checkTextCount() {
		int packCountOrig = Utils.parseInt(textCount.getText().toString());
		boolean correct = packCountOrig > 0 && packCountOrig <= packLimit;

		if (correct) {
			textCount.setBackgroundTintList(null);
		} else {
			textCount.setBackgroundTintList(ContextCompat.getColorStateList(this, R.color.tint_incorrect));
		}
	}

	@Override
	protected void onCraneWeight(long craneId, int value) {
		textWeight.setText(String.valueOf(value));
	}
}
