package com.metinvest.smc.view;

import static android.content.DialogInterface.BUTTON_POSITIVE;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;

import com.metinvest.smc.R;
import com.metinvest.smc.tools.INfc;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.NFC;
import com.metinvest.smc.tools.Scales;
import com.metinvest.smc.tools.ScalesConfig;
import com.metinvest.smc.tools.Utils;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ScalesActivity extends MyActivity implements INfc, IScan {

    @BindView(R.id.viewContentData)
    View viewContentData;
    @BindView(R.id.textMacScales)
    EditText textMac;

    @BindView(R.id.textNameScales)
    EditText textName;
    @BindView(R.id.buttonTestScales)
    TextView buttonTest;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scales);
        ButterKnife.bind(this);
    }


    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        readConfig();
        textMac.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                onMacChanged(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        /*Utils.runOnBackground(() -> {
            Utils.sleep(1000);
            runOnUiThread(() -> {

                spinnerPaperType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        onPaperTypeChanged();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
            });
        });*/
    }

    private void onMacChanged(String mac) {
        //spinnerPrinterType.setEnabled(!Utils.isNullOrEmpty(mac));
    }

    private void readConfig() {
        ScalesConfig scales = config.getScales();

        textMac.setText(scales == null ? null : scales.getMac());

        textName.setText(scales == null ? null : scales.getName());

        viewContentData.setVisibility(config.isScalesConnected() ? View.VISIBLE : View.GONE);
        refreshButtons();
    }

    @Override
    protected String getHelpContent() {
        return getString(R.string.text_printer_prompt_message);
    }

    @Override
    protected void onFunctionKey(int number) {
        switch (number) {
            case 2:
                beginTest();
                break;

        }
    }

    private void beginTest() {
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            //char[] dpl = {0x01};//app.processTemplate(Config.TemplateType.TEMPLATE_TEST, null);

            final Scales.ScalesResult finalResult = Scales.sendCommand(config.getScales(), (byte)0, true);
            runOnUiThread(() -> endScales(finalResult));
        });
    }

    private void refreshButtons() {
        boolean enabled = config.isScalesConnected();
        buttonTest.setEnabled(enabled);
    }

    private void endScales(Scales.ScalesResult result) {
        hideLoading();

        if (result.getStatus() == Scales.ScalesResultStatus.OK) {
            showDiagResult(result.getStatus() + "/" + result.getScalesResult().getStatus() /*+ "/" + result.getScalesResult().toString()*/);
            //showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.warning_after_set_paper_type_zebra, null);
            refreshButtons();
            if (config.getScales().getName() == null || config.getScales().getName().isEmpty())
                showToast(R.string.text_no_scales_name);
        } else {
            @StringRes final int message = app.getScalesResultMessage(result);
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, message, null);
        }
    }

    public void buttonAddMacScalesClick(View view) {
        beginDetectScalesByScan(textMac.getText().toString());
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {
        beginDetectScalesByScan(barcodeData);
    }

    @Override
    public void onNfcEvent(NFC nfc) {
        runOnUiThread(() -> beginDetectScalesByNfc(nfc));
    }

    private void resetScales() {
        config.setScales(null);
        config.saveConfig();
    }

    private void beginDetectScalesByScan(String barcodeData) {
        ScalesConfig scalesConfig = new ScalesConfig(null, barcodeData);
        beginDetectScales(scalesConfig);
    }

    private void beginDetectScalesByNfc(NFC nfc) {
        ScalesConfig scalesConfig = Scales.detectScales(nfc);
        if (scalesConfig == null) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_scales_error, null);
        } else {
            beginDetectScales(scalesConfig);
        }
    }

    private void beginDetectScales(ScalesConfig scalesConfig) {
        if (isLoading()) return;
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            resetScales();

            boolean result = Utils.isCorrectMacAddress(scalesConfig.getMac());

            if (result) {
                if (scalesConfig.getName() == null)
                    scalesConfig.setName(textName.getText().toString());
                config.setScales(new ScalesConfig(scalesConfig.getName(), Utils.formatMacAddress(scalesConfig.getMac())));
                config.saveConfig();
            }

            runOnUiThread(() -> endDetectScales(result));

        });
    }

    private void endDetectScales(boolean result) {
        readConfig();
        hideLoading();

        if (!result)
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_print_result_bluetooth_mac_invalid, null);

        refreshButtons();
    }

    private void showDiagResult(String text) {
        if (isFinishing()) return;

        app.copyToClipboard(text);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(R.drawable.ic_warning_24dp);
        builder.setTitle(R.string.diag_result_dialog_title);

        String finalMessage = text.replaceAll("\n", "<br>");
        builder.setMessage(app.fromHtml(Utils.format("%s<br><br><i>TerminalId: %s</i><br><i>Версія:</i> %s", finalMessage, app.getDeviceId(), app.getApkVersionName())));
        builder.setPositiveButton(R.string.text_ok, null);

        final AlertDialog myDialog = builder.create();
        myDialog.setOnShowListener(dialog -> {
            Button button = myDialog.getButton(BUTTON_POSITIVE);
            button.setFocusable(true);
            button.setFocusableInTouchMode(true);
            button.requestFocus();
            app.hideUi(this);
        });
        myDialog.show();

        TextView textView = myDialog.findViewById(android.R.id.message);
        if (textView != null) textView.setTextSize(12);
    }
}
