package com.metinvest.smc.view;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ShipReverseActivity extends MyActivity implements IScan {

	@BindView(R.id.textContentTitle)
	TextView textContentTitle;
	@BindView(R.id.textContent)
	TextView textContent;
	@BindView(R.id.textWeight)
	EditText textWeight;
	@BindView(R.id.textLocation1)
	EditText textLocation1;
	@BindView(R.id.textLocation2)
	EditText textLocation2;
	@BindView(R.id.textLocation3)
	EditText textLocation3;
	@BindView(R.id.textWeightToShip)
	TextView textWeightToShip;
	@BindView(R.id.table)
	View table;
	@BindView(R.id.buttonAccept)
	Button buttonAccept;
	@BindView(R.id.frameButtonAccept)
	View frameButtonAccept;
	@BindView(R.id.textWeightTotal)
	TextView textWeightTotal;

	private Date date, dateVo;
	private String documentNumber;
	private String transportName;
	private int planLineId;
	private List<String> listLabelId;
	private int fact;
	private int lineId;
	private int labelSohId;
	private String idQr;
	private String idPos;
	private String smcIdSoh;
	//private ShipmentDocument document;
	//private ShipmentItem shipmentItem;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ship_reverse);
		ButterKnife.bind(this);

		date = (Date) getIntent().getSerializableExtra("date");
		dateVo = (Date) getIntent().getSerializableExtra("dateVo");
		documentNumber = getIntent().getStringExtra("documentNumber");
		transportName = getIntent().getStringExtra("transportName");
		planLineId = getIntent().getIntExtra("planLineId", 0);
		idPos = getIntent().getStringExtra("idPos");
		smcIdSoh = getIntent().getStringExtra("smcIdSoh");
		fact = getIntent().getIntExtra("fact", 0);
		lineId = getIntent().getIntExtra("lineId", 0);
		labelSohId = getIntent().getIntExtra("labelSohId", 0);
		idQr = getIntent().getStringExtra("idQr");

		if (idPos != null) log("idPos: %s", idPos);

		textContent.setVisibility(View.GONE);
		textContentTitle.setText(getString(R.string.reverse_title, documentNumber));

		TextWatcher textWatcher = new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				refreshLeft();
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		};
		textWeight.addTextChangedListener(textWatcher);

		listLabelId = null;
		textWeight.setEnabled(lineId > 0);
	}

	@Override
	public void onBarcodeEvent(String barcodeData) {
		if (isLoading()) return;

		runOnUiThread(() -> {

			setLocation(null);

			ScanItem scanItem = new ScanItem(barcodeData);

			if (scanItem.getType() == ScanItem.ScanItemType.LOCATIONCODE) {

				if (scanItem.isCorrect()) {
					setLocation(scanItem.getData(0));
				} else {
					showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.location_identity_error, null);
				}
			}

		});
	}

	private void setLocation(String locationCode) {

		if (locationCode == null) {
			textLocation1.setText(null);
			textLocation2.setText(null);
			textLocation3.setText(null);
		}

		try {
			String[] arr = app.fixLocation(locationCode).split("-");
			String r = arr[0];
			String p = arr[1];
			String t = arr[2];
			textLocation1.setText(r);
			textLocation2.setText(p);
			textLocation3.setText(t);
		} catch (Exception ignored) {

		}
	}

	private void refreshLeft() {
		int weightToShip = Utils.parseInt(textWeight.getText().toString());
		textWeightToShip.setText(Utils.format("%d", weightToShip));
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		textWeightToShip.requestFocus();
		beginLoad();
	}

	@Override
	public void onBackPressed() {
		setResult(RESULT_OK);
		super.onBackPressed();
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 2) buttonAcceptClick();
	}

	private void beginPrint() {

		showLoading(R.string.text_printing_title);

		Utils.runOnBackground(() -> {
			Utils.NetworkPrintResult result = Utils.printLabel(listLabelId, smcIdSoh);
			runOnUiThread(() -> endPrint(result));
		});

	}

	private void endPrint(Utils.NetworkPrintResult result) {

		hideLoading();
		if (result == null || result.getNetworkResult() == null) return;

		if (result.getNetworkResult().isOk()) {
			if (result.getPrintResult().getStatus() == Printer.PrintResultStatus.OK) {
				showToast(R.string.text_print_result_succeeded);
		//		app.sendFaPrint();
				onBackPressed();
			} else {
				@StringRes final int message = app.getPrintResultMessage(result.getPrintResult());
				showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> beginPrint());
			}
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result.getNetworkResult()), (dialog, which) -> beginPrint());
		}

	}

	private void buttonAcceptClick() {
		if (isLoading() || !buttonAccept.isEnabled()) return;
		if (listLabelId == null) beginAccept();
		else beginPrint();
	}

	private void beginLoad() {

		refreshInfo();

        /*showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {

            shipmentItem = null;

            NetworkResult result = app.loadShipmentOrders(date, transportName);

            if (result.isOk()) {
                document = db.shipmentDocumentDao().getByName(documentNumber, transportName);
                result = app.loadShipmentOrderDetails(date, documentNumber);
                if (result.isOk()) {
                    shipmentItem = db.shipmentItemDao().getByLineId(documentNumber, planLineId);
                }
            }

            NetworkResult finalResult = result;
            runOnUiThread(() -> endLoad(finalResult));

        });*/

	}

    /*private void endLoad(NetworkResult result) {
        hideLoading();

        if (result.isOk()) {
            refreshInfo();
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
        }

    }*/

	private void refreshInfo() {

        /*if (document.getStatus() >= 1) {
            AlertDialog dialog = showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.cant_edit_closed_ship, null);
            dialog.setOnDismissListener(dialog1 -> ShipReverseActivity.this.finish());
            return;
        }*/

		textWeightTotal.setText(String.valueOf(fact));

		StringBuilder sb = new StringBuilder();
        /*sb.append(Utils.format("%s | <b>%s</b><br>", shipmentItem.getPositionId(), shipmentItem.getSapMattDescr()));
        sb.append(Utils.format("%s<br>", app.sizeToString(shipmentItem.getWidth(), shipmentItem.getLength(), shipmentItem.getThickness())));
        sb.append(Utils.format("ОЗМ: %s<br>", shipmentItem.getSapOzm()));
        sb.append(Utils.format("Вже відвантажено, кг.: <b>%s</b>", shipmentItem.getSapWeightNettFact()));*/

		textWeight.setText(String.valueOf(fact));
		textWeight.selectAll();

		textContent.setText(app.fromHtml(sb.toString()));

		textWeight.requestFocus();
	}

	private void beginAccept() {

		int weightToShip = Utils.parseInt(textWeight.getText().toString());

		if (weightToShip <= 0 || weightToShip > fact) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.incorrect_weight,
					(dialog, which) -> textWeight.post(textWeight::requestFocus));
			return;
		}

		String locationCode = Utils.format("%s-%s-%s",
				textLocation1.getText().toString(),
				textLocation2.getText().toString(),
				textLocation3.getText().toString());

		if (!app.isLocationCorrect(locationCode)) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.text_error_location_incorrect, null);
			textLocation1.post(textLocation1::requestFocus);
			return;
		}

		showLoading(R.string.text_please_wait);
		buttonAccept.setEnabled(false);
		listLabelId = null;

		Utils.runOnBackground(() -> {

			String url;

			if (lineId == 0) {
				url = config.getUrlApi() + "editsapshipmentitem";
				//url = net.addUrlParam(url, "Plan_line_id", String.valueOf(planLineId));
				url = net.addUrlParam(url, "weight_nett", String.valueOf(weightToShip));
				url = net.addUrlParam(url, "location", app.fixLocation(locationCode));
				url = net.addUrlParam(url, "Id_doc", documentNumber);
				url = net.addUrlParam(url, "Id_pos", idPos);
				url = net.addUrlParam(url, "Car", transportName);
				url = net.addUrlParam(url, "date_vo", app.getDateFormat().format(dateVo));
				if (smcIdSoh != null && smcIdSoh != "")
					url = net.addUrlParam(url, "smc_id", smcIdSoh);
			} else {
				if (labelSohId == 0)
					url = config.getUrlApi() + "editsapshipmentitem2";
				else
					url = config.getUrlApi() + "editsapshipmentitemsoh";
				url = net.addUrlParam(url, "line_Id", String.valueOf(lineId));
				url = net.addUrlParam(url, "label_Id", String.valueOf(idQr));
				url = net.addUrlParam(url, "weight_nett", String.valueOf(weightToShip));
				url = net.addUrlParam(url, "location", app.fixLocation(locationCode));
				if (smcIdSoh != null && smcIdSoh != "")
					url = net.addUrlParam(url, "smc_id", smcIdSoh);
			}

			JsonResult result = net.downloadJson(url);
			runOnUiThread(() -> endAccept(result));
		});
	}

	private void endAccept(JsonResult result) {

		hideLoading();
		buttonAccept.setEnabled(true);

		if (result.isOk()) {

			Toast.makeText(this, R.string.ship_reverse_ok, Toast.LENGTH_SHORT).show();

			if (lineId > 0) {

				listLabelId = new ArrayList<>();
				listLabelId.add(idQr);
				buttonAccept.setText(R.string.button_print);
				beginPrint();

			} else {

				JSONArray jsonArray = Utils.getJsonArray(result.getJson(), "data");

				if (jsonArray != null && jsonArray.length() > 0) {
					listLabelId = new ArrayList<>();
					for (int i = 0; i < jsonArray.length(); i++) {
						int value = Utils.getJsonInt(jsonArray, i);
						if (value != 0) {
							listLabelId.add(String.valueOf(value));
						}
					}

					buttonAccept.setText(R.string.button_print);
					beginPrint();
				} else {
					showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginAccept());
				}
			}
		} else if (result.getStatus() == LoadResultStatus.ZERO) {
			if (lineId > 0) {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.label_in_archive,
						(dialog, which) -> textWeight.post(textWeight::requestFocus));
			} else {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.incorrect_weight,
						(dialog, which) -> textWeight.post(textWeight::requestFocus));
			}
		} else if (result.getStatus() == LoadResultStatus.S009){
			Toast.makeText(this, R.string.s009_error, Toast.LENGTH_LONG).show();
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginAccept());
		}
	}
}
