package com.metinvest.smc.inc;

import static com.metinvest.smc.R.color;
import static com.metinvest.smc.R.id;
import static com.metinvest.smc.R.layout;

import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.core.content.ContextCompat;

import com.metinvest.smc.App;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemDoc extends AbstractFlexibleItem<AdapterItemDoc.DocViewHolder> {

	private final TransportDoc doc;
	private final App app;
	private final boolean isManager;
	private @ColorInt int backgroundColor;

	public AdapterItemDoc(TransportDoc doc, boolean isManager) {
		this.app = App.getInstance();
		this.doc = doc;
		this.backgroundColor = -1;
		this.isManager = isManager;
	}

	public void setBackgroundColor(@ColorInt int backgroundColor) {
		this.backgroundColor = backgroundColor;
    }

    public TransportDoc getDoc() {
        return doc;
    }

    @Override
    public boolean equals(Object o) {
		//return o instanceof AdapterItemDoc && ((AdapterItemDoc) o).getDoc().getTtn().equals(getDoc().getTtn());
		return o instanceof AdapterItemDoc && ((AdapterItemDoc) o).getDoc().equals(getDoc());
	}

    @Override
    public int hashCode() {
        return getDoc().hashCode();
    }

    @Override
    public int getLayoutRes() {
		return layout.adapter_inc_document;
    }

    @Override
    public DocViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new DocViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, DocViewHolder holder, int position, List<Object> payloads) {
		String title = Utils.format("<b>%s</b>", Html.escapeHtml(doc.getTransport().getName()));

		StringBuilder sb = new StringBuilder();
		sb.append(Utils.format("План, тн: %.3f<br>", doc.getTotalWeightPlan() / 1000.0f));
		sb.append(Utils.format("Факт, тн: %s %s<br>", Utils.factToString(doc.getTotalWeightFact()), doc.getTotalWeightPercentString()));
		if (doc.getTotalWeightFactTemp() > 0) {
			sb.append(Utils.format("<font color=\"red\">з них тимчасових, тн: %.3f</font><br>", doc.getTotalWeightFactTemp() / 1000.0f));
		}
		sb.append(Utils.format("ТТН: %s %s<br>", doc.getTtn().getNum(), doc.getTransport().getDate() == null ? "" : app.getDateFormat().format(doc.getTransport().getDate())));
		sb.append(Utils.format("%s<br>", doc.getStatusString()));
		sb.append(Utils.format("Склад: %s<br>", app.getConfig().getStorage()==null?doc.getStorage():app.getConfig().getStorage()));

		String content = sb.toString();
		if (content.endsWith("<br>")) content = content.substring(0, content.length() - 4);

		holder.textTitle.setText(app.fromHtml(title));
		holder.textContent.setText(app.fromHtml(content));
		holder.imageView.setImageResource(Utils.getStatusDrawable(getDoc().getStatus()));

		View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
		holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
		refreshBackground(holder, holder.itemView.isFocused());
	}

    private void refreshBackground(DocViewHolder holder, boolean hasFocus) {
        if (backgroundColor == -1) {
			holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? color.color_yellow : color.color_adapter_light));
        } else {
            holder.itemView.setBackgroundColor(backgroundColor);
        }
    }

	static class DocViewHolder extends FlexibleViewHolder {

		@BindView(id.textTitle)
		TextView textTitle;
		@BindView(id.textContent)
		TextView textContent;
		@BindView(id.imageView)
		ImageView imageView;

		DocViewHolder(View view, FlexibleAdapter adapter) {
			super(view, adapter);
			ButterKnife.bind(this, view);
		}
	}
}
