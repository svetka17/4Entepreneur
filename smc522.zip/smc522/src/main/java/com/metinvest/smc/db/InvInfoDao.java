package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface InvInfoDao {
    @Query("SELECT * FROM invinfo")
    List<InvInfo> getAll();

    @Query("SELECT * FROM invinfo WHERE id = :id")
    InvInfo getById(long id);

    @Query("SELECT count(1) FROM invinfo")
    long getCount();

    @Insert
    long insert(InvInfo invinfo);

    @Update
    void update(InvInfo invinfo);

    @Delete
    void delete(InvInfo invinfo);

    @Query("DELETE FROM invinfo")
    void truncate();
}