package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

import com.metinvest.smc.R;
import com.metinvest.smc.tools.Utils;

import butterknife.BindView;
import butterknife.ButterKnife;

public class InventoryWeightActivity extends MyActivity {

    @BindView(R.id.textWeightBrutto)
    EditText textWeightBrutto;
    @BindView(R.id.textWeightPack)
    EditText textWeightPack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_weight);
        ButterKnife.bind(this);

        textWeightBrutto.setText(String.valueOf(getIntent().getIntExtra("WeightBrutto", 0)));
        textWeightPack.setText(String.valueOf(getIntent().getIntExtra("WeightPack", 0)));
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    private void buttonAcceptClick() {
        Intent data = new Intent();
        data.putExtra("WeightBrutto", Utils.parseInt(textWeightBrutto.getText().toString()));
        data.putExtra("WeightPack", Utils.parseInt(textWeightPack.getText().toString()));
        setResult(RESULT_OK, data);
        finish();
    }
}
