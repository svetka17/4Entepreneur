package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;

import com.phearme.macaddressedittext.MacAddressEditText;
import com.metinvest.smc.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PrinterManualActivity extends MyActivity {

    @BindView(R.id.textMac)
    MacAddressEditText textMac;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_printer_manual);
        ButterKnife.bind(this);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) textMac.requestFocus();
        else if (number == 5) buttonAcceptClick();
    }

    private void buttonAcceptClick() {

        if (textMac.getText() == null || textMac.getText().length() == 0) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, "Будь-ласка заповніть MAC-адресу!", (dialog, which) -> textMac.requestFocus());
            return;
        }

        Intent intent = new Intent();
        intent.putExtra("mac", textMac.getText().toString());
        setResult(RESULT_OK, intent);
        finish();

    }
}
