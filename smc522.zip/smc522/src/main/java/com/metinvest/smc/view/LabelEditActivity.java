package com.metinvest.smc.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.LabelEditItem;
import com.metinvest.smc.tools.Utils;

import java.util.Calendar;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LabelEditActivity extends MyActivity {

    private String labelId;
    private String name, batch, lowPricePercent;
    private int netto;
	private int pack;
	private boolean release;

    @BindView(R.id.textContent)
    TextView textContent;
    @BindView(R.id.textWeightNetto)
    EditText textWeightNetto;
    @BindView(R.id.textWeightPack)
    EditText textWeightPack;
    @BindView(R.id.textBatch)
    EditText textBatch;
	@BindView(R.id.textLowPricePercent)
	EditText textLowPricePercent;
	@BindView(R.id.textActDate)
	EditText textActDate;
	@BindView(R.id.textActNumber)
	EditText textActNumber;
	@BindView(R.id.buttonAccept)
	Button buttonAccept;
	@BindView(R.id.viewDates)
	View viewDates;
	@BindView(R.id.checkRelease)
	CheckBox checkRelease;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_label_edit);
		ButterKnife.bind(this);

		labelId = getIntent().getStringExtra("labelId");
		name = getIntent().getStringExtra("name");
		netto = getIntent().getIntExtra("netto", 0);
        pack = getIntent().getIntExtra("pack", 0);
        batch = getIntent().getStringExtra("batch");
		lowPricePercent = getIntent().getStringExtra("lowPricePercent");
		release = getIntent().getBooleanExtra("release", false);

        textWeightNetto.setText(String.valueOf(netto));
        textWeightPack.setText(String.valueOf(pack));
        textBatch.setText(batch);
		textLowPricePercent.setText(lowPricePercent);
		checkRelease.setChecked(release);

        textActDate.setText(app.getDateFormat().format(Calendar.getInstance().getTime()));

        textContent.setText(app.fromHtml(Utils.format("<b>%s</b>", name)));
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        if (textActDate.getText().length() == 0) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.warning_date_act_empty, (dialog, which) -> textActDate.requestFocus());
            return;
        }

        if (textActNumber.getText().length() == 0) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.warning_date_act_num, (dialog, which) -> textActNumber.requestFocus());
            return;
        }

        beginAccept();
    }

    private void beginAccept() {

        showLoading(R.string.text_please_wait);
        int nettoNew = Utils.parseInt(textWeightNetto.getText().toString());
        int packNew = Utils.parseInt(textWeightPack.getText().toString());
        String batchNew = textBatch.getText().toString();
		String lowPricePercentNew = textLowPricePercent.getText().toString();
		boolean releaseNew = checkRelease.isChecked();

        Utils.runOnBackground(() -> {
			JsonResult result = app.editLabelWeight(
					new LabelEditItem(labelId, App.getInstance().getSmcIdCurrent(), nettoNew, packNew, batchNew, lowPricePercentNew, releaseNew),
					app.parseDfDate(textActDate.getText().toString()),
					textActNumber.getText().toString()
			);
            runOnUiThread(() -> endAccept(result));
        });
    }

	private void endAccept(JsonResult result) {

		hideLoading();
		buttonAccept.setEnabled(true);

		if (result.isOk()) {
			Toast.makeText(this, R.string.successful_accepted, Toast.LENGTH_SHORT).show();
			setResult(RESULT_OK);
			finish();
		} else if (result.getStatus() == LoadResultStatus.PLUS2) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.set_label_weight_error_plus2, null);
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginAccept());
		}
    }
}

