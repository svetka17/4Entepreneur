package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface CarrierDao {
    @Query("SELECT * FROM carrier ORDER BY name")
    List<Carrier> getAll();

    @Query("SELECT * FROM carrier WHERE id = :id")
    Carrier getById(long id);

    @Query("SELECT * FROM carrier WHERE name = :name")
    Carrier getByName(String name);

    @Query("SELECT * FROM carrier WHERE lower(name) LIKE lower(:name)")
    List<Carrier> getByNameLike(String name);

    @Insert
    long insert(Carrier carrier);

    @Insert
    void insertAll(List<Carrier> carrier);

    @Update
    void update(Carrier carrier);

    @Delete
    void delete(Carrier carrier);

    @Query("DELETE FROM carrier")
    void truncate();
}