package com.metinvest.smc.ui;

import android.view.View;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.db.Printed;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterOut extends AbstractFlexibleItem<AdapterOut.PlaceAdapterViewHolder> {

    private final OnTheWay way;
    private final Printed printed;

    public AdapterOut(Printed printed, OnTheWay way) {
        this.printed = printed;
        this.way = way;
    }

    public Printed getPrinted() {
        return printed;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterOut && ((AdapterOut) o).getPrinted().getId() == getPrinted().getId();
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_out;
    }

    @Override
    public PlaceAdapterViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new PlaceAdapterViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, PlaceAdapterViewHolder holder, int position, List<Object> payloads) {

        StringBuilder sb = new StringBuilder();

        //sb.append(Utils.format("<b><font color=\"#34326D\">Позиція №%s</font></b><br>", i + 1));
        sb.append(Utils.format("LabelId: %d<br>", printed.getId()));
        sb.append(Utils.format("Призначена вага: <font color=\"#34326D\">%s кг.</font><br>", printed.getWeightNetto()));
        sb.append(Utils.format("Упаковка/тара: %s/%s кг.<br>", printed.getWeightPack(), printed.getWeightTara()));
        sb.append(Utils.format("Партія: %s<br>", printed.isTemporary() ? "-" : way.getSapBatch()));
        sb.append(Utils.format("Склад: %s<br>", way.getStorage()));
        sb.append(Utils.format("Локація: %s", App.getInstance().fixLocation(printed.getLocation())));

        holder.textTitle.setText(App.getInstance().fromHtml(sb.toString()));

        View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
        holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
        refreshBackground(holder, holder.itemView.isFocused());

        holder.buttonEdit.setVisibility(View.GONE);
    }

    private void refreshBackground(PlaceAdapterViewHolder holder, boolean hasFocus) {
        holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_background));
    }

    static class PlaceAdapterViewHolder extends FlexibleViewHolder {

        private final TextView textTitle;
        private final View buttonEdit;

        PlaceAdapterViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.textTitle = view.findViewById(R.id.textTitle);
            this.buttonEdit = view.findViewById(R.id.buttonEdit);
        }
    }
}
