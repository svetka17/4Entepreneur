package com.metinvest.smc.tools;

import com.metinvest.smc.App;
import com.metinvest.smc.BuildConfig;
import com.metinvest.smc.db.ShipmentDocument;
import com.metinvest.smc.db.ShipmentItem;
import com.metinvest.smc.db.ShipmentItemLoc;

import java.util.Calendar;
import java.util.Collections;
import java.util.List;

public class LabelGeneratorCardSaveDpl {
    private final List<ShipmentDocument> documentList;
    private final App app;
    private StringBuilder printedData;
    private int printedY;
    private int printedPage;
    private int printedPageCount;
    private final int maxY = 1460;
    private final int lineHeight = 40;
    private String transportName;

    public LabelGeneratorCardSaveDpl(List<ShipmentDocument> documentList) {
        this.documentList = documentList;
        this.app = App.getInstance();
        this.transportName = documentList.get(0).getTransportName();
    }

    public String generateDpl() {

        long t1 = Calendar.getInstance().getTime().getTime();

        printedData = new StringBuilder();
        printedY = 0;
        printedPage = 0;
        printedPageCount = 0;

        processItems();

        long t2 = Calendar.getInstance().getTime().getTime();

        app.log(this, "TIME FOR GENERATE DPL: %d ms", t2 - t1);

        return printedData.toString();

    }

    private void addHeader() {
        printedPage++;
        printedPageCount++;

        addY(lineHeight);
        addY(lineHeight);
        printedData.append(Utils.format("3911S53%04d0980P010P010Транспорт: %s\n", printedY, transportName));
        printedData.append(Utils.format("3911S53%04d0250P010P010Лист %d з {{PAGE_COUNT}}\n", printedY, printedPage));

        addY(lineHeight);

    }

    private void addY(int value) {
        printedY += value;

        if (value > 0 && printedY > maxY) {
            addNewPage();
        }
    }

    private void addNewPage() {
        printedData.append("Q0001 \n E \n");
        if (BuildConfig.DEBUG) {
            printedData.append("\u0002m\n\u0002L\nD11\nPC\nySU8\n");
        } else {
            printedData.append("\u0002m\n\u0002L\nD11\nPA\nySU8\n");
        }

        printedY = 0;
        addHeader();
    }

    private void processItems() {

        printedData.append("\u0002m\n\u0002L\nD11\nPC\nySU8\n");

        addHeader();

        for (int i = 0; i < documentList.size(); i++ ) {
            ShipmentDocument document = documentList.get(i);
            addY(lineHeight);
            printedData.append(Utils.format("3911S53%04d0980P010P011Наряд на відгрузку №: %s\n", printedY, document.getDocNumber()));
            addY(lineHeight);
            addY(lineHeight);
            for (int j = 0; j < document.schipmentItems.size(); j++){
                ShipmentItem item = document.schipmentItems.get(j);
                printedData.append(Utils.format("3911S53%04d0980P010P011%s\n", printedY, item.getName()));
                addY(lineHeight);

                String ozm = "";//item.getSapOzm();
                String size = app.sizeToString(item.getLength(), item.getWidth(), item.getThickness());
                String plan = Utils.format(" План: %.3f тн", item.getSapWeightNett() / 1000.0f);

                printedData.append(Utils.format("3911S53%04d0980P010P011%s%s%s\n", printedY, size, ozm.length()>0 ? " ОЗМ: " + ozm : "", plan));
                addY(lineHeight);

                Locations(item.shipmentItemLoc);
            }
        }

        addY(40);

        printedData.append("Q0001\n E\n");

        Utils.replaceAll(printedData, "{{PAGE_COUNT}}", String.valueOf(printedPageCount));
    }

    public String generateTitle() {
        return Utils.format("<b>Карта зберігання</b><br>Номер машини: %s", transportName);
    }

    private void Locations(List<ShipmentItemLoc> shipmentItemLoc) {
        if(shipmentItemLoc == null || shipmentItemLoc.size() == 0){
            printedData.append(Utils.format("3911S53%04d0915P010P011Відсутній на складі\n",printedY));
            addY(lineHeight);
        }else{
            Collections.sort(shipmentItemLoc, (o1, o2) -> Utils.compareLocations(o1.getLocation(), o2.getLocation()));
            for (int i = 0; i < shipmentItemLoc.size(); i++ ) {
                ShipmentItemLoc loc2 = null;
                ShipmentItemLoc loc1 = shipmentItemLoc.get(i);
                if(i + 1 < shipmentItemLoc.size())
                    loc2 = shipmentItemLoc.get(++i);
                String locText1 = Utils.format("%s %.3f тн", loc1.getLocation(), loc1.getSumWeight() / 1000.0f);
                String locText2 = loc2 != null ? Utils.format("\t\t\t\t%s %.3f тн", loc2.getLocation(), loc2.getSumWeight() / 1000.0f) : "";
                printedData.append(Utils.format("3911S53%04d0915P010P011%s%s\n", printedY,locText1, locText2));
                addY(lineHeight);
            }
        }
    }

}
