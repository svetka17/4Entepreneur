package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterItemShipment;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class ShipmentViewActivity extends MyActivity implements IScan, AdapterItemShipment.IItemAction {

	@BindView(R.id.textContentTitle)
	TextView textContentTitle;
	@BindView(R.id.listView)
	RecyclerView listView;
	@BindView(R.id.scrollView)
	NestedScrollView scrollView;
	@BindView(R.id.buttonPrint)
	Button buttonPrint;

	@BindView(R.id.textLabelId)
	EditText textLabelId;
	@BindView(R.id.buttonAcceptLabel)
	ImageButton buttonAcceptLabel;

	private FlexibleAdapter<AdapterItemShipment> adapter;

	private String number, product, car;
	private JSONObject json;
	private JSONArray labels;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_shipment_view);
		ButterKnife.bind(this);

		number = getIntent().getStringExtra("number");

		listView = findViewById(R.id.listView);
		LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
		DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
		listView.setLayoutManager(layoutManager);
		listView.addItemDecoration(dividerItemDecoration);
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		beginLoad(getIntent().getStringExtra("json"));
	}

	@Override
	public void onBarcodeEvent(String barcodeData) {

		if (isLoading()) return;

		runOnUiThread(() -> {

			textLabelId.setText(null);

			ScanItem scanItem = new ScanItem(barcodeData);

			if (scanItem.getType() == ScanItem.ScanItemType.LABELID) {
				if (scanItem.isCorrect()) {
					textLabelId.setText(scanItem.getData(0));
					beginAdd(scanItem.getData(0));
				} else {
					showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_label, null);
					return;
				}
			}

			if (scanItem.getType() == ScanItem.ScanItemType.SMC06) {

				if (scanItem.isCorrect()) {
					textLabelId.setText(scanItem.getData(0));
					beginAdd(scanItem.getData(0));
				} else {
					showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_label, null);
					return;
				}

			}

		});
	}

	private void beginAdd(String labelId) {
		showLoading(R.string.text_please_wait);

		String url = config.getUrlApi() + "getlabelinfo";
		url = net.addUrlParam(url, "label_id", labelId);
		reqGet(url, result -> endLoadLabel(labelId, result));
	}

	private void endLoadLabel(String labelId, JsonResult result) {

		hideLoading();

		if (result.isOk()) {

			Label label = Label.fromJson(Utils.getJsonObject(result.getJson(), "data"));

			if (label != null) {

				if (label.isTheor()) {
					Intent intent = new Intent(this, ShipmentLabelListActivity.class);
					intent.putExtra("labelId", labelId);
					intent.putExtra("netto", label.getWeightNetto());
					intent.putExtra("ozm", label.getOzm());
					intent.putExtra("length", label.getLength());
					intent.putExtra("width", label.getWidth());
					intent.putExtra("thickness", label.getThickness());
					intent.putExtra("locationId", String.valueOf(label.getLocationId()));
					startActivityForResult(intent, REQUEST_ACTION);
				} else {
					Intent intent = new Intent(this, ShipmentAddActivity.class);
					intent.putExtra("number", number);
					intent.putExtra("labelId", labelId);
					intent.putExtra("netto", label.getWeightNetto());
					startActivityForResult(intent, REQUEST_ADD);
				}
			}
		} else if (result.getStatus() == LoadResultStatus.ZERO) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_id_not_found, null);
		} else if (result.getStatus() == LoadResultStatus.S007) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_s007, null);
		} else {
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginAdd(labelId));
		}
	}

	private void viewLabel(String labelId) {
		showInfoByLabelId(labelId);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
		if (requestCode == REQUEST_ADD) {
			if (resultCode == RESULT_OK && data != null) {
				boolean zero = data.getBooleanExtra("zero", false);
				if (!zero) viewLabel(data.getStringExtra("labelId"));
				beginLoadData();
			}
		}

		if (requestCode == REQUEST_ACTION && resultCode == RESULT_OK && data != null) {
			int netto = data.getIntExtra("netto", 0);
			String id = data.getStringExtra("labelId");
			Intent intent = new Intent(this, ShipmentAddActivity.class);
			intent.putExtra("number", number);
			intent.putExtra("labelId", id);
			intent.putExtra("netto", netto);
			startActivityForResult(intent, REQUEST_ADD);
		}

		super.onActivityResult(requestCode, resultCode, data);
	}

	private void beginLoadData() {
		String url = config.getUrlApi() + "shipmentinfo";
		url = net.addUrlParam(url, "shipment_number", number);
		reqGet(url, result -> runOnUiThread(() -> endLoadData(result)));
	}

	private void endLoadData(JsonResult result) {
		if (result.isOk()) {
			beginLoad(Utils.jsonToString(result.getJson()));
		} else {
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoadData());
		}
	}

	private void beginLoad(String newJson) {

		json = Utils.getJsonObject(Utils.getJsonObject(newJson), "data");
		product = Utils.getJsonStringIgnoreCase(json, "product");
		car = Utils.getJsonStringIgnoreCase(json, "car_Number");

		textContentTitle.setText(Utils.format("Відвантаження №%s%nНомер машини: %s", number, car));

		labels = Utils.getJsonArray(json, "item_List");

		List<AdapterItemShipment> items = new ArrayList<>();
		for (int i = 0; i < (labels == null ? 0 : labels.length()); i++) {
			items.add(new AdapterItemShipment(Utils.getJsonObject(labels, i), this));
		}
		showList(items);
	}

	private void showList(List<AdapterItemShipment> items) {
		adapter = new FlexibleAdapter<>(items);
		listView.setAdapter(adapter);
		scrollView.post(() -> scrollView.scrollTo(0, 0));
		//textNotFound.setVisibility(adapter.getItemCount() > 0 ? View.GONE : View.VISIBLE);
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 2) {
			String labelId = textLabelId.getText().toString();
			if (labelId.length() > 0) beginAdd(labelId);
		} else if (number == 5) buttonPrintClick();
	}

	private void buttonPrintClick() {
		if (isLoading() || !buttonPrint.isEnabled()) return;

		if (labels == null || labels.length() == 0) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, "Спочатку додайте позиції на відвантаження!", null);
			return;
		}

		showLoading(R.string.text_printing_title);
		buttonPrint.setEnabled(false);

		Utils.runOnBackground(this::beginPrint);
	}

	@Override
	protected void onStop() {
		super.onStop();
		setResult(RESULT_OK);
	}

	public void beginPrint() {

		String data = app.generateDplShipment(number, product, car, labels);

		String name = Utils.format("<b>Відвантаження</b><br>Номер наряду: %s<br>Номер машини: %s<br>Кількість позицій: %s", number, car, labels.length());

		final Printer.PrintResult result = Printer.sendCommand(name, config.getPrinter(), data);

		runOnUiThread(() -> endPrint(result));
	}

	private void endPrint(Printer.PrintResult result) {
		buttonPrint.setEnabled(true);
		hideLoading();

		if (result.getStatus() == Printer.PrintResultStatus.OK) {
			//showDialogRetry(R.drawable.ic_info_24dp, R.string.text_information, R.string.text_print_result_succeeded, (dialog, which) -> buttonPrintClick());
			showToast(R.string.text_print_result_succeeded);
			int pageCount = (int) Math.ceil((double) labels.length() / 4.0);
			//app.sendFaPrint(pageCount);
		} else {
			@StringRes final int message = app.getPrintResultMessage(result);
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> buttonPrintClick());
		}
	}

	@Override
	public void OnDeleteClick(int position) {
		JSONObject item = Utils.getJsonObject(labels, position);
		if (item != null) {
			String id = Utils.getJsonStringIgnoreCase(item, "itemId");
			String labelId = Utils.getJsonStringIgnoreCase(item, "labelId");
			showDialogConfirm(R.string.text_confirm, R.string.delete_position_confirm, (dialog, which) -> {
				beginDelete(id, labelId);
			});
		}
	}

	private void beginDelete(String id, String labelId) {
		if (isLoading()) return;
		showLoading(R.string.text_please_wait);

		String url = config.getUrlApi() + "deleteshipmentitem";
		url = net.addUrlParam(url, "item_id", id);
		reqGet(url, result -> endDelete(id, labelId, result));
	}

	private void endDelete(String id, String labelId, JsonResult result) {

		hideLoading();

		if (result.isOk()) {
			beginLoadData();
			viewLabel(labelId);
		} else {
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginDelete(id, labelId));
		}
	}
}
