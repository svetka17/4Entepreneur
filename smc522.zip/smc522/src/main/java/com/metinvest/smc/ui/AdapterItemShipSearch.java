package com.metinvest.smc.ui;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemShipSearch extends AbstractFlexibleItem<AdapterItemShipSearch.AdapterItemShipSearchViewHolder> {

    private final boolean isTransport;
    private final long id;
    private final String title, content;
    private final int status;

    public AdapterItemShipSearch(boolean isTransport, long id, String title, String content, int status) {
        this.isTransport = isTransport;
        this.id = id;
        this.title = title;
        this.content = content;
        this.status = status;
    }

    public boolean isTransport() {
        return isTransport;
    }

    public long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public int getStatus() {
        return status;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterItemShipSearch && ((AdapterItemShipSearch) o).getId() == getId() && ((AdapterItemShipSearch) o).isTransport() == isTransport();
    }

    @Override
    public AdapterItemShipSearchViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new AdapterItemShipSearchViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemShipSearchViewHolder holder, int position, List<Object> payloads) {

        holder.textTitle.setVisibility(isTransport() ? View.VISIBLE : View.GONE);
        holder.textTitle2.setVisibility(!isTransport() ? View.VISIBLE : View.GONE);
        holder.textTitle.setText(getTitle());
        holder.textTitle2.setText(getTitle());

        holder.textContent.setText(App.getInstance().fromHtml(getContent()));

        holder.imageView.setImageResource(Utils.shipStatusToImage(getStatus()));

        View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
        holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
        refreshBackground(holder, holder.itemView.isFocused());
    }

    private void refreshBackground(AdapterItemShipSearchViewHolder holder, boolean hasFocus) {
        holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.imageView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_background));
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_ship_search;
    }

    /**
     * The ViewHolder used by this item.
     * Extending from FlexibleViewHolder is recommended especially when you will use
     * more advanced features.
     */
    class AdapterItemShipSearchViewHolder extends FlexibleViewHolder {

        private TextView textTitle, textTitle2, textContent;
        private ImageView imageView;

        AdapterItemShipSearchViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.textTitle = view.findViewById(R.id.textTitle);
            this.textTitle2 = view.findViewById(R.id.textTitle2);
            this.textContent = view.findViewById(R.id.textContent);
            this.imageView = view.findViewById(R.id.imageView);
        }
    }
}
