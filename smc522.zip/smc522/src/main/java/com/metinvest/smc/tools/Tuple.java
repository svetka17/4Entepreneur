package com.metinvest.smc.tools;

import androidx.annotation.NonNull;

public class Tuple<X, Y> {
	public final X x;
	public final Y y;

	public Tuple(X x, Y y) {
		this.x = x;
		this.y = y;
	}

	@NonNull
	@Override
	public String toString() {
		return Utils.format("\"%s\":\"%s\"", x, y);
	}
}