package com.metinvest.smc.view;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class IncActivity extends MyActivity {

    @BindView(R.id.buttonDateFrom)
    Button buttonDateFrom;
    @BindView(R.id.buttonDateTo)
    Button buttonDateTo;

    private Date dateFrom, dateTo;
	private int subSmcCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inc);
        ButterKnife.bind(this);

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -14);
        dateFrom = calendar.getTime();

        calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, 14);
        dateTo = calendar.getTime();

        /*if (BuildConfig.DEBUG) {
            Calendar calendar = Calendar.getInstance();
            calendar.set(2019, 9 - 1, 5);
            dateFrom = calendar.getTime();
        }*/

        subSmcCount = getSubSmcCount();
        refreshButtons();
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) buttonDateFromClick();
        else if (number == 3) buttonDateToClick();
        else if (number == 5) buttonSohClick();
        else if (number == 6) buttonAcceptClick();
    }

    private void refreshButtons() {
        buttonDateFrom.setText(app.getDateFormat().format(dateFrom));
        buttonDateTo.setText(app.getDateFormat().format(dateTo));
    }

    private void buttonDateFromClick() {
        Calendar calendar = Utils.toCalendar(dateFrom);

        DatePickerDialog dialog = new DatePickerDialog(this,
                (view1, year, month, dayOfMonth) -> {
                    Calendar calendar1 = Calendar.getInstance();
                    calendar1.set(year, month, dayOfMonth);
                    dateFrom = calendar1.getTime();
                    refreshButtons();
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DATE));
        dialog.show();
    }

    private void buttonDateToClick() {
        Calendar calendar = Utils.toCalendar(dateTo);

        DatePickerDialog dialog = new DatePickerDialog(this,
                (view1, year, month, dayOfMonth) -> {
                    Calendar calendar1 = Calendar.getInstance();
                    calendar1.set(year, month, dayOfMonth);
                    dateTo = calendar1.getTime();
                    refreshButtons();
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DATE));
        dialog.show();
    }

    private List<String> getSubSmcList() {
        List<String> res = new ArrayList<>();
        JSONArray jsonArray = Utils.getJsonArray(config.getSmcListJson());
        for (int i = 0; jsonArray != null && i < jsonArray.length(); i++) {
            JSONObject jsonObject = Utils.getJsonObject(jsonArray, i);
            int parent = Utils.getJsonIntIgnoreCase(jsonObject, "parent");
            String smcId = Utils.getJsonStringIgnoreCase(jsonObject, "smcid");
            if (parent > 0) res.add(smcId);
        }
        return res;
    }

    private int getSubSmcCount() {
        return getSubSmcList().size();
    }

    private void buttonSohClick() {
        if (getSubSmcCount() == 0) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, "Немає складів СОХ!", null);
            return;
        }

        Intent intent = new Intent(this, SubSmcSelectActivity.class);
        startActivityForResult(intent, REQUEST_ACTION);
    }

    private void buttonAcceptClick() {
        goNext(null);
    }

    private void goNext(String sohSmcId) {
        Intent intent = new Intent(this, IncTransportListActivity.class);
        intent.putExtra("dateFrom", dateFrom);
        intent.putExtra("dateTo", dateTo);
        intent.putExtra("isNew", getIntent().getBooleanExtra("isNew", false));
        intent.putExtra("sohSmcId", sohSmcId);
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ACTION && resultCode == RESULT_OK && data != null) {
            String smcId = data.getStringExtra("smc_id");
            log("COX SMC_ID: %s", smcId);
            goNext(smcId);
        }
    }
}
