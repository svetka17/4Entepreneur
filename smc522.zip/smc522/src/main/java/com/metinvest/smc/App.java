package com.metinvest.smc;

//import static com.metinvest.smc.view.MyActivity.REQUEST_LOGIN;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.bluetooth.BluetoothAdapter;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.BatteryManager;
import android.os.Build;
import android.provider.Settings;
import android.text.Html;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.room.Room;

import com.metinvest.smc.db.Db;
import com.metinvest.smc.db.ShipmentDocument;
import com.metinvest.smc.db.ShipmentItem;
import com.metinvest.smc.db.ShipmentItemLoc;
import com.metinvest.smc.db.ShipmentTransport;
import com.metinvest.smc.inc.Order;
import com.metinvest.smc.inc.SohFilter;
import com.metinvest.smc.inc.TTN;
import com.metinvest.smc.inc.Transport;
import com.metinvest.smc.inc.TransportDoc;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.scanner.BarcodeHoneywell;
import com.metinvest.smc.scanner.BarcodeSunmi;
import com.metinvest.smc.scanner.BarcodeUnitech;
import com.metinvest.smc.scanner.BarcodeZebra;
import com.metinvest.smc.tools.INfc;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.LabelEditItem;
import com.metinvest.smc.tools.NFC;
import com.metinvest.smc.tools.PrintLabelConfig;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.PrinterType;
import com.metinvest.smc.tools.Scales;
import com.metinvest.smc.tools.Tuple;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.ImageGetterTag;
import com.metinvest.smc.view.MainActivity;
import com.metinvest.smc.view.MyActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class App extends Application implements IScan, INfc {

	protected static App instance;
	private Network network;
	private BarcodeHoneywell barcodeHoneywell;
	private BarcodeZebra barcodeZebra;
	private BarcodeUnitech barcodeUnitech;
	private BarcodeSunmi barcodeSunmi;
	private Db db;
	private WeakReference<MyActivity> activity;
	private SimpleDateFormat dateFormat, dateFormat2, dateFormat3, timeFormat, timeStampFormat, dateTimeFormat, dateTimeFormat2;//, dateTimeNetFormat;
	private BluetoothAdapter bluetoothAdapter;
	private boolean paused;

	private final List<Tuple<String, String>> permLocations = new ArrayList<>();
	private String permLocationsSmc = null;
	private static final String SMC_WITH_LOC_PERM = "1406";
	private static final String LOGTAG = "LOGTAG";

	//private FirebaseCrashlytics firebaseCrashlytics;
	//private FirebaseAnalytics firebaseAnalytics;

	//public FirebaseAnalytics getFirebaseAnalytics() {
	//	return firebaseAnalytics;
	//}

	public boolean isPaused() {
		return paused;
	}

	public App() {
		instance = this;
	}

	public static App getInstance() {
		return instance;
	}

	private Config config;
	private JSONObject user;

	public int getConfUserId() {
		return config.getConfigUserId();
	}

	public String getUserToken() {
		return config.getToken();
	}


	public void authUser(JSONObject json, String userName) {
		this.user = json;
		JSONArray smcList = Utils.getJsonArray(json, "smc_info");
		String smcListJson = smcList != null ? smcList.toString() : "";
		config.setSmcListJson(smcListJson);
		config.setUserName(userName);
		config.setUserId(Utils.getJsonInt(user, "user_id"));
		if (!config.isAuthMSAL())
			config.setToken(Utils.getJsonString(user, "token"));
		config.saveConfig();
		try {
			db.idQrStoreDao().truncate();
		} catch (Exception ignored) {
		}

		//sendFaLogin();
	}

	public void logoutUser() {
		user = null;
		config.setUserId(0);
		config.setToken(null);
		config.setAccount(null);
		config.saveConfig();
	}

	public SimpleDateFormat getDateFormat() {
		return dateFormat;
	}

	public Date parseDate(DateFormat dateFormat, String value) {
		try {
			return dateFormat.parse(value);
		} catch (Exception e) {
			log(this, e, "dateFormat.parse(%s)", value);
			return null;
		}
	}

	public Date parseDate(String value) {
		Date date = parseDate(dateFormat3, value);
		if(date == null)
			date = parseDate(dateFormat2, value);
		if(date == null)
			date = parseDate(dateFormat, value);
		return date;
	}

	public SimpleDateFormat getTimeFormat() {
		return timeFormat;
	}

	public SimpleDateFormat getTimeStampFormat() {
		return timeStampFormat;
	}

	public SimpleDateFormat getDateTimeFormat() {
		return dateTimeFormat;
	}

	public Locale getLocale() {

		Locale locale;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
			locale = getResources().getConfiguration().getLocales().get(0);
		} else {
			locale = getResources().getConfiguration().locale;
		}
		return locale;

	}

	@Override
	public void onCreate() {
		super.onCreate();

/*
		firebaseCrashlytics = FirebaseCrashlytics.getInstance();
		firebaseAnalytics = FirebaseAnalytics.getInstance(this);

		firebaseCrashlytics.setUserId(getDeviceId());
		firebaseAnalytics.setUserId(getDeviceId());
 */
		create();
	}

	public void onDestroy(MyActivity myActivity) {
		if (myActivity instanceof MainActivity)
			destroy();
	}

	/*public void onCreate(MyActivity myActivity) {
		create();
	}*/

	private void destroy() {
		logoutUser();
		if (barcodeHoneywell != null) {
			barcodeHoneywell.onDestroy();
			barcodeHoneywell = null;
		}
		if (barcodeZebra != null) {
			barcodeZebra.onDestroy();
			barcodeZebra = null;
		}
		if (barcodeUnitech != null) {
			barcodeUnitech.onDestroy();
			barcodeUnitech = null;
		}
		if (barcodeSunmi != null) {
			barcodeSunmi.onDestroy();
			barcodeSunmi = null;
		}
	}

	public SimpleDateFormat getDateTimeFormat2() {
		return dateTimeFormat2;
	}

	public SimpleDateFormat getDateFormat2() {
		return dateFormat2;
	}

	private void create() {
		if (dateFormat == null)
			dateFormat = new SimpleDateFormat("dd.MM.yyyy", getLocale());
		if (dateFormat2 == null) {
			dateFormat2 = new SimpleDateFormat("yyyy-MM-dd", getLocale());
		}
		if (dateFormat3 == null) {
			dateFormat3 = new SimpleDateFormat("MM/dd/yyyy", getLocale());
		}
		if (timeFormat == null)
			timeFormat = new SimpleDateFormat("HH:mm", getLocale());
		if (timeStampFormat == null)
			timeStampFormat = new SimpleDateFormat("yyyyMMddHHmmss", getLocale());
		if (dateTimeFormat == null) {
			dateTimeFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", getLocale());
		}
		if (dateTimeFormat2 == null)
			dateTimeFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", getLocale());
		//if (dateTimeNetFormat == null)
		//	dateTimeNetFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss", getLocale());
		if (barcodeHoneywell == null) barcodeHoneywell = new BarcodeHoneywell(this);
		if (barcodeZebra == null) barcodeZebra = new BarcodeZebra(this);
		if (barcodeUnitech == null) barcodeUnitech = new BarcodeUnitech(this);
		if (barcodeSunmi == null) barcodeSunmi = new BarcodeSunmi(this);
		if (config == null) config = new Config(this);
		if (network == null) network = new Network();
		if (db == null) {
			db = openDb();
		}
		if (bluetoothAdapter == null) bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

		//sendFaSmcId();
	}

	//public SimpleDateFormat getDateTimeNetFormat() {
	//	return dateTimeNetFormat;
	//}

	public Spanned fromHtml(String html) {
		if (html == null) {
			return new SpannableString("");
		} else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
			return Html.fromHtml(html, Html.FROM_HTML_MODE_COMPACT);
		} else {
			return Html.fromHtml(html);
		}
	}

	public Spanned fromHtmlImg(String html, int idDrawable) {
		ImageGetterTag imageGetter = new ImageGetterTag(idDrawable);
		imageGetter.getDrawable("1");
		///
		if (html == null) {
			return new SpannableString("");
		} else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
			return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY, imageGetter, null);
		} else {
			return Html.fromHtml(html);
		}
	}

	public BluetoothAdapter getBluetoothAdapter() {
		return bluetoothAdapter;
	}

	public Db getDb() {
		return db;
	}

	private Db openDb() {

		try {
			Db database = Room.databaseBuilder(getApplicationContext(),
					Db.class, "database")
					.allowMainThreadQueries()
					.fallbackToDestructiveMigration()
					.build();
			database.initDb();
			return database;
		} catch (Exception e) {
			log(this, e, null);
			return null;
		}
	}

	public void log(@NonNull Object object, @Nullable Exception e, @Nullable String message, Object... args) {
		String content = Utils.format(
				"%s%s%s",
				getClassName(object),
				message == null ? "" : "->" + Utils.format(message, args),
				e == null ? "" : ":" + e.getMessage()
		);
		Log.e(LOGTAG, content);
		//if (e != null) firebaseCrashlytics.recordException(e);
	}

	public void log(@NonNull Object object, @NonNull String message, Object... args) {
		String content = Utils.format("%s->%s", getClassName(object), Utils.format(message, args));
		Log.d(LOGTAG, content);
		//firebaseCrashlytics.log(content);
	}

	public MyActivity getActivity() {
		return activity == null ? null : activity.get();
	}

	private Timer timerUi, timerFullscreen;

	private void timerStart() {
		timerUi = new Timer();
		timerUi.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				timerEvent();
			}
		}, 10, 1000);

		timerFullscreen = new Timer();
		timerFullscreen.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				timerFullscreenEvent();
			}
		}, 0, 1000);
	}

	private void timerFullscreenEvent() {
		if (activity != null && activity.get() != null) {
			try {
				activity.get().timerFullscreenEvent();
			} catch (Exception ignored) {

			}
		}
	}

	private void timerEvent() {
		if (activity != null && activity.get() != null) {
			try {
				activity.get().timerEvent();
			} catch (Exception ignored) {

			}
		}
	}

	private void timerStop() {
		if (timerUi != null) timerUi.cancel();
		if (timerFullscreen != null) timerFullscreen.cancel();
	}

	public void onPause(MyActivity myActivity) {
		paused = true;
		if (barcodeHoneywell != null) barcodeHoneywell.onPause();
		if (barcodeZebra != null) barcodeZebra.onPause();
		if (barcodeUnitech != null) barcodeUnitech.onPause();
		if (barcodeSunmi != null) barcodeSunmi.onPause();
		timerStop();
		activity = null;
	}

	public void onResume(MyActivity myActivity) {
		paused = false;
		if (barcodeHoneywell != null) barcodeHoneywell.onResume();
		if (barcodeZebra != null) barcodeZebra.onResume();
		if (barcodeUnitech != null) barcodeUnitech.onResume();
		if (barcodeSunmi != null) barcodeSunmi.onResume();
		activity = new WeakReference<>(myActivity);
		hideUi(myActivity);
		timerStart();
		initPermLocations();
		log(myActivity, "OnResume()");
	}

	public void hideUi(Activity activity) {

		View decorView = activity.getWindow().getDecorView();
		//decorView.setSystemUiVisibility(0);

		// Enables regular immersive mode.
		// For "lean back" mode, remove SYSTEM_UI_FLAG_IMMERSIVE.
		// Or for "sticky immersive," replace it with SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        /*decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        // Set the content to appear under the system bars so that the
                        // content doesn't resize when the system bars hide and show.
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // Hide the nav bar and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);*/

		int val = View.SYSTEM_UI_FLAG_IMMERSIVE | View.SYSTEM_UI_FLAG_FULLSCREEN;
		if (!config.isNavigationVisible()) val |= View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
		decorView.setSystemUiVisibility(val);
	}

	public void onBarcodeEvent(String barcodeData) {
		if (getActivity() != null) {
			if (getActivity() instanceof IScan) {
				log(this, "%s", barcodeData);
				((IScan) getActivity()).onBarcodeEvent(barcodeData);
			} else {
				log(this, "%s", barcodeData);
			}
		}
	}

	public String getClassName(Object object) {
		if (object instanceof String) return (String) object;
		Class<?> enclosingClass = object.getClass().getEnclosingClass();
		if (enclosingClass != null) {
			return enclosingClass.getSimpleName();
		} else {
			return object.getClass().getSimpleName();
		}
	}

	@Override
	public void onNfcEvent(NFC nfc) {
		if (getActivity() != null) {
			getActivity().onNfcEvent(nfc);
		} else {
			log(this, "%s", nfc.getId());
		}
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		log(this, "onConfigurationChanged");
	}

	public Config getConfig() {
		return config;
	}

	public Network getNetwork() {
		return network;
	}

	public String readAssetsFile(String file) {

		String result = "";

		try {
			try (InputStream inputStream = getAssets().open(file)) {
				byte[] buffer = new byte[inputStream.available()];
				int len = inputStream.read(buffer);
				result = new String(buffer, StandardCharsets.UTF_8);
				log(this, "readAssetsFile(\"%s\")", file);
			}
		} catch (Exception e) {
			log(this, e, "readAssetsFile(\"%s\")", file);
		}

		return result;
	}

	public int getApkVersion() {
		return BuildConfig.VERSION_CODE;
	}

	public String getApkVersionName() {
		return BuildConfig.VERSION_NAME;
	}

	@SuppressLint("HardwareIds")
	public String getDeviceId() {
		try {
			return Settings.Secure.getString(getApplicationContext().getContentResolver(),
					Settings.Secure.ANDROID_ID).toUpperCase();
		} catch (Exception ignored) {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
				if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
					return Build.SERIAL;
				}

				try {
					return Build.getSerial();
				} catch (Exception e) {
					log(this, e, "Build.getSerial()");
				}
			}

			return Build.SERIAL;
		}
	}

	public boolean isBluetoothOn() {
		return getBluetoothAdapter() != null && getBluetoothAdapter().isEnabled();
	}

	@SuppressLint("MissingPermission")
	public boolean bluetoothOn() {
		if (getBluetoothAdapter() == null) return false;
		if (getBluetoothAdapter().isEnabled()) {
			return true;
		} else {
			if (getBluetoothAdapter().enable()) {
				return true;
			} else {
				Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
				startActivity(intent);
				Utils.sleep(1000);
				return isBluetoothOn();
			}
		}
	}

	public int getBatteryLevel() {
		try {
			IntentFilter intentFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
			Intent batteryStatus = this.registerReceiver(null, intentFilter);

			if (batteryStatus != null) {
				int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
				int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
				return (int) (level / (float) scale * 100.0f);
			} else {
				return 0;
			}
		} catch (Exception e) {
			log(this, e, "getBatteryLevel()");
			return 0;
		}
	}

	public boolean isBatteryCharging() {
		try {
			IntentFilter intentFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
			Intent batteryStatus = this.registerReceiver(null, intentFilter);

			if (batteryStatus != null) {
				int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
				return status == BatteryManager.BATTERY_STATUS_CHARGING ||
						status == BatteryManager.BATTERY_STATUS_FULL;
			} else {
				return false;
			}
		} catch (Exception e) {
			log(this, e, "isBatteryCharging()");
			return false;
		}
	}

	public String processTemplate(Config.TemplateType templateType, Map<String, String> map) {

		if (config.getPrinter() == null) return "";

		String result = "";
		PrinterType printerType = config.getPrinter().getType();

		if (printerType == PrinterType.ZEBRA) {

			String content = config.getTemplateZebra(templateType);

			String head;
			if (config.getPrinterPaperType() == 1) { //етикетка
				//~SD15
				head = Utils.format("~SD%d\n", config.getZebraBrightness()) +
						"~TA000\n" +
						"~JSN\n" +
						"\n" +
						"^XA\n" +
						"^SZ2\n" +
						"^PW800\n" +
						"^LL1199\n" +
						"^PR2,2\n" +
						"^MMT,N\n" +
						"^MPE\n" +
						"^XZ\n" +
						"\n" +
						"^XA^JUS^XZ\n";
			} else if (config.getPrinterPaperType() == 2) { //бирка
				//~SD20
				head = Utils.format("~SD%d\n", config.getZebraBrightness()) +
						"~TA000\n" +
						"~JSN\n" +
						"\n" +
						"^XA\n" +
						"^SZ2\n" +
						"^PW800\n" +
						"^LL1199\n" +
						"^PR2,2\n" +
						"^MNM,40\n" +
						"^MMT,N\n" +
						"^MPE\n" +
						"^XZ\n" +
						"\n" +
						"^XA^JUS^XZ\n";
			} else {
				head = "";
			}

			result = head + content;

		} else if (printerType == PrinterType.HONEYWELL) {

			result = config.getTemplateHoneywell(templateType);

			if (map == null) map = new HashMap<>();
			map.put("{{H}}", "");
			map.put("{{P}}", "PA");

		}

		if (map != null) {
			for (Map.Entry<String, String> entry : map.entrySet()) {
				result = result.replace(entry.getKey(), entry.getValue());
			}
		}

		return result;
	}

	@StringRes
	public int getPrintResultMessage(Printer.PrintResult result) {
		@StringRes int message = R.string.text_print_result_error;
		switch (result.getStatus()) {
			case ERROR_NO_PRINTER:
				message = R.string.text_print_result_no_printer;
				break;
			case ERROR_NO_PAPER_TYPE:
				message = R.string.text_print_result_no_paper_type;
				break;
			case ERROR_BLUETOOTH_OFF:
			case ERROR_BLUETOOTH_ADAPTER_NULL:
			case ERROR_BLUETOOTH_MAC_INVALID:
			case ERROR_BLUETOOTH_CONNECTION_ERROR:
			case ERROR_SOCKET_CONNECT:
			case ERROR_SOCKET_STREAM:
			case ERROR_SOCKET_WRITE:
			case ERROR_DATA_EMPTY:
				message = R.string.text_print_result_error;
				break;
		}
		return message;
	}

	@StringRes
	public int getScalesResultMessage(Scales.ScalesResult result) {
		@StringRes int message = R.string.text_scales_error;
		switch (result.getStatus()) {
			case ERROR_NO_SCALES:
				message = R.string.text_scales_result;
				break;
			case ERROR_BLUETOOTH_OFF:
			case ERROR_BLUETOOTH_ADAPTER_NULL:
			case ERROR_BLUETOOTH_MAC_INVALID:
			case ERROR_BLUETOOTH_CONNECTION_ERROR:
			case ERROR_SOCKET_CONNECT:
			case ERROR_SOCKET_STREAM:
			case ERROR_SOCKET_WRITE:
			case ERROR_DATA_EMPTY:
				message = R.string.text_scales_result_error;
				break;
		}
		return message;
	}

	public String generateDplLocation(String locationId, String locationCode) {

		Map<String, String> map = new HashMap<>();

		String[] arr = fixLocation(locationCode).split("-");
		String r = arr[0];
		String p = arr[1];
		String t = arr[2];

		map.put("{{QR}}", /*"M" + */locationCode);
		map.put("{{CODE}}", /*"M" + */locationCode);
		map.put("{{L1}}", r);
		map.put("{{L2}}", p);
		map.put("{{L3}}", t);

		return processTemplate(Config.TemplateType.TEMPLATE_LOCATION, map);
	}

	public String[] stringToSize(String string) {
		String[] arr = new String[3];
		try {
			String[] arr1 = string.split("x");
			String[] arr2 = string.split("х");
			String[] finalArr = arr1.length > arr2.length ? arr1 : arr2;
			for (int i = 0; i < finalArr.length && i < 3; i++) {
				arr[i] = finalArr[i];
			}
		} catch (Exception ignored) {

		}
		return arr;
	}

	public String sizeToString(float width, float length, float thickness) {
		String size = "";

		String w1 = floatToStringSize(width);
		String w2 = floatToStringSize(length);
		String w3 = floatToStringSize(thickness);

		if (length > 0) size += Utils.format("%sx", w2);
		if (width > 0) size += Utils.format("%sx", w1);
		if (thickness > 0) size += Utils.format("%sx", w3);
		if (size.endsWith("x")) size = size.substring(0, size.length() - 1);

		return size;
	}

	public String floatToStringSize(float value) {
		String out = String.valueOf(value);
		if (out.endsWith(".0")) out = out.substring(0, out.length() - 2);
		return out;
	}

	public String generateDplShipment(String number, String product, String car, JSONArray items) {

		if (items == null) return "";

		int pageCount = (int) Math.ceil((double) items.length() / 4.0);

		StringBuilder sb = new StringBuilder();

		for (int page = 1; page <= pageCount; page++) {
			Map<String, String> map = new HashMap<>();
			map.put("{{NUMBER}}", number);
			map.put("{{PRODUCT}}", product);
			map.put("{{CAR}}", car);
			map.put("{{PAGE}}", String.valueOf(page));
			map.put("{{PAGE_COUNT}}", String.valueOf(pageCount));

			for (int i = (page - 1) * 4; i < (page - 1) * 4 + 4; i++) {
				JSONObject item = Utils.getJsonObject(items, i);
				processDplShipmentItem(map, i - (page - 1) * 4, item);
			}

			sb.append(processTemplate(Config.TemplateType.TEMPLATE_SHIPMENT, map));
		}

		return sb.toString();
	}

	private void processDplShipmentItem(Map<String, String> map, int position, JSONObject item) {
		String name = Utils.getJsonStringIgnoreCase(item, "name");
		int netto = Utils.getJsonIntIgnoreCase(item, "shipment_Weight");
		String pack = Utils.getJsonStringIgnoreCase(item, "pack_weight");
		String batch = Utils.getJsonStringIgnoreCase(item, "batch");
		String ozm = Utils.getJsonStringIgnoreCase(item, "ozm");

		String hr = "";
		/*if (item != null) {
			if (position == 0) hr = "1X1100002000010l10000006";
			else if (position == 1) hr = "1X1100005000010l10000006";
			else if (position == 2) hr = "1X1100007900010l10000006";
			else if (position == 3) hr = "1X1100010800010l10000006";
		}*/

		map.put(Utils.format("{{HR%d}}", position + 1), hr);

		map.put(Utils.format("{{OZM%d_TITLE}}", position + 1), item == null ? "" : "ОЗМ:");
		map.put(Utils.format("{{BATCH%d_TITLE}}", position + 1), item == null ? "" : "Партія:");
		map.put(Utils.format("{{NETTO%d_TITLE}}", position + 1), item == null ? "" : "НЕТТО факт, тн:");
		map.put(Utils.format("{{PACK%d_TITLE}}", position + 1), item == null ? "" : "Упаковка, кг :");

		map.put(Utils.format("{{BARCODE%d}}", position + 1), batch);
		map.put(Utils.format("{{OZM%d}}", position + 1), ozm);
		map.put(Utils.format("{{BATCH%d}}", position + 1), batch);
		map.put(Utils.format("{{NETTO%d}}", position + 1), (netto > 0 ? String.valueOf(netto / 1000.0f) : ""));
		map.put(Utils.format("{{PACK%d}}", position + 1), pack);
		map.put(Utils.format("{{NAME%d_1}}", position + 1), name);
		map.put(Utils.format("{{NAME%d_2}}", position + 1), "");
		map.put(Utils.format("{{NAME%d_3}}", position + 1), "");

	}

	public String fixLocation(String locationCode) {
		try {

			//String newCode = "";
			StringBuilder sb = new StringBuilder();

			String[] arr = locationCode.split("-");
			for (int i = 0; i < 3; i++) {
				String s = i > arr.length - 1 ? "0" : arr[i];
				if (!TextUtils.isDigitsOnly(s)) s = "0";
				if (i + 1 < 3) s += "-";
				//newCode += s;
				sb.append(s);
			}

			//return newCode;
			return sb.toString();
		} catch (Exception e) {
			log(this, e, "fixLocation(%s)", locationCode);
		}

		return locationCode;
	}

	public boolean isLocationCorrect(String locationCode) {

		if (locationCode == null) return false;

		try {
			String[] s = locationCode.split("-");

			if (s.length > 3 || s.length < 2 /*s.length == 0*/) return false;

			for (String value : s) {
				if (!TextUtils.isDigitsOnly(value)) return false;
			}

			return true;

		} catch (Exception e) {
			log(this, e, "isLocationCorrect(%s)", locationCode);
		}

		return false;
	}

	public void beepRepeat() {
		beepRepeat(2000);
	}

	public void beepRepeat(int durationMs) {
		try {
			ToneGenerator toneGen1 = new ToneGenerator(AudioManager.STREAM_SYSTEM, 100);
			toneGen1.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, durationMs);
		} catch (Exception e) {
			log(this, e, "beepRepeat(%s)", durationMs);
		}
	}

	private int getShipmentStatus(JSONObject json) {

		JSONArray array = Utils.getJsonArray(json, "ttN_NUMBERS");

		int count = array == null ? 0 : array.length();
		int countCompleted = 0;

		for (int i = 0; i < count; i++) {
			JSONObject item = Utils.getJsonObject(array, i);
			int value = Utils.parseShipStatus(Utils.getJsonStringIgnoreCase(item, "statuS_OUT"));

			if (value == 0) return 0;
			else if (value == 1) countCompleted++;
		}

		return countCompleted == count ? 1 : -1;
	}

	public JsonResult loadShipmentOrderDetails(Date date, String documentNumber, SohFilter sohFilter) {
		List<String> documentNumbers = new ArrayList<>();
		documentNumbers.add(documentNumber);
		return loadShipmentOrderDetails(date, documentNumbers, sohFilter);
	}

	public JsonResult putStatusEO(String idDoc, int status, int numQueue){
		/*
		* status = 0 погрузка не начиналась
		* 		   1 началась погрузка
		* 		   2 погрузка частично завершена
		* 		   3 погрузка завершена*/
		JsonResult result = new JsonResult();
		result.setStatus(LoadResultStatus.H004);
		//if (config.isEo()){
			//Utils.runOnBackground(() -> {
				StringBuilder sb = new StringBuilder();
				sb.append(Utils.format("{%s%s%s}"
						, Utils.format("\"idDoc\":\"%s\",", idDoc)
						, Utils.format("\"idDocStatusCode\":%s,", status)
						, Utils.format("\"positionInQueue\":%s", numQueue)
				));
				String url = config.getUrlApiEO() + "IdDoc/Status";
				result = network.uploadJson(url, true, sb.toString());
			//});
		//}
		return result;
	}

	public JsonResult getStatusEO(String idDoc){
		/*
		 * status = 1 началась погрузка
		 * 		   2 погрузка частично завершена
		 * 		   3 погрузка завершена*/
		String url = config.getUrlApiEO() + "IdDoc/Status";
		url = network.addUrlParam(url, "idDoc", idDoc);

		JsonResult result = network.downloadJson(url);
		return result;
	}

	public JsonResult loadShipmentOrderDetails(Date date, List<String> documentNumbers, SohFilter sohFilter) {

		StringBuilder idDocList = new StringBuilder();

		for (int i = 0; i < documentNumbers.size(); i++) {
			String documentNumber = documentNumbers.get(i);
			db.shipmentItemDao().deleteByDocument(documentNumber);
			idDocList.append(documentNumber);
			if (i + 1 < documentNumbers.size()) idDocList.append(",");
		}
		db.shipmentItemLocDao().truncate();

		String url = config.getUrlApi() + "getorderlistdetails";
		url = network.addUrlParam(url, "DATE", getDateFormat().format(date));
		url = network.addUrlParam(url, "ID_DOC", idDocList.toString());
		if (sohFilter.getSohSmcId() != null) {
			url = network.addUrlParam(url, "smc_id", sohFilter.getSohSmcId());
			//if (sohFilter.getType() == SohFilterType.EO_TRUE)
			url = network.addUrlParam(url, "store", sohFilter.getSohStorage());
			//else url = network.addUrlParam(url, "lgort", "0001");
		} else if (config.getStorage().length() > 1)
			url = network.addUrlParam(url, "store", config.getStorage());

		JsonResult result = network.downloadJson(url);

		if (result.isOk()) {
			JSONArray array = Utils.getJsonArray(result.getJson(), "data");

			for (int i = 0; array != null && i < array.length(); i++) {
				JSONObject jsonDoc = Utils.getJsonObject(array, i);

				String idDoc = Utils.getJsonStringIgnoreCase(jsonDoc, "iD_DOC");
				//log(this, "idDoc = %s", idDoc);

				JSONArray arrayOrders = Utils.getJsonArray(jsonDoc, "orders");

				if (arrayOrders != null) {

					//log(this, "items = %d", arrayOrders.length());

					for (int j = 0; j < arrayOrders.length(); j++) {

						JSONObject jsonOrder = Utils.getJsonObject(arrayOrders, j);
						if (jsonOrder != null) {
							ShipmentItem shipmentItem = new ShipmentItem(
									0,
									Utils.getJsonIntIgnoreCase(jsonOrder, "line_Id"),
									Utils.getJsonIntIgnoreCase(jsonOrder, "saP_Weight_NETT"),
									Utils.getJsonIntIgnoreCase(jsonOrder, "saP_Weight_NETT_FACT"),
									Utils.getJsonStringIgnoreCase(jsonOrder, "smC_ID"),
									idDoc,
									Utils.getJsonStringIgnoreCase(jsonOrder, "iD_POS"),
									Utils.getJsonStringIgnoreCase(jsonOrder, "vo"),
									Utils.getJsonStringIgnoreCase(jsonOrder, "ttN_CARRIER_ID"),
									Utils.getJsonStringIgnoreCase(jsonOrder, "saP_Ozm"),
									Utils.getJsonStringIgnoreCase(jsonOrder, "saP_Matt_Descr"),
									Utils.getJsonStringIgnoreCase(jsonOrder, "delflag"),
									0,
									0,
									Utils.getJsonFloatIgnoreCase(jsonOrder, "length"),
									Utils.getJsonFloatIgnoreCase(jsonOrder, "width"),
									Utils.getJsonFloatIgnoreCase(jsonOrder, "thickness"),
									Utils.getJsonStringIgnoreCase(jsonOrder, "discount")
							);
							long itemId = db.shipmentItemDao().insert(shipmentItem);
							//log(this, "addShipmentItem(%d)", itemId);

							JSONArray arrayLoc = Utils.getJsonArray(jsonOrder, "locationWeights");
							for (int z = 0; arrayLoc != null && z < arrayLoc.length(); z++) {
								JSONObject itemLoc = Utils.getJsonObject(arrayLoc, z);

								ShipmentItemLoc shipmentItemLoc = new ShipmentItemLoc(
										0,
										itemId,
										Utils.getJsonStringIgnoreCase(itemLoc, "locationCode"),
										Utils.getJsonWeightKgIgnoreCase(itemLoc, "sumWeight"),
										Utils.getJsonStringIgnoreCase(itemLoc, "saP_Batch"),
										"0"
								);
								db.shipmentItemLocDao().insert(shipmentItemLoc);
							}
						}

					}

				}

                /*ShipmentItem shipmentItem = new ShipmentItem(
                        0,
                        Utils.getJsonIntIgnoreCase(jsonDoc, "line_Id"),
                        Utils.getJsonIntIgnoreCase(jsonDoc, "saP_Weight_NETT"),
                        Utils.getJsonIntIgnoreCase(jsonDoc, "saP_Weight_NETT_FACT"),
                        Utils.getJsonStringIgnoreCase(jsonDoc, "smC_ID"),
                        Utils.getJsonStringIgnoreCase(jsonDoc, "iD_DOC"),
                        Utils.getJsonStringIgnoreCase(jsonDoc, "iD_POS"),
                        Utils.getJsonStringIgnoreCase(jsonDoc, "vo"),
                        Utils.getJsonStringIgnoreCase(jsonDoc, "ttN_CARRIER_ID"),
                        Utils.getJsonStringIgnoreCase(jsonDoc, "saP_Ozm"),
                        Utils.getJsonStringIgnoreCase(jsonDoc, "saP_Matt_Descr"),
                        Utils.getJsonStringIgnoreCase(jsonDoc, "delflag"),
                        0,
                        0,
                        Utils.getJsonFloatIgnoreCase(jsonDoc, "length"),
                        Utils.getJsonFloatIgnoreCase(jsonDoc, "width"),
                        Utils.getJsonFloatIgnoreCase(jsonDoc, "thickness")
                );
                long itemId = db.shipmentItemDao().insert(shipmentItem);

                JSONArray arrayLoc = Utils.getJsonArray(jsonDoc, "locationWeights");
                for (int j = 0; arrayLoc != null && j < arrayLoc.length(); j++) {
                    JSONObject itemLoc = Utils.getJsonObject(arrayLoc, j);

                    ShipmentItemLoc shipmentItemLoc = new ShipmentItemLoc(
                            0,
                            itemId,
                            Utils.getJsonStringIgnoreCase(itemLoc, "locationCode"),
                            Utils.getJsonWeightKgIgnoreCase(itemLoc, "sumWeight") * 1000)
                    );
                    db.shipmentItemLocDao().insert(shipmentItemLoc);
                }*/
			}
		}

		return result;
	}

	public JsonResult loadShipmentFact(Date date, String documentNumber, String transportName) {
		int totalFact = 0;
		String url = config.getUrlApi() + "getorderlistdetails";
		url = network.addUrlParam(url, "DATE", getDateFormat().format(date));
		url = network.addUrlParam(url, "ID_DOC", documentNumber);
		url = network.addUrlParam(url, "store", config.getStorage());

		JsonResult result = network.downloadJson(url);

		if (result.isOk()) {
			JSONArray array = Utils.getJsonArray(result.getJson(), "data");

			for (int i = 0; array != null && i < array.length(); i++) {
				JSONObject jsonDoc = Utils.getJsonObject(array, i);

				String idDoc = Utils.getJsonStringIgnoreCase(jsonDoc, "iD_DOC");

				JSONArray arrayOrders = Utils.getJsonArray(jsonDoc, "orders");

				if (arrayOrders != null) {

					for (int j = 0; j < arrayOrders.length(); j++) {

						JSONObject jsonOrder = Utils.getJsonObject(arrayOrders, j);
						if (jsonOrder != null) {
							totalFact += Utils.getJsonIntIgnoreCase(jsonOrder, "saP_Weight_NETT_FACT");
						}

					}
					ShipmentDocument document = db.shipmentDocumentDao().getByName(documentNumber, transportName);
					if (document != null) {
						document.setFact(totalFact);
						db.shipmentDocumentDao().update(document);
					}
				}
			}
		}

		return result;
	}

	private void truncateShipTables() {
		db.shipmentDocumentDao().truncate();
		db.shipmentTransportDao().truncate();
		db.shipmentItemDao().truncate();
		db.shipmentItemLocDao().truncate();
	}

	public JsonResult loadShipmentOrdersEO() {

		truncateShipTables();
		String url = config.getUrlApiEO() + "RouteList";
		url = network.addUrlParam(url, "stock", config.getStorage());
		url = network.addUrlParam(url, "smcId", config.getSmcId());
		JsonResult result = network.downloadJson(url);
		JSONArray data = Utils.getJsonArray(result.getJson(), "content");
		if (result.isOk() && data != null) {

				for (int i = 0; i < data.length(); i++) {

					JSONObject jsonTransport = Utils.getJsonObject(data, i);
					String dateVoStr = Utils.getJsonStringIgnoreCase(jsonTransport, "queueStatusSetDate");
					String dateBookStr = Utils.getJsonStringIgnoreCase(jsonTransport, "bookingDate");
					Date dateVo = dateVoStr == null || dateVoStr.isEmpty() ? null : parseDateTime(dateVoStr.substring(0,19).replaceAll("T"," "));
					Date dateBook = dateBookStr == null || dateBookStr.isEmpty() ? null : parseDateTime(dateBookStr.substring(0,19).replaceAll("T"," "));
					String driverNumber = Utils.getJsonStringIgnoreCase(jsonTransport, "driverPhoneNumber");
					String driver = Utils.getJsonStringIgnoreCase(jsonTransport, "driverName");
					int position = Utils.getJsonIntIgnoreCase(jsonTransport, "positionInQueue");
					//TRANSPORT
					ShipmentTransport shipmentTransport = new ShipmentTransport(0,
							Utils.getJsonStringIgnoreCase(jsonTransport, "licensePlate"),
							driverNumber,
							driver,
							Utils.getJsonStringIgnoreCase(jsonTransport, "eoStatus"),
							Utils.getJsonIntIgnoreCase(jsonTransport, "eoStatusCode"), //getShipmentStatusEO(jsonTransport)
							position,
							Utils.getJsonStringIgnoreCase(jsonTransport, "currentLocation"),
							Utils.getJsonIntIgnoreCase(jsonTransport, "tripId"),
							dateVo
					);
					shipmentTransport.setLastDate(dateBook==null?0:dateBook.getTime());
					long transportId = db.shipmentTransportDao().insert(shipmentTransport);
					shipmentTransport.setId(transportId);
					db.shipmentTransportDao().update(shipmentTransport);

					JSONArray arrayDocument = Utils.getJsonArray(jsonTransport, "documents");

					for (int j = 0; arrayDocument != null && j < arrayDocument.length(); j++) {

						JSONObject jsonDoc = Utils.getJsonObject(arrayDocument, j);
						String doc = Utils.getJsonStringIgnoreCase(jsonDoc, "idDoc");
						doc = String.format("%1$" + 10 + "s", doc).replace(' ', '0');
						//DOCUMENT
						ShipmentDocument shipmentDocument = new ShipmentDocument(
								0, shipmentTransport.getId(), shipmentTransport.getName(),
								doc,
								Utils.getJsonIntIgnoreCase(jsonDoc, "idDocStatusCode"),
								0,//Utils.getJsonWeightKgIgnoreCase(jsonDoc, "suM_PLAN_WEIGHT"),
								0,//Utils.getJsonWeightKgIgnoreCase(jsonDoc, "suM_FACT_WEIGHT"),
								shipmentTransport.getOrderCount(),
								dateVo,
								Utils.getJsonIntIgnoreCase(jsonDoc, "locationId"),
								Utils.getJsonStringIgnoreCase(jsonDoc, "locationName"),
								Utils.getJsonStringIgnoreCase(jsonDoc, "smc_id"),
								Utils.getJsonStringIgnoreCase(jsonDoc, "lgort")
						);
						shipmentDocument.setDriverName(driver);
						shipmentDocument.setDriverCellPhone(driverNumber);
						shipmentDocument.setTurnId(position);
						db.shipmentDocumentDao().insert(shipmentDocument);
					}
				}
		}
		return result;
	}

	public JsonResult loadShipmentOrdersEO(ArrayList<String> documentList) {

		//truncateShipTables();

		String url = config.getUrlApi() + "getshipmentorderseo";
		url = network.addUrlParam(url, "smc_id", config.getSmcId());
		//if (config.getStorage().length() > 1)
		//	url = network.addUrlParam(url, "lgort", config.getStorage());

		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for (int i = 0; i < documentList.size(); i++) {
			sb.append(Utils.format("{%s}"
					, Utils.format("\"ID_DOC\":\"%s\"", documentList.get(i))
			));
			//if (i + 1 < documentList.size()) sb.append(",");
			if (i < documentList.size() - 1) sb.append(",");
		}
		sb.append("]");

		JsonResult result = network.uploadJson(url, sb.toString());

		JSONArray data = Utils.getJsonArray(result.getJson(), "data");

		if (result.isOk() && data != null) {

				for (int i = 0; i < data.length(); i++) {

					JSONObject jsonTransport = Utils.getJsonObject(data, i);

					//TRANSPORT
					ShipmentTransport transport;
					//List<ShipmentTransport> transports = db.shipmentTransportDao().getAll();
					String ttn_sap = Utils.getJsonStringIgnoreCase(jsonTransport, "ttN_CARIER_ID");
					//DOCUMENT
					List<ShipmentDocument> documentsDb;
					//List<ShipmentDocument> documents = db.shipmentDocumentDao().getAll();
					JSONArray arrayDocument = Utils.getJsonArray(jsonTransport, "ttN_NUMBERS");
					for (int j = 0; arrayDocument != null && j < arrayDocument.length(); j++) {
						JSONObject jsonDocument = Utils.getJsonObject(arrayDocument, j);
						String id_doc = Utils.getJsonStringIgnoreCase(jsonDocument, "iD_DOC");
						int plan_weight = Utils.getJsonWeightKgIgnoreCase(jsonDocument, "suM_PLAN_WEIGHT");
						int fact_weight = Utils.getJsonWeightKgIgnoreCase(jsonDocument, "suM_FACT_WEIGHT");
						int order_count = Utils.getJsonIntIgnoreCase(jsonDocument, "ordeR_COUNT");
						documentsDb = db.shipmentDocumentDao().getByNameLike(id_doc);
						for (ShipmentDocument doc: documentsDb) {
						doc.setPlan(plan_weight);
						doc.setFact(fact_weight);
						doc.setOrderCount(order_count);
						doc.setSapPoNum(Utils.getJsonStringIgnoreCase(jsonDocument, "saP_PO_NUM"));
						doc.setClientNumber(Utils.getJsonStringIgnoreCase(jsonDocument, "iD_DP"));
						doc.setTransportNameSap(ttn_sap);
						String dateVoStr = Utils.getJsonStringIgnoreCase(jsonDocument, "datE_VO");
						Date dateVo = parseDfDateTime(dateVoStr);
						doc.setFirstDate(dateVo.getTime());
						//transport = db.shipmentTransportDao().getByName(doc.getTransportName());
						transport = db.shipmentTransportDao().getById(doc.getTransportId());
						if (transport.getId() == doc.getTransportId()) {
							transport.setCurrentLocation(ttn_sap);
							//doc.setDriverName(transport.getDriverName());
							db.shipmentTransportDao().update(transport);
							db.shipmentDocumentDao().update(doc);
						}
						}
					}
				}
		}

		return result;
	}
	public JsonResult loadShipmentOrders(Date date, Date date2, String carrierId, SohFilter sohFilter) {

		truncateShipTables();

		String url = config.getUrlApi() + "getshipmentorders";
		url = network.addUrlParam(url, "date", getDateFormat().format(date));
		url = network.addUrlParam(url, "date_to", getDateFormat().format(date2));
		if (sohFilter.getSohSmcId() != null) {
			url = network.addUrlParam(url, "smc_id", sohFilter.getSohSmcId());
			url = network.addUrlParam(url, "lgort", "0001");
		} else if (config.getStorage().length() > 1)
			url = network.addUrlParam(url, "lgort", config.getStorage());
		if (carrierId != null) url = network.addUrlParam(url, "TTN_CARRIER_ID", carrierId);

		JsonResult result = network.downloadJson(url);

		//truncateShipTables();

		JSONObject data = Utils.getJsonObject(result.getJson(), "data");

		if (result.isOk() && data != null) {
			JSONArray arrayTransport = Utils.getJsonArray(data, "orderlists");

			if (arrayTransport != null) {

				//log(this, "arrayTransport %d", arrayTransport.length());

				for (int i = 0; i < arrayTransport.length(); i++) {

					JSONObject jsonTransport = Utils.getJsonObject(arrayTransport, i);

					//TRANSPORT
					ShipmentTransport shipmentTransport = new ShipmentTransport(0,
							Utils.getJsonStringIgnoreCase(jsonTransport, "ttN_CARIER_ID"),
							Utils.getJsonIntIgnoreCase(jsonTransport, "iP_COUNT"),
							getShipmentStatus(jsonTransport)
					);

					JSONArray arrayDocument = Utils.getJsonArray(jsonTransport, "ttN_NUMBERS");

					int minTurnId = 0;
					Date minDate = null;
					Date maxDate = null;
					Date minPlanTime = null;
					int totalDocumentCount = arrayDocument == null ? 0 : arrayDocument.length();
					int totalOrderCount = 0;

					for (int j = 0; arrayDocument != null && j < arrayDocument.length(); j++) {

						JSONObject jsonDoc = Utils.getJsonObject(arrayDocument, j);

						int turnId = Utils.getJsonIntIgnoreCase(jsonDoc, "turN_ID");
						if (turnId != 0 && (turnId < minTurnId || minTurnId == 0)) {
							minTurnId = turnId;
						}

						String planTime = Utils.getJsonStringIgnoreCase(jsonDoc, "plaN_TIME");
						if (planTime != null && planTime.length() > 0 && !planTime.endsWith(" 0:00:00")) {
							Date dt = parseDfDateTime(planTime);
							if (dt != null) {
								if (minPlanTime == null || dt.getTime() < minPlanTime.getTime()) {
									minPlanTime = dt;
								}
							}
						}

						String firstDate = Utils.getJsonStringIgnoreCase(jsonDoc, "firsT_LID");
						String lastDate = Utils.getJsonStringIgnoreCase(jsonDoc, "lasT_LID");
						if (firstDate != null && firstDate.length() > 0) {
							Date d1 = parseDfDateTime(firstDate);
							if (d1 != null) {
								if (minDate == null || d1.getTime() < minDate.getTime()) {
									minDate = d1;
								}
							}
						}
						if (lastDate != null && lastDate.length() > 0) {
							Date d2 = parseDfDateTime(lastDate);
							if (d2 != null) {
								if (maxDate == null || d2.getTime() > maxDate.getTime()) {
									maxDate = d2;
								}
							}
						}

						int orderCount = Utils.getJsonIntIgnoreCase(jsonDoc, "ordeR_COUNT");
						totalOrderCount += orderCount;
					}

					shipmentTransport.setMinTurnId(minTurnId);
					shipmentTransport.setFirstDate(minDate == null ? 0 : minDate.getTime());
					shipmentTransport.setLastDate(maxDate == null ? 0 : maxDate.getTime());
					shipmentTransport.setPlanTime(minPlanTime == null ? 0 : minPlanTime.getTime());
					shipmentTransport.setOrderCount(totalOrderCount);

					long transportId = db.shipmentTransportDao().insert(shipmentTransport);
					int deletedDocumentCount = 0;

					//DOCUMENT
					for (int j = 0; arrayDocument != null && j < arrayDocument.length(); j++) {

						JSONObject jsonDocument = Utils.getJsonObject(arrayDocument, j);

						Date dt = null;
						Date d1 = null;
						Date d2 = null;

						String planTime = Utils.getJsonStringIgnoreCase(jsonDocument, "plaN_TIME");
						String firstDate = Utils.getJsonStringIgnoreCase(jsonDocument, "firsT_LID");
						String lastDate = Utils.getJsonStringIgnoreCase(jsonDocument, "lasT_LID");
						if (planTime != null && planTime.length() > 0 && !planTime.endsWith(" 0:00:00")) {
							dt = parseDfDateTime(planTime);
						}
						if (firstDate != null && firstDate.length() > 0) {
							d1 = parseDfDateTime(firstDate);
						}
						if (lastDate != null && lastDate.length() > 0) {
							d2 = parseDfDateTime(lastDate);
						}

						int orderCount = Utils.getJsonIntIgnoreCase(jsonDocument, "ordeR_COUNT");
						boolean docDeleted = Utils.getJsonIntIgnoreCase(jsonDocument, "delflag") == 1;
						if (docDeleted) deletedDocumentCount++;

						int turnId = Utils.getJsonIntIgnoreCase(jsonDocument, "turN_ID");

						String dateVoStr = Utils.getJsonStringIgnoreCase(jsonDocument, "datE_VO");
						Date dateVo = parseDfDateTime(dateVoStr);

						ShipmentDocument shipmentDocument = new ShipmentDocument(
								0, transportId, shipmentTransport.getName(),
								Utils.getJsonStringIgnoreCase(jsonDocument, "iD_DOC"),
								Utils.getJsonStringIgnoreCase(jsonDocument, "iD_DP"),
								Utils.parseShipStatus(Utils.getJsonStringIgnoreCase(jsonDocument, "statuS_OUT")),
								docDeleted,
								Utils.getJsonWeightKgIgnoreCase(jsonDocument, "suM_PLAN_WEIGHT"),
								Utils.getJsonWeightKgIgnoreCase(jsonDocument, "suM_FACT_WEIGHT"),
								d1 == null ? 0 : d1.getTime(), d2 == null ? 0 : d2.getTime(), dt == null ? 0 : dt.getTime(),
								Utils.getJsonStringIgnoreCase(jsonDocument, "saP_PO_NUM"),
								Utils.getJsonStringIgnoreCase(jsonDocument, "pO_DRIVER_NAME"),
								Utils.getJsonStringIgnoreCase(jsonDocument, "pO_CREATOR_NAME"),
								Utils.getJsonStringIgnoreCase(jsonDocument, "PO_DRIVER_CELLPHONE"),
								orderCount, turnId, dateVo
						);
						db.shipmentDocumentDao().insert(shipmentDocument);
					}

					if (deletedDocumentCount == totalDocumentCount) {
						shipmentTransport.setId(transportId);
						shipmentTransport.setDeleted(true);
						db.shipmentTransportDao().update(shipmentTransport);
					}
				}

			}

		}

		return result;
	}

	public void copyToClipboard(String text) {
		try {
			ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
			if (clipboard != null) {
				ClipData clip = ClipData.newPlainText("Text", text);
				clipboard.setPrimaryClip(clip);
			}
		} catch (Exception e) {
			log(this, e, "copyToClipboard(%s)", text);
		}
	}

	public Network.NetworkResultValue<TransportDoc> loadIncTransportDoc(Date date, Date dateFrom, Date dateTo, @NonNull String transportName, TTN ttn, SohFilter sohFilter) {
		String url = config.getUrlApi() + "getsapinbound";

		if (transportName.length() > 0) {
			url = network.addUrlParam(url, "ttn_carrier_id", transportName);
			url = network.addUrlParam(url, "ttn_date", getDateFormat().format(date));
		} else {
			url = network.addUrlParam(url, "date_from", getDateFormat().format(dateFrom));
			url = network.addUrlParam(url, "date_to", getDateFormat().format(dateTo));
		}

		if (sohFilter.getSohSmcId() != null)
			url = network.addUrlParam(url, "smc_id", sohFilter.getSohSmcId());
		JsonResult result = network.downloadJson(url);

		JSONObject json = Utils.getJsonObject(result.getJson(), "data");

		if (result.isOk() && json != null) {

			JSONArray array = Utils.getJsonArray(json, "orderlists");

			for (int i = 0; array != null && i < array.length(); i++) {
				JSONObject jsonTransport = Utils.getJsonObject(array, i);
				Transport transport = Transport.fromJson(jsonTransport, sohFilter);

				if (transport != null && transportName.equalsIgnoreCase(transport.getName()) && transport.getDate().getTime() == date.getTime()) {
					return new Network.NetworkResultValue<>(result, TransportDoc.fromTransport(transport, ttn));
				}
			}

		}

		return new Network.NetworkResultValue<>(result, null);
	}

	public Network.NetworkResultValue<Transport> loadIncTransport(Date dateFrom, Date dateTo, String transportName, SohFilter sohFilter) {
		Network.NetworkResultValue<List<Transport>> resultValue = loadIncTransportList(dateFrom, dateTo, transportName, sohFilter);
		if (resultValue.getResult().isOk() && !resultValue.getValue().isEmpty()) {
			return new Network.NetworkResultValue<>(resultValue.getResult(), resultValue.getValue().get(0));
		} else {
			return new Network.NetworkResultValue<>(resultValue.getResult(), null);
		}
	}

	public Network.NetworkResultValue<List<Transport>> loadIncTransportList(Date dateFrom, Date dateTo, String transportName, SohFilter sohFilter) {

		String url = config.getUrlApi() + "getsapinbound";
		url = network.addUrlParam(url, "date_from", getDateFormat().format(dateFrom));
		url = network.addUrlParam(url, "date_to", getDateFormat().format(dateTo));
		if (sohFilter.getSohSmcId() != null)
			url = network.addUrlParam(url, "smc_id", sohFilter.getSohSmcId());
		JsonResult result = network.downloadJson(url);

		JSONObject json = Utils.getJsonObject(result.getJson(), "data");

		if (result.isOk() && json != null) {

			JSONArray array = Utils.getJsonArray(json, "orderlists");
			List<Transport> transportList = new ArrayList<>();

			for (int i = 0; array != null && i < array.length(); i++) {
				Transport transport = Transport.fromJson(Utils.getJsonObject(array, i), sohFilter);
				if (transport == null) continue;
				if (transportName == null || transportName.equalsIgnoreCase(transport.getName())) {
					transportList.add(transport);
				}
			}

			return new Network.NetworkResultValue<>(result, transportList);

		}

		return new Network.NetworkResultValue<>(result, null);
	}

	public Network.NetworkResultValue<List<Order>> loadIncOrderList(Date date, TransportDoc transportDoc, SohFilter sohFilter) {

		Network.NetworkResultValue<List<Order>> result = new Network.NetworkResultValue<>();
		result.setValue(new ArrayList<>());

		String url = config.getUrlApi() + "getinboundorderdetails";
		if (sohFilter.getSohSmcId() != null)
			url = network.addUrlParam(url, "smc_id", sohFilter.getSohSmcId());
		url = network.addUrlParam(url, "TTN_DATE", getDateFormat().format(date));
		url = network.addUrlParam(url, "TTN_CARRIER_ID", transportDoc.getTransport().getName());
		url = network.addUrlParam(url, "TTN_NUM", transportDoc.getTtn().getNum());
		//url = network.addUrlParam(url, "TTN_ID", transportDoc.getTtn().getId());
		result.setResult(network.downloadJson(url));

		JSONArray array = Utils.getJsonArray(result.getResult().getJson(), "data");
		if (result.getResult().isOk() && array != null) {
			for (int i = 0; i < array.length(); i++) {
				JSONObject item = Utils.getJsonObject(array, i);
				result.getValue().add(new Order(item));
			}
		}

		return result;
	}

	public String getNetworkErrorMessage(JsonResult result) {
		if (result == null || result.getStatus() == LoadResultStatus.OK) {
			return getString(R.string.request_error_unknown) + (result == null ? "" : Utils.format("%n%n<i>Method: %s</i>", result.getFunctionName()));
		} else if (result.getStatus() == LoadResultStatus.CONNECT_ERROR) {
			return result.getDescription() + Utils.format("%n%n<i>Method: %s</i>", result.getFunctionName());
		} else if (result.getStatus() == LoadResultStatus.PARSE_ERROR) {
			return result.getDescription() + Utils.format("%n%n<i>Method: %s</i>", result.getFunctionName());
		} else if (result.getStatus() == LoadResultStatus.TIMEOUT) {
			return getString(R.string.request_error_timeout) + Utils.format("%n%n<i>Method: %s</i>", result.getFunctionName());
		} else {
			if (result.getStatus() == LoadResultStatus.S006 || result.getStatus() == LoadResultStatus.ZERO) {
				return getString(R.string.request_error, "сервера (S006)") + Utils.format("%n%n<i>Method: %s</i>", result.getFunctionName());
			} else if (result.getStatus() == LoadResultStatus.S000) {
				return getString(R.string.s000_work) + Utils.format("%n%n<i>Method: %s</i>", result.getFunctionName());
			} else if (result.getStatus() == LoadResultStatus.S003) {
				return getString(R.string.s003_work) + Utils.format("%n%n<i>Method: %s</i>", result.getFunctionName());
			} else {
				if (result.getDescription().equalsIgnoreCase("504")) {
					return getString(R.string.request_error_504) + Utils.format("%n%n<i>Method: %s</i>", result.getFunctionName());
				} else {
					return getString(R.string.request_error, "№" + result.getDescription() + Utils.format("%n%n<i>Method: %s</i>", result.getFunctionName()));
				}
			}
		}
	}

	public String longToTimeString(long value) {
		if (value == 0) {
			return "";
		} else {
			return getTimeFormat().format(new Date(value));
		}
	}

	public JsonResult editLabelWeight(LabelEditItem item, Date actDate, String actNumber) {
		List<LabelEditItem> list = new ArrayList<>(1);
		list.add(item);
		return editLabelWeight(list, actDate, actNumber);
	}

	public JsonResult editLabelWeight(List<LabelEditItem> list, Date actDate, String actNumber) {
		String url = config.getUrlApi() + "setlabelweight";
		url = network.addUrlParam(url, "Actdate", getDateFormat().format(actDate));
		url = network.addUrlParam(url, "Actnumber", String.valueOf(actNumber));

		StringBuilder sb = new StringBuilder();
		sb.append("[");

		for (int i = 0; i < list.size(); i++) {
			sb.append("{").append(Utils.format(
					"\"id\":\"%s\",\"smc_id\":\"%s\",\"nett_Weight\":\"%s\",\"pack_Weight\":\"%s\",\"sap_batch\":%s,\"low_price_percent\":%s,\"release\":%s",
					list.get(i).getLabelId(), list.get(i).getSmcId()/*App.getInstance().getSmcIdCurrent()*/, list.get(i).getNettoNew(), list.get(i).getPackNew(),
					(list.get(i).getBatch() == null ? "null" : Utils.format("\"%s\"", list.get(i).getBatch())),
					((list.get(i).getLowPricePercent() == null || list.get(i).getLowPricePercent().length() == 0) ? "null" : list.get(i).getLowPricePercent()),
					list.get(i).isRelease() ? "1" : "0"
			)).append("}");
			if (i + 1 < list.size()) sb.append(",");
		}

		sb.append("]");

		return network.uploadJson(url, sb.toString());
	}

	public String getSmcIdCurrent() {
		return config.getSmcIdUser() != null && !config.getSmcIdUser().isEmpty() ? config.getSmcIdUser() : config.getSmcId();
	}

	public Date parseDfDate(String value) {
		if (Utils.isNullOrEmpty(value)) return null;
		try {
			SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy", getLocale());
			return format.parse(value);
		} catch (Exception e) {
			log(this, e, "parseDfDate(%s)", value);
			return null;
		}
	}

	public Date parseDfDateTime(String value) {
		try {
			SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", getLocale());
			return format.parse(value);
		} catch (Exception e) {
			log(this, e, "parseDfDateTime(%s)", value);
			return null;
		}
	}

	public Date parseDateTime(String value) {
		try {//2023-10-12T14:25:45.0156785
			//SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", getLocale());
			return App.getInstance().getDateTimeFormat2().parse(value);
		} catch (Exception e) {
			log(this, e, "parseDateTime(%s)", value);
			return null;
		}
	}

	public String getCurrentDtString() {
		try {
			return dateTimeFormat.format(Calendar.getInstance().getTime());
		} catch (Exception ignored) {
			return "";
		}
	}

	public void initPermLocations() {
		if (permLocationsSmc != null && permLocationsSmc.equalsIgnoreCase(getSmcIdCurrent())) {
			return;
		}

		log(this, "initPermLocations(%s)", getSmcIdCurrent());

		permLocationsSmc = getSmcIdCurrent();

		permLocations.clear();

		if (!getSmcIdCurrent().equalsIgnoreCase(SMC_WITH_LOC_PERM)) return;

		for (int cell = 1; cell <= 15; cell++) addPermLocation(1, cell);
		for (int cell = 1; cell <= 55; cell++) addPermLocation(2, cell);
		for (int cell = 1; cell <= 60; cell++) addPermLocation(3, cell);
		for (int cell = 1; cell <= 6; cell++) addPermLocation(4, cell);
		for (int cell = 1; cell <= 70; cell++) addPermLocation(5, cell);
		for (int cell = 1; cell <= 29; cell++) addPermLocation(6, cell);
		for (int cell = 1; cell <= 29; cell++) addPermLocation(7, cell);
		for (int cell = 1; cell <= 1; cell++) addPermLocation(8, cell);

	}

	private void addPermLocation(int row, int cell) {
		permLocations.add(new Tuple<>(String.valueOf(row), String.valueOf(cell)));
	}

	public boolean isLocationPermitted(String locationCode) {
		if (!getSmcIdCurrent().equalsIgnoreCase(SMC_WITH_LOC_PERM)) return true;

		for (Tuple<String, String> item : permLocations) {
			String[] arr = fixLocation(locationCode).split("-");
			String r = arr[0];
			String p = arr[1];
			if (item.x.equalsIgnoreCase(r) && item.y.equalsIgnoreCase(p)) return true;
		}

		log(this, "Location \"%s\" not permitted!", locationCode);
		return false;
	}

	public String generateDplUnknown(Date date, int weightCrane, String carrier, String name, String ozm, float width, float length, float thickness,
									 int netto, int pack, int tara, String locationCode, String labelId, String ttnNum, String idQr) {

		String dateString = getDateFormat().format(date);

		String sb = "[" +
				Utils.format(
						"{\"netto\":\"%d\",\"pack\":\"%d\",\"tara\":\"%d\",\"id\":\"%s\"}",
						netto, pack, tara, labelId) +
				"]";
		String qr = Utils.format(
				"SMC07|%d|%d|%s|%s|%s|%s|%s|%s|%s|%f|%f|%f",
				weightCrane, 1, sb, dateString, carrier, locationCode, ttnNum,
				ozm, name, length, width, thickness);

		PrintLabelConfig labelConfig = new PrintLabelConfig()
				.withDataMatrix(qr)
				.withLabelId(labelId)
				.withName(name)
				.withSize(sizeToString(width, thickness, length))
				.withOzm(ozm)
				.withZavPlavka("")
				.withZavBatch("")
				.withBruttoKg(weightCrane)
				.withNettoKg(weightCrane - pack)
				.withPackKg(pack)
				.withTransport(carrier)
				.withBatch("TEMP")
				.withTheor(false)
				.withTheorCount(0)
				.withLowPrice(null)
				.withUser(config.getUserName())
				.withDate(date)
				.withLocation(locationCode)
				.withIdQr(idQr);

		return generateDplNewLabel(labelConfig);
	}

	public String generateDplLabel(String labelId, Date date, String name,
								   float width, float length, float thickness, int netto, int pack, int tara,
								   String ozm, String batch, String carrier, int packCount,
								   boolean isTheor, int theorCount, String locationCode, String zavBatch, String zavPlavka, String zavOdin, String lowPrice, String proizvod, String postavkaMera
	, String lgort) {

		String label = Utils.format("%s|%s|%s|%s|%f|%f|%f|%d|%s|%s|%d|%d|%s|%d|%s|%s",
				"SMC06",
				labelId,
				getSmcIdCurrent(),
				name,
				length,
				width,
				thickness,
				netto,
				isTheor ? "ТВ" : "ФВ",
				ozm,
				pack,
				tara,
				batch == null ? "" : batch,
				packCount,
				getTimeStampFormat().format(date),
				carrier
		);

		PrintLabelConfig labelConfig = new PrintLabelConfig()
				.withDataMatrix(label)
				.withLabelId(labelId)
				.withName(name)
				.withSize(sizeToString(width, thickness, length))
				.withOzm(ozm)
				.withZavPlavka(zavPlavka)
				.withZavBatch(zavBatch)
				.withZavOdin(zavOdin)
				.withBruttoKg(netto + pack)
				.withNettoKg(netto)
				.withPackKg(pack)
				.withTransport(carrier)
				.withBatch(Utils.isNullOrEmpty(batch) ? "АВТО" : batch)
				.withTheor(isTheor)
				.withTheorCount(theorCount)
				.withLowPrice(lowPrice)
				.withUser(config.getUserName())
				.withDate(date)
				.withLocation(locationCode)
				.withProizvod(proizvod)
				.withPostavkaMera(postavkaMera)
				.withLgort(lgort)
				;

		return generateDplNewLabel(labelConfig);

	}

	private String generateDplNewLabel(
			PrintLabelConfig labelConfig
	) {
		Map<String, String> map = new HashMap<>();
		String weightType = labelConfig.isTheor() ? "ТВ" : "ФВ";
		//if (Utils.parseInt(labelConfig.getLowPrice()) > 0)
		//	weightType += Utils.format(", УЦІНКА %s%%", labelConfig.getLowPrice());

		String lowPrice = Utils.parseDiscount(labelConfig.getLowPrice()) > 0 ? labelConfig.getLowPrice() : "";
		if (lowPrice == null) lowPrice = "";
		map.put("{{LOW_PRICE}}", lowPrice);

		map.put("{{DATAMATRIX}}", labelConfig.getDataMatrix());
		map.put("{{LABEL_ID}}", labelConfig.getLabelId());

		map.put("{{NAME}}", labelConfig.getName());
		map.put("{{SIZE}}", labelConfig.getSize());
		map.put("{{OZM}}", labelConfig.getOzm());

		map.put("{{FACTORY_PLAVKA_TITLE}}", /*Utils.isNullOrEmpty(labelConfig.getZavPlavka()) ? "" : */"ЗАВ. ПЛАВКА");
		map.put("{{FACTORY_BATCH_TITLE}}", /*Utils.isNullOrEmpty(labelConfig.getZavBatch()) ? "" : */"ЗАВ. ПАРТІЯ");
		map.put("{{FACTORY_ODIN_TITLE}}", /*Utils.isNullOrEmpty(labelConfig.getZavOdin()) ? "" : *//*"№ ОД. ПРОД."*/
				Utils.isNullOrEmpty(labelConfig.getPostavkaMera()) ? "" : labelConfig.getPostavkaMera());
				//labelConfig.getPostavkaMera());
		map.put("{{PROIZVOD}}", /*Utils.isNullOrEmpty(labelConfig.getZavOdin()) ? "" : *//*"№ ОД. ПРОД."*/
				Utils.isNullOrEmpty(labelConfig.getProizvod()) ? "" : labelConfig.getProizvod());
				//labelConfig.getProizvod());
		map.put("{{FACTORY_BATCH}}", Utils.isNullOrEmpty(labelConfig.getZavBatch()) ? "" : labelConfig.getZavBatch());
		map.put("{{FACTORY_PLAVKA}}", Utils.isNullOrEmpty(labelConfig.getZavPlavka()) ? "" : labelConfig.getZavPlavka());
		map.put("{{FACTORY_ODIN}}", Utils.isNullOrEmpty(labelConfig.getZavOdin()) ? "" : labelConfig.getZavOdin());
		//map.put("{{POSTAVKA_MERA}}", Utils.isNullOrEmpty(labelConfig.get) ? "" : labelConfig.getZavOdin());

		map.put("{{BRUTTO_WEIGHT}}", String.valueOf(labelConfig.getBruttoKg()));
		map.put("{{NETTO_WEIGHT}}", String.valueOf(labelConfig.getNettoKg()));
		map.put("{{PACK_WEIGHT}}", String.valueOf(labelConfig.getPackKg()));

		map.put("{{TRANSPORT_TITLE}}", Utils.isNullOrEmpty(labelConfig.getTransport()) ? "" : "ТР-Т");
		map.put("{{TRANSPORT}}", Utils.isNullOrEmpty(labelConfig.getTransport()) ? "" : labelConfig.getTransport());

		if (!Utils.isNullOrEmpty(labelConfig.getBatch()) && labelConfig.getBatch().equalsIgnoreCase("TEMP")) {
			map.put("{{BATCH_TITLE}}", "");
			map.put("{{BATCH}}", "");
			if (Utils.isNullOrEmpty(labelConfig.getIdQr())) {
				map.put("{{BATCH_TEMP}}", getString(R.string.temp_label_batch_title).toUpperCase());
			} else {
				map.put("{{BATCH_TEMP}}", labelConfig.getIdQr());
			}
		} else {
			map.put("{{BATCH_TITLE}}", Utils.isNullOrEmpty(labelConfig.getBatch()) || labelConfig.getBatch().equalsIgnoreCase("THEOR") ? "" : "ЛОГ. ПАРТІЯ");
			map.put("{{BATCH}}", Utils.isNullOrEmpty(labelConfig.getBatch()) || labelConfig.getBatch().equalsIgnoreCase("THEOR") ? "" : labelConfig.getBatch());
			map.put("{{BATCH_TEMP}}", "");
		}

		map.put("{{USER}}", labelConfig.getUser());
		map.put("{{DATE}}", getDateFormat().format(labelConfig.getDate()));
		map.put("{{WEIGHT_TYPE}}", weightType);

		String info = Utils.format("%s  %s  %s",
				Utils.isNullOrEmpty(config.getStorage()) ? "" : "СКЛАД " + (labelConfig.getLgort()!=null && labelConfig.getLgort()!="" ? labelConfig.getLgort() : config.getStorage()),
				(Utils.isNullOrEmpty(labelConfig.getLocation()) ? "" : labelConfig.getLocation()) + (labelConfig.isTheor() && labelConfig.getTheorCount() > 0 ? Utils.format(" (%d шт)", labelConfig.getTheorCount()) : ""),
				"ТИП " + weightType
				);
		map.put("{{INFO}}", info);

		//map.put("{{STORAGE}}", Utils.isNullOrEmpty(config.getStorage()) ? "" : "СКЛАД " + config.getStorage());
		//map.put("{{WEIGHT_TYPE}}", weightType);
		//map.put("{{LOCATION}}", (Utils.isNullOrEmpty(labelConfig.getLocation()) ? "" : labelConfig.getLocation()) + (labelConfig.isTheor() && labelConfig.getTheorCount() > 0 ? Utils.format(" (%d шт)", labelConfig.getTheorCount()) : ""));

		return processTemplate(Config.TemplateType.TEMPLATE_WORK, map);
	}

	/*public void sendFaLogin() {
		Bundle bundle = new Bundle();
		bundle.putString(FirebaseAnalytics.Param.METHOD, "user_name");
		bundle.putString("user_name", config.getUserName());
		bundle.putString("smc_id", config.getSmcId());
		firebaseAnalytics.logEvent(FirebaseAnalytics.Event.LOGIN, bundle);
	}*/

	//public void sendFaSmcId() {
	//	firebaseAnalytics.setUserProperty("smc_id", config.getSmcId());
	//}
/*
	public void sendFaPrint() {
		sendFaPrint(1);
	}

	public void sendFaPrint(int pageCount) {
		try {
			Bundle bundle = new Bundle();
			bundle.putString("user_name", config.getUserName());
			bundle.putString("smc_id", config.getSmcId());
			for (int i = 0; i < pageCount; i++) {
				firebaseAnalytics.logEvent("page_print", bundle);
			}
		} catch (Exception e) {
			log(this, e, "logEvent(\"page_print\")");
		}
	}
 */

	public boolean isPrinterAvailable() {
		return config.isPrinterConnected() && config.getPrinterPaperType() > 0;
	}

    public boolean isPrinterZebra() {
		return config.isPrinterConnected() && config.getPrinter().getType() == PrinterType.ZEBRA;
    }
}
