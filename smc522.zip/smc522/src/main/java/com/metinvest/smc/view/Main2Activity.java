package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;

import com.metinvest.smc.R;

public class Main2Activity extends MyActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    @Override
    protected String getHelpContent() {
        return getString(R.string.select_operation_help);
    }

    @Override
    protected void onFunctionKey(int number) {
        switch (number) {
            case 2:
                startActivity(new Intent(this, ComingActivity.class));
                break;
            case 3:
                startActivity(new Intent(this, ShipmentActivity.class));
                break;
            /*case 4:
                startActivity(new Intent(this, PrinterActivity.class));
                break;*/
            case 4:
                startActivity(new Intent(this, ExportActivity.class));
                break;
            case 5:
                startActivity(new Intent(this, RollActivity.class));
                break;
            /*case 7:
                startActivity(new Intent(this, CranesActivity.class));
                break;*/
            case 6:
                //Intent intent = new Intent(this, IncActivity.class);
                //intent.putExtra("isNew", true);
                //startActivity(intent);
                startActivity(new Intent(this, HistoryActivity.class));
                break;
        }
    }
}
