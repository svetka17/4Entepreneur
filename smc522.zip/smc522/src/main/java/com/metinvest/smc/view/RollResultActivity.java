package com.metinvest.smc.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.db.Roll;
import com.metinvest.smc.db.RollName;
import com.metinvest.smc.inc.Weight;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.Printer;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class RollResultActivity extends MyActivity {

	@BindView(R.id.textContentTitle)
	TextView textContentTitle;
	@BindView(R.id.textContent)
	TextView textContent;
	@BindView(R.id.listView)
	RecyclerView listView;
	@BindView(R.id.scrollView)
	NestedScrollView scrollView;
	@BindView(R.id.buttonAccept)
	Button buttonAccept;
	@BindView(R.id.buttonPrint)
	Button buttonPrint;
	@BindView(R.id.viewButtonPrint)
	View viewButtonPrint;
	@BindView(R.id.viewButtonAccept)
	View viewButtonAccept;

	private RollName rollName;
	private String locationCode;
	private boolean isTheor;
	private int weightCraneBrutto, weightCraneNetto, packCount, basePackCount;
	private ArrayList<Weight> weightList;
	private ArrayList<Roll> rollList;
	private ArrayList<Integer> weightListFinal;
	private boolean accepted;
	private FlexibleAdapter<Adapter> adapter;
	private String storage;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_roll_result);
		ButterKnife.bind(this);

		long rollNameId = getIntent().getLongExtra("rollNameId", 0);
		rollName = db.rollNameDao().getById(rollNameId);
		if (rollName == null) {
			setResult(RESULT_CANCELED);
			finish();
		}

		storage = getIntent().getStringExtra("storage");
		isTheor = getIntent().getBooleanExtra("isTheor", false);
		weightCraneBrutto = getIntent().getIntExtra("weightCraneBrutto", 0);
		weightCraneNetto = getIntent().getIntExtra("weightCraneNetto", 0);
		packCount = getIntent().getIntExtra("packCount", 0);
		basePackCount = getIntent().getIntExtra("basePackCount", packCount);
		locationCode = getIntent().getStringExtra("locationCode");
		weightList = new ArrayList<>(getIntent().getParcelableArrayListExtra("weightList"));

		rollList = new ArrayList<>();
		List<Long> currentRollListChecked = (List<Long>) getIntent().getSerializableExtra("rollListChecked");
		if (currentRollListChecked != null) {
			for (Long id : currentRollListChecked) {
				rollList.add(db.rollDao().getById(id));
			}
		}

		LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
		DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
		listView.setLayoutManager(layoutManager);
		listView.addItemDecoration(dividerItemDecoration);

		viewButtonPrint.setVisibility(View.GONE);
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		beginLoad();
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 5) {
			if (accepted)
				buttonPrintClick();
			else
				buttonAcceptClick();
		}
	}

	private Weight getTotalWeight() {
		Weight total = new Weight(0, 0, 0);
		for (Weight weight : weightList) {
			total.setNetto(total.getNetto() + weight.getNetto());
			total.setPack(total.getPack() + weight.getPack());
			total.setTara(total.getTara() + weight.getTara());
		}
		return total;
	}

	private void beginLoad() {
		if (isLoading()) return;

		showLoading(R.string.text_please_wait);

		Utils.runOnBackground(() -> {

			weightListFinal = new ArrayList<>(packCount);

			Weight totalWeight = getTotalWeight();
			int weightToDivide = weightCraneBrutto - totalWeight.getBrutto();
			double weightExtra = 0;

			for (int i = 0; i < packCount; i++) {

				double weightToAdd = 0;

				if (weightToDivide != 0) {
					double itemPercent = totalWeight.getNetto() == 0 ? 0 : (double) weightList.get(i).getNetto() * 100 / totalWeight.getNetto();
					weightToAdd = itemPercent * weightToDivide / 100.0f;
				}

				weightExtra += weightToAdd - (int) weightToAdd;
				weightListFinal.add(weightList.get(i).getNetto() + (int) weightToAdd);
			}

			weightExtra = Math.round(weightExtra);

			log("weightExtra: %.3f", weightExtra);

			if (Math.abs(weightExtra) > 0) {
				int i = 0;
				while (Math.abs(weightExtra) >= 1.0f) {
					weightListFinal.set(i, weightListFinal.get(i) + (weightExtra > 0 ? 1 : -1));
					weightExtra -= (weightExtra > 0 ? 1 : -1);
					i = i == weightListFinal.size() - 1 ? 0 : i + 1;
				}
			}

			log("weightExtra: %.3f", weightExtra);

			StringBuilder sb = new StringBuilder();

			sb.append(Utils.format("<b>%s</b><br>", rollName.getName()));
			sb.append(Utils.format("<b>Брутто, тн: </b>%.3f<br>", weightCraneBrutto / 1000.0f));
			sb.append(Utils.format("<b>Локація: </b>%s<br>", locationCode));
			sb.append(Utils.format("<b>Пачок, шт: </b>%d", packCount));
			if (packCount < basePackCount) {
				sb.append(Utils.format("<br><font color=\"red\">Знайдено %d партій з %d</font>", packCount, basePackCount));
			}

			runOnUiThread(() -> endLoad(sb.toString()));
		});
	}

	private void endLoad(String content) {
		hideLoading();
		textContent.setText(app.fromHtml(content));

		List<Adapter> list = new ArrayList<>();

		for (int i = 0; i < packCount; i++) {
			list.add(new Adapter(i, null, rollName, isTheor, isTheor ? packCount : 0, rollList.get(i), weightList.get(i), weightListFinal.get(i), this::onLabelPrintClicked, locationCode));
		}

		setAdapter(list);
	}

	private void buttonAcceptClick() {
		if (isLoading() || !buttonAccept.isEnabled()) return;

		beginAccept();
	}

	private void buttonPrintClick() {
		beginPrint(adapter.getCurrentItems(), true);
	}

	private void beginAccept() {

		showLoading(R.string.text_please_wait);
		buttonAccept.setEnabled(false);

		Utils.runOnBackground(() -> {

			String url;
			JsonResult result;
			List<String> listLabelId = new ArrayList<>();

			url = config.getUrlApi() + "rollout";
			url = net.addUrlParam(url, "location", locationCode);

			StringBuilder sb = new StringBuilder();

			sb.append("[");

			for (int i = 0; i < packCount; i++) {

				Roll roll = rollList.get(i);
				Weight weight = weightList.get(i);
				int weightFinal = weightListFinal.get(i);

				//TODO STORAGE

				sb.append(Utils.format("{%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%s%n%n}"
						, Utils.format("\"SAP_Matt_Descr\" : \"%s\",", roll.getMaterialName())
						, Utils.format("\"SAP_Ozm\" : \"%s\",", roll.getOzm())
						, Utils.format("\"SAP_Batch\" : \"%s\",", roll.getBatch())
						, Utils.format("\"SAP_Weight_NETT\" : \"%s\",", weightFinal)
						, Utils.format("\"Length\" : \"%s\",", roll.getLength())
						, Utils.format("\"Width\" : \"%s\",", roll.getWidth())
						, Utils.format("\"Thickness\" : \"%s\",", roll.getThickness())
						, Utils.format("\"Pack_Weight\" : \"%s\",", weight.getPack())
						, Utils.format("\"Nett_Weight\" : \"%s\",", weightFinal)
						, Utils.format("\"TEOR_Weight\":%s,", isTheor ? "true" : "false")
						, Utils.format("\"LGORT\" : \"%s\",", storage)
						, "\"External_Id\" : null"
				));

				if (i + 1 < packCount) sb.append(",");

			}

			sb.append("]");

			result = net.uploadJson(url, sb.toString());

			if (result.isOk()) {
				JSONArray jsonArray = Utils.getJsonArray(result.getJson(), "data");
				for (int i = 0; jsonArray != null && i < jsonArray.length(); i++) {
					String labelId = Utils.getJsonString(jsonArray, i);
					listLabelId.add(labelId == null ? "" : labelId);
				}

				if (isTheor) {
					for (int i = 0; i < packCount; i++) {
						Roll roll = rollList.get(i);
						//roll.setStockUsed(roll.getStockUsed() + weightListFinal.get(i));
						roll.setActual(false);
						db.rollDao().update(roll);
					}
				}else{
					for (int i = 0; i < packCount; i++) {
						Roll roll = rollList.get(i);
						int weightFinal = weightListFinal.get(i);
						int stock = weightFinal > roll.getStock() ? 0 : roll.getStock() - weightFinal;
						roll.setStock(stock);
						db.rollDao().update(roll);
					}
				}
			}

			JsonResult finalResult = result;
			runOnUiThread(() -> endAccept(finalResult, listLabelId));
		});
	}

	private void endAccept(JsonResult result, List<String> listLabelId) {

		hideLoading();
		buttonAccept.setEnabled(true);

		if (result.isOk()) {
			finishAccept(listLabelId);
		} else if (result.getStatus() == LoadResultStatus.ZERO) {
			AlertDialog dialog = showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_inc_batch_to_old, (dialog1, which) -> {
				setResult(RESULT_NEED_REFRESH);
				finish();
			});
			dialog.setCanceledOnTouchOutside(false);
			dialog.setCancelable(false);

		} else if (result.getStatus() == LoadResultStatus.MINUS1) {
			AlertDialog dialog = showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_inc_status_deleted, (dialog1, which) -> {
				setResult(RESULT_DELETED);
				finish();
			});
			dialog.setCanceledOnTouchOutside(false);
			dialog.setCancelable(false);
		} else {
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginAccept());
		}
	}

	private void finishAccept(List<String> listLabelId) {
		accepted = true;
		viewButtonPrint.setVisibility(View.VISIBLE);
		viewButtonAccept.setVisibility(View.GONE);
		textContentTitle.setText(R.string.title_activity_inc_result_accepted);

		List<Adapter> list = new ArrayList<>();

		for (int i = 0; i < packCount; i++) {
			list.add(new Adapter(i, listLabelId.get(i), rollName, isTheor, isTheor ? packCount : 0, rollList.get(i), weightList.get(i), weightListFinal.get(i), this::onLabelPrintClicked, locationCode));
		}

		setAdapter(list);
	}

	private void setAdapter(List<Adapter> items) {
		adapter = new FlexibleAdapter<>(items);
		listView.setAdapter(adapter);
		scrollView.post(() -> scrollView.scrollTo(0, 0));
	}

	@Override
	public void onBackPressed() {
		close();
		super.onBackPressed();
	}

	private void close() {
		if (accepted) {
			setResult(RESULT_OK);
		} else {
			setResult(RESULT_CANCELED);
		}
		finish();
	}

	private void onLabelPrintClicked(Adapter item) {
		List<Adapter> list = new ArrayList<>();
		list.add(item);
		beginPrint(list, false);
	}

	private void beginPrint(List<Adapter> listToPrint, boolean isPrintAll) {

		if (isLoading() || !buttonPrint.isEnabled()) return;

		showLoading(R.string.text_printing_title);
		buttonPrint.setEnabled(false);

		Utils.runOnBackground(() -> {
			StringBuilder data = new StringBuilder();

			if (isPrintAll && isTheor) {
				Adapter item = listToPrint.get(0);
				data.append(app.generateDplLabel(
						item.getLabelId(), item.getDate(), item.getRoll().getMaterialName(),
						item.getRoll().getWidth(), item.getRoll().getLength(), item.getRoll().getThickness(),
						item.getWeightFinal(), item.getWeight().getPack(), item.getWeight().getTara(),
						item.getRoll().getOzm(), "THEOR",
						"", 0,
						item.isTheor(), packCount, item.getLocationCode(),
						"", "", "", null, "", "", null));
			} else {
				for (Adapter item : listToPrint) {

					data.append(app.generateDplLabel(
							item.getLabelId(), item.getDate(), item.getRoll().getMaterialName(),
							item.getRoll().getWidth(), item.getRoll().getLength(), item.getRoll().getThickness(),
							item.getWeightFinal(), item.getWeight().getPack(), item.getWeight().getTara(),
							item.getRoll().getOzm(), item.getRoll().getBatch(),
							"", 0,
							item.isTheor(), item.getTheorCount(), item.getLocationCode(),
							"", "", "", null, "", "", null));
				}
			}

			StringBuilder dplName = new StringBuilder("<b>Зважування</b><br>");
			//dplName.append(Utils.format("%s<br>", transportDoc.getTransport().getName()));
			//dplName.append(Utils.format("ТТН: %s<br>", transportDoc.getTtn().getId()));
			dplName.append(Utils.format("Вага з крану: %s кг.<br>", weightCraneBrutto));
			dplName.append(Utils.format("Кількість позицій: %s<br>", packCount));
			for (int i = 0; i < packCount; i++) {
				dplName.append(Utils.format("Позиція №%s: %s кг", i + 1, weightListFinal.get(i)));
				if (i + 1 < packCount) dplName.append("<br>");
			}

			final Printer.PrintResult result = Printer.sendCommand(dplName.toString(), config.getPrinter(), data.toString());
			runOnUiThread(() -> endPrint(result, isPrintAll));
		});

	}

	private void endPrint(Printer.PrintResult result, boolean closeOnSuccess) {

		buttonPrint.setEnabled(true);
		hideLoading();

		if (result.getStatus() == Printer.PrintResultStatus.OK) {
			showToast(R.string.text_print_result_succeeded);
			//app.sendFaPrint();
			if (closeOnSuccess) close();
		} else {
			@StringRes final int message = app.getPrintResultMessage(result);

			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error_print, message, (dialog, which) -> {
				dialog.dismiss();
				buttonPrintClick();
			});
		}

	}

	public static class Adapter extends AbstractFlexibleItem<Adapter.ViewHolder> {

		private final String labelId;
		private final Roll roll;
		private final Weight weight;
		private final int weightFinal;
		private final Date date;
		private final boolean theor;
		private final RollName rollName;
		private final String locationCode;
		private final int theorCount;

		public int getTheorCount() {
			return theorCount;
		}

		public interface Listener {
			void onPrintClicked(Adapter item);
		}

		private final int index;
		private final Listener listener;

		public Adapter(int index, String labelId, RollName rollName, boolean theor, int theorCount, Roll roll, Weight weight, int weightFinal, Listener listener, String locationCode) {
			this.date = Calendar.getInstance().getTime();
			this.rollName = rollName;
			this.theor = theor;
			this.theorCount = theorCount;
			this.index = index;
			this.labelId = labelId;
			this.roll = roll;
			this.weight = weight;
			this.weightFinal = weightFinal;
			this.listener = listener;
			this.locationCode = locationCode;
		}

		public String getLocationCode() {
			return locationCode;
		}

		public boolean isTheor() {
			return theor;
		}

		public Date getDate() {
			return date;
		}

		public String getLabelId() {
			return labelId;
		}

		public Roll getRoll() {
			return roll;
		}

		public Weight getWeight() {
			return weight;
		}

		public int getWeightFinal() {
			return weightFinal;
		}

		public int getIndex() {
			return index;
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof Adapter && ((Adapter) o).getLabelId().equalsIgnoreCase(getLabelId());
		}

		@Override
		public int hashCode() {
			return getLabelId().hashCode();
		}

		@Override
		public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
			return new ViewHolder(view, adapter);
		}

		@Override
		public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {

			String title;

			if (labelId == null) {
				title = Utils.format("<b><font color=\"#34326D\">Позиція №%d</font></b>", index + 1);
			} else {
				title = Utils.format("<b><font color=\"#34326D\">LabelId %s</font></b>", labelId);
			}

			holder.textTitle.setText(App.getInstance().fromHtml(title));

			StringBuilder sb = new StringBuilder();

			sb.append(Utils.format("Вага з бірки, тн: %.3f<br>", weight.getNetto() / 1000.0f));
			sb.append(Utils.format("Упаковка, кг: %d<br>", weight.getPack() + weight.getTara()));
			sb.append(Utils.format("Призначена вага, тн: %.3f<br>", weightFinal / 1000.0f));
			sb.append(Utils.format("Партія: %s", roll.getBatch()));

			if (listener != null) {
				holder.buttonPrint.setOnClickListener(v -> listener.onPrintClicked(this));
			}

			holder.textContent.setText(App.getInstance().fromHtml(sb.toString()));
			holder.buttonPrint.setVisibility(labelId == null || isTheor() ? View.INVISIBLE : View.VISIBLE);
		}

		@Override
		public int getLayoutRes() {
			return R.layout.adapter_inc_result;
		}

		public class ViewHolder extends FlexibleViewHolder {

			@BindView(R.id.textTitle)
			TextView textTitle;
			@BindView(R.id.textContent)
			TextView textContent;
			@BindView(R.id.buttonPrint)
			ImageButton buttonPrint;

			public ViewHolder(View view, FlexibleAdapter adapter) {
				super(view, adapter);
				ButterKnife.bind(this, view);
			}
		}
	}
}
