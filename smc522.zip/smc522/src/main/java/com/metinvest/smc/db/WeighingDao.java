package com.metinvest.smc.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface WeighingDao {
    @Query("SELECT * FROM weighing ORDER BY number")
    List<Weighing> getAll();

    @Query("SELECT * FROM weighing WHERE id = :id")
    Weighing getById(long id);

    @Query("SELECT * FROM weighing WHERE id in (:idList)")
    List<Weighing> getById(List<Long> idList);

    @Insert
    long insert(Weighing weighing);

    @Insert
    void insertAll(List<Weighing> weighingList);

    @Update
    void update(Weighing weighing);

    @Delete
    void delete(Weighing weighing);

    @Query("DELETE FROM weighing")
    void truncate();

    @Query("SELECT MAX(number) FROM weighing")
    Integer getMaxNumber();
}