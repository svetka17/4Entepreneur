package com.metinvest.smc.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.metinvest.smc.tools.IValue;
import com.metinvest.smc.tools.Utils;

@Entity
public class OnTheWay implements IValue {

	@PrimaryKey(autoGenerate = true)
	private long id;

	private String storage, lineId, sapBatch, sapId1, sapId2, ttnNum, ttnCarrierId, ttnDate, smcId, dateUpload, dateArrive;

	private int sapWeightNett;
	private int weightAccepted;

	private long nameId;
	private long carrierId;

	private boolean printed;
	private long datePrinted;

	@Ignore
	public OnTheWay(long id, String storage, String lineId, String sapBatch, int sapWeightNett, String sapId1, String sapId2, String ttnNum, String ttnCarrierId, String ttnDate, String smcId, String dateUpload, String dateArrive, long nameStoreId, long carrierId, int weightAccepted, boolean printed, long datePrinted) {
		this.id = id;
		this.storage = storage;
		this.lineId = lineId;
		this.sapBatch = sapBatch;
		this.sapWeightNett = sapWeightNett;
		this.sapId1 = sapId1;
		this.sapId2 = sapId2;
		this.ttnNum = ttnNum;
		this.ttnCarrierId = ttnCarrierId;
		this.ttnDate = ttnDate;
        this.smcId = smcId;
        this.dateUpload = dateUpload;
        this.dateArrive = dateArrive;
        this.nameId = nameStoreId;
        this.carrierId = carrierId;
        this.weightAccepted = weightAccepted;
        this.printed = printed;
        this.datePrinted = datePrinted;
	}

	@Override
	public String getName() {
		return String.valueOf(nameId);
	}

	public OnTheWay() {
	}

	public String getStorage() {
		return storage;
	}

	public void setStorage(String storage) {
		this.storage = storage;
	}

	public int getWeightAccepted() {
		return weightAccepted;
	}

	public boolean isPrinted() {
		return printed;
	}

	public void setPrinted(boolean printed) {
        this.printed = printed;
    }

    public long getDatePrinted() {
        return datePrinted;
    }

    public void setWeightAccepted(int weightAccepted) {
        this.weightAccepted = weightAccepted;
    }

    public void setDatePrinted(long datePrinted) {
        this.datePrinted = datePrinted;
    }

    public long getNameId() {
        return nameId;
    }

    public void setNameId(long nameId) {
        this.nameId = nameId;
    }

    public long getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(long carrierId) {
        this.carrierId = carrierId;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getLineId() {
        return lineId;
    }

    public void setLineId(String lineId) {
        this.lineId = lineId;
    }

    public String getSapBatch() {
        return sapBatch;
    }

    public void setSapBatch(String sapBatch) {
        this.sapBatch = sapBatch;
    }

    public int getSapWeightNett() {
        return sapWeightNett;
    }

    public void setSapWeightNett(int sapWeightNett) {
        this.sapWeightNett = sapWeightNett;
    }

    public String getSapId1() {
        return sapId1;
    }

    public void setSapId1(String sapId1) {
        this.sapId1 = sapId1;
    }

    public String getSapId2() {
        return sapId2;
    }

    public void setSapId2(String sapId2) {
        this.sapId2 = sapId2;
    }

    public String getTtnNum() {
        return ttnNum;
    }

    public void setTtnNum(String ttnNum) {
        this.ttnNum = ttnNum;
    }

    public String getTtnCarrierId() {
        return ttnCarrierId;
    }

    public void setTtnCarrierId(String ttnCarrierId) {
        this.ttnCarrierId = ttnCarrierId;
    }

    public String getTtnDate() {
        return ttnDate;
    }

    public void setTtnDate(String ttnDate) {
        this.ttnDate = ttnDate;
    }

    public String getSmcId() {
        return smcId;
    }

    public void setSmcId(String smcId) {
        this.smcId = smcId;
    }

    public String getDateUpload() {
        return dateUpload;
    }

    public void setDateUpload(String dateUpload) {
        this.dateUpload = dateUpload;
    }

    public String getDateArrive() {
        return dateArrive;
    }

    public void setDateArrive(String dateArrive) {
        this.dateArrive = dateArrive;
    }

    @NonNull
    @Override
    public String toString() {
        return Utils.format("[%s] %s W:%s", getId(), getNameId(), getSapWeightNett());
    }
}
