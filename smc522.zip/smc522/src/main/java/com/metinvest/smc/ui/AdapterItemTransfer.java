package com.metinvest.smc.ui;

import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemTransfer extends AbstractFlexibleItem<AdapterItemTransfer.AdapterItemTransferViewHolder> {

    private final IItemAction action;
    private final Label label;
    private final boolean inGroup;

    public interface IItemAction {
        void onDeleteClick(String labelId);
    }

    public AdapterItemTransfer(Label label, boolean inGroup, IItemAction action) {
        this.label = label;
        this.action = action;
        this.inGroup = inGroup;
    }

    public boolean isInGroup() {
        return inGroup;
    }

    public String getLabelId() {
        return label.getId();
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterItemTransfer && ((AdapterItemTransfer) o).getLabelId().equalsIgnoreCase(getLabelId());
    }

    @Override
    public int hashCode() {
        return label.hashCode();
    }

    @Override
    public AdapterItemTransferViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new AdapterItemTransferViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemTransferViewHolder holder, int position, List<Object> payloads) {
        StringBuilder sb = new StringBuilder();
        if (!inGroup) sb.append(Utils.format("<b>%s</b><br>", label.getName()));
        sb.append(Utils.format("LabelId: %s<br>", label.getId()));
        if (Utils.isNullOrEmpty(label.getZavBatch())) {
            sb.append(Utils.format("Партія: %s<br>", label.getBatch()));
        } else {
            sb.append(Utils.format("Зав. партія: %s<br>", label.getZavBatch()));
        }

        if (label.isTheor()) {
            sb.append(Utils.format("Теоретична вага: %s кг.<br>", label.getWeightNetto()));
        } else {
            sb.append(Utils.format("Вага нетто: %s кг.<br>", label.getWeightNetto()));
        }

        sb.append(Utils.format("Склад: %s", Utils.isNullOrEmpty(label.getStorage()) ? "-" : label.getStorage()));
        holder.textContent.setText(App.getInstance().fromHtml(sb.toString()));
        holder.buttonDelete.setOnClickListener(v -> action.onDeleteClick(getLabelId()));
        holder.viewSpace.setVisibility(inGroup ? View.VISIBLE : View.GONE);
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_transfer_row;
    }

    static class AdapterItemTransferViewHolder extends FlexibleViewHolder {

        @BindView(R.id.viewSpace)
        View viewSpace;
        @BindView(R.id.textContent)
        TextView textContent;
        @BindView(R.id.buttonDelete)
        ImageButton buttonDelete;

        AdapterItemTransferViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            ButterKnife.bind(this, view);
        }
    }
}
