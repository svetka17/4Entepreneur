package com.metinvest.smc.net;

import androidx.annotation.NonNull;

public class NetworkResult<T> {

	private LoadResultStatus status;
	private String description;
	private T data;
	private long packetId;
	private String functionName;

	public String getFunctionName() {
		return functionName == null ? "" : functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public NetworkResult(long packetId, LoadResultStatus status, String description, T data) {
		this.packetId = packetId;
		this.status = status;
		this.description = description;
		this.data = data;
	}

	public NetworkResult(LoadResultStatus status) {
		this.status = status;
	}

	public NetworkResult() {
	}

	public boolean isOk() {
		return getStatus() == LoadResultStatus.OK;
	}

	public LoadResultStatus getStatus() {
		return status;
	}

	public long getPacketId() {
		return packetId;
	}

	public void setPacketId(long packetId) {
		this.packetId = packetId;
	}

	public void setStatus(LoadResultStatus status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	@NonNull
	@Override
	public String toString() {
		return String.valueOf(status);
	}
}