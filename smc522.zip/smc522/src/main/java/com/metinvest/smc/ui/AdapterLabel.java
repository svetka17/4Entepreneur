package com.metinvest.smc.ui;

import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.Utils;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterLabel extends AbstractFlexibleItem<AdapterLabel.ViewHolder> {

	private final IListener listener;
	private final boolean showOzmHead;
	private final boolean showCheck;
	private final boolean offline;
	private AdapterLabelGroup group;
	private boolean checked;
	private boolean discount;
	private Date checkedDate;
	private int nettoFact = -1;

	public interface IListener {
		void onPrintClicked(AdapterLabel item);

		void onEditClicked(AdapterLabel item);

		void onSplitClicked(AdapterLabel item);

		void onOzmViewClicked(AdapterLabel item);

		void onTransferClicked(AdapterLabel item);
	}

	public boolean isOffline() {
		return offline;
	}

	public boolean isShowOzmHead() {
		return showOzmHead;
	}

	private final Label label;

	public IListener getListener() {
		return listener;
	}

	public AdapterLabelGroup getGroup() {
		return group;
	}

	public void setCheckedDate(Date checkedDate) {
		this.checkedDate = checkedDate;
	}

	public Date getCheckedDate() {
		return checkedDate;
	}

	public void setGroup(AdapterLabelGroup group) {
		this.group = group;
	}

	public AdapterLabel(@Nullable AdapterLabelGroup group, Label label, boolean showOzmHead, boolean showCheck, boolean checked, boolean offline, boolean discount, IListener listener) {
		this.group = group;
		this.listener = listener;
		this.showOzmHead = showOzmHead;
		this.label = label;
		this.showCheck = showCheck;
		this.checked = checked;
		this.discount = discount;
		this.offline = offline;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		setChecked(checked, -1);
	}

	public void setChecked(boolean checked, int nettoFact) {
		this.checked = checked;
		this.checkedDate = checked ? Calendar.getInstance().getTime() : null;
		this.nettoFact = nettoFact;
	}

	public boolean isShowCheck() {
		return showCheck;
	}

	public Label getLabel() {
		return label;
	}

	@Override
	public boolean equals(Object o) {
		return o instanceof AdapterLabel && ((AdapterLabel) o).getLabel().getId().equals(getLabel().getId());
	}

	@Override
	public int hashCode() {
		return getLabel().hashCode();
	}

	@Override
	public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
		return new ViewHolder(view, adapter);
	}

	@Override
	public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {

		if (discount) {
		holder.buttonEdit.setVisibility(View.GONE);
		holder.buttonSplit.setVisibility(View.GONE);
		holder.buttonTransfer.setVisibility(View.GONE);
		holder.imageCheck.setVisibility(View.GONE);
		holder.textTitle.setVisibility(View.GONE);
		} else {

			holder.viewEditor.setVisibility(isOffline() ? View.GONE : View.VISIBLE);
		holder.viewCheck.setVisibility(isShowCheck() ? View.VISIBLE : View.GONE);
		if (isShowCheck()) {
			if (isChecked()) {
				holder.imageCheck.setImageResource(R.drawable.ic_check_24dp);
			} else {
				holder.imageCheck.setImageDrawable(null);
			}
		}

		if (label.getName().length() > 0) {
			String labelIdTitle = "LabelID: %s";
			if (label.getWeightNetto() != label.getWeightStart()){
				labelIdTitle = "<font color=\"blue\"><b>LabelID: %s</b></font>";
			}
			holder.textTitle.setText(showOzmHead ? label.getName() : App.getInstance().fromHtml(Utils.format(labelIdTitle, label.getId())));
				holder.textTitle.setVisibility(View.VISIBLE);
		} else {
			holder.textTitle.setVisibility(View.GONE);
		}
			holder.buttonEdit.setVisibility(View.VISIBLE);
		}

		StringBuilder sb = new StringBuilder();

		if (showOzmHead) {
			String size = App.getInstance().sizeToString(label.getWidth(), label.getLength(), label.getThickness());
			if (!discount && size.length() > 0) sb.append(Utils.format("%s<br>", size));
			if (label.getOzm().length() > 0)
				sb.append(Utils.format("ОЗМ: %s<br>", label.getOzm()));
			sb.append(Utils.format("<b>LabelID: %s</b><br>", label.getId()));
		}

		if (Utils.isNullOrEmpty(label.getZavBatch())) {
			if (label.getBatchUcenka() != null && label.getBatchUcenka().length() > 0) {
				sb.append(Utils.format("Партія: %s->%s<br>", label.getBatch(), label.getBatchUcenka()));
			} else
				sb.append(Utils.format("Партія: %s<br>", label.getBatch()));
		} else {
			sb.append(Utils.format("Зав. партія: %s<br>", label.getZavBatch()));
		}

		if (!Utils.isNullOrEmpty(label.getZavPlavka())) {
			sb.append(Utils.format("Зав. плавка: %s<br>", label.getZavPlavka()));
		}

		if (!Utils.isNullOrEmpty(label.getZavOdin())) {
			sb.append(Utils.format("№ од. прод.: %s<br>", label.getZavOdin()));
		}
		if (discount && !Utils.isNullOrEmpty(label.getLowPricePercent())) {
			sb.append(Utils.format("Змiна уцiнки: %s<br>", label.getDiscount()+"->"+label.getLowPricePercent()));
		}

		if (label.getWeightNetto() != -1) {
			if (nettoFact == -1) {
				sb.append(Utils.format("Вага НЕТТО, тн: %.3f (%s)<br>", (label.getWeightNetto() / 1000.0f), label.isTheor() ? "ТВ" : "ФВ"));
			} else {
				sb.append(Utils.format("НЕТТО план, тн: %.3f (%s)<br>", label.getWeightNetto() / 1000.0f, label.isTheor() ? "ТВ" : "ФВ"));
				sb.append(Utils.format("НЕТТО факт, тн: %.3f<br>", nettoFact / 1000.0f));
			}
		}

		sb.append(Utils.format("Склад: %s<br>", Utils.isNullOrEmpty(label.getStorage()) ? "-" : label.getStorage()));

		//СТАТУС
		if (label.getStatus().length() > 0) {
			if (label.isRelease()) {
				sb.append(Utils.format("Статус: %s<br>", "<font color=\"#145A32\">Оприходувано SAP</font>"));
			} else {
				sb.append(Utils.format("Статус: %s<br>", Utils.getLabelStatusDescr(label.getStatus())));
			}
		}

		//proizvod, PRICHINA_OTSORT
		if (label.getManufacturer().length() > 0)
			sb.append(Utils.format("Производитель: %s<br>", label.getManufacturer()));
		if (label.getSortCriterion().length() > 0)
			sb.append(Utils.format("Причина отсортировки: %s<br>", label.getSortCriterion()));

		//sb.append(Utils.format("Статус: %s<br>", Utils.getLabelStatusDescr(label.getStatus())));
		//sb.append(Utils.format("%s<br>", label.isRelease() ? "<font color=\"#145A32\">Оприходувано SAP</font>" : "<font color=\"red\">Не оприходувано</font>"));
		//

		if (checkedDate != null) {
			sb.append(Utils.format("Відскановано: <font color=\"blue\">%s</font><br>", App.getInstance().getTimeFormat().format(checkedDate)));
		}

		holder.viewLocations.setVisibility(label.getLocationCode().length() > 0 ? View.VISIBLE : View.GONE);

		if (label.getLocationCode().length() > 0) {
			holder.textLocation.setText(Utils.format("Локація: %s", label.getLocationCode()));
		}

		holder.buttonPrint.setVisibility(View.VISIBLE);

		String content = sb.toString();
		if (content.endsWith("<br>")) {
			content = content.substring(0, content.length() - 4);
		}

		holder.textContent.setText(App.getInstance().fromHtml(content));

		if (listener != null) {
			holder.textTitle.setOnClickListener(v -> listener.onOzmViewClicked(this));
			holder.buttonPrint.setOnClickListener(v -> listener.onPrintClicked(this));
			holder.buttonEdit.setOnClickListener(v -> listener.onEditClicked(this));
			holder.buttonSplit.setOnClickListener(v -> listener.onSplitClicked(this));
			holder.buttonTransfer.setOnClickListener(v -> listener.onTransferClicked(this));
		}

        /*View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
        Utils.setOnFocusListener(onFocusChangeListener,
                holder.itemView, holder.textTitle, holder.textContent,
                holder.buttonEdit, holder.buttonPrint, holder.buttonSplit,
                holder.viewLocations, holder.viewCheck
        );

        refreshBackground(holder, holder.itemView.isFocused());*/
	}

    /*private void refreshBackground(ViewHolder holder, boolean hasFocus) {
        holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_background));
    }*/

	public int getNettoFact() {
		return nettoFact;
	}

	@Override
	public int getLayoutRes() {
		return R.layout.adapter_label;
	}

	static class ViewHolder extends FlexibleViewHolder {

		@BindView(R.id.textTitle)
		TextView textTitle;
		@BindView(R.id.textContent)
		TextView textContent;
		@BindView(R.id.buttonPrint)
		ImageButton buttonPrint;
		@BindView(R.id.buttonEdit)
		ImageButton buttonEdit;
		@BindView(R.id.buttonSplit)
		ImageButton buttonSplit;
		@BindView(R.id.buttonTransfer)
		ImageButton buttonTransfer;
		@BindView(R.id.viewLocations)
		View viewLocations;
		@BindView(R.id.textLocation)
		TextView textLocation;
		@BindView(R.id.viewCheck)
		View viewCheck;
		@BindView(R.id.imageCheck)
		ImageView imageCheck;
		@BindView(R.id.viewEditor)
		View viewEditor;

		ViewHolder(View view, FlexibleAdapter adapter) {
			super(view, adapter);
			ButterKnife.bind(this, view);
		}
	}
}
