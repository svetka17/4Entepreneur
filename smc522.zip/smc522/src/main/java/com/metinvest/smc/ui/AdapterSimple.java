package com.metinvest.smc.ui;

import android.view.View;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterSimple extends AbstractFlexibleItem<AdapterSimple.ViewHolder> {

    private final String id;
    private final String title, content;

    public AdapterSimple(String id, String title, String content) {
        this.id = id;
        this.title = title;
        this.content = content;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof AdapterSimple && ((AdapterSimple) o).getTitle().equalsIgnoreCase(getTitle());
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    @Override
    public ViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
        return new ViewHolder(view, adapter);
    }

    @Override
    public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, ViewHolder holder, int position, List<Object> payloads) {
        String data = Utils.format("<b>%s</b>", getTitle());
        holder.textTitle.setText(App.getInstance().fromHtml(data));
        holder.textContent.setVisibility(getContent() == null ? View.GONE : View.VISIBLE);
        holder.textContent.setText(App.getInstance().fromHtml(getContent()));

        View.OnFocusChangeListener onFocusChangeListener = (v, hasFocus) -> refreshBackground(holder, hasFocus);
        holder.itemView.setOnFocusChangeListener(onFocusChangeListener);
        refreshBackground(holder, holder.itemView.isFocused());
    }

    private void refreshBackground(ViewHolder holder, boolean hasFocus) {
        holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), hasFocus ? R.color.color_yellow : R.color.color_adapter_light));
    }

    @Override
    public int getLayoutRes() {
        return R.layout.adapter_simple;
    }

    public static class ViewHolder extends FlexibleViewHolder {

        public TextView textTitle, textContent;

        public ViewHolder(View view, FlexibleAdapter adapter) {
            super(view, adapter);
            this.textTitle = view.findViewById(R.id.textTitle);
            this.textContent = view.findViewById(R.id.textContent);
        }
    }
}
