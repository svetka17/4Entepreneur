package com.metinvest.smc.view;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import butterknife.BindView;
import butterknife.ButterKnife;

public class QrInfoActivity extends MyActivity implements IScan {

	@BindView(R.id.qrText)
	EditText qrText;
	@BindView(R.id.buttonAccept)
	Button buttonAccept;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_qr_info);
		ButterKnife.bind(this);
		setActionDone(qrText, buttonAccept);
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		qrText.requestFocus();
	}

	@Override
	protected String getHelpContent() {
		return "Відскануйте штрихкод";
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 5) {
			buttonAcceptClick();
		}
	}

	private void buttonAcceptClick() {
		if (isLoading() || !buttonAccept.isEnabled()) return;

		if (qrText.getText().length() == 0) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, "Відскануйте або введіть вручну штрихкод!", null);
			return;
		}

		String newIdQr = qrText.getText().toString();
		showInfoByIdQr(newIdQr);
	}

	@Override
	public void onBarcodeEvent(String barcodeData) {
		if (isLoading()) return;

		runOnUiThread(() -> {
			qrText.setText(barcodeData);
			processBarcode(barcodeData);
			qrText.setText(null);
		});
	}

	private void processBarcode(String data) {
		ScanItem scanItem = new ScanItem(data);

		if (!scanItem.isCorrect()) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_identity_error, null);
		} else {
			if (scanItem.getType() == ScanItem.ScanItemType.ZAPOR) {
				beginLoadLabelZapor(scanItem);
			} else if (scanItem.getType() == ScanItem.ScanItemType.KOMINMET) {
				beginLoadLabelKominmet(scanItem);
			} else if (scanItem.getType() == ScanItem.ScanItemType.TRUBOSTAL) {
				beginLoadLabelTrubostal(scanItem);
			} else if (scanItem.getType() == ScanItem.ScanItemType.ARCELOR) {
				beginLoadLabelArcelor(scanItem);
			} else {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_identity_error, null);
			}
		}
	}

	private void beginLoadLabelArcelor(ScanItem scanItem) {
		String idQr = scanItem.getData(0);
		showInfoByIdQr(idQr);
	}

	private void beginLoadLabelTrubostal(ScanItem scanItem) {
		String idQr = scanItem.getData(8);
		showInfoByIdQr(idQr);
	}

	private void beginLoadLabelKominmet(ScanItem scanItem) {
		String idQr = scanItem.getData(1);
		showInfoByIdQr(idQr);
	}

	private void beginLoadLabelZapor(ScanItem scanItem) {
		String idQr = Utils.format("%s&%s&%s&%s",
				scanItem.getData(1),
				scanItem.getData(2),
				scanItem.getData(3),
				scanItem.getData(4)
		);
		showInfoByIdQr(idQr);
	}
}

