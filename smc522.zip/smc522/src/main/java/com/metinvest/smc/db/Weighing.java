package com.metinvest.smc.db;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.metinvest.smc.tools.IValue;

@Entity
public class Weighing implements IValue {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private int number;
    private int weightCrane;
    private int packCount;

    public Weighing() {

    }

    @Ignore
    public Weighing(long id, int number, int weightCrane, int packCount) {
        this.id = id;
        this.number = number;
        this.weightCrane = weightCrane;
        this.packCount = packCount;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getWeightCrane() {
        return weightCrane;
    }

    public void setWeightCrane(int weightCrane) {
        this.weightCrane = weightCrane;
    }

    public int getPackCount() {
        return packCount;
    }

    public void setPackCount(int packCount) {
        this.packCount = packCount;
    }

    @Override
    public String getName() {
        return String.valueOf(getNumber());
    }
}
