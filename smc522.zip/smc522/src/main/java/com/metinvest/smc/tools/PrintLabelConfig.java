package com.metinvest.smc.tools;

import java.util.Date;

public class PrintLabelConfig {
	private String dataMatrix;
	private String labelId;
	private String name;
	private String size;
	private String ozm;
	private String zavPlavka;
	private String zavBatch;
	private String zavOdin;

	private String postavkaMera;
	private String proizvod;

	private String lgort;
	private int bruttoKg;
	int nettoKg;
	int packKg;
	private String transport;
	private String batch;
	private boolean isTheor;
	private int theorCount;
	private String lowPrice;
	private String user;
	private Date date;
	private String location;
	private String idQr;

	public String getDataMatrix() {
		return dataMatrix;
	}

	public String getLabelId() {
		return labelId;
	}

	public String getName() {
		return name;
	}

	public String getSize() {
		return size;
	}

	public String getOzm() {
		return ozm;
	}

	public String getZavPlavka() {
		return zavPlavka;
	}

	public String getZavBatch() {
		return zavBatch;
	}

	public String getZavOdin() {
		return zavOdin;
	}

	public int getBruttoKg() {
		return bruttoKg;
	}

	public int getNettoKg() {
		return nettoKg;
	}

	public int getPackKg() {
		return packKg;
	}

	public String getTransport() {
		return transport;
	}

	public String getBatch() {
		return batch;
	}

	public boolean isTheor() {
		return isTheor;
	}

	public int getTheorCount() {
		return theorCount;
	}

	public String getLowPrice() {
		return lowPrice;
	}

	public String getUser() {
		return user;
	}

	public Date getDate() {
		return date;
	}

	public String getLocation() {
		return location;
	}

	public String getIdQr() {
		return idQr;
	}

	public String getPostavkaMera() {
		return postavkaMera;
	}

	public String getProizvod() {
		return proizvod;
	}

	public String getLgort() {
		return lgort;
	}

	public PrintLabelConfig withDataMatrix(String dataMatrix) {
		this.dataMatrix = dataMatrix;
		return this;
	}

	public PrintLabelConfig withProizvod(String proizvod) {
		this.proizvod = proizvod;
		return this;
	}

	public PrintLabelConfig withLgort(String lgort) {
		this.lgort = lgort;
		return this;
	}

	public PrintLabelConfig withPostavkaMera(String postavkaMera) {
		this.postavkaMera = postavkaMera;
		return this;
	}

	public PrintLabelConfig withLabelId(String labelId) {
		this.labelId = labelId;
		return this;
	}

	public PrintLabelConfig withName(String name) {
		this.name = name;
		return this;
	}

	public PrintLabelConfig withSize(String size) {
		this.size = size;
		return this;
	}

	public PrintLabelConfig withOzm(String ozm) {
		this.ozm = ozm;
		return this;
	}

	public PrintLabelConfig withZavPlavka(String zavPlavka) {
		this.zavPlavka = zavPlavka;
		return this;
	}

	public PrintLabelConfig withZavBatch(String zavBatch) {
		this.zavBatch = zavBatch;
		return this;
	}

	public PrintLabelConfig withZavOdin(String zavOdin) {
		this.zavOdin = zavOdin;
		return this;
	}

	public PrintLabelConfig withBruttoKg(int bruttoKg) {
		this.bruttoKg = bruttoKg;
		return this;
	}

	public PrintLabelConfig withNettoKg(int nettoKg) {
		this.nettoKg = nettoKg;
		return this;
	}

	public PrintLabelConfig withPackKg(int packKg) {
		this.packKg = packKg;
		return this;
	}

	public PrintLabelConfig withTransport(String transport) {
		this.transport = transport;
		return this;
	}

	public PrintLabelConfig withBatch(String batch) {
		this.batch = batch;
		return this;
	}

	public PrintLabelConfig withTheor(boolean theor) {
		isTheor = theor;
		return this;
	}

	public PrintLabelConfig withTheorCount(int theorCount) {
		this.theorCount = theorCount;
		return this;
	}

	public PrintLabelConfig withLowPrice(String lowPrice) {
		this.lowPrice = lowPrice;
		return this;
	}

	public PrintLabelConfig withUser(String user) {
		this.user = user;
		return this;
	}

	public PrintLabelConfig withDate(Date date) {
		this.date = date;
		return this;
	}

	public PrintLabelConfig withLocation(String location) {
		this.location = location;
		return this;
	}

	public PrintLabelConfig withIdQr(String idQr) {
		this.idQr = idQr;
		return this;
	}
}
