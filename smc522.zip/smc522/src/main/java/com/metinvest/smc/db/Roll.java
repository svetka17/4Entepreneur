package com.metinvest.smc.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.metinvest.smc.App;
import com.metinvest.smc.tools.Utils;

import java.util.Date;

@Entity
public class Roll {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private int stock;
    private String smcId, storage, storageName, ozm, materialName, batch, baseEi, markdown, materialGroup, dateVozn, category, travl, s2, mera, s4, s5, s6, s7, s8, codeUktVed, manufacturer;
    private float thickness, width, length;
    private long nameId, nameInfoId;
    private boolean actual;
    //private int stockUsed;
    private long dt;

    public Roll() {
    }

    @Ignore
    public Roll(long id, long nameId, long nameInfoId, String smcId, String storage, String storageName, String ozm, String materialName, String batch, String baseEi, int stock, float thickness, float width, float length, String markdown, String materialGroup, String dateVozn, String category, String travl, String s2, String mera, String s4, String s5, String s6, String s7, String s8, String codeUktVed, String manufacturer) {
        this.id = id;
        this.nameId = nameId;
        this.nameInfoId = nameInfoId;
        this.smcId = smcId;
        this.storage = storage;
        this.storageName = storageName;
        this.ozm = ozm;
        this.materialName = materialName;
        this.batch = batch;
        this.baseEi = baseEi;
        this.stock = stock;
        this.markdown = markdown;
        this.materialGroup = materialGroup;
        this.dateVozn = dateVozn;
        this.category = category;
        this.travl = travl;
        this.s2 = s2;
        this.mera = mera;
        this.s4 = s4;
        this.s5 = s5;
        this.s6 = s6;
        this.s7 = s7;
        this.s8 = s8;
        this.codeUktVed = codeUktVed;
        this.manufacturer = manufacturer;
        this.width = width;
        this.length = length;
        this.thickness = thickness;
        //this.stockUsed = 0;
        Date date = App.getInstance().parseDate(this.s2);
        this.dt = date == null ? 0 : date.getTime();
        this.actual = true;
    }

    public boolean isActual() {
        return actual;
    }

    public void setActual(boolean actual) {
        this.actual = actual;
    }

    public long getNameInfoId() {
        return nameInfoId;
    }

    public void setNameInfoId(long nameInfoId) {
        this.nameInfoId = nameInfoId;
    }

    public long getDt() {
        return dt;
    }

    public void setDt(long dt) {
        this.dt = dt;
    }

    /*public int getStockUsed() {
        return stockUsed;
    }

    public void setStockUsed(int stockUsed) {
        this.stockUsed = stockUsed;
    }*/

    public long getNameId() {
        return nameId;
    }

    public void setNameId(long nameId) {
        this.nameId = nameId;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSmcId() {
        return smcId;
    }

    public void setSmcId(String smcId) {
        this.smcId = smcId;
    }

    public String getStorage() {
        return storage;
    }

    public void setStorage(String storage) {
        this.storage = storage;
    }

    public String getStorageName() {
        return storageName;
    }

    public void setStorageName(String storageName) {
        this.storageName = storageName;
    }

    public String getOzm() {
        return ozm;
    }

    public void setOzm(String ozm) {
        this.ozm = ozm;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public String getBaseEi() {
        return baseEi;
    }

    public void setBaseEi(String baseEi) {
        this.baseEi = baseEi;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public float getThickness() {
        return thickness;
    }

    public void setThickness(float thickness) {
        this.thickness = thickness;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getLength() {
        return length;
    }

    public void setLength(float length) {
        this.length = length;
    }

    public String getMarkdown() {
        return markdown;
    }

    public void setMarkdown(String markdown) {
        this.markdown = markdown;
    }

    public String getMaterialGroup() {
        return materialGroup;
    }

    public void setMaterialGroup(String materialGroup) {
        this.materialGroup = materialGroup;
    }

    public String getDateVozn() {
        return dateVozn;
    }

    public void setDateVozn(String dateVozn) {
        this.dateVozn = dateVozn;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getTravl() {
        return travl;
    }

    public void setTravl(String travl) {
        this.travl = travl;
    }

    public String getS2() {
        return s2;
    }

    public void setS2(String s2) {
        this.s2 = s2;
    }

    public String getMera() {
        return mera;
    }

    public void setMera(String mera) {
        this.mera = mera;
    }

    public String getS4() {
        return s4;
    }

    public void setS4(String s4) {
        this.s4 = s4;
    }

    public String getS5() {
        return s5;
    }

    public void setS5(String s5) {
        this.s5 = s5;
    }

    public String getS6() {
        return s6;
    }

    public void setS6(String s6) {
        this.s6 = s6;
    }

    public String getS7() {
        return s7;
    }

    public void setS7(String s7) {
        this.s7 = s7;
    }

    public String getS8() {
        return s8;
    }

    public void setS8(String s8) {
        this.s8 = s8;
    }

    public String getCodeUktVed() {
        return codeUktVed;
    }

    public void setCodeUktVed(String codeUktVed) {
        this.codeUktVed = codeUktVed;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    @NonNull
    @Override
    public String toString() {
        return Utils.format("[%d] %s %d", getId(), getBatch(), getStock());
    }

    /*public int getAvailableNetto() {
        return getStock() - getStockUsed();
    }*/
}
