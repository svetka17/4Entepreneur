package com.metinvest.smc.tools;

import androidx.annotation.NonNull;

public class Value implements IValue {
    private long id;
    private String name;

    public Value(long id, String name) {
        this.id = id;
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NonNull
    @Override
    public String toString() {
        return Utils.format("[%s] %s", getId(), getName());
    }
}
