package com.metinvest.smc.view;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Inv;
import com.metinvest.smc.db.InvInfo;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class InvActivity extends MyActivity {

    @BindView(R.id.buttonDate)
	Button buttonDate;
	//@BindView(R.id.textStorage)
	//EditText textStorage;
	@BindView(R.id.textStorageTitle) TextView textStorageTitle;
	@BindView(R.id.buttonListLoad)
	Button buttonListLoad;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;
    @BindView(R.id.buttonReportGroup)
    Button buttonReportGroup;
    @BindView(R.id.textContent)
    TextView textContent;

    private Date date;
    private boolean dateSelected = false;
    private InvInfo invInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inv);
        ButterKnife.bind(this);
		date = Calendar.getInstance().getTime();
		textStorageTitle.setText(Utils.format("Склад: %s", config.getStorage()));

        refreshButtons();
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        loadInfo();
    }

    private void loadInfo() {
        List<InvInfo> info = db.invInfoDao().getAll();
        invInfo = info.isEmpty() ? null : info.get(0);
        showContent();
    }

    private void refreshButtons() {
        buttonDate.setText(dateSelected ? app.getDateFormat().format(date) : "Не вказана");
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) buttonDateClick();
            //else if (number == 3) textStorage.post(() -> textStorage.requestFocus());
        else if (number == 4) buttonLoadClick();
        else if (number == 5) buttonAcceptClick();
            //else if (number == 6) buttonRollClick();
        else if (number == 6) buttonReportGroupClick();
        else if (number == 7) buttonReportLocationClick();
    }

    private void buttonRollClick() {
        startActivity(new Intent(this, RollActivity.class));
    }

    private void buttonReportLocationClick() {
        if (isLoading()) return;

        if (!dateSelected) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.inv_date_not_selected, null);
            return;
        }

		String storage = config.getStorage();

        if (storage.isEmpty()) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.text_error_storage_empty, null);
            //textStorage.post(() -> textStorage.requestFocus());
            return;
        }

        startActivityForResult(new Intent(this, LocationListActivity.class), REQUEST_LOCATION_SELECT);
    }

    private void buttonReportGroupClick() {
        if (isLoading()) return;

        if (!dateSelected) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.inv_date_not_selected, null);
            return;
        }

        if (invInfo == null) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.inv_report_no_downloaded, null);
        } else {
            beginReportGroup();
        }
    }

    private void beginReportGroup() {
		String storage = config.getStorage();

        Intent intent = new Intent(this, InvReportActivity.class);
        intent.putExtra("date", date);
        intent.putExtra("storage", storage);
        startActivity(intent);
    }

    private boolean permis = false;

    private void buttonLoadClick() {
        if (isLoading() || !buttonListLoad.isEnabled())
            return;

        if (!dateSelected) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.inv_date_not_selected, null);
            return;
        }

        if (!permis) {
            Intent intent = new Intent(this, PincodeActivity.class);
            intent.putExtra("action", "load");
            startActivityForResult(intent, REQUEST_ACTION);
            return;
        }

        beginLoad();
    }

    private void buttonDateClick() {
        Calendar calendar = Utils.toCalendar(date);

        DatePickerDialog dialog = new DatePickerDialog(this,
                (view1, year, month, dayOfMonth) -> {
                    Calendar calendar1 = Calendar.getInstance();
                    calendar1.set(year, month, dayOfMonth);
                    date = calendar1.getTime();
                    dateSelected = true;
                    refreshButtons();
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DATE));
        dialog.show();
    }

    private void buttonAcceptClick() {

        if (!dateSelected) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.inv_date_not_selected, null);
            return;
        }

		String storage = config.getStorage();

        if (storage.isEmpty()) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_error, R.string.text_error_storage_empty, null);
            //textStorage.post(() -> textStorage.requestFocus());
            return;
        }

        Intent intent = new Intent(this, InvLocationActivity.class);
        intent.putExtra("date", date);
        intent.putExtra("storage", storage);
        startActivity(intent);
    }

    private void beginLoad() {
        showLoading(R.string.text_please_wait);
        buttonListLoad.setEnabled(false);
        loadInfo();

        Utils.runOnBackground(() -> {

            invInfo = null;
            db.invDao().truncate();
            db.invInfoDao().truncate();

            /*String url = config.getUrlApi() + "getfile";
            url = net.addUrlParam(url, "Subtype", "Inbox");
            url = net.addUrlParam(url, "FileName", "stock");
            url = net.addUrlParam(url, "FileExt", "csv");

            NetworkResult result = net.downloadFile(url, true);*/
            String url = config.getUrlApi() + "inventorydata";
            url = net.addUrlParam(url, "date", app.getDateFormat().format(date));
            JsonResult result = net.downloadJson(url);

            db.invDao().truncate();

            if (result.isOk()) {

                InvInfo invInfoNew = new InvInfo();

                //log("%s %d kb", result.getFile().getName(), result.getFile().length() / 1024);

                invInfoNew.setId(0);
                invInfoNew.setInvDate(date.getTime()/* Calendar.getInstance().getTime().getTime()*/);

                List<Inv> invs = new ArrayList<>();

                JSONArray array = Utils.getJsonArray(result.getJson(), "data");
                log("%s %d kb", "inventorydata", result.getJson().length() / 1024);

                //String[] lines = data.split("\r\n");
                if (array != null) {
                    long lineId = 0;
                    for (int i = 0; i < array.length(); i++) {
                        String line = Utils.getJsonString(array, i);
                        if (lineId > 0) {
                            Inv inv = processLine(line);
                            if (inv != null) invs.add(inv);
                        }
                        lineId++;
                    }
                }

                /*try {

                    long fileLength = result.getFile().length();
                    long fileReadedLength = 0;

                    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(result.getFile()), "windows-1251"));
                    String line;
                    long lineId = 0;

                    float percent = 0;
                    showPercentage(percent);

                    while ((line = br.readLine()) != null) {

                        fileReadedLength += line.length();
                        float percentNew = fileReadedLength * 100.0f / fileLength;
                        if (percentNew - percent >= 10.0f) {
                            percent = percentNew;
                            showPercentage(percent);
                        }

                        if (lineId > 0) {
                            Inv inv = processLine(line);
                            if (inv != null) invs.add(inv);
                        }
                        lineId++;
                    }

                    br.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }*/

                showPercentage(95);
                db.invDao().insertAll(invs);

                invInfoNew.setInvCount(db.invDao().getCount());
                db.invInfoDao().insert(invInfoNew);
            }

            runOnUiThread(() -> endLoad(result));
        });
    }

    private void showPercentage(float percent) {
        runOnUiThread(() -> {
            if (isLoading()) {
                showLoading(getString(R.string.text_please_wait2, (int) percent));
            }
        });
    }

    private Inv processLine(String line) {
        try {
            String[] arr = line.split(";");

            String category = arr[2];
            int percent = Utils.parseInt(arr[3]);
            String smcId = arr[4];
            String storage = arr[5];
            String storageName = storage;
            String ozm = arr[6];
            String name = arr[7];
            String batch = arr[8];
            int nett = (int) Math.round(Utils.parseDouble(arr[10]) * /**/ 1000);
            float thickness = Utils.parseFloat(Utils.getArrayItem(arr, 11).replace(" ", ""));
            float width = Utils.parseFloat(Utils.getArrayItem(arr, 12).replace(" ", ""));
            float length = Utils.parseFloat(Utils.getArrayItem(arr, 13).replace(" ", ""));
            String markdown = Utils.getArrayItem(arr, 14);
            String group = Utils.getArrayItem(arr, 15);

            return new Inv(
                    0,
                    category,
                    percent,
                    smcId,
                    storage, storageName, ozm, name, batch, "", nett, thickness, width, length,
                    markdown, group, "", "", "", "",
                    "", "", "", "", "", "",
                    "", ""
            );

        } catch (Exception e) {
            log(e, "processLine(%s)", line);
            return null;
        }
    }

    private void endLoad(JsonResult result) {

        loadInfo();
        hideLoading();
        buttonListLoad.setEnabled(true);

        if (result.isOk()) {
            showToast(Utils.format("Завантажено позицій: %d", invInfo.getInvCount()));
        } else if (result.getStatus() == LoadResultStatus.H004) {
            showToast(R.string.file_not_found);
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> buttonLoadClick());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_LOCATION_SELECT && resultCode == RESULT_OK && data != null) {
            String locationCode = data.getStringExtra("id");
            log("location %s", locationCode);
            beginReportLocation(locationCode);
        }

        if (requestCode == REQUEST_ACTION && resultCode == RESULT_OK && data != null) {

            String intentAction = data.getStringExtra("action");

            if (intentAction.equalsIgnoreCase("load")) {
                permis = true;
                beginLoad();
            }

        }
    }

    private void beginReportLocation(String locationCode) {
		String storage = config.getStorage();

        showLoading(R.string.text_please_wait);

        String url = config.getUrlApi() + "getinventoryonlinedeltas";
        url = net.addUrlParam(url, "wh_type", storage);
        url = net.addUrlParam(url, "inv_date", app.getDateFormat2().format(date));
        reqGet(url, result -> endReportLocation(result, locationCode));
    }

    private void endReportLocation(JsonResult result, String locationCode) {
        hideLoading();

        if (result.isOk() || result.getStatus() == LoadResultStatus.PLUS2) {
            ArrayList<String> list = new ArrayList<>();

            JSONArray array = Utils.getJsonArray(result.getJson(), "data");
            for (int i = 0; array != null && i < array.length(); i++) {
                JSONObject json = Utils.getJsonObject(array, i);
                if (json != null) {
                    String jsonLoc = Utils.getJsonStringIgnoreCase(json, "location_Code");
                    //String jsonDt = Utils.getJsonStringIgnoreCase(json, "scan_DateTime");

                    if (jsonLoc.equalsIgnoreCase(locationCode))
                        list.add(json.toString());
                }
            }

            openLocationList(locationCode, list);
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginReportLocation(locationCode));
        }
    }

    public void openLocationList(String locationCode, ArrayList<String> checkedLabelList) {
        Intent intent = new Intent(this, BarcodeResultActivity.class);
        intent.putExtra("type", ShowInfoType.BY_LOCATION_CODE);
        intent.putExtra("locationCode", locationCode);
        if (checkedLabelList != null) {
            intent.putStringArrayListExtra("checkedList", checkedLabelList);
            intent.putExtra("canScan", false);
        }
        intent.putExtra("canRefresh", false);
        intent.putExtra("action", "block");
        intent.putExtra("actionTitle", getString(R.string.button_block_location));
        startActivityForResult(intent, REQUEST_VIEW);
    }

    private void showContent() {
        StringBuilder sb = new StringBuilder();

        if (invInfo != null) {
            sb.append(Utils.format(
                    "Файл залишків від %s, %d рядки",
                    app.getDateTimeFormat().format(invInfo.getInvDate()), invInfo.getInvCount()
            ));
        }

        textContent.setText(app.fromHtml(sb.toString()));
    }
}
