package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.tools.Utils;

import org.json.JSONObject;

import java.util.Calendar;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;

public class InventoryManualActivity extends MyActivity {

    @BindView(R.id.textLabelId)
    EditText textLabelId;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_manual);
        ButterKnife.bind(this);
        int labelId = getIntent().getIntExtra("labelId", 0);
        if (labelId > 0) {
            textLabelId.setText(String.valueOf(labelId));
            buttonAcceptClick();
        }
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        showLoading(R.string.text_please_wait);
        buttonAccept.setEnabled(false);

        String labelId = textLabelId.getText().toString();

        String url = config.getUrlApi() + "getlabelinfo";
        url = net.addUrlParam(url, "label_id", labelId);
        reqGet(url, result -> endFind(labelId, result));
    }

	private void endFind(String labelId, JsonResult result) {
		hideLoading();
		buttonAccept.setEnabled(true);

        if (result.isOk()) {
            showInfo(labelId, result.getJson());
        } else if (result.getStatus() == LoadResultStatus.ZERO) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.labelid_not_found, (dialog, which) -> textLabelId.requestFocus());
        } else if (result.getStatus() == LoadResultStatus.S007) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_s007, (dialog, which) -> textLabelId.requestFocus());
        } else {
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_warning, app.getNetworkErrorMessage(result), (dialog, which) -> buttonAcceptClick());
        }
    }

    private void showInfo(String labelId, JSONObject jsonResult) {

        JSONObject json = Utils.getJsonObject(jsonResult, "data");

        Date date = Calendar.getInstance().getTime();
        String name = Utils.getJsonStringIgnoreCase(json, "name");
        float width = Utils.getJsonFloatIgnoreCase(json, "width");
        float length = Utils.getJsonFloatIgnoreCase(json, "length");
        float thickness = Utils.getJsonFloatIgnoreCase(json, "thickness");
        int nett = (int) Utils.getJsonFloatIgnoreCase(json, "netT_Weight");
        int pack = (int) Utils.getJsonFloatIgnoreCase(json, "pacK_Weight");
        String batch = Utils.getJsonStringIgnoreCase(json, "batch");
        String ozm = Utils.getJsonStringIgnoreCase(json, "ozm").replace("null", "");

        String data = Utils.format("%s|%s|%s|%s|%f|%f|%f|%d|%s|%s|%d|%d|%s|%d|%s|%s",
                "SMC06",
                labelId,
                app.getSmcIdCurrent(),
                name,
                length,
                width,
                thickness,
                nett,
                "ФВ",
                ozm,
                pack,
                0,
                batch == null ? "" : batch,
                0,
                "",
                ""
        );

        Intent intent = new Intent();
        intent.putExtra("data", data);
        setResult(RESULT_OK, intent);
        finish();

        /*String data = "";
        data += "<b>" + name + "</b><br>";
        data += "LabelID: " + labelId + "<br>";
        data += "Розмір: " + app.sizeToString(width, length, thickness) + "<br>";
        data += "Вага брутто: " + nett + " кг.<br>";
        data += "Вага упаковки: " + pack + " кг.<br>";
        data += "Партія: " + batch + "<br>";
        data += "ОЗМ: " + ozm + "<br>";
        textContent.setText(app.fromHtml(data));*/
    }

    @Override
    protected String getHelpContent() {
        return "Введіть LabelID та натисніть \"F5 - Прийняти\"";
    }
}
