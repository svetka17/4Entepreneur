package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;

import com.metinvest.smc.R;

public class ManagerActivity extends MyActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager);
    }

    @Override
    protected String getHelpContent() {
        return getString(R.string.select_operation_help);
    }

    @Override
    protected void onFunctionKey(int number) {
        switch (number) {
            case 2:
                startActivity(new Intent(this, BarcodeInfoActivity.class));
                break;
            case 3:
                startActivity(new Intent(this, QrInfoActivity.class));
                break;
            case 4:
                startActivity(new Intent(this, LocationInfoActivity.class));
                break;
            case 5:
                startActivity(new Intent(this, SearchOzmActivity.class));
                break;
            case 6:
                startActivity(new Intent(this, SearchBatchActivity.class));
                break;
            case 7:
                startActivity(new Intent(this, InvActivity.class));
                break;
            case 8:
                startActivity(new Intent(this, CloneActivity.class));
                break;
            case 9:
                startActivity(new Intent(this, UcenkaActivity.class));
                break;
        }
    }
}
