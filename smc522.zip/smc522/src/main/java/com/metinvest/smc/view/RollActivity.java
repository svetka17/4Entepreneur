package com.metinvest.smc.view;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Roll;
import com.metinvest.smc.db.RollInfo;
import com.metinvest.smc.db.RollName;
import com.metinvest.smc.db.RollNameInfo;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.IValue;
import com.metinvest.smc.tools.StoreItem;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.tools.Value;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class RollActivity extends MyActivity {

	@BindView(R.id.textContent)
	TextView textContent;
	@BindView(R.id.viewButtons)
	View viewButtons;
	@BindView(R.id.buttonListLoad)
	Button buttonListLoad;
	@BindView(R.id.buttonWeighing)
	Button buttonWeighing;
	@BindView(R.id.viewInv)
	View viewInv;
	@BindView(R.id.buttonDate)
	Button buttonDate;
	@BindView(R.id.spinnerStorage)
	Spinner spinnerStorage;

	private Date date;
	private boolean dateSelected = false;
	private RollInfo rollInfo;
	private List<IValue> listStorage;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_roll);
		ButterKnife.bind(this);
		buttonWeighing.setEnabled(false);
		//textContent.setText(Utils.format("Очікую файл Rollout.csv для SMC_ID %s", config.getSmcId()));
		textContent.setText(null);

		boolean showInv = getIntent().getBooleanExtra("showInv", true);
		if (!showInv) {
			viewInv.setVisibility(View.GONE);
		}

		date = Calendar.getInstance().getTime();
		refreshButtons();
	}

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		beginLoadStorageList();
		loadInfo();
		if (rollInfo != null) showContent();
	}

	private void beginLoadStorageList() {
		showLoading(R.string.text_please_wait);

		Utils.runOnBackground(() -> {
			Network.NetworkResultValue<List<StoreItem>> result = net.loadStorageList(app.getSmcIdCurrent());
			runOnUiThread(() -> endLoadStorageList(result));
		});
	}

	private void endLoadStorageList(Network.NetworkResultValue<List<StoreItem>> result) {
		hideLoading();

		if (result.isOk()) {
			StoreItem storeItem = Utils.getSourceStoreItem(result.getValue());
			if (storeItem == null) {
				showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, R.string.error_data, (dialog, which) -> beginLoadStorageList(), (dialog, which) -> finish());
				return;
			}
			int selectedIndex = 0;
			listStorage = new ArrayList<>();
			for (int i = 0; i < storeItem.getStoreList().size(); i++) {
				if (storeItem.getStoreList().get(i).equalsIgnoreCase(config.getStorage()))
					selectedIndex = i;
				listStorage.add(new Value(i + 1, storeItem.getStoreList().get(i)));
			}

			Utils.fillData(spinnerStorage, listStorage);
			spinnerStorage.setSelection(selectedIndex);
		} else {
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result.getResult()), (dialog, which) -> beginLoadStorageList(), (dialog, which) -> finish());
		}
	}

	private String getSelectedStorage() {
		int pos = spinnerStorage.getSelectedItemPosition();
		return pos > 0 ? listStorage.get(pos).getName() : config.getStorage();
	}

	private void loadInfo() {
		List<RollInfo> info = db.rollInfoDao().getAll();
		rollInfo = info.isEmpty() ? null : info.get(0);
	}

	@Override
	protected void onFunctionKey(int number) {
		if (number == 2) {
			buttonDateClick();
		} else if (number == 4) {
			buttonLoadClick();
		} else if (number == 5) {
			buttonWeighingClick();
		} else if (number == 6) {
			startActivity(new Intent(this, InvActivity.class));
		}
	}

	private void buttonDateClick() {
		Calendar calendar = Utils.toCalendar(date);

		DatePickerDialog dialog = new DatePickerDialog(this,
				(view1, year, month, dayOfMonth) -> {
					Calendar calendar1 = Calendar.getInstance();
					calendar1.set(year, month, dayOfMonth);
					date = calendar1.getTime();
					dateSelected = true;
					refreshButtons();
				}, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DATE));
		dialog.show();
	}

	private void refreshButtons() {
		buttonDate.setText(dateSelected ? app.getDateFormat().format(date) : "Не вказана");
	}

	private boolean permis = false;

	private void buttonLoadClick() {
		if (isLoading() || viewButtons.getVisibility() != View.VISIBLE || !buttonListLoad.isEnabled())
			return;

		if (!dateSelected) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.roll_date_not_selected, null);
			return;
		}

		if (!permis) {
			Intent intent = new Intent(this, PincodeActivity.class);
			intent.putExtra("action", "load");
			startActivityForResult(intent, REQUEST_ACTION);
			return;
		}

		beginLoad();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == REQUEST_ACTION && resultCode == RESULT_OK && data != null) {

			String intentAction = data.getStringExtra("action");

			if (intentAction != null && intentAction.equalsIgnoreCase("load")) {
				permis = true;
				beginLoad();
			}

		}
	}

	private void beginLoad() {
		showLoading(R.string.text_please_wait);
		buttonListLoad.setEnabled(false);
		viewButtons.setVisibility(View.GONE);

		Utils.runOnBackground(() -> {

			rollInfo = null;
			db.rollDao().truncate();
			db.rollNameDao().truncate();
			db.rollInfoDao().truncate();
			db.rollNameInfoDao().truncate();

            /*String url = config.getUrlApi() + "getfile";
            url = net.addUrlParam(url, "Subtype", "Inbox");
            url = net.addUrlParam(url, "FileName", "rollout");
            url = net.addUrlParam(url, "FileExt", "csv");*/

			String url = config.getUrlApi() + "inventorydata";
			url = net.addUrlParam(url, "date", app.getDateFormat().format(date));
			JsonResult result = net.downloadJson(url);

			//NetworkResult result = net.downloadFile(url, true);

			db.rollDao().truncate();
			db.rollNameDao().truncate();
			db.rollInfoDao().truncate();
			db.rollNameInfoDao().truncate();

			if (result.isOk()) {

				//long fileLength = result.getFile().length();
				//long fileReadedLength = 0;

				RollInfo rollInfoNew = new RollInfo();

				//log("%s %d kb", result.getFile().getName(), result.getFile().length() / 1024);

				rollInfoNew.setId(0);
				rollInfoNew.setRollDate(date.getTime()/* Calendar.getInstance().getTime().getTime()*/);

				List<Roll> rolls = new ArrayList<>();

				JSONArray array = Utils.getJsonArray(result.getJson(), "data");
				log("%s %d kb", "inventorydata", result.getJson().length() / 1024);

				if (array != null) {
					long lineId = 0;
					for (int i = 0; i < array.length(); i++) {
						String line = Utils.getJsonString(array, i);
						if (lineId > 0) {
							Roll roll = processLine(line);
							if (roll != null) rolls.add(roll);
						}
						lineId++;
					}
				}

                /*try {

                    float percent = 0;
                    showPercentage(percent);

                    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(result.getFile()), "windows-1251"));

                    String line;
                    long lineId = 0;

                    while ((line = br.readLine()) != null) {

                        fileReadedLength += line.length();
                        float percentNew = fileReadedLength * 100.0f / fileLength;
                        if (percentNew - percent >= 10.0f) {
                            percent = percentNew;
                            showPercentage(percent);
                        }

                        if (lineId > 0) {
                            Roll roll = processLine(line);
                            if (roll != null) rolls.add(roll);
                        }

                        lineId++;
                    }

                    br.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }*/

				showPercentage(95);
				db.rollDao().insertAll(rolls);

				rollInfoNew.setRollCount(db.rollDao().getCount());
				rollInfoNew.setRollOzmCount(db.rollNameDao().getCount());
				db.rollInfoDao().insert(rollInfoNew);

				loadInfo();
			}

			runOnUiThread(() -> endLoad(result));
		});
	}

	private void showPercentage(float percent) {
		runOnUiThread(() -> {
			if (isLoading()) {
				showLoading(getString(R.string.text_please_wait2, (int) percent));
			}
		});
	}

	private Roll processLine(String line) {
		try {
			String[] arr = line.split(";");

            /*int nett = (int) (Utils.parseFloat(arr[7]) * 1000);
            String ozm = Utils.getArrayItem(arr, 3);
            String name = Utils.getArrayItem(arr, 4);
            float thickness = Utils.parseFloat(Utils.getArrayItem(arr, 8).replace(" ", ""));
            float width = Utils.parseFloat(Utils.getArrayItem(arr, 9).replace(" ", ""));
            float length = Utils.parseFloat(Utils.getArrayItem(arr, 10).replace(" ", ""));
            String markdown = Utils.getArrayItem(arr, 11);
            String mera = Utils.getArrayItem(arr, 17);
            String travl = Utils.getArrayItem(arr, 15);
            String batch = Utils.getArrayItem(arr, 5);*/

			String category = arr[2];
			int percent = Utils.parseInt(arr[3]);
			String smcId = arr[4];
			String storage = arr[5];
			String storageName = storage;
			String ozm = arr[6];
			String name = arr[7];
			String batch = arr[8];
			int nett = (int) Math.round(Utils.parseDouble(arr[10]) * /**/ 1000);
			float thickness = Utils.parseFloat(Utils.getArrayItem(arr, 11).replace(" ", ""));
			float width = Utils.parseFloat(Utils.getArrayItem(arr, 12).replace(" ", ""));
			float length = Utils.parseFloat(Utils.getArrayItem(arr, 13).replace(" ", ""));
			String markdown = Utils.getArrayItem(arr, 14);
			String group = Utils.getArrayItem(arr, 15);
			String travl = Utils.getArrayItem(arr, 18);
			String mera = Utils.getArrayItem(arr, 9);

			if (batch.length() > 0/* && Character.isDigit(batch.charAt(0))*/) {
				//batch = "00" + batch;
				if (batch.length() == 8) {
					batch = "00" + batch;
				}
			}

			RollName rollName = db.rollNameDao().getByFull(name, ozm, width, length, thickness);
			long nameId = rollName != null ? rollName.getId() : db.rollNameDao().insert(new RollName(0, ozm, name, width, length, thickness));

			RollNameInfo rollNameInfo = db.rollNameInfoDao().getByFull(nameId, markdown, mera, travl);
			long nameInfoId = rollNameInfo != null ? rollNameInfo.getId() : db.rollNameInfoDao().insert(new RollNameInfo(0, nameId, markdown, mera, travl));

			return new Roll(
					0,
					nameId,
					nameInfoId,
					Utils.getArrayItem(arr, 0),
					Utils.getArrayItem(arr, 1),
					Utils.getArrayItem(arr, 2),
					ozm,
					name,
					batch,
					Utils.getArrayItem(arr, 6),
					nett,
					thickness,
					width,
					length,
					markdown,
					Utils.getArrayItem(arr, 12),
					Utils.getArrayItem(arr, 13),
					Utils.getArrayItem(arr, 14),
					travl,
					Utils.getArrayItem(arr, 16),
					mera,
					Utils.getArrayItem(arr, 18),
					Utils.getArrayItem(arr, 19),
					Utils.getArrayItem(arr, 20),
					Utils.getArrayItem(arr, 21),
					Utils.getArrayItem(arr, 22),
					Utils.getArrayItem(arr, 23),
					Utils.getArrayItem(arr, 24)
			);

		} catch (Exception e) {
			log(e, "processLine(%s)", line);
			return null;
		}
	}

	private void buttonWeighingClick() {
		if (isLoading() || viewButtons.getVisibility() != View.VISIBLE || !buttonWeighing.isEnabled())
			return;

		Intent intent = new Intent(this, RollOzmActivity.class);
		intent.putExtra("storage", getSelectedStorage());
		startActivity(intent);
	}

	private void endLoad(JsonResult result) {

		hideLoading();
		buttonListLoad.setEnabled(true);
		viewButtons.setVisibility(View.VISIBLE);

		showContent();

		if (!result.isOk()) {
			if (result.getStatus() == LoadResultStatus.H004) {
				showToast(R.string.file_not_found);
			} else {
				showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> buttonLoadClick());
			}
		}
	}

	private void showContent() {

		StringBuilder sb = new StringBuilder();

		if (rollInfo == null) {
			sb.append("Дані за обрану дату відсутні");
		} else {
			sb.append(Utils.format(
					"Дані отримано<br>%s<br>%d рядки",
					app.getDateFormat().format(rollInfo.getRollDate()), rollInfo.getRollCount()
			));
			date = new Date(rollInfo.getRollDate());
			dateSelected = true;
			refreshButtons();
		}

		textContent.setText(app.fromHtml(sb.toString()));

		buttonWeighing.setEnabled(rollInfo != null);
	}
}
