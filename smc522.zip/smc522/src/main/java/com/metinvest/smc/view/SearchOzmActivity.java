package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.annotation.Nullable;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.Utils;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SearchOzmActivity extends MyActivity implements IScan {

    @BindView(R.id.textSearch)
    EditText textSearch;
    @BindView(R.id.textThickness)
    EditText textThickness;
    @BindView(R.id.textWidth)
    EditText textWidth;
    @BindView(R.id.textLength)
    EditText textLength;
    @BindView(R.id.checkFullName)
    CheckBox checkFullName;
    @BindView(R.id.buttonAccept)
    Button buttonSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_ozm);
        ButterKnife.bind(this);
        textSearch.requestFocus();
    }

    public void buttonThicknessClearClick(View view) {
        textThickness.setText(null);
    }

    public void buttonWidthClearClick(View view) {
        textWidth.setText(null);
    }

    public void buttonLengthClearClick(View view) {
        textLength.setText(null);
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 2) textSearch.requestFocus();
        else if (number == 5) buttonSearchClick();
    }

    private void buttonSearchClick() {
        if (isLoading() || !buttonSearch.isEnabled()) return;

        beginSearch();
    }

    @Override
    protected String getHelpContent() {
        return getString(R.string.help_search_ozm);
    }

    private void beginSearch(String ozm) {
        textSearch.setText(ozm);
        beginSearch();
    }

    private void beginSearch() {

        String text = textSearch.getText().toString();
        if (text.trim().length() == 0) {
            showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.ozm_search_text_null_warning, (dialog, which) -> textSearch.requestFocus());
            return;
        }

        float searchWidth = textWidth.getText().toString().isEmpty() ? -1 : Utils.parseFloat(textWidth.getText().toString());
        float searchLength = textLength.getText().toString().isEmpty() ? -1 : Utils.parseFloat(textLength.getText().toString());
        float searchThickness = textThickness.getText().toString().isEmpty() ? -1 : Utils.parseFloat(textThickness.getText().toString());

        showInfoByOzm(text, checkFullName.isChecked(), searchLength, searchWidth, searchThickness);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_DEFAULT && resultCode == RESULT_OK) {
            textSearch.selectAll();
            textSearch.requestFocus();
        }
    }

    private void beginLoadLabel(String labelId) {
        if (isLoading()) return;

        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {
            JsonResult result = net.loadLabelInfo(labelId);
            String ozm = null;
            if (result.isOk()) {
                ozm = Utils.getJsonStringIgnoreCase(Utils.getJsonObject(result.getJson(), "data"), "name");
            }

            String finalOzm = ozm;
            runOnUiThread(() -> endLoadLabel(result, finalOzm));
        });
    }

    private void endLoadLabel(JsonResult result, String ozm) {
        hideLoading();

        beginSearch(ozm);
    }

    @Override
    public void onBarcodeEvent(String barcodeData) {
        if (isLoading()) return;

        runOnUiThread(() -> {

            ScanItem scanItem = new ScanItem(barcodeData);

            if (scanItem.isCorrect()) {
                if (scanItem.getType() == ScanItem.ScanItemType.LABELID) {
                    beginLoadLabel(scanItem.getData(0));
                } else if (scanItem.getType() == ScanItem.ScanItemType.SMC06) {
                    beginSearch(scanItem.getData(2));
                }
            } else {
                showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_barcode_format, null);
            }

        });
    }

}
