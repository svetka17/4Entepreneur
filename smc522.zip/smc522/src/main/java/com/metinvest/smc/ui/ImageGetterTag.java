package com.metinvest.smc.ui;

import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.text.Html;

import com.metinvest.smc.App;

public class ImageGetterTag implements Html.ImageGetter{

    private int drow;

    public ImageGetterTag(int drow) {
        this.drow = drow;
        //this.drow = R.drawable.ic_location_on_black_24dp;
    }

    @Override
    public Drawable getDrawable(String source) {
        BitmapDrawablePlaceHolder drawable = new BitmapDrawablePlaceHolder();
        drawable.setDrawable(App.getInstance().getDrawable(drow));
        return drawable;
    }

    private class BitmapDrawablePlaceHolder extends BitmapDrawable {

        protected Drawable drawable;

        @Override
        public void draw(final Canvas canvas) {
            if (drawable != null) {
                drawable.draw(canvas);
            }
        }

        public void setDrawable(Drawable draw) {
            this.drawable = draw;
            int width = drawable.getIntrinsicWidth();
            int height = drawable.getIntrinsicHeight();
            drawable.setBounds(0, 0, width, height);
            setBounds(0, 0, width, height);
        }
    }
}
