package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.LoadResultStatus;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.IScan;
import com.metinvest.smc.tools.IValue;
import com.metinvest.smc.tools.Label;
import com.metinvest.smc.tools.ScanItem;
import com.metinvest.smc.tools.StoreItem;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.tools.Value;
import com.metinvest.smc.ui.AdapterItemTransfer;
import com.metinvest.smc.ui.AdapterItemTransferGroup;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.IFlexible;

public class TransferLabelManyActivity extends MyActivity implements IScan, AdapterItemTransfer.IItemAction {

	@BindView(R.id.textPrompt)
	TextView textPrompt;
	@BindView(R.id.textContentTitle)
	TextView textContentTitle;
	@BindView(R.id.listView)
	RecyclerView listView;
	@BindView(R.id.scrollView)
	NestedScrollView scrollView;
	@BindView(R.id.buttonAccept)
	Button buttonAccept;
	@BindView(R.id.textLabelId)
	EditText textLabelId;
	@BindView(R.id.viewStorage)
	View viewStorage;
	@BindView(R.id.spinnerStorage)
	Spinner spinnerStorage;

	private FlexibleAdapter<IFlexible> adapter;
	private List<IValue> listStorage;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_transfer_label_many);
		ButterKnife.bind(this);
		refreshTitle();

		viewStorage.setVisibility(View.GONE);
		listView = findViewById(R.id.listView);
		LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
		DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listView.getContext(), layoutManager.getOrientation());
		listView.setLayoutManager(layoutManager);
		listView.addItemDecoration(dividerItemDecoration);
		adapter = new FlexibleAdapter<>(null);
		listView.setAdapter(adapter);
		onItemsChanged();
	}

	private void refreshTitle() {
		textContentTitle.setText(R.string.title_activity_transfer_label_many);
		refreshButtons();
	}

	boolean autoAccept = false;

	@Override
	protected void onPostCreate(@Nullable Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		String labelId = getIntent().getStringExtra("labelId");
		if (labelId != null) {
			autoAccept = true;
			beginLoadLabel(labelId);
		}
	}

	private void onItemsChanged() {
		textPrompt.setVisibility(adapter.getItemCount() > 0 ? View.GONE : View.VISIBLE);
		refreshButtons();

		if (notEmpty() && listStorage == null) {
			beginLoadStorageList();
		}
	}

	private void beginLoadStorageList() {
		showLoading(R.string.text_please_wait);

		Utils.runOnBackground(() -> {
			Network.NetworkResultValue<List<StoreItem>> result = net.loadStorageList(app.getSmcIdCurrent());
			runOnUiThread(() -> endLoadStorageList(result));
		});
	}

	private void endLoadStorageList(Network.NetworkResultValue<List<StoreItem>> result) {
		hideLoading();

		if (result.isOk()) {
			StoreItem storeItem = Utils.getSourceStoreItem(result.getValue());
			if (storeItem == null) {
				showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, R.string.error_data, (dialog, which) -> beginLoadStorageList(), (dialog, which) -> finish());
				return;
			}
			int selectedIndex = 0;
			listStorage = new ArrayList<>();
			listStorage.add(new Value(0, "[Змінити склад]"));
			for (int i = 0; i < storeItem.getStoreList().size(); i++) {
				if (storeItem.getStoreList().get(i).equalsIgnoreCase(config.getStorage()))
					selectedIndex = i;
				listStorage.add(new Value(i + 1, storeItem.getStoreList().get(i)));
			}

			Utils.fillData(spinnerStorage, listStorage);
			spinnerStorage.setSelection(0);
			//spinnerStorage.setSelection(selectedIndex);
		} else {
			showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result.getResult()), (dialog, which) -> beginLoadStorageList(), (dialog, which) -> finish());
		}
	}

	private boolean notEmpty() {
		return adapter != null && adapter.getItemCount() > 0;
	}

	private void refreshButtons() {
		viewStorage.setVisibility(notEmpty() ? View.VISIBLE : View.GONE);
		buttonAccept.setEnabled(notEmpty());
	}

	@Override
	protected void onFunctionKey(int number) {

		if (isLoading()) return;

		if (number == 4 && adapter.getItemCount() > 0) {
			showDialogConfirm(R.string.text_warning, R.string.text_list_clear_prompt, (dialog, which) -> clearItems());
		}
		if (number == 5) {
			beginAccept();
		}
	}

	private void clearItems() {
		adapter.clear();
		onItemsChanged();
	}

	@Override
	public void onBarcodeEvent(String barcodeData) {
		if (isLoading()) return;

		runOnUiThread(() -> {

			ScanItem scanItem = new ScanItem(barcodeData);
			if (!scanItem.isCorrect()) {
				showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.error_identity_label, null);
				return;
			}

			if (scanItem.getType() == ScanItem.ScanItemType.LABELID) {
				String newLabelId = scanItem.getData(0);
				if (!isLabelIdLoaded(newLabelId)) {
					beginLoadLabel(newLabelId);
				} else {
					showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_already_exist, null);
				}
			}

			if (scanItem.getType() == ScanItem.ScanItemType.SMC06) {
				String newLabelId = scanItem.getData(0);
				if (!isLabelIdLoaded(newLabelId)) {
					beginLoadLabel(newLabelId);
				} else {
					showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_already_exist, null);
				}
			}

			if (scanItem.getType() == ScanItem.ScanItemType.SMC05 || scanItem.getType() == ScanItem.ScanItemType.SMC07) {
				processUnknown(scanItem, scanItem.getType() == ScanItem.ScanItemType.SMC07);
			}

		});
	}

	private void processUnknown(ScanItem scanItem, boolean isNew) {

		//int packCount = Utils.parseInt(scanItem.getData(1));

		JSONArray array = Utils.getJsonArray(scanItem.getData(2));
		if (array == null) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_error_scan_item, null);
		} else {

			List<String> listId = new ArrayList<>();

			for (int i = 0; i < array.length(); i++) {
				JSONObject object = Utils.getJsonObject(array, i);
				listId.add(Utils.getJsonStringIgnoreCase(object, "id"));
			}

			if (!listId.isEmpty()) {
				beginLoadLabel(listId.get(0));
			}
		}
	}

	private AdapterItemTransferGroup getGroup(String labelId) {

		for (int i = 0; i < adapter.getItemCount(); i++) {
			IFlexible item = adapter.getItem(i);
			if (item instanceof AdapterItemTransferGroup) {
				AdapterItemTransferGroup group = (AdapterItemTransferGroup) item;
				for (AdapterItemTransfer subItem : group.getSubItems()) {
					if (subItem.getLabelId().equalsIgnoreCase(labelId)) {
						return group;
					}
				}
			}
		}

		return null;
	}

	private boolean isLabelIdLoaded(String labelId) {

		for (int i = 0; i < adapter.getItemCount(); i++) {
			IFlexible item = adapter.getItem(i);
			if (item instanceof AdapterItemTransfer) {
				if (((AdapterItemTransfer) item).getLabelId().equalsIgnoreCase(labelId))
					return true;
			} else if (item instanceof AdapterItemTransferGroup) {
				AdapterItemTransferGroup group = (AdapterItemTransferGroup) item;
				for (AdapterItemTransfer subItem : group.getSubItems()) {
					if (subItem.getLabelId().equalsIgnoreCase(labelId)) return true;
				}
			}
		}

		return false;
	}

	private void beginLoadLabel(String newLabelId) {
		if (isLoading()) return;

		showLoading(R.string.text_please_wait);

		Utils.runOnBackground(() -> {
			String url = config.getUrlApi() + "getlabelinfo";
			url = net.addUrlParam(url, "label_id", newLabelId);
			JsonResult result = net.downloadJson(url);

			List<Label> labelList = new ArrayList<>();
			if (result.isOk()) {
				Label labelBase = Label.fromJson(Utils.getJsonObject(result.getJson(), "data"));
				if (labelBase != null) {
					labelBase.setId(newLabelId);
					if (labelBase.isTheor()) {
						Network.NetworkResultValue<String> resultValue = net.getLocationCodeNet(String.valueOf(labelBase.getLocationId()));
						if (resultValue.isOk()) {
							String locationCode = resultValue.getValue();

							url = config.getUrlApi() + "getlocationinfo2";
							url = net.addUrlParam(url, "location_code", locationCode);
							url = net.addUrlParam(url, "ozm", labelBase.getOzm());
							url = net.addUrlParam(url, "length", String.valueOf(labelBase.getLength()));
							url = net.addUrlParam(url, "width", String.valueOf(labelBase.getWidth()));
							url = net.addUrlParam(url, "thickness", String.valueOf(labelBase.getThickness()));
							url = net.addUrlParam(url, "nett_weight", String.valueOf(labelBase.getWeightNetto()));
							url = net.addUrlParam(url, "teor_weight", "1");

							result = net.downloadJson(url);
							if (result.isOk()) {
								JSONObject jsonData = Utils.getJsonObject(result.getJson(), "data");
								JSONArray array = Utils.getJsonArray(jsonData, "labels");
								if (array != null) {
									for (int i = 0; i < array.length(); i++) {
										//JSONObject item = Utils.getJsonObject(array, i);
										//Label label = Label.fromJson(item);

										String itemLabelId = Utils.getJsonString(array, i);
										if (itemLabelId != null && itemLabelId.length() > 0) {
											Label label = labelBase.copyLabel(itemLabelId);

											if (label != null && label.isTheor()
													&& label.getOzm().equalsIgnoreCase(labelBase.getOzm())
													&& label.getWeightNetto() == labelBase.getWeightNetto()
													&& label.getLength() == labelBase.getLength()
													&& label.getWidth() == labelBase.getWidth()
													&& label.getThickness() == labelBase.getThickness()
											) {
												labelList.add(label);
											}
										}


									}
								}
							}

						} else {
							result = resultValue.getResult();
						}
					} else {
						labelList.add(labelBase);
					}
				}
			}

			JsonResult finalResult = result;
			runOnUiThread(() -> endLoadLabel(newLabelId, finalResult, labelList));
		});
	}

	private void endLoadLabel(String newLabelId, JsonResult result, List<Label> labelList) {
		hideLoading();

		if (result.isOk()) {
			if (labelList.size() > 1) {
				prepareAddTheorLabels(labelList);
			} else {
				addItems(labelList);
				if (autoAccept) beginAccept();
			}
		} else if (result.getStatus() == LoadResultStatus.S007) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_s007, null);
		} else if (result.getStatus() == LoadResultStatus.ZERO) {
			showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.label_id_not_found, null);
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoadLabel(newLabelId));
		}
	}

	private void prepareAddTheorLabels(List<Label> labelList) {
		Intent intent = new Intent(this, TheorCountActivity.class);

		intent.putExtra("maxCount", labelList.size());

		for (int i = 0; i < labelList.size(); i++) {
			intent.putExtra("label" + i, labelList.get(i));
		}

		startActivityForResult(intent, REQUEST_COUNT_SELECT);
	}

	private void addItems(List<Label> labelList) {

		if (labelList.isEmpty()) return;

		if (labelList.size() == 1) {
			if (!isLabelIdLoaded(labelList.get(0).getId())) {
				adapter.addItem(new AdapterItemTransfer(labelList.get(0), false, this));
			}
		} else {
			AdapterItemTransferGroup group = new AdapterItemTransferGroup(labelList.get(0).getName());
			for (Label label : labelList) {
				if (!isLabelIdLoaded(label.getId())) {
					group.addSubItem(new AdapterItemTransfer(label, true, this));
				}
			}
			if (group.getSubItemsCount() > 0) adapter.addItem(group);
		}

		onItemsChanged();
		scrollView.post(() -> scrollView.fullScroll(ScrollView.FOCUS_DOWN));
	}

	@Override
	protected String getHelpContent() {
		return "Створіть лист бірок, які слід перемістити і натисніть «Далі..»\n\n" +
				"Якщо бірка не сканується, то через меню «Інфо по біркам» надрукуйте нову копію.\n" +
				"Для видалення зі списку натисніть на іконку «Смітник».\n\n" +
				"F4 - Повне очищення списку\n\n" +
				"F5 - Почати переміщення";
	}

	private void beginAccept() {
		if (isLoading()) return;

		if (adapter != null && adapter.getItemCount() == 0) return;

		Intent intent = new Intent(this, LocationSelectActivity.class);
		startActivityForResult(intent, REQUEST_LOCATION_SELECT);
	}

	private String getSelectedStorage() {
		int pos = spinnerStorage.getSelectedItemPosition();
		return pos > 0 ? listStorage.get(pos).getName() : null;
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == REQUEST_LOCATION_SELECT && resultCode == RESULT_OK && data != null) {
			String locationCode = data.getStringExtra("locationCode");
			String storage = getSelectedStorage();

			if (!checkLocationPermit(locationCode)) return;
			beginTransfer(locationCode, storage);
		}

		if (requestCode == REQUEST_COUNT_SELECT && resultCode == RESULT_OK && data != null) {
			log("REQUEST_COUNT_SELECT OK");

			int count = data.getIntExtra("count", 0);
			int maxCount = data.getIntExtra("maxCount", 0);
			List<Label> labelList = new ArrayList<>(maxCount);

			for (int i = 0; i < count; i++) {
				Serializable item = data.getSerializableExtra("label" + i);
				if (item instanceof Label) labelList.add((Label) item);
			}

			addItems(labelList);
			if (autoAccept) beginAccept();
		}
	}

	private List<AdapterItemTransfer> getAllItems() {
		List<AdapterItemTransfer> list = new ArrayList<>();

		for (int i = 0; i < adapter.getItemCount(); i++) {
			IFlexible item = adapter.getItem(i);
			if (item instanceof AdapterItemTransfer) {
				list.add((AdapterItemTransfer) item);
			} else if (item instanceof AdapterItemTransferGroup) {
				//TODO
				List<AdapterItemTransfer> itemsList = ((AdapterItemTransferGroup) item).getSubItems();
				list.addAll(itemsList);
			}
		}

		return list;
	}

	private void beginTransfer(String locationCode, String storage) {
		if (isLoading()) return;

		showLoading(R.string.text_please_wait);
		buttonAccept.setEnabled(false);

		Utils.runOnBackground(() -> {

			StringBuilder sb = new StringBuilder();
			sb.append("[");

			List<AdapterItemTransfer> items = getAllItems();

			for (int i = 0; i < items.size(); i++) {
				AdapterItemTransfer itemTransfer = items.get(i);
				sb.append(Utils.format(
						"{\"Label_Id\":%s,\n" +
								"\t \"Location_Code\":\"%s\",\n" +
								"%s" +
								"\t \"Date_FV\":\"%s\"\t}",
						itemTransfer.getLabelId(),
						locationCode,
						(storage == null ? "" : Utils.format("\t \"LGORT\":\"%s\",\n", storage)),
						app.getDateTimeFormat().format(Calendar.getInstance().getTime())
				));
				if (i < items.size() - 1) sb.append(",");
			}
			sb.append("]");

			String url = config.getUrlApi() + "sapchangelocation";
			JsonResult result = net.uploadJson(url, sb.toString());

			runOnUiThread(() -> endTransfer(locationCode, storage, result));

		});
	}

	private void endTransfer(String locationCode, String storage, JsonResult result) {
		hideLoading();
		buttonAccept.setEnabled(true);
		if (result.isOk()) {
			showToast(getString(R.string.label_transfer_complete, locationCode));
			finish();
		} else {
			showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_warning, getString(R.string.label_transfer_error, result.getStatus().name()), (dialog, which) -> beginTransfer(locationCode, storage));
		}
	}

	@Override
	public void onDeleteClick(String labelId) {
		showDialogConfirm(R.string.text_confirm, R.string.delete_position_confirm, (dialog, which) -> {

			List<IFlexible> list = adapter.getCurrentItems();

			IFlexible foundItem = null;

			for (IFlexible item : list) {
				if (item instanceof AdapterItemTransfer && ((AdapterItemTransfer) item).getLabelId().equalsIgnoreCase(labelId)) {
					foundItem = item;
					break;
				}
			}

			if (foundItem != null) {
				AdapterItemTransferGroup group = getGroup(labelId);
				if (group != null) {
					for (AdapterItemTransfer subItem : group.getSubItems()) {
						if (subItem.getLabelId().equalsIgnoreCase(labelId)) {
							group.removeSubItem(subItem);
							break;
						}
					}
				}

				int posId = adapter.getGlobalPositionOf(foundItem);
				if (posId != -1) {
					adapter.removeItem(posId);
				}

				if (group != null) {
					if (group.getSubItemsCount() > 0) {
						adapter.updateItem(group);
					} else {
						posId = adapter.getGlobalPositionOf(group);
						if (posId != -1) adapter.removeItem(posId);
					}
				}
			}

			onItemsChanged();
		});
	}

	public void buttonLabelAdd(View view) {
		String labelId = textLabelId.getText().toString();
		if (labelId.length() > 0)
			beginLoadLabel(labelId);
	}
}
