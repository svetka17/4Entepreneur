package com.metinvest.smc.tools;

public interface IValue {
    long getId();

    String getName();
}
