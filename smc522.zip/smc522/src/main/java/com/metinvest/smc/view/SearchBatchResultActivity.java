package com.metinvest.smc.view;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.Location;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterSimple;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class SearchBatchResultActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.textNotFound)
    TextView textNotFound;

    private FlexibleAdapter<AdapterSimple> adapter;
    private String text;
    private ArrayList<Location> locationList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_ozm_result);
        ButterKnife.bind(this);

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        textNotFound.setVisibility(View.GONE);
        listView.setVisibility(View.GONE);

        text = getIntent().getStringExtra("text");
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        beginSearch();
    }

    private void beginSearch() {

        showLoading(R.string.text_please_wait);
        textNotFound.setVisibility(View.GONE);
        listView.setVisibility(View.GONE);

        Utils.runOnBackground(() -> {
            locationList = new ArrayList<>();

            String url = config.getUrlApi() + "getbatchinfo";
            url = net.addUrlParam(url, "sap_batch", text);

            JsonResult result = net.downloadJson(url);
            List<AdapterSimple> list = new ArrayList<>();

            if (result.isOk()) {
                JSONArray array = Utils.getJsonArray(result.getJson(), "data");
                if (array != null) {
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject json = Utils.getJsonObject(array, i);
                        if (json != null) {
                            String location = Utils.getJsonStringIgnoreCase(json, "location_Code");
                            int nett = (int) Utils.getJsonFloatIgnoreCase(json, "netT_Weight");
                            addLocation(location, nett);
                        }
                    }
                }

                Collections.sort(locationList, (o1, o2) -> Utils.compareLocations(o1.code, o2.code));

                for (int i = 0; i < locationList.size(); i++) {
                    float w = locationList.get(i).weight / 1000.0f;
                    String content = Utils.format("Загальна вага тн.: <b>%.3f</b>", w < 0 ? 0 : w);
                    AdapterSimple item = new AdapterSimple(String.valueOf(i), locationList.get(i).code, content);
                    list.add(item);
                }
            }

            runOnUiThread(() -> endSearch(result, list));
        });
    }

    private int getLocationIndex(String location) {
        for (int i = 0; i < locationList.size(); i++) {
            if (locationList.get(i).code.equalsIgnoreCase(location)) {
                return i;
            }
        }
        return -1;
    }

    private void addLocation(String location, int weight) {

        int index = getLocationIndex(location);

        if (index == -1) {
            locationList.add(new Location(location, weight));
        } else {
            locationList.get(index).weight += weight;
        }
    }

    private void endSearch(JsonResult result, List<AdapterSimple> list) {
        hideLoading();

        if (result.isOk()) {

            if (list.isEmpty()) textNotFound.setVisibility(View.VISIBLE);
            if (!list.isEmpty()) listView.setVisibility(View.VISIBLE);

            adapter = new FlexibleAdapter<>(list);
            adapter.addListener(this);
            listView.setAdapter(adapter);
            listView.requestFocus();
            scrollView.post(() -> scrollView.scrollTo(0, 0));

        } else {
            textNotFound.setVisibility(View.VISIBLE);
            showDialogRetry(R.drawable.ic_warning_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginSearch());
        }
    }

    @Override
    public boolean onItemClick(View view, int position) {
        AdapterSimple item = adapter.getItem(position);
        if (item != null) {
            int id = Utils.parseInt(item.getId());
            Location location = locationList.get(id);
            showInfoByLocationCodeBatch(text, location.code);
            return true;
        }
        return false;
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        super.onBackPressed();
    }
}
