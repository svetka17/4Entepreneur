package com.metinvest.smc.view;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.metinvest.smc.R;
import com.metinvest.smc.db.Carrier;
import com.metinvest.smc.db.NameStore;
import com.metinvest.smc.db.OnTheWay;
import com.metinvest.smc.db.Printed;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.tools.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ComingListLoadActivity extends MyActivity {

    @BindView(R.id.buttonListLoad)
    View buttonListLoad;
    @BindView(R.id.buttonDateFrom)
    Button buttonDateFrom;
    @BindView(R.id.buttonDateTo)
    Button buttonDateTo;
    @BindView(R.id.textContent)
    TextView textContent;
    @BindView(R.id.viewButtonWeighting)
    View viewButtonWeighting;

    private Date dateFrom, dateTo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coming_list_load);
        ButterKnife.bind(this);

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(Calendar.getInstance().getTime());
        calendar.add(Calendar.DATE, -13);

        dateFrom = config.getComingListPeriodFrom() == null ? calendar.getTime() : config.getComingListPeriodFrom();
        dateTo = config.getComingListPeriodTo() == null ? Calendar.getInstance().getTime() : config.getComingListPeriodTo();

        textContent.setVisibility(View.GONE);

        refreshDateButtons();
        refreshButtons();
    }

    @Override
    protected void onFunctionKey(int number) {
        switch (number) {
            case 2:
                buttonDateFrom.performClick();
                break;
            case 3:
                buttonDateTo.performClick();
                break;
            case 4:
                buttonWeightingClick();
                break;
            case 5:
                if (buttonListLoad.isEnabled()) prepareLoad();
                break;
            /*case 5:
                if (buttonListView.isEnabled()) beginView();
                break;*/
        }
    }

    private void buttonWeightingClick() {
        if (viewButtonWeighting.getVisibility() != View.VISIBLE) return;

        setResult(RESULT_OK);
        finish();
    }

    private void prepareLoad() {

        if (db.printedDao().getCountNew() > 0) {
            showDialogConfirm(R.string.text_warning, "Ви не відправили дані з попереднього зважування. Ви дійсно бажаєте відмінити попередні результати зважування та завантажити новий список?", (dialog, which) -> beginLoad());
        } else {
            beginLoad();
        }

    }

    private void beginView() {
        startActivity(new Intent(this, ComingListActivity.class));
    }

    private void beginLoad() {

        textContent.setVisibility(View.GONE);
        viewButtonWeighting.setVisibility(View.GONE);
        buttonListLoad.setEnabled(false);
        refreshButtons();
        showLoading(R.string.text_please_wait);

        Utils.runOnBackground(() -> {
            db.carrierDao().truncate();
            db.onTheWayDao().truncate();
            db.nameStoreDao().truncate();
            db.printedDao().truncate();
            db.weighingDao().truncate();
            config.setComingListPeriodFrom(null);
            config.setComingListPeriodTo(null);
            config.saveConfig();
            runOnUiThread(this::refreshButtons);

            String url = config.getUrlApi() + "markinglist";

            url = net.addUrlParam(url, "from", app.getDateFormat().format(dateFrom));
            url = net.addUrlParam(url, "to", app.getDateFormat().format(dateTo));

            JsonResult result = net.downloadJson(url);
            runOnUiThread(() -> endLoad(result));
        });
    }

    private void refreshDateButtons() {
        buttonDateFrom.setText(app.getDateFormat().format(dateFrom));
        buttonDateTo.setText(app.getDateFormat().format(dateTo));
    }

    private void endLoad(JsonResult result) {

        runOnUiThread(() -> buttonListLoad.setEnabled(true));
        hideLoading();

        if (result.isOk()) {

            JSONObject data = Utils.getJsonObject(result.getJson(), "data");
            final JSONArray list = Utils.getJsonArray(data, "markinglist");

            if (list != null && list.length() > 0) {
                beginSave(list);
            } else {
                runOnUiThread(() -> showDialog(R.drawable.ic_warning_24dp, R.string.text_warning, R.string.text_load_coming_list_empty, (dialog, which) -> buttonListLoad.setEnabled(true)));
            }

        } else {

            runOnUiThread(() -> showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, getString(R.string.text_load_coming_list_error, result.getStatus()), (dialog, which) -> beginLoad()));
        }
    }

    private void beginSave(final JSONArray list) {

        config.setComingListPeriodFrom(dateFrom);
        config.setComingListPeriodTo(dateTo);
        config.saveConfig();

        for (int i = 0; i < list.length(); i++) {
            try {
                JSONObject item = list.getJSONObject(i);

                int wayId = Utils.getJsonIntIgnoreCase(item, "ID");
                String carrierName = Utils.getJsonStringIgnoreCase(item, "TTN_Carier_ID");
                String ozm = Utils.getJsonStringIgnoreCase(item, "SAP_OZM");
                String name = Utils.getJsonStringIgnoreCase(item, "sap_matt_descr");
                float width = Utils.getJsonFloatIgnoreCase(item, "width");
                float length = Utils.getJsonFloatIgnoreCase(item, "length");
                float thickness = Utils.getJsonFloatIgnoreCase(item, "thickness");
                int sapWeightNett = Utils.getJsonWeightKgIgnoreCase(item, "SAP_Weight_NETT");

                Carrier carrier = db.carrierDao().getByName(carrierName);
                long carrierId = carrier != null ? carrier.getId() : db.carrierDao().insert(new Carrier(0, carrierName));

                NameStore nameStore = db.nameStoreDao().getByFull(name, ozm, width, length, thickness);
                long nameId = nameStore != null ? nameStore.getId() : db.nameStoreDao().insert(new NameStore(
                        0, ozm, name, width, length, thickness
                ));

                //
                int weightAccepted = 0;

                JSONArray labelList = Utils.getJsonArray(item, "labelList");
                if (labelList != null && labelList.length() > 0) {
                    for (int j = 0; j < labelList.length(); j++) {

                        try {
                            JSONObject labelItem = Utils.getJsonObject(labelList, j);
                            long labelId = Utils.getJsonIntIgnoreCase(labelItem, "label_Id");
                            int labelWeightNett = Utils.getJsonIntIgnoreCase(labelItem, "netto_Weight");
							int labelWeightPack = Utils.getJsonIntIgnoreCase(labelItem, "pack_Weight");
							int labelWeightTara = Utils.getJsonIntIgnoreCase(labelItem, "tara_Weight");
							String plavka = Utils.getJsonStringIgnoreCase(labelItem, "plavka");

							db.printedDao().insert(new Printed(
									labelId, wayId, labelWeightNett, labelWeightPack, labelWeightTara, name, ozm, 0, true, null, false, 0, 0, false, plavka
							));

							weightAccepted += labelWeightNett;

						} catch (Exception e) {
							log(e, "beginSave(%s)", list);
						}
                    }
                }
                //


                db.onTheWayDao().insert(new OnTheWay(
                        wayId,
                        //--
                        config.getStorage()/*Utils.getJsonStringIgnoreCase(item, "lgort")*/,
                        //--
                        Utils.getJsonStringIgnoreCase(item, "line_id"),
                        Utils.getJsonStringIgnoreCase(item, "SAP_BATCH"),
                        sapWeightNett,
                        Utils.getJsonStringIgnoreCase(item, "SAP_ID1"),
                        Utils.getJsonStringIgnoreCase(item, "SAP_ID2"),
                        Utils.getJsonStringIgnoreCase(item, "TTN_Num"),
                        carrierName,
                        Utils.getJsonStringIgnoreCase(item, "TTN_Date"),
                        Utils.getJsonStringIgnoreCase(item, "SMC_ID"),
                        Utils.getJsonStringIgnoreCase(item, "DateUpload"),
						Utils.getJsonStringIgnoreCase(item, "DateArrive"),
						nameId, carrierId,
						weightAccepted,
						sapWeightNett == weightAccepted,
						0
				));
				//}

			} catch (Exception e) {
				log(e, "beginSave(#%s)", i);
			}
        }

        runOnUiThread(this::endSave);

    }

    @Override
    protected String getHelpContent() {
        return "Вкажіть дати і нитсніть F4 для зкачування списку приходування OnTheWay";
    }

    private void refreshButtons() {
        //buttonListView.setEnabled(config.isComingListLoaded());
        viewButtonWeighting.setVisibility(config.isComingListLoaded() ? View.VISIBLE : View.GONE);
        if (config.isComingListLoaded()) viewButtonWeighting.requestFocus();
    }

    private void endSave() {

        String content = Utils.format(
                "Лист скачано: %s%nКількість рядків: %d",
                app.getDateFormat().format(Calendar.getInstance().getTime()), db.onTheWayDao().count()
        );

        textContent.setVisibility(View.VISIBLE);
        textContent.setText(content);
        refreshButtons();
        /*showDialog(R.drawable.ic_info_24dp, R.string.text_information, getString(R.string.text_load_coming_list_ok, db.onTheWayDao().count()), (dialog, which) -> {

        });*/
    }

    public void buttonDateFromClick(View view) {
        Calendar calendar = Utils.toCalendar(dateFrom);

        DatePickerDialog dialog = new DatePickerDialog(this,
                (view1, year, month, dayOfMonth) -> {
                    Calendar calendar1 = Calendar.getInstance();
                    calendar1.set(year, month, dayOfMonth);
                    dateFrom = calendar1.getTime();
                    refreshDateButtons();
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DATE));
        dialog.show();
    }

    public void buttonDateToClick(View view) {
        Calendar calendar = Utils.toCalendar(dateTo);

        DatePickerDialog dialog = new DatePickerDialog(this,
                (view1, year, month, dayOfMonth) -> {
                    Calendar calendar1 = Calendar.getInstance();
                    calendar1.set(year, month, dayOfMonth);
                    dateTo = calendar1.getTime();
                    refreshDateButtons();
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DATE));
        dialog.show();
    }

}
