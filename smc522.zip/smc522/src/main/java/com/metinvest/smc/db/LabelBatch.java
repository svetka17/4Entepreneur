package com.metinvest.smc.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.metinvest.smc.tools.Utils;

@Entity
public class LabelBatch {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private String labelid;
    private String batch;

    public LabelBatch() {
    }

    @Ignore
    public LabelBatch(long id, String labelId, String batch) {
        this.id = id;
        this.labelid = labelId;
        this.batch = batch;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getLabelid() {
        return labelid;
    }

    public void setLabelid(String labelid) {
        this.labelid = labelid;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    @NonNull
    @Override
    public String toString() {
        return Utils.format("[%d] %s %s", id, labelid, batch);
    }
}
