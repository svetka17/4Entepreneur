package com.metinvest.smc.ui;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.metinvest.smc.App;
import com.metinvest.smc.R;
import com.metinvest.smc.tools.Utils;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;
import eu.davidea.flexibleadapter.items.AbstractFlexibleItem;
import eu.davidea.flexibleadapter.items.IFlexible;
import eu.davidea.viewholders.FlexibleViewHolder;

public class AdapterItemPack extends AbstractFlexibleItem<AdapterItemPack.AdapterItemPackViewHolder> {

	public interface Listener {
		void onItemNettoTextChanged(int index);

		void onItemPackTextChanged(int index);

		void onItemCalcClicked(int index);

		void onItemDeleteClicked(int index);
	}

	@NonNull
	@Override
	public String toString() {
		return Utils.format("[%d] %d %d %d", index, w1, w2, w3);
	}

	private final Listener listener;
	private String title;
	private int w1, w2, w3, w0;
	private int index;
	private String labelId, idQr;
	private String smcId;
	private String batch;
	private String scanLabelId;
	private String barcode;
	private boolean listenerEnabled = true;
	private boolean nettoOnly;
	private boolean isRecalcNetto = false;

	public boolean isNettoOnly() {
		return nettoOnly;
	}

	public void setNettoOnly(boolean nettoOnly) {
		this.nettoOnly = nettoOnly;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public String getScanLabelId() {
		return scanLabelId;
	}

	public void setScanLabelId(String scanLabelId) {
		this.scanLabelId = scanLabelId;
	}

	public String getBatch() {
		return batch;
	}

	public void setBatch(String batch) {
		this.batch = batch;
	}

	public void setSmcId(String smcId) {
		this.smcId = smcId;
	}

	public String getSmcId() {
		return smcId;
	}

	public boolean isListenerEnabled() {
		return listenerEnabled;
	}

	public void setListenerEnabled(boolean listenerEnabled) {
		this.listenerEnabled = listenerEnabled;
	}

	public AdapterItemPack(int index, String title, int w1, int w2, int w3, Listener listener, boolean isRecalc) {
		this(index, title, w1, w2, w3, "", "", "", "", listener);
		this.isRecalcNetto = isRecalc;
	}

	public AdapterItemPack(int index, String title, int w1, int w2, int w3, Listener listener) {
		this(index, title, w1, w2, w3, "", "", "", "", listener);
	}

	public AdapterItemPack(int index, String title, int w1, int w2, int w3, String labelId, String idQr, String batch, String scanLabelId, Listener listener) {
		this.index = index;
		this.title = title;
		this.w1 = w1;
		this.w2 = w2;
		this.w3 = w3;
		this.labelId = labelId;
		this.idQr = idQr;
		this.batch = batch;
		this.scanLabelId = scanLabelId;
		this.listener = listener;
		this.nettoOnly = true; //false;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getIndex() {
		return index;
	}

	@Override
	public boolean equals(Object o) {
		return o instanceof AdapterItemPack && ((AdapterItemPack) o).getIndex() == getIndex();
	}

	public String getIdQr() {
		return idQr;
	}

	public void setIdQr(String idQr) {
		this.idQr = idQr;
	}

	public String getLabelId() {
		return labelId;
	}

	public void setLabelId(String labelId) {
		this.labelId = labelId;
	}

	public int getW1() {
		return w1;
	}

	public int getW2() {
		return w2;
	}

	public int getW3() {
		return w3;
	}


	public void setW1(int w1) {
		this.w1 = w1;
	}

	public void setW2(int w2) {
		this.w2 = w2;
	}

	public void setW3(int w3) {
		this.w3 = w3;
	}

	public void setW0(int w0) {
		isRecalcNetto = true;
		this.w0 = w0;
		setW1(w0);
	}

	@Override
	public AdapterItemPackViewHolder createViewHolder(View view, FlexibleAdapter<IFlexible> adapter) {
		return new AdapterItemPackViewHolder(view, adapter);
	}

	@Override
	public void unbindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemPackViewHolder holder, int position) {

		if (holder.textW1.getTag() instanceof TextWatcher) {
			holder.textW1.removeTextChangedListener((TextWatcher) holder.textW1.getTag());
		}
		if (holder.textW2.getTag() instanceof TextWatcher) {
			holder.textW2.removeTextChangedListener((TextWatcher) holder.textW2.getTag());
		}
		if (holder.textW3.getTag() instanceof TextWatcher) {
			holder.textW3.removeTextChangedListener((TextWatcher) holder.textW3.getTag());
		}

		super.unbindViewHolder(adapter, holder, position);
	}

	@Override
	public void bindViewHolder(FlexibleAdapter<IFlexible> adapter, AdapterItemPackViewHolder holder, int position, List<Object> payloads) {

		AdapterItemPack itemPack = null;
		IFlexible item = adapter.getItem(position);
		if (item instanceof AdapterItemPack) {
			itemPack = (AdapterItemPack) item;
		}

		if (itemPack == null) return;

		AdapterItemPack finalItemPack = itemPack;

		StringBuilder sb = new StringBuilder();
		sb.append(title);

		holder.textContent.setText(App.getInstance().fromHtml(sb.toString()));
		holder.textIdQr.setVisibility(itemPack.getLabelId().length() > 0 || itemPack.getIdQr().length() > 0 ? View.VISIBLE : View.GONE);
		if (itemPack.getIdQr().length() > 0) {
			//holder.textIdQr.setText(Utils.format("%s", getIdQr()));
			holder.textIdQr.setText("IDQR");
		} else if (getLabelId().length() > 0) {
			holder.textIdQr.setText(Utils.format("LabelId #%s", itemPack.getLabelId()));
		}

		holder.textW1.setText(String.valueOf(itemPack.getW1()));
		holder.textW2.setText(String.valueOf(itemPack.getW2()));
		holder.textW3.setText(String.valueOf(itemPack.getW3()));

		if(isRecalcNetto)
			holder.textW1.setEnabled(false);

		TextWatcher tw1 = new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				finalItemPack.setW1(Utils.parseInt(s.toString()));
				refreshButtons(holder);
				if (listener != null && isListenerEnabled())
					listener.onItemNettoTextChanged(finalItemPack.getIndex());
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		};
		TextWatcher tw2 = new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				finalItemPack.setW2(Utils.parseInt(s.toString()));
				refreshW1(holder);
				refreshButtons(holder);
				if (listener != null && isListenerEnabled())
					listener.onItemPackTextChanged(finalItemPack.getIndex());
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		};
		TextWatcher tw3 = new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				finalItemPack.setW3(Utils.parseInt(s.toString()));
				refreshW1(holder);
				refreshButtons(holder);
				if (listener != null && isListenerEnabled())
					listener.onItemPackTextChanged(finalItemPack.getIndex());
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		};

		holder.textW1.setTag(tw1);
		holder.textW2.setTag(tw2);
		holder.textW3.setTag(tw3);

		/*holder.textW1.setEnabled(nettoOnly);
		holder.textW2.setEnabled(nettoOnly);
		holder.textW3.setEnabled(nettoOnly);*/
		holder.textW1.setEnabled(true);
		holder.textW2.setEnabled(true);
		holder.textW3.setEnabled(true);

		holder.textW1.addTextChangedListener(tw1);
		holder.textW2.addTextChangedListener(tw2);
		holder.textW3.addTextChangedListener(tw3);

		holder.buttonCalc.setOnClickListener(null);
		holder.buttonDelete.setOnClickListener(null);

		holder.viewButtons.setVisibility(listener != null ? View.VISIBLE : View.GONE);

		if (listener != null) {
			holder.buttonCalc.setOnClickListener(v -> listener.onItemCalcClicked((finalItemPack).getIndex()));
			holder.buttonDelete.setOnClickListener(v -> listener.onItemDeleteClicked((finalItemPack).getIndex()));
		}

		refreshButtons(holder);
	}

	private void refreshW1(AdapterItemPackViewHolder holder) {
		if(isRecalcNetto) {
			int w = w0 - w2 - w3;
			holder.textW1.setText(String.valueOf(w));
		}
	}

	private void refreshButtons(AdapterItemPackViewHolder holder) {
		holder.buttonDelete.setEnabled(!isEmpty());
		if (isEmpty()) {
			holder.buttonDelete.setBackground(ContextCompat.getDrawable(holder.itemView.getContext(), R.drawable.image_button_disabled));
		} else {
			holder.buttonDelete.setBackground(ContextCompat.getDrawable(holder.itemView.getContext(), R.drawable.button_enabled));
		}
	}

	public boolean isEmpty() {
		//return w1 == 0 && w2 == 0 && w3 == 0 && labelId.length() == 0 && idQr.length() == 0;
		return w1 == 0 /*&& w2 == 0 && w3 == 0*/ && labelId.length() == 0 && idQr.length() == 0;
	}

	@Override
	public int getLayoutRes() {
		return R.layout.adapter_in2_row;
	}

	static class AdapterItemPackViewHolder extends FlexibleViewHolder {

		@BindView(R.id.textContent)
		TextView textContent;
		@BindView(R.id.textIdQr)
		TextView textIdQr;
		@BindView(R.id.textW1)
		EditText textW1;
		@BindView(R.id.textW2)
		EditText textW2;
		@BindView(R.id.textW3)
		EditText textW3;
		@BindView(R.id.viewButtons)
		View viewButtons;
		@BindView(R.id.buttonCalc)
		ImageButton buttonCalc;
		@BindView(R.id.buttonDelete)
		ImageButton buttonDelete;

		AdapterItemPackViewHolder(View view, FlexibleAdapter adapter) {
			super(view, adapter);
			ButterKnife.bind(this, view);
		}
	}
}
