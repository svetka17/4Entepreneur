package com.metinvest.smc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.metinvest.smc.R;
import com.metinvest.smc.net.JsonResult;
import com.metinvest.smc.net.Network;
import com.metinvest.smc.tools.Utils;
import com.metinvest.smc.ui.AdapterSimpleCheck;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import eu.davidea.flexibleadapter.FlexibleAdapter;

public class ShipmentLabelListActivity extends MyActivity implements FlexibleAdapter.OnItemClickListener {

    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.listView)
    RecyclerView listView;
    @BindView(R.id.textNotFound)
    TextView textNotFound;
    @BindView(R.id.buttonAccept)
    Button buttonAccept;

    private FlexibleAdapter<AdapterSimpleCheck> adapter;

    private String locationId, locationCode;
    private int netto;
    private String labelId, ozm;
    private float length, width, thickness;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shipment_label_list);
        ButterKnife.bind(this);

        listView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        /*locationCode = getIntent().getStringExtra("locationCode");
        netto = getIntent().getIntExtra("netto", 0);
        ozm = getIntent().getStringExtra("ozm");
        length = getIntent().getFloatExtra("length", 0);
        width = getIntent().getFloatExtra("width", 0);
        thickness = getIntent().getFloatExtra("thickness", 0);
        labelIdList = new ArrayList<>(getIntent().getStringArrayListExtra("labelIdList"));
        theor = getIntent().getBooleanExtra("theor", false);
        theorId = getIntent().getStringExtra("id");*/

        labelId = getIntent().getStringExtra("labelId");
        locationId = getIntent().getStringExtra("locationId");
        netto = getIntent().getIntExtra("netto", 0);
        ozm = getIntent().getStringExtra("ozm");
        length = getIntent().getFloatExtra("length", 0);
        width = getIntent().getFloatExtra("width", 0);
        thickness = getIntent().getFloatExtra("thickness", 0);

        beginLoad();
    }

    private void beginLoad() {
        if (isLoading()) return;

        showLoading(R.string.text_please_wait);
        buttonAccept.setEnabled(false);

        Utils.runOnBackground(() -> {

            List<AdapterSimpleCheck> list = new ArrayList<>();
            JsonResult result = null;

            Network.NetworkResultValue<String> resultValue = net.getLocationCodeNet(locationId);
            if (resultValue.isOk()) {

                locationCode = resultValue.getValue();

                String url = config.getUrlApi() + "getlocationinfo2";
                url = net.addUrlParam(url, "location_code", locationCode);
                url = net.addUrlParam(url, "ozm", ozm);
                url = net.addUrlParam(url, "length", length);
                url = net.addUrlParam(url, "width", width);
                url = net.addUrlParam(url, "thickness", thickness);
                url = net.addUrlParam(url, "nett_weight", netto);
                url = net.addUrlParam(url, "teor_weight", "1");

                result = net.downloadJson(url);

                if (result.isOk()) {
                    JSONObject json = Utils.getJsonObject(result.getJson(), "data");

                    if (json != null) {
                        JSONArray labels = Utils.getJsonArray(json, "labels");

                        if (labels != null && labels.length() > 0) {
                            for (int i = 0; i < labels.length(); i++) {

                                JSONObject jsonObject = Utils.getJsonObject(labels, i);
                                String id = Utils.getJsonStringIgnoreCase(jsonObject, "id");
                                String labelBatch = Utils.getJsonStringIgnoreCase(jsonObject, "saP_Batch");
                                boolean labelTheor = Utils.getJsonStringIgnoreCase(jsonObject, "teoR_Weight").equalsIgnoreCase("true");

                                if (!labelBatch.equalsIgnoreCase("TEMP") && labelTheor
                                ) {
                                    String title = Utils.format("LabelId: %s", id);
                                    String content = Utils.format("Партія: %s", labelBatch);

                                    list.add(new AdapterSimpleCheck(
                                            id, title, content, false
                                    ));
                                }
                            }
                        }
                    }
                }

                Collections.sort(list, (o1, o2) -> o1.getId().compareTo(o2.getId()));
            } else {
                result = resultValue.getResult();
            }

            JsonResult finalResult = result;
            runOnUiThread(() -> endLoad(finalResult, list));

        });
    }

    private void endLoad(JsonResult result, List<AdapterSimpleCheck> list) {
        hideLoading();

        textNotFound.setVisibility(!result.isOk() || list.isEmpty() ? View.VISIBLE : View.GONE);

        if (result.isOk()) {
            adapter = new FlexibleAdapter<>(list);
            adapter.addListener(this);
            listView.setAdapter(adapter);
            scrollView.post(() -> scrollView.scrollTo(0, 0));
            refreshButtonAccept();
        } else {
            showDialogRetry(R.drawable.ic_error_24dp, R.string.text_error, app.getNetworkErrorMessage(result), (dialog, which) -> beginLoad());
        }
    }

    @Override
    public boolean onItemClick(View view, int position) {
        AdapterSimpleCheck item = adapter.getItem(position);
        if (item != null) {
            item.setChecked(!item.isChecked());
            adapter.notifyItemChanged(position);
            refreshButtonAccept();
            return true;
        }
        return false;
    }

    @Override
    protected void onFunctionKey(int number) {
        if (number == 5) {
            buttonAcceptClick();
        }
    }

    private int getCheckedCount() {
        int c = 0;
        if (adapter != null) {
            List<AdapterSimpleCheck> list = adapter.getCurrentItems();
            for (AdapterSimpleCheck item : list) {
                if (item.isChecked()) c++;
            }
        }
        return c;
    }

    private void refreshButtonAccept() {
        buttonAccept.setEnabled(getCheckedCount() == 1);
    }

    private void buttonAcceptClick() {
        if (isLoading() || !buttonAccept.isEnabled()) return;

        ArrayList<String> listOut = new ArrayList<>();
        List<AdapterSimpleCheck> list = adapter.getCurrentItems();
        for (AdapterSimpleCheck item : list) {
            if (item.isChecked()) {
                listOut.add(item.getId());
                break;
            }
        }

        Intent data = new Intent();
        //data.putStringArrayListExtra("labelIdList", listOut);
        data.putExtra("labelId", listOut.get(0));
        data.putExtra("netto", netto);
        setResult(RESULT_OK, data);
        finish();
    }
}
